Name: John Doe
SID: 111-111-111
Email: student@ucla.edu

NOTE: My calculator performs a bit differently than the demo page in that
      it handles all errors (including divide by zero errors) as
      "expression = Undefined". Also it returns "Invalid input expression"
      for any input that includes double negatives (e.g. "--4") or has
      values that start with a zero (e.g. "5+01234").
