CS143
Name: Angel Darquea
SID: 003512936
Email: angeldarquea@ucla.edu

Enhancements:
- Calculator accepts first numbers of expression that start
with a '.'. e.g. ".45+32"
- Expressions with one operand and ending with an operator are invalid 
expressions. e.g. "453-"
- 



