Cody Prestwood
sid: 303596543
Project 1A

The calculator project is a combination of html and php languages.
To use the calculator, open a browser and supply URL:
http://192.168.162.128/~cs143/calculator.php
The calculator only accepts numbers and +,-,* and / operators are allowed in the expression.

I completed the project without a partner. I used the websites
http://www.ibm.com/developerworks/library/os-php-regex1/index.html
http://us.php.net/manual/en/
and my CS35L class notes to complete the assignment.
Also the discussion was equally helpful.
