Tanya Gillis
903463696
turtletsg@gmail.com

Notes: 

Only numbers and +,-,* and / operators are allowed in the expression. 
The calculator does not support parentheses. 