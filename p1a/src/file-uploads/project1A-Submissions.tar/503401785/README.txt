Name: Mary Qi
SID: 503401785
E-mail: maryqi@ucla.edu

Although the spec states that it should handle errors gracefully, I
wasn't sure what type of error would be calculated for. Since it was
stated in lecture that we don't need to worry about negatives,
division by zero, etc, the only error that my calculator.php checks
for is the input of alphabets into the text field.