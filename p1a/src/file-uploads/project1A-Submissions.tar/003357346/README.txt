Albert Hsieh 003357346 alhsieh@ucla.edu
Bryan Chen 603506391 bryanchen@ucla.edu

We worked on the project together via pair programming.
