Readme:
Matt Ross
mattross@ucla.edu
703373258

This project proved more difficult than expected for me.
Just getting everything installed and becoming familiar
with all the new software and coding practices took
a great deal of time and effort.  I also ran into problems
coding in PHP.  I found it difficult to figure out the regex.
Originally I tried to use preg_split, however it was not functioning correctly
eventually I decided to try to manually split up the numbers by turning the string
into an array and going character by character to create new strings, floats, and deal with the
operations.