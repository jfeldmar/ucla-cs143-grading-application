Kimberly Hsiao
303450164
kimberly.hsiao@gmail.com

10/05/08
I completed my calculator by October 2nd, and at that time, my calculator had all the functionality that the provided calculator did. However, the online calculator was updated some time between October 2nd and October 5th, and additional functionality was added. The only new functionality that I could see was that negative signs were now accounted for in some situations. I believe that I updated my solution to meet all the new requirements, but I cannot be sure since there is no specifics on the updated functionality. In the future, I think that changing the requirements for a project after the project has been assigned should be avoided because it provides confusion and hurts those that started early.

10/02/08
I believe that my solution meets the requirements of the 6 specifications on the class website. However, it includes a tiny bit more functionality such as reading a - at the beginning of the input equation as a negative sign and accepting a decimal that comes before the numbers. For example, my calculator will read .12 as 0.12 whereas the provided calculator gives an input error. I think this is a good introductory assignment to get people familiar with php.