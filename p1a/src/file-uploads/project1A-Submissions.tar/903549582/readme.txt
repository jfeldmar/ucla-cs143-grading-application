CS143 Project1A: calculator.php
	
Alfred Heu, 903549582, elf777@cs.ucla.edu
SeungHoon Lee, 403450559, shlee@cs.ucla.edu

As a team, we did pair programming and tested/verified the logics together.

Functionalities
1)Performs basic mathematical operations (such as addition/ subtraction / multiplication/ division)
2)Handles inappropriate user inputs (such as non-mathematical expressions, division by 0)