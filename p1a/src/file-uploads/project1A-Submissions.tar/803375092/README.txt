Name: Brian Jew
SID: 803375092
email: brian_jew@yahoo.com

I worked alone.