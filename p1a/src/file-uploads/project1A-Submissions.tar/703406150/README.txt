Mike Nichols
703406150
mykphyre@yahoo.com

This calculator handles +,-,*,/ and integers or decimal numbers.
If the input is not valid math syntax, it will display a (graceful) error.
For example: 5 + =(error)
It also can do automatic negative number conversion with the '-' operator.
For example: -4+5 = 1 and 4 + -5 = -1.
