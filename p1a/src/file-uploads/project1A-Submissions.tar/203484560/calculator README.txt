Raymond Moy
SID: 203484560
E-mail: ramoy@ucla.edu

The calculator supports +, -, * and / operators with standard operator precedence. Parentheses are 
not supported. No white space is allowed.

Both integers and real numbers can be used as input. If real numbers less than 1 are used, a zero 
should precede the decimal point (e.g., 0.4, not .4)

An expression that results in dividing by zero is considered invalid input.

In general, using + and - to denote the sign of a number is supported at the beginning of an 
expression or immediately following an operator. However, using the + sign after using the + 
operator or using the - sign after the - operator is not supported. (e.g., "1--1" and "1++1" are 
not supported)