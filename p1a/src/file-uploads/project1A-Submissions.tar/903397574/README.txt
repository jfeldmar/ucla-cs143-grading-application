SID: 903397574
NAME: Sona Chaudhuri
EMAIL: sona310@ucla.edu

I don't really think there is anything important to note about my project. I think the regular expresion is done pretty decently.
