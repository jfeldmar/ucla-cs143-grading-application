Name: Jeremy Shaw
SID#: 403-361-577
e-mail: katachi38@hotmail.com

Notes:
The simple calculator that I designed works pretty much with the exact same functionalities as the example in the spec.
Comments in the coding of the php file will guide through the concept of the code.