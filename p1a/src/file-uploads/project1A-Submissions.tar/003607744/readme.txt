Hanako Ueda
003607744
flowerchan@ucla.edu

I have a problem where * and / does not work, but + and - work.
I tried to find out why, but I cannot figure it out within the time limit, so I will just leave it as it is.
I hope to find out the reason why during the weekend.