Course: CS 143
Project: Project 1A

Name:	Matthew Snider
SID:	003467745
Email:	msnider@ucla.edu

Name:	Alan Zhao
SID:	503539698
Email:	aqyzhao@gmail.com

How the work was divided:
We met in the computer lab and colaborated together equally.