Name: Michael Wilson
SID: 503-361-181
Email: mihae.wilson@gmail.com

I worked alone, and used eval() and preg_match() as suggested.
