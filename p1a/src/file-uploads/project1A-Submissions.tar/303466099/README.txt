Name: 	Alexander Olivares
SID: 	303466099
Email: 	afolivares@hotmail.com

This PHP Calculator supports the following operations:
	+ - * /

It does not support parentheses.
Real numbers are supported.
Dividing by 0 is not allowed.
Subtracting negative numbers are supported:
	i.e. 1--1 = 2