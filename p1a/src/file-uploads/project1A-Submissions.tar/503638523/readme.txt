Name: Tetsuya Takahashi
SID: 503-638-523
Email: everyell@gmail.com

My php program 
1. recognizes only "- (negative)", an integer, a decimal, and the four basic operations. 
2. shows "undefined" if you try to divide by zero.
3. changes "--" to "+" in the input.
4. shows "invalid input expression" except above.
