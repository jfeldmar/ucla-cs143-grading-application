Student's Name: Ho Ching Lam
ID: 703464017
email: ionlam2000@ucla.edu
