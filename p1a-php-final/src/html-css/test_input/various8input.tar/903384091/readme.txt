Jimmy Nguyen
903-384-091
jnmgd@ucla.edu

Unlike the demo calculator, this calculator should not allow you to divide by zero anywhere, returning an undefined value. For example, the demo calculator gives an answer of 100 for 5/0.1+5/0+5/0.1, while this calculator gives an answer of undefined.