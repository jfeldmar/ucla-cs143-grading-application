<html>
	<body bgcolor="#993366">
		Add a new Movie:
		<hr/>
			<form method="get" action="./addmovieinfo.php">
			<table>
			<tr>
			<td>
			Title :
			<input type="text" maxlength="20" name="title"/>
			</td>
			</tr>
			<tr>
			<td>
			 Compnay:
			<input type="text" maxlength="50" name="company"/>
			</td>
			</tr>
			<tr>
			<td>
			 Year :
			<input type="text" maxlength="4" name="year"/>
			</td>
			</tr>
			<tr>
			<td>
			Select a director : <select name = "did">
			<?php
				$query = "select all id, last, first, dob from Director group by last, first;";
				// $query = "select id, last, first, dob from Actor;";
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection)
				  {
					die('Could not connect: ' . mysql_error());
				  }
				mysql_select_db("CS143", $db_connection);
				$rs = mysql_query($query, $db_connection);
				if(!$rs)
				{
					echo "Could not run thequery" . mysql_error();
					exit;
				}
				
				 $number_rows = mysql_num_rows($rs);
				 $number_columns = mysql_num_fields($rs);
				$return_aid = $_GET["did"];
				while($row = mysql_fetch_row($rs)) 
				{
					if($return_aid == $row[0])
					{
						echo "<option value=".$row[0]." selected>".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
					}
					else
					{
					echo "<option value=".$row[0].">".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
					}
				}
				
				mysql_close($db_connection);
			?>
			</select>
			</td>
			</tr>
			<tr>
			<td>
			 MPAA Rating :
			<select name="rating">
			<option value="G">G</option>
			<option value="NC-17">NC-17</option>
			<option value="PG">PG</option>
			<option value="PG-13">PG-13</option>
			<option value="R">R</option>
			</select>
			</td>
			</tr>
			<tr>
			<td>
			 Genre :
			<input type="checkbox" value="Action" name="genre[]"/>
			Action
			<input type="checkbox" value="Adult" name="genre[]"/>
			Adult
			<input type="checkbox" value="Adventure" name="genre[]"/>
			Adventure
			<input type="checkbox" value="Animation" name="genre[]"/>
			Animation
			<input type="checkbox" value="Comedy" name="genre[]"/>
			Comedy
			<input type="checkbox" value="Crime" name="genre[]"/>
			Crime
			<input type="checkbox" value="Documentary" name="genre[]"/>
			Documentary
			<input type="checkbox" value="Drama" name="genre[]"/>
			Drama
			<input type="checkbox" value="Family" name="genre[]"/>
			Family
			<input type="checkbox" value="Fantasy" name="genre[]"/>
			Fantasy
			<input type="checkbox" value="Horror" name="genre[]"/>
			Horror
			<input type="checkbox" value="Musical" name="genre[]"/>
			Musical
			<input type="checkbox" value="Mystery" name="genre[]"/>
			Mystery
			<input type="checkbox" value="Romance" name="genre[]"/>
			Romance
			<input type="checkbox" value="Sci-Fi" name="genre[]"/>
			Sci-Fi
			<input type="checkbox" value="Short" name="genre[]"/>
			Short
			<input type="checkbox" value="Thriller" name="genre[]"/>
			Thriller
			<input type="checkbox" value="War" name="genre[]"/>
			War
			<input type="checkbox" value="Western" name="genre[]"/>
			Western
			<br/>
			</td>
			</tr>
			</table>
			<input type="submit" value="Add it!!"/>
			</form>
		<hr/>
			<?php
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection)
				{
					die('Could not connect: ' . mysql_error());
				}
				else
				{
					mysql_select_db("CS143", $db_connection);
				///////////
					if($_GET["title"])
					{
						$did = $_GET["did"];
						$title = $_GET["title"];
						$rating = $_GET["rating"];
						$company = $_GET["company"];
						if(is_numeric($_GET["year"]))
						{
							$year = intval($_GET["year"]);
							if($year >= 0)
							{
								$maxid_query = "select id from MaxMovieID;";
								$maxid_tup = mysql_query($maxid_query, $db_connection);
								if(!$maxid_tup)
								{
									// echo $insert_query;
									echo "<br>";
									echo "Could not run thequery while inserting! " . mysql_error();
									echo "<br>";
									exit;
								}
								$maxid_row = mysql_fetch_row($maxid_tup);
								$id = $maxid_row[0];
								
								$newid = $id + 1;
								// $newid = $id ;
								
								$maxid_query2 = "update MaxMovieID set id = $newid where id = $id;";
								$maxid_tup2 = mysql_query($maxid_query2, $db_connection);
								$mid = $newid;
								
								
								if($company == NULL)
								{
									$insert_query = "insert into Movie (id, title, year, rating) values ($mid, \"".$title."\", $year, \"".$rating."\" );";
									echo $insert_query;
									// echo "<br>";
									$insert_query_tup = mysql_query($insert_query, $db_connection);
									if(!$insert_query_tup)
									{
										// echo $insert_query;
										echo "<br>";
										echo "Could not run thequery while inserting~ " . mysql_error();
										echo "<br>";
										exit;
									}
									
								}
								else
								{
									$insert_query = "insert into Movie (id, title, year, rating, company) values ($mid, \"".$title."\", $year, \"".$rating."\", \"".$company."\");";
									$insert_query_tup = mysql_query($insert_query, $db_connection);
									if(!$insert_query_tup)
									{
										// echo $insert_query;
										echo "<br>";
										echo "Could not run thequery while inserting1 " . mysql_error();
										echo "<br>";
										exit;
									}		
									// echo $insert_query;
									// echo "<br>";
								
								}
								
								$movie_director_insert = "insert into MovieDirector values ($mid, $did);";
								$movie_director_tup = mysql_query($movie_director_insert, $db_connection);
								if(!$movie_director_tup)
								{
										echo "<br>";
										echo "Could not run thequery while inserting2 " . mysql_error();
										echo "<br>";
										exit;
								}
								// echo $movie_director_insert;
								//doing movie genre now
								$base = "insert into MovieGenre values ( $mid,";
								if(count($_GET["genre"]) > 0)
								{
									foreach ($_GET["genre"] as $value)
									{
										$movie_genre_query = $base."\"".$value."\");";
										$genre_insert_tup = mysql_query($movie_genre_query, $db_connection);
										if(!$genre_insert_tup)
										{
											echo "<br>";
											echo "Could not run thequery while inserting " . mysql_error();
											echo "<br>";
											exit;
										}
									}
								}
								else
								{
									$movie_genre_query = "insert into MovieGenre (mid) values ($mid);";
									$genre_insert_tup = mysql_query($movie_genre_query, $db_connection);
									if(!$genre_insert_tup)
									{
											echo "<br>";
											echo "Could not run thequery while retrieving " . mysql_error();
											echo "<br>";
											exit;
									}
								}							
								echo "<br>";
								echo "The additions were succesfully made to the database! Feel free to check out more links!";
								echo "<br>";
								echo "<a href=\"./browesing_movie.php?mid=". $mid. "\">". "Check out movies here!". "</a>";
								echo "<br>";
								echo "<a href=\"./movieactor.php?mid=". $mid. "\">". "Click to add movie actor relations!!". "</a>";
								echo "<br>";
							}
							else
							{
								echo "Please enter a valid numeric year!";
								echo "<br>"; 
							}
						}
						else
						{
							echo "Please enter a valid numeric year!";
							echo "<br>";
						}
					}
					else
					{
						echo "<br>";
						echo "Please Note. Title for the Movie is mandatory!";
						echo "<br>";
					}
				}
				///////////////////////////////////
				mysql_close($db_connection);
			?>
	
	</body>
</html>