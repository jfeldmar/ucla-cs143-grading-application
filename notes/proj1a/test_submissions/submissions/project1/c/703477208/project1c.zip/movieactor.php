<html>
	<head>
		<title>CS143 Project 1C Demo by Tarun</title>
	</head>
	<body bgcolor="#6699CC">
	Add new actor in the movie!:
	<hr>
	<form method="get" action="./movieactor.php">
	<table>
	<tr>
	<td>
	Select the movie : <select name="mid">
		
	<?php
		$query = "select id, title, year from Movie group by title;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query, $db_connection);
		if(!$rs)
		{
			echo "Could not run thequery while generating menu" . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		
		 $sent_mid = $_GET["mid"];
		
		while($row = mysql_fetch_row($rs)) 
		{
			if($sent_mid != $row[0])
			{
				echo "<option value=".$row[0].">".$row[1]."(".$row[2].")"."</option>";
			}
			else
			{
				echo "<option value=".$row[0]." SELECTED>".$row[1]."(".$row[2].")"."</option>";
			}
		}
		
		// while($row = mysql_fetch_row($rs)) 
		// {
			// echo "<option value=".$row[0].">".$row[1]."(".$row[2].")"."</option>";
		// }
		mysql_close($db_connection);
	
	?>
	</select>
	</tr>
	</td>	
	<tr>
	<td>
	Select an actor : <select name = "aid">
	<?php
		$query = "select all id, last, first, dob from Actor group by last, first;";
		// $query = "select id, last, first, dob from Actor;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query, $db_connection);
		if(!$rs)
		{
			echo "Could not run thequery" . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		$return_aid = $_GET["aid"];
		while($row = mysql_fetch_row($rs)) 
		{
			if($return_aid == $row[0])
			{
				echo "<option value=".$row[0]." selected>".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
			}
			else
			{
			echo "<option value=".$row[0].">".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
			}
		}
		
		mysql_close($db_connection);
	?>
	</select>
	</td>
	</tr>
	<tr>
	<td>
	Role in the movie: <input type="text" maxlength="20" name="role"/>
	</td>
	</tr>
	</table>
	<input type="submit" value="Submit"/>
	</form>
	
	<hr>
	<?php
		if($_GET["role"] == NULL)
		{
			echo "Please enter the role played by the actor";
		}
		else
		{
			if($_GET["mid"] && $_GET["aid"] && $_GET["role"] )
			{
				$mid = $_GET["mid"];
				$aid = $_GET["aid"];
				$role = $_GET["role"];
				$insert_query = "insert into MovieActor (mid,aid,role) values ($mid, $aid, \"". $role."\");";
				 // echo $insert_query;
				 // echo "<br>";
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection)
				  {
					die('Could not connect: ' . mysql_error());
				  }
				mysql_select_db("CS143", $db_connection);
				
				$insert = mysql_query($insert_query, $db_connection);
				if(!$insert)
				{
					// echo $insert_query;
					echo "<br>";
					echo "Could not run thequery while inserting " . mysql_error();
					echo "<br>";
					exit;
				}
				echo "Thank you for your input! Feel free to check out more about this movie!";
				echo "<br>";
				echo "<a href=\"./browesing_movie.php?mid=". $mid. "\">". "Check out movies here!". "</a>";
				echo "<br>";
				echo "You can check out information about the actor here!";
				echo "<br>";
				echo "<a href=\"./browesing_actor.php?aid=". $aid. "\">". "Check out actor here!". "</a>";
				echo "<br>";
							
				mysql_close($db_connection);
			}
		}
	?>
	</body>
</html>