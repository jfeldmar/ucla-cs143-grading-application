<html>
	<head>
		<title>cs143 project 1c demo by Tarun</title>
		</head>
		<body bgcolor="#CC6633">
		Add a new actor or director:
		<hr/>

		<form method="get" action="./add_actor_director.php">
		<table>
		<tr>
		<td>
		Please select:
		<input type="radio" checked="true" value="actor" name="category"/>
		Actor
		<input type="radio" checked="false" value="director" name="category"/>
		Director
		</td>
		</tr>
		<tr>
		<td>
		 First Name:
		<input type="text" maxlength="20" name="first"/>
		</td>
		</tr>	
		<tr>
		<td>
		Last Name:
		<input type="text" maxlength="20" name="last"/>
		</td>
		</tr>
		<tr>
		<td>
		Sex:
		<input type="radio" checked="true" value="Male" name="sex"/>
		Male
		<input type="radio" value="Female" name="sex"/>
		Female
		<br/>
		</td>
		</tr>
		<tr>
		<td>
		Date of Birth => 
		Year : <input type="text" maxlength="4" name="year"/> Month : <input type="text" maxlength="2" name="month"/> Day : <input type="text" maxlength="2" name="day"/>
		</td>
		</tr>	
		<tr>
		<td>
		Date of Death=>
		Year : <input type="text" maxlength="4" name="dyear"/> Month : <input type="text" maxlength="2" name="dmonth"/> Day : <input type="text" maxlength="2" name="dday"/>
		(leave blank if alive)
		</td>
		</tr>
		</table>
		<input type="submit" value="add it!!"/>
		</form>
		<hr/>
		<?php
			
			$db_connection = mysql_connect("localhost", "cs143", "");
			if (!$db_connection)
			{
				die('Could not connect: ' . mysql_error());
			}
			mysql_select_db("CS143", $db_connection);

			$dflag = 0;
			if(($_GET["first"] && $_GET["last"] && $_GET["year"] && $_GET["month"] && $_GET["day"]))
			{
				$first = $_GET["first"];
				$last = $_GET["last"];
				$year = intval($_GET["year"]);
				$month = intval($_GET["month"]);
				$day = intval($_GET["day"]);
				$sex = $_GET["sex"];
				$category = $_GET["category"];
				
				
				if($_GET["dyear"] && $_GET["dmonth"] && $_GET["dday"])
				{
					$dyear = intval($_GET["dyear"]);
					$dmonth = intval($_GET["dmonth"]);
					$dday = intval($_GET["dday"]);
					//$dflag = 1;
					if(checkdate($dmonth, $dday, $dyear))
					{
						$dflag = 1;
						$ddate = date("Y-m-d", mktime(0, 0, 0, $dmonth, $dday, $dyear));
						// $ddate = mktime(0, 0, 0, $dmonth, $dday, $dyear);
					}
					else
					{
						$dflag = 0;
						
					}
				}
				else
				{
					$dflag = 1;
					$ddate = NULL;
				}
				
				if(checkdate($month, $day, $year) && $dflag == 1)
				{
					 $bdate = date("Y-m-d", mktime(0, 0, 0, $month, $day, $year));
					//$bdate =  mktime(0, 0, 0, $month, $day, $year);
					$maxid_query = "select id from MaxPersonID;";
					$maxid_tup = mysql_query($maxid_query, $db_connection);
					if(!$maxid_tup)
					{
						// echo $insert_query;
						echo "<br>";
						echo "Could not run thequery while retrieving " . mysql_error();
						echo "<br>";
						exit;
					}
					$maxid_row = mysql_fetch_row($maxid_tup);
					$id = $maxid_row[0];
					$newid = $id + 1;
					$maxid_query2 = "update MaxPersonID set id = $newid where id = $id;";
					$maxid_tup2 = mysql_query($maxid_query2, $db_connection);
					if(!$maxid_tup2)
					{
						// echo $insert_query;
						echo "<br>";
						echo "Could not run thequery while retrieving " . mysql_error();
						echo "<br>";
						exit;
					}
					
					if($category == "actor")
					{
						
						if($ddate == null)
						{
							$actor_query = "insert into Actor (id, last, first, sex, dob) values ($newid, \"". $last."\", \"".$first."\",\"".$sex."\", '".$bdate."');";
							// $actor_query;
						}
						else
						{
							$actor_query = "insert into Actor values ($newid, \"". $last."\", \"".$first."\",\"".$sex."\", '".$bdate."', '".$ddate."');";
							// $actor_query;
						}
						$actor_tup = mysql_query($actor_query, $db_connection);
						if(!$actor_tup)
						{
							// echo $actor_query;
							echo "<br>";
							echo "Could not run thequery while retrieving " . mysql_error();
							echo "<br>";
							exit;
						}
						else 
						{
							// echo $actor_query;
							echo "<br>";
							echo "The actor has been added in the database!";
							echo "<br>";
							echo "You can check out information about the actor here!";
							echo "<br>";
							echo "<a href=\"./browesing_actor.php?aid=". $newid. "\">". "Check out actor here!". "</a>";
							echo "<br>";
						}
						
					}
					else
					{
						if($ddate == null)
						{
							$director_query = "insert into Director (id, last, first, dob) values ($newid, \"". $last."\", \"".$first."\", '".$bdate."');";
							// echo $director_query;
						}
						else
						{
							$director_query = "insert into Director values ($newid, \"". $last."\", \"".$first."\", '".$bdate."', '".$ddate."');";
							// echo $director_query;
						}
						$director_tup = mysql_query($director_query, $db_connection);
						if(!$director_tup)
						{
							// echo $director_query;
							echo "<br>";
							echo "Could not run thequery while retrieving " . mysql_error();
							echo "<br>";
							exit;
						}
						else 
						{
							// echo $director_query;
							echo "<br>";
							echo "The director has been added in the database!";
						}
					}
					
					//use msql function STR_TO_DATE();
				}
				else
				{
					echo "Re enter date";
					echo "<br>";
				}				
			}
			else
			{
				echo "Please enter the all the required values";
				
			}
		
			mysql_close($db_connection);
		?>
	
	</body>
</html>