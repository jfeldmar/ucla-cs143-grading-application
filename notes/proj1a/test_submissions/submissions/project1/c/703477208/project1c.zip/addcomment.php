<html>
	<head>
		<title>CS143 Project 1C Demo by Tarun</title>
	</head>
	<body bgcolor="#999999">
	Add new comment:
	<hr>
	<form method="get" action="./addcomment.php">
	<table>
	<tr>
	<td>
	Select the movie : <select name="mid">
		
	<?php
		$query = "select id, title, year from Movie group by title;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query, $db_connection);
		if(!$rs)
		{
			echo "Could not run thequery while generating menu" . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		
		 $sent_mid = $_GET["mid"];
		
		while($row = mysql_fetch_row($rs)) 
		{
			if($sent_mid != $row[0])
			{
				echo "<option value=".$row[0].">".$row[1]."(".$row[2].")"."</option>";
			}
			else
			{
				echo "<option value=".$row[0]." SELECTED>".$row[1]."(".$row[2].")"."</option>";
			}
		}
		
		// while($row = mysql_fetch_row($rs)) 
		// {
			// echo "<option value=".$row[0].">".$row[1]."(".$row[2].")"."</option>";
		// }
		mysql_close($db_connection);
	
	?>
	</select>
	</tr>
	</td>	
	<tr>
	<td>
	Your name: <input type="text" maxlength="20" value="Anonymous" name="name"/>
	</tr>
	</td>
	<tr>
	<td>
	 Rating:
	<select name="rating">
	<option value="5"> 5 - Excellent </option>
	<option value="4"> 4 - Good </option>
	<option value="3"> 3 - It's ok </option>
	<option value="2"> 2 - Not worth watching </option>
	<option value="1"> 1 - Rotten tomatoes </option>
	</select>
	</tr>
	</td>
	
	<tr>
	<td> 
	Comments:
	<br/>
	<textarea rows="10" cols="80" name="comment"/></textarea>
	<br/>
	</tr>
	</td>
	
	</table>
	
	<input type="submit" value="Submit"/>
	</form>
	<hr>
	<?php
		if($_GET["mid"] && $_GET["rating"] && $_GET["name"] )
		{
			$mid = $_GET["mid"];
			$rating = $_GET["rating"];
			$comment = $_GET["comment"];
			$name = $_GET["name"];
			$insert_query = "insert into Review (name, mid, rating, comment) values ( \"". $name."\", $mid, $rating, \"". $comment."\");";
			$db_connection = mysql_connect("localhost", "cs143", "");
			if (!$db_connection)
			  {
				die('Could not connect: ' . mysql_error());
			  }
			mysql_select_db("CS143", $db_connection);
			
			$insert = mysql_query($insert_query, $db_connection);
			if(!$insert)
			{
				echo $insert_query;
				echo "<br>";
				echo "Could not run thequery while inserting " . mysql_error();
				echo "<br>";
				exit;
			}
		
			echo "Thank you for your comments. Feel free to check out more about this movie!";
			echo "<br>";
			echo "<a href=\"./browesing_movie.php?mid=". $mid. "\">". "Check out movies here!". "</a>";
			echo "<br>";
		
			mysql_close($db_connection);
		}
		else
		{
			echo "Please note, your name is required. If you wish to be anonymous, do not enter anything";
			echo "<br>";
		}
	?>
	</body>
</html>
	