<html>
	<head>
		<title>CS143 Project 1C Demo by Tarun</title>
	</head>
	<body bgcolor="#33FFCC">
	<p> </p>
	
	<form method="get" action="./browesing_actor.php">
	Select an actor : <select name="aid">
		
	<?php
		$query = "select all id, last, first, dob from Actor group by last, first;";
		// $query = "select id, last, first, dob from Actor;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query, $db_connection);
		if(!$rs)
		{
			echo "Could not run thequery" . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		$return_aid = $_GET["aid"];
		while($row = mysql_fetch_row($rs)) 
		{
			if($return_aid == $row[0])
			{
				echo "<option value=".$row[0]." selected>".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
			}
			else
			{
			echo "<option value=".$row[0].">".$row[1]." ".$row[2]." ( ". $row[3]." ) "."</option>";
			}
		}
		
		mysql_close($db_connection);
	?>
	</select>	
	<input type="submit" value="Submit"/>
	</form>
	<?php
	if($_GET["aid"])
	{
		 $aid = $_GET["aid"];
		 echo '--Actor information--';
		 echo "<br>";
		 $query3 = "select * from Actor where id = $aid;";
		 $db_connection = mysql_connect("localhost", "cs143", "");
		 if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query3, $db_connection);

		if(!$rs)
		{
			echo "Could not run the query " . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		
	 //printing tables now
		echo '<table border = "1">';
		echo '<tr>';
		for($i=0; $i < $number_columns - 2; $i++)
		{
			echo '<td>';
			echo mysql_field_name($rs,$i);
			echo '</td>';
		}
		echo '<td>';
		echo 'Date of Birth';
		echo '</td>';
		echo '<td>';
		echo 'Date of Death';
		echo '</td>';
		echo '</tr>';
		
		while($row = mysql_fetch_row($rs)) 
		{
			 echo '<tr>';
			 for($i=0; $i < $number_columns; $i++)
				{
				echo '<td>';
					if($row[$i] == NULL)
					print "N/A";
				else
						print $row[$i];
				echo '</td>';
				}
			 echo '</tr>';
		}
		
		echo '</table>';
		echo "<hr>";
		echo '--Movies Acted in--';
		echo "<br>";
		
		$movie_query = "select m.id, m.title, ma.role from Movie m, Actor a, MovieActor ma where a.id = $aid and a.id = ma.aid and ma.mid = m.id;";
		$mq = mysql_query($movie_query, $db_connection);

		if(!$mq)
		{
			echo "Could not run the query " . mysql_error();
			exit;
		}
		
		 $movie_rows_number = mysql_num_rows($mq);
		 $movie_columns_number = mysql_num_fields($mq);
		 if($movie_rows_number == 0)
		 {
			 echo 'Yet to act in a movie';
			 echo "<br>";
			 
		 }
		 // echo $movie_rows_number;
		while($movie_rows = mysql_fetch_row($mq)) 
		{
			echo "<a href=\"./browesing_movie.php?mid=". $movie_rows[0]. "\">". $movie_rows[1]. "</a>  As \"". $movie_rows[2]. "\"<br>"; 
		}
				
     	mysql_close($db_connection);
	}
	
	?>
	</body>
</html>

