<html>
	<head>
		<title>CS143 Project 1C Demo by Tarun</title>
	</head>
	<body bgcolor="#66FF00">
	<p> </p>
	
	<form method="get" action="./browesing_movie.php">
	Select the movie : <select name="mid">
		
	<?php
		$query = "select id, title, year from Movie group by title, year;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		if (!$db_connection)
		  {
			die('Could not connect: ' . mysql_error());
		  }
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($query, $db_connection);
		if(!$rs)
		{
			echo "Could not run thequery" . mysql_error();
			exit;
		}
		
		 $number_rows = mysql_num_rows($rs);
		 $number_columns = mysql_num_fields($rs);
		
		$sent_mid = $_GET["mid"];
		
		while($row = mysql_fetch_row($rs)) 
		{
			if($sent_mid != $row[0])
			{
				echo "<option value=".$row[0].">".$row[1]."(".$row[2].")"."</option>";
			}
			else
			{
				echo "<option value=".$row[0]." SELECTED>".$row[1]."(".$row[2].")"."</option>";
			}
		}
		mysql_close($db_connection);
		
	?>
	</select>	
	<input type="submit" value="Submit"/>
	</form>
	<?php
	
	if($_GET["mid"])
	{
	 $mid = $_GET["mid"];
	 echo '--Movie information--';
	 echo '<br>';
	 $query2 = "select * from Movie where id = $mid;";
	 
	 $db_connection = mysql_connect("localhost", "cs143", "");
	 if (!$db_connection)
	  {
	    die('Could not connect: ' . mysql_error());
	  }
	mysql_select_db("CS143", $db_connection);
	$rs = mysql_query($query2, $db_connection);
	if(!$rs)
	{
		echo "Could not run thequery" . mysql_error();
		exit;
	}
/////////////////////////////////////// director part
	
	$director = "select id, last, first from Director d, MovieDirector md where md.mid = $mid and md.did = d.id;";
	$dir = mysql_query($director, $db_connection);
	if(!$dir)
	{
		echo "Could not run thequery" . mysql_error();
		exit;
	}

/////////////////////////genre
	$genre = "select genre from MovieGenre where mid = $mid";
	$genr = mysql_query($genre, $db_connection);
	if(!$genr)
	{
		echo "Could not run thequery" . mysql_error();
		exit;
	}
	$genr_rows = mysql_num_rows($genr);
	$genr_columns = mysql_num_fields($rs);
	

	 $number_rows = mysql_num_rows($rs);
	 $number_columns = mysql_num_fields($rs);
	
 //printing tables now
	echo '<table border = "1">';
	echo '<tr>';
	for($i=0; $i < $number_columns; $i++)
	{
		echo '<td>';
		echo mysql_field_name($rs,$i);
		echo '</td>';
	}
	echo '<td>';
	echo "Director: ";	
	echo '</td>';
	echo '<td>';
	echo "Genre: ";	
	echo '</td>';
	echo '</tr>';
	
	echo '<tr>';
	while($row = mysql_fetch_row($rs)) 
	{
	 	//echo '<tr>';
	 	 for($i=0; $i < $number_columns; $i++)
		    {
			echo '<td>';
		        if($row[$i] == NULL)
				print "N/A";
			else
		    		print $row[$i];
			echo '</td>';
		    }
		//echo '</tr>';
	}
	$number = mysql_num_fields($dir);
	echo "<td>";

	if(mysql_num_rows($dir) > 0)
	{
		while($dir_name = mysql_fetch_row($dir)) 
		{
			 for($i=1; $i < $number; $i++)
				{
					if($dir_name[$i] == NULL)
						print "--";
					else
						print "$dir_name[$i] ";
				}
		}
	}
	else
	{
		echo "None";		
	}
	echo "</td>";
	echo "<td>";
	$temps = $genr_rows;
	if($genr_rows == 0)
	{
		echo "N/A";
		
	}
	while($genr_rw = mysql_fetch_row($genr))
	{
		if($temps > 1)
		{
			echo $genr_rw[0].", ";
		}
		else
		{
			if($genr_rw[0] == NULL)
				echo "N/A";
			else
				echo $genr_rw[0];
		}
		$temps = $temps -1;
	}
	
	echo '</td>';
	echo '</tr>';
	echo '</table>';
	
	//////////actors in the movie
	echo "<p>";
	echo "</p>";
	
	echo "<hr>";
	echo '--Actors in the Movie--';
	echo "<br>";
	
	$actor_query = "select a.id, a.last, a.first, ma.role from Actor a, MovieActor ma where ma.mid = $mid and ma.aid = a.id;";
	$actor_tup = mysql_query($actor_query, $db_connection);
	if(!$actor_tup)
	{
		echo "Could not run thequery" . mysql_error();
		exit;
	}
	$actor_tup_rows = mysql_num_rows($actor_tup);
	$actor_tup_columns = mysql_num_fields($actor_tup);
	
	while($actor_row = mysql_fetch_row($actor_tup)) 
	{
		echo "<a href=\"./browesing_actor.php?aid=". $actor_row[0]. "\">". $actor_row[1]. ", ". $actor_row[2]. "</a> acted as \"". $actor_row[3]. "\"<br>"; 
	}
	
	echo "<hr>";
	echo '--Reviews about the Movie--';
	echo "<br>";
	//query to get the average!
	$avg_query = "select avg(rating) from Review where mid = $mid;";
	$num_reviews = "select count(*) from Review where mid = $mid;";
	
	$avg_tup = mysql_query($avg_query, $db_connection);
	$num_reviews_tup = mysql_query($num_reviews, $db_connection);
	
	$flag = 1;
	$avg_number_rows = mysql_num_rows($avg_tup);
	$avg_number_columns = mysql_num_fields($avg_tup);
	
	$temp_hold = mysql_fetch_row($num_reviews_tup);
	$num_reviews_count = $temp_hold[0];
	while($avg_row = mysql_fetch_row($avg_tup)) 
	{
		if($avg_row[0] == NULL)
		{
			echo "no reviews";
			$flag = 0;
			echo "<br>";
		}
		else
		{
			echo "Average score: ".$avg_row[0]."/5 (5 is the best), Number of Reviewers : ".$num_reviews_count;
			
		}
	}
	echo "<br>";
	if($flag == 1)
	{
		echo "-- All comments in detail -- ";
		echo "<br>";
	}
	
	$reviews_query = "select name, time, rating, comment from Review where mid = $mid;";
	$reviews_query_tup = mysql_query($reviews_query, $db_connection);
	$reviews_number_rows = mysql_num_rows($reviews_query_tup);
	$reviews_number_columns = mysql_num_fields($reviews_query_tup);
	while($reviews_row = mysql_fetch_row($reviews_query_tup))
	{
		echo "<br>";
		echo "In $reviews_row[1] , $reviews_row[0] rated the movie: $reviews_row[2] , and commented the following";
		echo "<br>";
		if($reviews_row[3] == NULL)
		{
			echo "No Comment";
		}
		else
		{
		echo $reviews_row[3];
		}
	}
	echo "<br>";
	echo "<a href=\"./addcomment.php?mid=". $mid. "\">". "You can add your comments by clicking here!". "</a>";
	echo "<br>";

 	mysql_close($db_connection);
	}
	?>
	</body>
</html>
