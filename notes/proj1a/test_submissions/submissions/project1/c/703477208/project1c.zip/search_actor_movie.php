<html>
	<body bgcolor="#999999">
		Search Movie/Actor Database!
		<hr/>
			<form method="get" action="./search_actor_movie.php">
				Type your search here! <input type="text" maxlength="40" name="search"/>
				<input type="submit" value="Search it!!"/>
			</form>
		<hr/>
			<?php
				//Special thanks to Sendie Hudaya who helped in forming the LIKE queries and came up with explode function.
			

				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection)
				{
					die('Could not connect: ' . mysql_error());
				}
				else
				{
					mysql_select_db("CS143", $db_connection);
					if($_GET["search"])
					{
						$array = explode(" ",$_GET["search"]) ;
						$array_size = count($array);	
						$queryActor = "select id, last, first, dob from Actor where ";
						$queryMovie = "select id, title, year from Movie where title LIKE \"%". $_GET["search"]. "%\"  ";
						foreach ($array as $value)
						{
							if($array_size == 1)
								$queryActor = $queryActor. "(last like \"%". $value. "%\" OR first like \"%". $value ."%\") ";
							else
								$queryActor = $queryActor. "(last like \"%". $value. "%\" OR first like \"%". $value ."%\") AND ";
							
							$array_size = $array_size - 1;
						}
							
						$rsActor = mysql_query($queryActor, $db_connection);	 
						$rsMovie = mysql_query($queryMovie, $db_connection);
						
						
						if(!$Actor && !$rsMovie)
						{
							echo "Could not run the queries! ".mysql_error();
							exit;
						}				
						//once results are obtained, we run them!
						
						echo "<hr>"; 
						echo "Search results for: ". $_GET["search"]. "<hr/>";
										
						//Actors
						if( mysql_num_rows($rsActor) == 0)
						{	
							echo "Found no records in Actor database <br>";
						}
						else
						{
							echo "Matching records in Actor database! : <br>";
							
							while($row = mysql_fetch_row($rsActor))
							{
								echo "<a href = \"./browesing_actor.php?aid=". $row[0]. "\">". $row[1]. " ". $row[2]. " (". $row[3]. ")</a> <br>";					
							}
						}
						echo "<hr/>";
					
						//Movies
						if( mysql_num_rows($rsMovie) == 0)
						{
							echo "Found no records in Movie database! <br>";
						}
						else
						{
							echo "Matching records in Movie database! : <br>";
							while($row = mysql_fetch_row($rsMovie))
							{
								echo "<a href = \"./browesing_movie.php?mid=". $row[0]. "\">". $row[1]. " (". $row[2]. ")</a> <br>";					
							}
							
						}
						
					}
				}
				mysql_close($db_connection);
				
			?>
	</body>
</html>