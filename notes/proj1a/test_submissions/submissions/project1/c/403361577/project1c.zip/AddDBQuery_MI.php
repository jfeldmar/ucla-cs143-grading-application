<?php

    // request the inputs
    $title = $_REQUEST["title"];
    $company = $_REQUEST["company"];
    $year = $_REQUEST["year"];
    $rating = $_REQUEST["rating"];
    $genre = $_REQUEST["genre"];
    $dfirst = $_REQUEST["dfirst"];
    $dlast = $_REQUEST["dlast"];
    $afirst = $_REQUEST["afirst"];
    $alast = $_REQUEST["alast"];
    $role = $_REQUEST["role"];

    // validation keys
		$valid_title = "/^.{1,100}$/";
		$valid_company = "/^.{1,50}$/";
    $valid_name = "/^.{1,20}$/";
    $valid_year = "/^([1-9][0-9]{3})$/";
		$valid_role = "/^.{1,50}$/";

    // error flag
    $error_flag = 0;

    // error outputs
    if (preg_match($valid_title, $title) == 0) {
        print "ERROR: Invalid input on title.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_company, $company) == 0) {
        print "ERROR: Invalid input on company.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_year, $year) == 0) {
        print "ERROR: Invalid input on year.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_name, $dfirst) == 0) {
        print "ERROR: Invalid input on director first name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_name, $dlast) == 0) {
        print "ERROR: Invalid input on director last name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_name, $afirst) == 0) {
        print "ERROR: Invalid input on actor first name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_name, $alast) == 0) {
        print "ERROR: Invalid input on actor last name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_role, $role) == 0) {
        print "ERROR: Invalid input on actor role.<br/>";
        $error_flag = 1;
    }

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // if no error, add movie info
    // else create a link to go back redo the inputs
    if ($error_flag == 0) {

        // escape bad characters
        $title = mysql_real_escape_string($title);
        $company = mysql_real_escape_string($company);
        $dfirst = mysql_real_escape_string($dfirst);
        $dlast = mysql_real_escape_string($dlast);
        $afirst = mysql_real_escape_string($afirst);
        $alast = mysql_real_escape_string($alast);
        $role = mysql_real_escape_string($role);

        // add fail flag
        $add_fail_flag = 0;
        
				// get new ID for movie
				$maxmid_query = "SELECT id FROM MaxMovieID";
				$maxmid = mysql_query($maxmid_query, $db_connection);
				$data_maxmid = mysql_fetch_row($maxmid);
				if (!$data_maxmid) {
            print "ERROR: Failed to get MaxMovieID.<br/>";
            $add_fail_flag = 1;
        } else {
            $newid = $data_maxmid[0] + 1;
				}
				// update max movie's id
				$updatemid_query = "UPDATE MaxMovieID SET id=id+1";
				if (mysql_query($updatemid_query, $db_connection) != 1) {
            print "ERROR: Failed to update MaxMovieID.<br/>";
            $add_fail_flag = 1;
        }

        // get the id of the director
        $did_query = "SELECT id FROM Director WHERE first='$dfirst' AND last='$dlast'";
        $did_result = mysql_query($did_query, $db_connection);
        $data_did = mysql_fetch_row($did_result);

        // get the id of the actor
        $aid_query = "SELECT id FROM Actor WHERE first='$afirst' AND last='$alast'";
        $aid_result = mysql_query($aid_query, $db_connection);
        $data_aid = mysql_fetch_row($aid_result);

        // print error message if can't find director
        if (!$data_did) {
            print "ERROR: Failed to find director, $dfirst $dlast.<br/>";
            $add_fail_flag = 1;
        }
        // print error message if can't find actor
        if (!$data_aid) {
            print "ERROR: Failed to find actor, $afirst $alast.<br/>";
            $add_fail_flag = 1;
        }

        // add the movie if director and actor were found
        if ($add_fail_flag == 0) {
        
            // add the movie
            $addMovie_query = "INSERT INTO Movie VALUES($newid, '$title', $year, '$rating', '$company')";
            if (mysql_query($addMovie_query, $db_connection) != 1)
                $add_fail_flag = 1;
                
            // add the movie genre
            $addMovieGenre_query = "INSERT INTO MovieGenre VALUES($newid, '$genre')";
            if (mysql_query($addMovieGenre_query, $db_connection) != 1)
                $add_fail_flag = 1;
                
            // obtain director id
            $did = $data_did[0];
            // add the movie director
            $addMovieDirector_query = "INSERT INTO MovieDirector VALUES($newid, $did)";
            if (mysql_query($addMovieDirector_query, $db_connection) != 1)
                $add_fail_flag = 1;

            // obtain actor id
            $aid = $data_aid[0];
            // add the movie actor
            $addMovieActor_query = "INSERT INTO MovieActor VALUES($newid, $aid, '$role')";
            if (mysql_query($addMovieActor_query, $db_connection) != 1)
                $add_fail_flag = 1;

        }
           
				
				// if failed, print error on fail to add movie
				// else print confirmation on added movie
				if ($add_fail_flag == 1) {
            print "ERROR: Failed to add $title.<br/>";
            // update max movie's id
            $updatemid_query = "UPDATE MaxMovieID SET id=id-1";
            if (mysql_query($updatemid_query, $db_connection) != 1)
                print "ERROR: Failed to update MaxMovieID.<br/>";
        } else {
            print "$title has been added to the Movie list.<br/>";
        }
        
        print '<font size=3 color = "blue">';
        // link to moogle search page.
        print '<br/>Click ';
        print '<a href="MoogleSearch.php?&Name=correction">here</a>';
        print " to search for the Movie.";
        print '</font>'; 
    } else {
        print '<font size=3 color = "blue">';
        // link to add actor/director page.
        print '<br/>Browse back or click ';
        print '<a href="AddMovieInfo.php?&Name=correction">here</a>';
        print ' to go back and correct the information.';
        print '</font>';
    }


    // close db connection
    mysql_close($db_connection);

?>
