<html>	
	<body>

		<font size=4 color='blue'>
		Add movie information<br/>
		</font>
		<hr/>
		<form method="POST" action="AddDBQuery_MI.php" >			
			Title: <input type="text" name="title" value="" maxlength="20"><br/>
			Company: <input type="text" name="company" maxlength="50"><br/>
			Year: <input type="text" name="year" maxlength="4"><br/>
			Rating:
				<select size="1" name="rating">
			    <option selected value="G">G</option>
			    <option value="PG">PG</option>
			    <option value="PG-13">PG-13</option>
			    <option value="NC-17">NC-17</option>
			    <option value="R">R</option>
        </select>
			Genre: <select name="genre">
				<option value="Action">Action</option>
        <option value="Adult">Adult</option>
        <option value="Adventure">Adventure</option>
        <option value="Animation">Animation</option>
        <option value="Comedy">Comedy</option>
        <option value="Crime">Crime</option>
        <option value="Documentary">Documentary</option>
        <option value="Drama">Drama</option>
        <option value="Family">Family</option>
        <option value="Fantasy">Fantasy</option>
        <option value="Horror">Horror</option>
        <option value="Musical">Musical</option>
        <option value="Mystery">Mystery</option>
        <option value="Romance">Romance</option>
        <option value="Sci-Fi">Sci-Fi</option>
        <option value="Short">Short</option>
        <option value="Thriller">Thriller</option>
        <option value="War">War</option>
        <option value="Western">Western</option>
      </select>
      <br/>
			Director:  first <input type="text" name="dfirst" maxlength="20">
                 last <input type="text" name="dlast" maxlength="20"><br/>
			Actor:  first <input type="text" name="afirst" maxlength="20">
                 last <input type="text" name="alast" maxlength="20"><br/>
			Actor Role:  <input type="text" name="role" maxlength="50"><br/>
			<br/>
			<br/>
			<input type="submit" value="Add Movie"/>
		</form>
		<hr/>

	</body>
</html>
