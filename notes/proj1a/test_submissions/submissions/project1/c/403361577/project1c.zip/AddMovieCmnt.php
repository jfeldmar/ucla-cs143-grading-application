<html>	
	<body>

		<font size=4 color='blue'>
		Add new comment<br/>
		</font>
		<hr/>
		<form method="POST" action="AddDBQuery_MC.php">			
			Movie:	<input type="text" name="movie" maxlength="100"><br/>

			User:	<input type="text" name="user" value="Anonymous" maxlength="20"><br/>

			Rating:	<select name="rating">
						<option value="5"> 5 - Excellent </option>
						<option value="4"> 4 - Good </option>
						<option value="3"> 3 - Average </option>
						<option value="2"> 2 - Bad </option>
						<option value="1"> 1 - Wtf </option>
			</select>
			<br/>
			Comments: <br/>
			<textarea name="comment" cols="50" rows="10" maxlength="500"></textarea>
			<br/>
			<input type="submit" value="Submit"/>
		</form>
		<hr/>

	</body>
</html>
