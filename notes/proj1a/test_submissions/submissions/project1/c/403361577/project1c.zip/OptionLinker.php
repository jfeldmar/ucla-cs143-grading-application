<?php
  // get the search choice
  $choice = $_REQUEST[choice];

  if ($choice) {
    // go to according php file for further instruction
    // base on choice
    switch ($choice) {
      case "MoogleSearch":
        header('Location: MoogleSearch.php');
        break;
      case "BrowseActorInfo":
        header('Location: BrowseActorInfo.php');
        break;
      case "BrowseMovieInfo":
        header('Location: BrowseMovieInfo.php');
        break;
      case "AddActorDirectorInfo":
        header('Location: AddActorDirectorInfo.php');
        break;
      case "AddMovieCmnt":
        header('Location: AddMovieCmnt.php');
        break;
      case "AddMovieInfo":
        header('Location: AddMovieInfo.php');
        break;
      default:
        print "UNKNOWN SEARCH CHOICE";
    }
  }

?>

