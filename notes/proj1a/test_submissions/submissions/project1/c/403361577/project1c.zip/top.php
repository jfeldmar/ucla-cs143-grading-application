<html>

<style type="text/css">
body {background-image: "moogle.jpg"; background-position: bottom center; background-repeat: no-repeat;}
</style>

<body background="moogle.jpg">
</body>

</html>
