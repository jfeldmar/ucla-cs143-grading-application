<?php
    // request the input query
    $browsed_movie = $_REQUEST["Name"];

    // flag to indicate called by other search pages
    $calledByOther = 1;

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // escape bad characters
    $browsed_movie = mysql_real_escape_string($browsed_movie);

    // have query search for all information on any movie containing search phrase
    $movie_query = "SELECT title, year, rating, company FROM Movie WHERE id = $browsed_movie";
    
    // we overwrite the query to select all movie if nothing is inputted
    if ($browsed_movie == "") {
      $movie_query = "SELECT CONCAT(title, ', ', year) FROM Movie";
      $mid_query = "SELECT id FROM Movie";
      $rs_mid = mysql_query($mid_query, $db_connection);
      $calledByOther = 0;
    }
    
    print '<font size=4 color = "blue"><hr/>';
    print "Movie Information</br></br>";
    print '</font>';
    
    // run the actor query in db connection
    $rs_movie = mysql_query($movie_query, $db_connection);

        // get query's number of rows
        $col_movie = mysql_num_fields($rs_movie);
        
        // if called by other search pages.
        // 1. print attribute names
        // 2. don't hyper link results
        // else
        // 1. print out all movie info
        // 2. hyper link results
        if ($calledByOther == 1) {
            // PRINTING THE FOUND MOVIE TABLE
            
            print "<table border = 1>";
            // field names
            $k = 0;
            print "<tr>";
            while ($k < $col_movie) {
              // get the field name
              $attr = mysql_field_name($rs_movie, $k);
              print "<td>";
              print "$attr";
              print "</td>";
              $k++;
            }
            print "</tr>";
            
            // fetch the data
            while ($data_movie = mysql_fetch_row($rs_movie)) {
              // row index
              $i = 0;
              print "<tr>";
              while ($i < $col_movie) {
                print "<td>";
                print "$data_movie[$i]";
                print "</td>";
                // decrement the row
                $i++;
              }
              print "</tr>";
            }
            print "</table>";
            
            print '<font size=4 color = "blue">';
            print "</br></br><hr/>Actors participated in this movie</br></br>";
            print '</font>';

            // actor query to get the title of movies that this actor participated in
            $actor_query = "SELECT CONCAT(first, ' ',last, ', ',dob) FROM Actor WHERE id IN (
                                SELECT aid FROM MovieActor WHERE mid = (
                                      SELECT id FROM Movie WHERE id = $browsed_movie) )";
            $actor = mysql_query($actor_query, $db_connection);

            if ($actor) {
                print "<table border = 1>";
                // get query's number of rows
                $col_actor = mysql_num_fields($actor);

                // fetch the data
                while ($data_actorName = mysql_fetch_row($actor)) {
                  // row index
                  $i = 0;
                  print "<tr>";
                  while ($i < $col_actor) {
                    print "<td>";
                    print '<a href="BrowseActorInfo.php?&Name='.$data_actorName[$i].'">'.$data_actorName[$i].'</a><br>';
                    print "</td>";
                    // decrement the row
                    $i++;
                  }
                  print "</tr>";
                }
                print "</table>";
            
            } else {
                print "no actors participated in this movie.</br></br>";
            }
            
            
            print '<font size=4 color = "blue">';
            print "</br></br><hr/>Movie Review</br></br>";
            print '</font>';
            print '<font size=3>';
            print "Average Rating:</br>";
            print '</font>';
            
            // ranking query
            $rank_query = "SELECT AVG(rating) FROM Review WHERE mid = (
                                SELECT id FROM Movie WHERE id = $browsed_movie) GROUP BY mid";
            $rank = mysql_query($rank_query, $db_connection);

            if ($rank) {
                if ($data_rank = mysql_fetch_row($rank))
                    print $data_rank[0] . "</br></br>";
                else
                    print "no one rated the movie.</br></br>";
            }
            
            print '<font size=3>';
            print "Comments: </br>";
            print '</font>';
            
            // comment query
            $cmnt_query = "SELECT name, time, comment FROM Review WHERE mid = (
                                SELECT id FROM Movie WHERE id = $browsed_movie)";
            $cmnt = mysql_query($cmnt_query, $db_connection);
            
            if ($cmnt) {
                // get query's number of rows
                $col_cmnt = mysql_num_fields($cmnt);

                print "<table border = 1>";
                // field names
                $k = 0;
                print "<tr>";
                while ($k < $col_cmnt) {
                  // get the field name
                  $attr = mysql_field_name($cmnt, $k);
                  print "<td>";
                  print "$attr";
                  print "</td>";
                  $k++;
                }
                print "</tr>";
                
                // fetch the data
                while ($data_cmnt = mysql_fetch_row($cmnt)) {
                  // row index
                  $i = 0;
                  print "<tr>";
                  while ($i < $col_cmnt) {
                    print "<td>";
                    print "$data_cmnt[$i]";
                    print "</td>";
                    // decrement the row
                    $i++;
                  }
                  print "</tr>";
                }
                print "</table>";
            }
            
            print '<font size=3 color = "blue">';
            // link to add movie comment page.
            print '<br/>Click ';
            print '<a href="AddMovieCmnt.php?&Name=comment">here</a>';
            print ' to add your comment.';
            print '</font>';
            
            // FINISH PRINTING THE FOUND MOVIE TABLE
        } else {
            // PRINTING ALL MOVIE TABLE

            print "<table border = 1>";
            // fetch the data
            while ($data_movie = mysql_fetch_row($rs_movie)) {
              $data_mid = mysql_fetch_row($rs_mid);
              // row index
              $i = 0;
              print "<tr>";
              while ($i < $col_movie) {
                print "<td>";
                print '<a href="BrowseMovieInfo.php?&Name='.$data_mid[$i].'">'.$data_movie[$i].'</a><br>';
                print "</td>";
                // decrement the row
                $i++;
              }
              print "</tr>";
            }
            print "</table>";
            
            // FINISH PRINTING ALL MOVIE TABLE
        }

    // close db connection
    mysql_close($db_connection);

?>
