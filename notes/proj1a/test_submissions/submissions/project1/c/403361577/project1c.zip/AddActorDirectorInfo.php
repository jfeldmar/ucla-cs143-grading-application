<html>
	<body>

    <font size=4 color='blue'>
    Add actor/director information<br/>
    </font>
    <hr/>
		<form method="POST" action="AddDBQuery_AD.php">
			Job:	<input type="radio" name="job" value="Actor" checked="true">Actor
						<input type="radio" name="job" value="Director">Director<br/>
			First Name:	<input type="text" name="first" maxlength="20"><br/>
			Last Name:	<input type="text" name="last" maxlength="20"><br/>
			Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
						<input type="radio" name="sex" value="Female">Female<br/>
			Date of Birth:	(mm) <input type="text" name="dobm"> (dd) <input type="text" name="dobd"> (yyyy) <input type="text" name="doby"><br/>
			Date of Death:	(mm) <input type="text" name="dodm"> (dd) <input type="text" name="dodd"> (yyyy) <input type="text" name="dody"><br/>
			</br>
			<input type="submit" value="Add Actor/Director"/>
		</form>
		<hr/>

	</body>
</html>

