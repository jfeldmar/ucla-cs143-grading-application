<?php

    // request the inputs
    $movie = $_REQUEST["movie"];
    $user = $_REQUEST["user"];
    $rating = $_REQUEST["rating"];
    $comment = $_REQUEST["comment"];

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // escape bad characters
    $movie = mysql_real_escape_string($movie);
    $user= mysql_real_escape_string($user);
    $comment = mysql_real_escape_string($comment);

    // get the time stamp
    $time_query = "SELECT CURRENT_TIMESTAMP";
    $time_result = mysql_query($time_query, $db_connection);
    while ($data_time = mysql_fetch_row($time_result)) {
      $time = $data_time[0];
    }
    
    // add error flag
    $add_error_flag = 0;
    
    // search for the movie
    $movie_query = "SELECT id FROM Movie WHERE title = '$movie'";
    $movie_result = mysql_query($movie_query, $db_connection);
    $data_mid = mysql_fetch_row($movie_result);
    if ($data_mid)
        $mid = $data_mid[0];
    else {
        print "ERROR: movie is not found in the database.<br/>";
        $add_error_flag = 1;
    }
    
    if ($add_error_flag == 0) {
        if($comment)
            $review_query = "INSERT INTO Review VALUES('$user', '$time', $mid, $rating, '$comment')";
        else
            $review_query = "INSERT INTO Review VALUES('$user', '$time', $mid, $rating, \N)";
        if(mysql_query($review_query, $db_connection) != 1)
            $add_error_flag = 1;
    }

    if($add_error_flag == 0)
        print "Review has been added.<br/>";
    else{
        print "ERROR: failed to add the Review.<br/>";
    }


    // close db connection
    mysql_close($db_connection);

?>
