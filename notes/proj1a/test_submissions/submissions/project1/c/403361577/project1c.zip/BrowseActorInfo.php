<?php
    // request the input query
    $browsed_actor = $_REQUEST["Name"];

    // flag to indicate called by other search pages
    $calledByOther = 1;

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // escape bad characters
    $browsed_actor = mysql_real_escape_string($browsed_actor);

    // have query search for all information on any actor containing search phrase
    $actor_query = "SELECT last, first, sex, dob, dod FROM Actor WHERE '$browsed_actor' = CONCAT(first, ' ',last, ', ',dob)";
    
    // we overwrite the query to select all actor if nothing is inputted
    if ($browsed_actor == "") {
      $actor_query = "SELECT CONCAT(first, ' ',last, ', ',dob) FROM Actor";
      $calledByOther = 0;
    }
    
    print '<font size=4 color = "blue"><hr/>';
    print "Actor/Actress Information</br></br>";
    print '</font>';
    
    // run the actor query in db connection
    $rs_actor = mysql_query($actor_query, $db_connection);


        // get query's number of rows
        $col_actor = mysql_num_fields($rs_actor);
        
        // if called by other search pages.
        // 1. print attribute names
        // 2. don't hyper link results
        // else
        // 1. print out all actor name and dob
        // 2. hyper link results
        if ($calledByOther == 1) {
            // PRINTING THE FOUND ACTOR TABLE
            
            print "<table border = 1>";
            // field names
            $k = 0;
            print "<tr>";
            while ($k < $col_actor) {
              // get the field name
              $attr = mysql_field_name($rs_actor, $k);
              print "<td>";
              print "$attr";
              print "</td>";
              $k++;
            }
            print "</tr>";
            
            // fetch the data
            while ($data_actor = mysql_fetch_row($rs_actor)) {
              // row index
              $i = 0;
              print "<tr>";
              while ($i < $col_actor) {
                print "<td>";
                print "$data_actor[$i]";
                print "</td>";
                // decrement the row
                $i++;
              }
              print "</tr>";
            }
            print "</table>";
            
            print '<font size=4 color = "blue">';
            print "</br></br><hr/>Movies that the actor participated in</br></br>";
            print '</font>';

            // movie query to get the title of movies that this actor participated in
            $movie_query = "SELECT CONCAT(title, ', ', year) FROM Movie WHERE id IN (
                                SELECT mid FROM MovieActor WHERE aid IN (
                                      SELECT id FROM Actor WHERE '$browsed_actor' = CONCAT(first, ' ',last, ', ',dob) ) )";
            $movie = mysql_query($movie_query, $db_connection);
            $mid_query = "SELECT id FROM Movie WHERE id IN (
                                SELECT mid FROM MovieActor WHERE aid IN (
                                      SELECT id FROM Actor WHERE '$browsed_actor' = CONCAT(first, ' ',last, ', ',dob) ) )";
            $mid = mysql_query($mid_query, $db_connection);

            if ($movie) {

                print "<table border = 1>";

                // get query's number of rows
                $col_movie = mysql_num_fields($movie);

                // fetch the data
                while ($data_movieTitle = mysql_fetch_row($movie)) {
                  $data_mid = mysql_fetch_row($mid);
                  // row index
                  $i = 0;
                  print "<tr>";
                  while ($i < $col_movie) {
                    print "<td>";
                    print '<a href="BrowseMovieInfo.php?&Name='.$data_mid[$i].'">'.$data_movieTitle[$i].'</a><br>';
                    print "</td>";
                    // decrement the row
                    $i++;
                  }
                  print "</tr>";
                }
                print "</table>";
            
            } else {
                print "no movies were participated by this actor.</br></br>";
            }
            
            // FINISH PRINTING THE FOUND ACTOR TABLE
        } else {
            // PRINTING ALL ACTOR TABLE

            print "<table border = 1>";
            // fetch the data
            while ($data_actor = mysql_fetch_row($rs_actor)) {
              // row index
              $i = 0;
              print "<tr>";
              while ($i < $col_actor) {
                print "<td>";
                print '<a href="BrowseActorInfo.php?&Name='.$data_actor[$i].'">'.$data_actor[$i].'</a><br>';
                print "</td>";
                // decrement the row
                $i++;
              }
              print "</tr>";
            }
            print "</table>";
            
            // FINISH PRINTING ALL ACTOR TABLE
        }

    // close db connection
    mysql_close($db_connection);

?>
