<html>

<body>

<center>

<font face="Arial" size=2 color='blue'>
Welcome to Moogle Search.
</font>

<p>

<font face="Helvetica" size=2 color='blue'>
Make Moogle Your Homepage!
</font>

<p>


<font face="sans-serif" size=1>
&reg;2008 - 
</font>
<font face="sans-serif" size=1 color='blue'>
<b>Privacy</b>
</font>

</center>

</body>

</html>
