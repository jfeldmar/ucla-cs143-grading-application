<?php
  // request the input query
  $phrase = $_REQUEST["MoogleSearch"];

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // get rid of bad characters
    $phrase = mysql_real_escape_string($phrase);

    // have query search for any actor name containing search phrase + dob
    $actordob_query = "SELECT CONCAT(first, ' ',last, ', ',dob) FROM Actor WHERE first LIKE '%$phrase%' OR last LIKE '%$phrase%' OR CONCAT(first, ' ', last) = '$phrase'";
    // have query search for any movie title containing search phrase
    $movie_query = "SELECT CONCAT(title, ', ', year) FROM Movie WHERE title LIKE '%$phrase%'";
    $mid_query = "SELECT id FROM Movie WHERE title LIKE '%$phrase%'";
    
    // we overwrite the query to select all movie/actor if nothing is inputted
    if ($phrase == "") {
      //$actor_query = "SELECT CONCAT(first, ' ',last) FROM Actor";
      $actordob_query = "SELECT CONCAT(first, ' ',last, ', ',dob) FROM Actor";
      $movie_query = "SELECT CONCAT(title, ', ', year) FROM Movie";
      $mid_query = "SELECT id FROM Movie";
    }
    
    print '<font size=4 color="blue">';
    print "<hr/>Matching results for Actors . . .</br></br>";
    print '</font>';

    // run the actor query in db connection
    $rs_actordob = mysql_query($actordob_query, $db_connection);

        // PRINTING THE FOUND ACTOR TABLE

        // get query's number of rows
        $col_actor = mysql_num_fields($rs_actordob);
        
        print "<table border = 1>";
        
        // fetch the data
        while($data_actordob = mysql_fetch_row($rs_actordob)){
          // row index
          $i = 0;
          print "<tr>";
          while ($i < $col_actor) {
            print "<td>";
			      print '<a href="BrowseActorInfo.php?&Name=' . $data_actordob[$i] . '">' . $data_actordob[$i] . '</a><br>';
            print "</td>";
            // decrement the row
            $i++;
          }
          print "</tr>";
        }
        print "</table>";
        
        // FINISH PRINTING THE FOUND ACTOR TABLE

    print '<font size=4 color = "blue">';
    print "</br></br><hr/>Matching results for Movies . . .</br></br>";
    print '</font>';

    // run the movie query in db connection
    $rs_movie = mysql_query($movie_query, $db_connection);
    $rs_mid = mysql_query($mid_query, $db_connection);

        // PRINTING THE FOUND MOVIE TABLE

        // get query's number of rows
        $col_movie = mysql_num_fields($rs_movie);
        
        print "<table border = 1>";
        
        // fetch the data
        while ($data_movie = mysql_fetch_row($rs_movie)) {
          $data_mid = mysql_fetch_row($rs_mid);
          // row index
          $i = 0;
          print "<tr>";
          while ($i < $col_movie) {
            print "<td>";
			      print '<a href="BrowseMovieInfo.php?&Name=' . $data_mid[$i] . '">' . $data_movie[$i] . '</a><br>';
            print "</td>";
            // decrement the row
            $i++;
          }
          print "</tr>";
        }
        print "</table>";
        
        // FINISH PRINTING THE FOUND MOVIE TABLE

    // close db connection
    mysql_close($db_connection);

?>
