<?php

    // request the inputs
    $new_job = $_REQUEST["job"];
    $new_first = $_REQUEST["first"];
    $new_last = $_REQUEST["last"];
    $new_sex = $_REQUEST["sex"];
    $new_dobm = $_REQUEST["dobm"];
    $new_dobd = $_REQUEST["dobd"];
    $new_doby = $_REQUEST["doby"];
    $new_dodm = $_REQUEST["dodm"];
    $new_dodd = $_REQUEST["dodd"];
    $new_dody = $_REQUEST["dody"];

    // validation key on name
    $valid_name = "/^.{1,20}$/";
    // validation key on dates
    $valid_datem = "/^(0[1-9]|1[0-2])$/";
    $valid_dated = "/^(0[1-9]|[1-2][0-9]|3[0-1])$/";
    $valid_datey = "/^([1-9][0-9]{3})$/";

    // error flag
    $error_flag = 0;

    // error outputs
    if (preg_match($valid_name, $new_first) == 0) {
        print "ERROR: Invalid input on first name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_name, $new_last) == 0) {
        print "ERROR: Invalid input on last name.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_datem, $new_dobm) == 0) {
        print "ERROR: Invalid input on month for Date of Birth.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_dated, $new_dobd) == 0) {
        print "ERROR: Invalid input on day for Date of Birth.<br/>";
        $error_flag = 1;
    }
    if (preg_match($valid_datey, $new_doby) == 0) {
        print "ERROR: Invalid input on year for Date of Birth.<br/>";
        $error_flag = 1;
    }

    // date of death error flag
    $dod_error_flag = 0;
    if (preg_match($valid_datem, $new_dodm) == 0 ||
        preg_match($valid_dated, $new_dodd) == 0 ||
        preg_match($valid_datey, $new_dody) == 0)
        $dod_error_flag = 1;
    // blank inputs are fine, so set error back to 0
    if ($new_dodm == "" && $new_dodd == "" && $new_dody == "")
        $dod_error_flag = 0;
    // error output for date of death
    if ($dod_error_flag == 1) {
        print "ERROR: Invalid input on Date of Death.<br/>";
        $error_flag = 1;
    }

    // establish db connection
    $db_connection = mysql_connect("localhost", "cs143", "");
    // db connection error handling
    if(!$db_connection) {
      $errmsg = mysql_error($db_connection);
      echo "Connection failed: " . $errmsg . "<br />";
      exit(1);
    }
    // select database CS143
    mysql_select_db("CS143", $db_connection);

    // add the person if there are no error inputs
    // else create a link to go back redo the inputs
    if ($error_flag == 0) {

        // escape bad characters
        $new_first = mysql_real_escape_string($new_first);
        $new_last = mysql_real_escape_string($new_last);
    
				// add fail flag
				$add_fail_flag = 0;
				
				// get new ID for person
				$maxpid_query = "SELECT id FROM MaxPersonID";
				$maxpid = mysql_query($maxpid_query, $db_connection);
				$data_maxpid = mysql_fetch_row($maxpid);
				if (!$data_maxpid) {
            print "ERROR: Failed to get MaxPersonID.<br/>";
            $add_fail_flag = 1;
        } else {
            $newid = $data_maxpid[0] + 1;
				}
				// update max person's id
				$updatepid_query = "UPDATE MaxPersonID SET id=id+1";
				if (mysql_query($updatepid_query, $db_connection) != 1) {
            print "ERROR: Failed to update MaxPersonID.<br/>";
            $add_fail_flag = 1;
        }
				
				// add the actor/director
				if ($add_fail_flag == 0) {
            if ($new_job == "Actor") {
                if ($new_dodm == "" && $new_dodd == "" && $new_dody == "")
                    $addActor_query = "INSERT INTO Actor VALUES($newid, '$new_last', '$new_first', '$new_sex', $new_doby$new_dobm$new_dobd, \N)";
                else
                    $addActor_query = "INSERT INTO Actor VALUES($newid, '$new_last', '$new_first', '$new_sex', $new_doby$new_dobm$new_dobd, $new_dody$new_dodm$new_dodd)";
                if (mysql_query($addActor_query, $db_connection) != 1)
                    $add_fail_flag = 1;
            } else if ($new_job == "Director") {
                if ($new_dodm == "" && $new_dodd == "" && $new_dody == "")
                    $addDirector_query = "INSERT INTO Director VALUES($newid, '$new_last', '$new_first', $new_doby$new_dobm$new_dobd, \N)";
                else
                    $addDirector_query = "INSERT INTO Director VALUES($newid, '$new_last', '$new_first', $new_doby$new_dobm$new_dobd, $new_dody$new_dodm$new_dodd)";
                if (mysql_query($addDirector_query, $db_connection) != 1)
                    $add_fail_flag = 1;
            } else {
                print "ERROR: Invalid job entry.<br/>";
                $add_fail_flag = 1;
            }
				}
				
				// if failed, print error on fail to add person
				// else print confirmation on added person
				if ($add_fail_flag == 1) {
            print "ERROR: Failed to add $new_first $new_last.<br/>";
            // update max person's id
            $updatepid_query = "UPDATE MaxPersonID SET id=id-1";
            if (mysql_query($updatepid_query, $db_connection) != 1)
                print "ERROR: Failed to update MaxPersonID.<br/>";
        } else {
            print "$new_first $new_last has been added to the $new_job list.<br/>";
        }
        
        print '<font size=3 color = "blue">';
        // link to moogle search page.
        print '<br/>Click ';
        print '<a href="MoogleSearch.php?&Name=correction">here</a>';
        print " to search for the $new_job.";
        print '</font>'; 
    } else {
        print '<font size=3 color = "blue">';
        // link to add actor/director page.
        print '<br/>Browse back or click ';
        print '<a href="AddActorDirectorInfo.php?&Name=correction">here</a>';
        print ' to go back and correct the information.';
        print '</font>';
    }


    // close db connection
    mysql_close($db_connection);

?>
