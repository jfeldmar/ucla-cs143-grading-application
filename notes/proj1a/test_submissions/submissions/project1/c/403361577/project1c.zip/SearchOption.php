<html>

<base target="main">
<body>

<form method="POST" action="OptionLinker.php">

<center>
<select size="1" name="choice">
  <option selected value="MoogleSearch">Moogle Search</option>
  <option value="BrowseActorInfo">Browse Actor Information</option>
  <option value="BrowseMovieInfo">Browse Movie Information</option>
  <option value="AddActorDirectorInfo">Add Actor and/or Director Information</option>
  <option value="AddMovieCmnt">Add Movie Comments</option>
 	<option value="AddMovieInfo">Add Movie Information</option>
</select>

<INPUT TYPE="submit" VALUE="Moogle Search">
</center>

</form>

</body>

</html>

