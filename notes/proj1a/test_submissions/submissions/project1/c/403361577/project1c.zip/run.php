<html>

<head>
<title>
moogle
</title>
</head>

<frameset rows="200, 75, 500" framespacing="10" frameborder="no">

  <frame src="top.php" name="top" id="top" title="top" scrolling="no" noresize="noresize" />

  <frame src="SearchOption.php" name="SearchOption" id="SearchOption" title="SearchOption" target="main" />

  <frame src="main.php" name="main" id="main" title="main" scrolling="yes" />

</frameset>

</html>

