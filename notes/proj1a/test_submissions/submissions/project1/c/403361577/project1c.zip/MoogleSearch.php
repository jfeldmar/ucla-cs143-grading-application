<html>

<body>


<center>

<font color='blue'>
Moogle Search
</font>
<p>
Search for an actor/actress/movie.


<form method="POST" action="SearchDBQuery.php">

<center>
<input name="MoogleSearch" type="text" size="50" maxlength="100">  
</center>

<INPUT TYPE="submit" VALUE="I'm Feeling Lucky">

</form>

</center>


</body>

</html>
