<html>

  <head>
    <title>Add an Actor or Director</title>
  </head>	

  <body>
    Add a new actor or director: <br/>

    <form action="pagei1.php" method="GET">
       Identity:  <input type="checkbox" name="identity_actor" value="Actor">Actor</input>
                  <input type="checkbox" name="identity_director" value="Director">Director</input><br/>
    
    <hr/>
			
    First Name:  <input type="text" name="first" maxlength="20"><br/>
    Last Name:  <input type="text" name="last" maxlength="20"><br/>
    Sex:  <input type="radio" name="sex" value="Male" checked="true">Male
          <input type="radio" name="sex" value="Female">Female<br/>

    Date of Birth:  <input type="text" name="dob"><br/>
    Date of Death:  <input type="text" name="dod"> (If N/A, leave blank.)<br/>
		  <input type="submit" value="Submit"/><br/>
    </form>

    <?php

      if($_GET["first"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

        mysql_select_db("CS143", $db_connection);

        $identity_actor = $_GET["identity_actor"];
	$identity_director = $_GET["identity_director"];
        $first = $_GET["first"];
        $last = $_GET["last"];
        $sex = $_GET["sex"];
        $dob = $_GET["dob"];
	$dod = $_GET["dod"];

	mysql_query("UPDATE MaxPersonID SET id = id+1",$db_connection);

	$rs = mysql_query("SELECT id FROM MaxPersonID",$db_connection);

	$row = mysql_fetch_row($rs);

        if (!empty($identity_actor))
	{
	  $query = "INSERT INTO Actor VALUES (" 
	           . $row[0] . ",'" 
		   . $last . "','" 
		   . $first . "','" 
		   . $sex . "','" 
		   . $dob . "',";

	  if(empty($dod))
	    $query .= "NULL)";
	  else
 	    $query .= "'" . $dod . "')";

	  $rs = mysql_query($query,$db_connection);
	  echo mysql_error();
	}

        if (!empty($identity_director))
	{
	  $query = "INSERT INTO Director VALUES (" 
	           . $row[0] . ",'" 
		   . $last . "','" 
		   . $first . "','" 
		   . $dob . "',";
	  if(empty($dod))
	    $query .= "NULL)";
	  else
 	    $query .= "'" . $dod . "')";

	  $rs = mysql_query($query,$db_connection);
	  echo mysql_error();
	}

	mysql_close($db_connection);

	echo "Addition Complete. ";
	echo "<a href = \"pageb1.php?id=";	
	echo $row[0];
	echo "\">";
	echo "Go to the Actor/Director";
	echo "</a>";

      }
    
    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
				
  </body>

</html>