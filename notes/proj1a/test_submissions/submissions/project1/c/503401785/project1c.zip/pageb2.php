<html>

  <head>
    <title>Browse Movies</title>
  </head>

  <body>

    <?php

      if($_GET["id"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

	mysql_select_db("CS143", $db_connection);

	$id = $_GET["id"];

	$query = "SELECT title, year, rating, company FROM Movie WHERE id ="
		. $id;

	$rs = mysql_query($query, $db_connection);
	echo mysql_error();


	if($row = mysql_fetch_row($rs)) 
	{
	
	  echo "Information...";
	  echo "<br/><br/>";
	  echo "Title: ";
	  echo $row[0];
	  echo " (";
	  echo $row[1];
	  echo ")<br/>";
	  echo "Producer: ";
	  echo $row[3];
	  echo "<br/>";
	  echo "Rating: ";
	  echo $row[2];
	  echo "<br/>";
	  
	  $query2 = "SELECT did FROM MovieDirector WHERE mid = "
		. $id;

	  $rs2 = mysql_query($query2, $db_connection);
	  echo mysql_error();

	  if($row2 = mysql_fetch_row($rs2))
	  {
	    $query3 = "SELECT first, last, dob FROM Director WHERE id = "
		. $row2[0];

	    $rs3 = mysql_query($query3, $db_connection);
	    echo mysql_error();

	    if($row3 = mysql_fetch_row($rs3))
	    {
	      echo "Director: ";
	      echo "<a href = \"pageb1.php?id=";
	      echo $row2[0];
	      echo "\">";
	      echo $row3[0];
	      echo " ";
	      echo $row3[1];
	      echo "</a>";
              echo " (";
	      echo $row3[2];
	      echo ")";
	      echo "<br/>";
	    }
	  }

	  $query4 = "SELECT genre FROM MovieGenre WHERE mid = "
		. $id;

	  $rs4 = mysql_query($query4, $db_connection);
	  echo mysql_error();

	  if($row4 = mysql_fetch_row($rs4))
	  {
	    echo "Genre: ";
	    echo $row4[0];

	    while($row4 = mysql_fetch_row($rs4))
	    {
	      echo ", ";
	      echo $row4[0];
	    }
	    
	    echo "<br/>";
	  }

	  echo "<hr/>";

	  $query5 = "SELECT role, aid FROM MovieActor WHERE mid ="
		. $id;

	  $rs5 = mysql_query($query5, $db_connection);
	  echo mysql_error();

	  echo "Actors... (";
	  echo "<a href = \"pageu1.php\">";
	  echo "Add";
	  echo "</a>)";
	  echo "<br/><br/>";
	 	
          while($row5 = mysql_fetch_row($rs5)) 
	  {
	    $query6 = "SELECT first, last FROM Actor WHERE id ="
		. $row5[1];

	    $rs6 = mysql_query($query6, $db_connection);
	    echo mysql_error();

            if($row6 = mysql_fetch_row($rs6)) 
	    {
	      echo "<a href = \"pageb1.php?id=";
	      echo $row5[1];
	      echo "\">";
	      echo $row6[0];
	      echo " ";
	      echo $row6[1];
	      echo "</a>";
	      echo " as ";
	      echo $row5[0];
	      echo "<br/>";
	    }
	  }

	  echo "<hr/>";

	  $query7 = "SELECT name, time, rating, comment FROM Review WHERE mid ="
		. $id;

	  $rs7 = mysql_query($query7, $db_connection);
	  echo mysql_error();

  	  echo "Reviews...";
	  echo "<br/><br/>";

	  $query8 = "SELECT AVG(rating) FROM Review WHERE mid ="
		. $id . " GROUP BY mid";

	  $rs8 = mysql_query($query8, $db_connection);
	  echo mysql_error();

	  if($row8 = mysql_fetch_row($rs8))
	  {
	    echo "Average score: ";
	    echo $row8[0];
	    echo " (";
	    
	    $query9 = "SELECT COUNT(*) FROM Review WHERE mid ="
		. $id . " GROUP BY mid";

	    $rs9 = mysql_query($query9, $db_connection);
	    echo mysql_error();

	    $row9 = mysql_fetch_row($rs9);

	    echo $row9[0];
	    echo " reviews)";
	    echo "<br/><br/>";
	  }
	
          while($row7 = mysql_fetch_row($rs7)) 
	  {
	    echo "On ";
	    echo $row7[1];
	    echo ", ";
	    echo $row7[0];
	    echo " said: \"";
	    echo $row7[3];
	    echo "\" (";
	    echo $row7[2];
	    echo " stars)";
	    echo "<br/>";
	  }	

	  mysql_close($db_connection);  
	}

	else
	  echo "Incorrect query - please use the Search page. Thank you.";
	  
      }

    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
 
  </body>

</html>