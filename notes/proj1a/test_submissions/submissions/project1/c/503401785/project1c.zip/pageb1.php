<html>

  <head>
    <title>Browse Actors and Directors</title>
  </head>

  <body>

    <?php

      if($_GET["id"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

	mysql_select_db("CS143", $db_connection);

	$id = $_GET["id"];

	$query = "SELECT first, last, sex, dob, dod FROM Actor WHERE id ="
		. $id;

	$rs = mysql_query($query, $db_connection);
	echo mysql_error();


	if($row = mysql_fetch_row($rs)) 
	{
	
	  echo "Information...";
	  echo "<br/><br/>";
	  echo "Name: ";
	  echo $row[0];
	  echo " ";
	  echo $row[1];
	  echo "<br/>";
	  echo "Sex: ";
	  echo $row[2];
	  echo "<br/>";
	  echo "Date of Birth: ";
	  echo $row[3];
	  echo "<br/>";
	  
	  if (!empty($row[4]))
	  {
	    echo "Date of Death: ";
	    echo $row[4];
	    echo "<br/>";
	  }

	  echo "<hr/>";

	  $query2 = "SELECT role, mid FROM MovieActor WHERE aid ="
		. $id;

	  $rs2 = mysql_query($query2, $db_connection);
	  echo mysql_error();

	  echo "Roles...";
	  echo "<br/><br/>";
	 	
          while($row2 = mysql_fetch_row($rs2)) 
	  {
	    $query3 = "SELECT title FROM Movie WHERE id ="
		. $row2[1];

	    $rs3 = mysql_query($query3, $db_connection);
	    echo mysql_error();

            if($row3 = mysql_fetch_row($rs3)) 
	    {
	      echo "\"";
	      echo $row2[0];
	      echo "\" in ";
	      echo "<a href = \"pageb2.php?id=";
	      echo $row2[1];
	      echo "\">";
	      echo $row3[0];
	      echo "</a><br/>";
	    }
	  }

	  echo "<hr/>";

	  $query4 = "SELECT mid FROM MovieDirector WHERE did ="
		. $id;

	  $rs4 = mysql_query($query4, $db_connection);
	  echo mysql_error();

  	  echo "Directed...";
	  echo "<br/><br/>";
	
          while($row4 = mysql_fetch_row($rs4)) 
	  {
	    $query5 = "SELECT title FROM Movie WHERE id ="
		. $row4[0];

	    $rs5 = mysql_query($query5, $db_connection);
	    echo mysql_error();

            if($row5 = mysql_fetch_row($rs5)) 
	    {
	      echo "<a href = \"pageb2.php?id=";
	      echo $row4[0];
	      echo "\">";
	      echo $row5[0];
	      echo "</a><br/>";
	    }
	  }	  
	}


	else
	{
	  $query = "SELECT first, last, dob, dod FROM Director WHERE id ="
		. $id;

	  $rs = mysql_query($query, $db_connection);
	  echo mysql_error();

	  if($row = mysql_fetch_row($rs)) 
	  {
	    echo "Information...";
	    echo "<br/><br/>";
	    echo "Name: ";
	    echo $row[0];
	    echo " ";
	    echo $row[1];
	    echo "<br/>";
	    echo "Date of Birth: ";
	    echo $row[2];
	    echo "<br/>";
	  
	    if (!empty($row[3]))
	    {
	      echo "Date of Death: ";
	      echo $row[4];
	      echo "<br/>";
	    }

	    echo "<hr/>";


	    $query2 = "SELECT mid FROM MovieDirector WHERE did ="
		. $id;

	    $rs2 = mysql_query($query2, $db_connection);
	    echo mysql_error();

  	    echo "Directed...";
	    echo "<br/><br/>";
	 
            while($row2 = mysql_fetch_row($rs2)) 
	    {
	      $query3 = "SELECT title FROM Movie WHERE id ="
		. $row2[0];

	      $rs3 = mysql_query($query3, $db_connection);
	      echo mysql_error();

              if($row3 = mysql_fetch_row($rs3)) 
	      {
	  	echo "<a href = \"pageb2.php?id=";
	        echo $row2[0];
		echo "\">";
	        echo $row3[0];
	        echo "</a><br/>";
	      }
	    }	
	  }

	  else
	    echo "Incorrect query - please use the Search page. Thank you.";

	  mysql_close($db_connection);
	   
	}
      }

    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
 
  </body>

</html>