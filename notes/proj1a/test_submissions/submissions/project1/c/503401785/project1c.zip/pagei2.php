<html>

  <head>
    <title>Add a Comment</title>
  </head>	

  <body>
    Add a new comment: <br/>

    <form action="pagei2.php" method="GET">

    Movie:  <select name="mid">
    <?php

      $db_connection = mysql_connect("localhost", "cs143", "");

      mysql_select_db("CS143", $db_connection);

      $rs = mysql_query("SELECT title, id FROM Movie",$db_connection);

      while($row = mysql_fetch_row($rs))
      {
         echo "<option value =";
	 echo "$row[1]";
	 echo ">";
         echo "$row[0]";
         echo "</option>";
      }

      mysql_close($db_connection);

    ?>
   
    </select><br/>

    Your Name:  <input type="text" name="yourname" value="Anonymous" maxlength="20"><br/>
    Rating: <select name="rating">
      <option value="5"> 5 - Excellent </option>
      <option value="4"> 4 - Good </option>
      <option value="3"> 3 - It's O.K. </option>
      <option value="2"> 2 - Not Worth It </option>
      <option value="1"> 1 - I Hate It </option>
    </select><br/>
    Comments: <br/>
      <textarea name="comment" cols="80" rows="10"></textarea><br/>
    <input type="submit" value="Submit"/>

    </form>

    <?php

      if($_GET["yourname"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

        mysql_select_db("CS143", $db_connection);

        $mid = $_GET["mid"];
        $yourname = $_GET["yourname"];
        $rating = $_GET["rating"];
        $comment = $_GET["comment"];
	        
	$query = "INSERT INTO Review VALUES ('" 
	           . $yourname . "',Now()," 
		   . $mid . "," 
		   . $rating . ",'" 
		   . $comment . "')";
	
	$rs2 = mysql_query($query, $db_connection);
	echo mysql_error();

	mysql_close($db_connection);

	echo "Thank you for commenting! ";
	echo "<a href = \"pageb2.php?id=";
	echo $mid;
	echo "\">";
	echo "Go to the Movie";
	echo "</a>";
      }
    
    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
				
  </body>

</html>