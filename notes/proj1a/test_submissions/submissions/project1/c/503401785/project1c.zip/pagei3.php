<html>

  <head>
    <title>Add a New Movie</title>
  </head>	

  <body>
    Add a new movie: <br/>

    <form action="pagei3.php" method="GET">

    Title:  <input type="text" name="title" maxlength="20"><br/>
    Company:  <input type="text" name="company" maxlength="50"><br/>
    Year:  <input type="text" name="year" maxlength="4"><br/>	
    Director:  <select name="did">
    <?php

      $db_connection = mysql_connect("localhost", "cs143", "");

      mysql_select_db("CS143", $db_connection);

      $rs = mysql_query("SELECT first, last, id FROM Director",$db_connection);

      while($row = mysql_fetch_row($rs))
      {
         echo "<option value =";
	 echo "$row[2]";
	 echo ">";
         echo "$row[0]";
	 echo " ";
	 echo "$row[1]";
         echo "</option>";
      }

      mysql_close($db_connection);

    ?>
    </select><br/>

    MPAA Rating:  <select name="mpaarating">
      <option value="G">G</option>
      <option value="NC-17">NC-17</option>
      <option value="PG">PG</option>
      <option value="PG-13">PG-13</option>
      <option value="R">R</option>
      <option value="surrendere">surrendere</option>
    </select><br/>

    Genre:  
      <input type="checkbox" name="genre_Action" value="Action">Action</input>
      <input type="checkbox" name="genre_Adult" value="Adult">Adult</input>
      <input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input>
      <input type="checkbox" name="genre_Animation" value="Animation">Animation</input>
      <input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input>
      <input type="checkbox" name="genre_Crime" value="Crime">Crime</input>

      <input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input>

      <input type="checkbox" name="genre_Drama" value="Drama">Drama</input>

      <input type="checkbox" name="genre_Family" value="Family">Family</input>

      <input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input>

      <input type="checkbox" name="genre_Horror" value="Horror">Horror</input>

      <input type="checkbox" name="genre_Musical" value="Musical">Musical</input>

      <input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input>

      <input type="checkbox" name="genre_Romance" value="Romance">Romance</input>

      <input type="checkbox" name="genre_SciFi" value="SciFi">Sci-Fi</input>

      <input type="checkbox" name="genre_Short" value="Short">Short</input>

      <input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input>

      <input type="checkbox" name="genre_War" value="War">War</input>

      <input type="checkbox" name="genre_Western" value="Western">Western</input>
    <br/>

    <input type="submit" value="Submit"/><br/>

    </form>

    <?php

      if($_GET["title"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

        mysql_select_db("CS143", $db_connection);

        $title = $_GET["title"];
        $company = $_GET["company"];
        $year = $_GET["year"];
        $did = $_GET["did"];
        $mpaarating = $_GET["mpaarating"];

        $genre_Action = $_GET["genre_Action"];
	$genre_Adult = $_GET["genre_Adult"];
	$genre_Adventure = $_GET["genre_Adventure"];
	$genre_Animation = $_GET["genre_Animation"];
	$genre_Comedy = $_GET["genre_Comedy"];
	$genre_Crime = $_GET["genre_Crime"];
	$genre_Documentary = $_GET["genre_Documentary"];
	$genre_Drama = $_GET["genre_Drama"];
	$genre_Family = $_GET["genre_Family"];
	$genre_Fantasy = $_GET["genre_Fantasy"];
	$genre_Horror = $_GET["genre_Horror"];
	$genre_Musical = $_GET["genre_Musical"];
	$genre_Mystery = $_GET["genre_Mystery"];
	$genre_Romance = $_GET["genre_Romance"];
	$genre_SciFi = $_GET["genre_SciFi"];
	$genre_Short = $_GET["genre_Short"];
	$genre_Thriller = $_GET["genre_Thriller"];
	$genre_War = $_GET["genre_War"];
	$genre_Western = $_GET["genre_Western"];

	if(preg_match("/[a-z]/",$year))
	  echo "Invalid input.";

	else {

	mysql_query("UPDATE MaxMovieID SET id = id+1",$db_connection);

	$rs = mysql_query("SELECT id FROM MaxMovieID",$db_connection);

	$row2 = mysql_fetch_row($rs);

        $query = "INSERT INTO Movie VALUES (" 
	           . $row2[0] . ",'" 
		   . $title . "'," 
		   . $year . ",'" 
		   . $mpaarating . "','" 
		   . $company . "')";

	$rs2 = mysql_query($query, $db_connection);
	echo mysql_error();

	$query2 = "INSERT INTO MovieDirector VALUES ("
		   . $row2[0] . ","
		   . $did . ")";
	
	$rs3 = mysql_query($query2, $db_connection);
	echo mysql_error();

	if (!empty($genre_Action))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Action')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Adult))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Adult')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Adventure))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Adventure')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Animation))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Animation')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Comedy))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Comedy')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Crime))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Crime')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Documentary))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Documentary')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Drama))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Drama')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Family))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Family')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Fantasy))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Fantasy')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Horror))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Horror')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Musical))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Musical')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Mystery))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Mystery')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Romance))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Romance')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_SciFi))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Sci-Fi')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Short))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Short')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Thriller))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Thriller')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_War))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'War')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	if (!empty($genre_Western))
	{
	  $query_genre = "INSERT INTO MovieGenre VALUES ("
		      . $row2[0] . ",'Western')";
	  $rs_genre = mysql_query($query_genre, $db_connection);
	  echo mysql_error();
	}

	echo "Addition Complete. ";
	echo "<a href = \"pageb2.php?id=";
	echo $row2[0];
	echo "\">";
	echo "Go to the Movie";
	echo "</a>";

	}

	mysql_close($db_connection);
      }
    
    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
				
  </body>

</html>