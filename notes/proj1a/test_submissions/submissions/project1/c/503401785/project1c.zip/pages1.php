<html>

  <head>
    <title>Search Actors, Movies and Directors</title>
  </head>

  <body>

    <form action="pages1.php" method="GET">
    Search:  <input type="text" name="target" maxlength="20"><br/>
    <input type = "submit" value="Search">
    </form>
    <br />

    <?php

      if($_GET["target"])
      {
        $db_connection = mysql_connect("localhost", "cs143", "");

	mysql_select_db("CS143", $db_connection);

	$target = $_GET["target"];

	$query = "SELECT DISTINCT first, last, dob, id FROM Actor WHERE first LIKE '%"
		. $target . "%' OR last LIKE '%"
		. $target . "%'";

	$rs = mysql_query($query, $db_connection);
	echo mysql_error();
	
	echo "Actors:";
	echo "<br/>";

	while($row = mysql_fetch_row($rs)) 
	{
	  echo "<a href=\"pageb1.php?id=";
	  echo $row[3];
	  echo "\">";
	  echo $row[0];
	  echo " ";
	  echo $row[1];
	  echo "</a>";
	  echo " (";
	  echo $row[2];
	  echo ")";
	  echo "<br/>";
	}

	$query2 = "SELECT DISTINCT title, year, id FROM Movie WHERE title LIKE '%"
		. $target . "%'";

	$rs2 = mysql_query($query2, $db_connection);
	echo mysql_error();

	echo "Movies:";
	echo "<br/>";

	while($row2 = mysql_fetch_row($rs2)) 
	{
	  echo "<a href=\"pageb2.php?id=";
	  echo $row2[2];
	  echo "\">";
	  echo $row2[0];
	  echo "</a>";
	  echo " (";
	  echo $row2[1];
	  echo ")";
	  echo "<br/>";
	}

	$query3 = "SELECT DISTINCT first, last, dob, id FROM Director WHERE first LIKE '%"
		. $target . "%' OR last LIKE '%"
		. $target . "%'";

	$rs3 = mysql_query($query3, $db_connection);
	echo mysql_error();

	echo "Directors:";
	echo "<br/>";

	while($row3 = mysql_fetch_row($rs3)) 
	{
	  echo "<a href=\"pageb1.php?id=";
	  echo $row3[3];
	  echo "\">";
	  echo $row3[0];
	  echo " ";
	  echo $row3[1];
	  echo "</a>";
	  echo " (";
	  echo $row3[2];
	  echo ")";
	  echo "<br/>";
	}

	mysql_close($db_connection);
      }

    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
 
  </body>

</html>