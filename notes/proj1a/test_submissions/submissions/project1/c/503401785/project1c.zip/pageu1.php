<html>

  <head>
    <title>Update a Movie</title>
  </head>

  <body>

    <?php

        $db_connection = mysql_connect("localhost", "cs143", "");

	mysql_select_db("CS143", $db_connection);

	echo "<form action=\"pageu1.php\" method=\"GET\">";

	echo "Movie: ";
	echo "<select name=\"mid\">";

	$rs = mysql_query("SELECT title, id FROM Movie", $db_connection);
	echo mysql_error();

	while($row = mysql_fetch_row($rs))
	{
	    echo "<option value = ";
	    echo $row[1];
	    echo ">";
	    echo $row[0];
	    echo "</option>";
	}

	echo "</select><br/>";

	  echo "Actor: ";
	  echo "<select name=\"aid\">";

	  $rs2 = mysql_query("SELECT first, last, id FROM Actor", $db_connection);

	  while($row2 = mysql_fetch_row($rs2))
	  {
	    echo "<option value = ";
	    echo $row2[2];
	    echo ">";
	    echo $row2[0];
	    echo " ";
	    echo $row2[1];
	    echo "</option>";
	  }

	  echo "</select><br/>";

	  echo "Role: ";
	  echo "<input type=\"text\" name=\"role\" maxlength=\"50\"><br/>";
	  echo "<input type=\"submit\" value=\"Submit\"/><br/>";
	  echo "</form>";

	  if($_GET["mid"])
	  {
	    $mid = $_GET["mid"];
	    $aid = $_GET["aid"];
	    $role = $_GET["role"];

	    $query3 = "INSERT INTO MovieActor VALUES ("
			. $mid . ","
			. $aid . ",'"
			. $role . "')";

	    $rs3 = mysql_query($query3, $db_connection);
	    echo mysql_error();

	    echo "Update Complete. ";

	    echo "<a href = \"pageb2.php?id=";
	    echo $mid;
	    echo "\">";
	    echo "Go to the Movie";
	    echo "</a>";

	  }

	  mysql_close($db_connection);
	


    ?>

    <hr/>

    Add:   <a href="pagei1.php">Actor or Director</a>   <a href="pagei2.php">Movie Comments</a>   <a href="pagei3.php">Movie Information</a><br/>
    Search:   <a href="pages1.php">Actor/Director or Movie</a><br/>
 
  </body>

</html>