<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<link rel="stylesheet" type="text/css" href="stylesheet.css" />
<title>Fresh Tomatoes</title>
</head>
<body>
<div id="container">
<div id="logo"><img src="freshtomatoes.gif"></div>
<div id="navigation"><?php include 'navigation.php'; ?></div>
<div id="left"><?php include 'left.php'; ?></div>
<div id="content">
<div id="search"><?php include 'search.php'; ?></div>