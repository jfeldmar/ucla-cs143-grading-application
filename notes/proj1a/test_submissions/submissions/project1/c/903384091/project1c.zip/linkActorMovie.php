<?php include 'top.php';
# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


?>
<form action="linkActorMovie.php" method="POST">
<div id="apcontainer">
<h3 style="text-align:center" >Link Actor with Movie</h3>
<div class="input">Actor: <select name="actor">
<?php
$rs = mysql_query("SELECT id, last, first, dob FROM Actor ORDER BY last", $db_connection);
while($row = mysql_fetch_row($rs))
{
	echo "<option value=\"$row[0]\" ";
	if ($row[0] == $_POST["actor"])
		echo "selected ";
	echo "/>$row[1], $row[2] (Birthdate: $row[3])";
}
?>
</select></div>
<div class="input">Movie: <select name="movie">
<?php
$rs = mysql_query("SELECT id, title FROM Movie ORDER BY title;", $db_connection);
while($row = mysql_fetch_row($rs))	
{
	echo "<option value=\"$row[0]\" ";
	if ($row[0] == $_POST["movie"])
			echo "selected ";
	echo "/>$row[1]";
}
?>
</select></div>
<div class="input">Role: <input type="text" name="role" maxlength="50" /></div>
<div class="input"><input type="submit" value="Submit" /></div>
<input type="hidden" name="process" />
</div>
</form>

<?php
if (isset($_POST["process"]))
{	
	# Get input values
	$actor = $_POST["actor"];
	$movie = $_POST["movie"];
	$role = $_POST["role"];
	
	if (empty($role))
	{
		echo "Please specify a role.<br />";
		$err = true;
	}
	if (!$err)
	{	
		# Add review
		mysql_query("INSERT INTO MovieActor VALUES($movie, $actor, \"$role\");", $db_connection);
		
		echo "<p>Your form has successfully been submitted!</p><p><a href=\"showMovieInfo.php?mid=$movie\">Show movie information,</a> or <a href=\"showActorInfo.php?aid=$actor\">show actor information,</a></p>";
	}
}
	
# Close database
mysql_close($db_connection);

?>

</div>

</body>
</html>