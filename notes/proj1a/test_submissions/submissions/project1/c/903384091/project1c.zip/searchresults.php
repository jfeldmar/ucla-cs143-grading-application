<?php include 'top.php'; ?>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_POST["processSearch"]))
{
	# Get input values
	$adm = $_POST["adm"];
	$search = $_POST["search"];

	switch($adm)
	{
		case "Actor":
			$query = "SELECT id, first, last, dob FROM Actor WHERE last LIKE '%$search%' OR first LIKE '%$search%' OR CONCAT(first, ' ', last) LIKE '%$search%' OR CONCAT(last, ' ', first) LIKE '%$search%' ORDER BY last;";
			break;
		case "Director":
			$query = "SELECT id, first, last, dob FROM Director WHERE last LIKE '%$search%' OR first LIKE '%$search%' OR CONCAT(first, ' ', last) LIKE '%$search%' OR CONCAT(last, ' ', first) LIKE '%$search%' ORDER BY last;";
			break;
		case "Movie":
			$query = "SELECT id, title, year FROM Movie WHERE title LIKE '%$search%' ORDER BY year DESC;";
			break;
		case "Actor and Movie":
			$query = "SELECT id, first, last, dob FROM Actor WHERE last LIKE '%$search%' OR first LIKE '%$search%' OR CONCAT(first, ' ', last) LIKE '%$search%' OR CONCAT(last, ' ', first) LIKE '%$search%' ORDER BY last;";
			$query2 = "SELECT id, title, year FROM Movie WHERE title LIKE '%$search%' ORDER BY year DESC;";
			break;
		case "Company":
			$query = "SELECT DISTINCT(company) FROM Movie WHERE company LIKE '%$search%' ORDER BY company;";
			break;
	}
	
	# Send the query to MySQL
	$rs = mysql_query($query, $db_connection);
	
	if ($adm == "Actor and Movie")
		$rs2 = mysql_query($query2, $db_connection);

	$numRows = mysql_num_rows($rs);
	
	if ($adm == "Actor and Movie")
	{
		$numRows2 = mysql_num_rows($rs2);
		if ($numRows == 0)
			echo "Sorry, no actors found.<br />";
		if ($numRows2 == 0)
			echo "Sorry, no movies found.";
		if ($numRows != 0 && $numRows < 1000)
		{
		echo "Your search returned $numRows actor(s)";
		if ($numRows2 != 0 && $numRows2 < 1000)
			echo " and $numRows2 movie(s)";
		echo ".";
		echo "<h3>Actors:</h3>";
		
		# Retrieve results
		$i = 1;
		while($row = mysql_fetch_row($rs)) {
		
			echo "<p>$i. <a href=\"showActorInfo.php?aid=$row[0]\">$row[1] $row[2]</a><br />Date of birth: $row[3]";
			$i++;
		}
		}
		if ($numRows2 != 0 && $numRows2 < 1000)
		{
		echo "<h3>Movies:</h3>";
		
		# Retrieve results
		$i = 1;
		while($row = mysql_fetch_row($rs2)) {
			echo "<p>$i. <a href=\"showMovieInfo.php?mid=$row[0]\">$row[1]</a> ($row[2])";
			$i++;
		}
		}
	}
	else if ($numRows == 0)
		echo "Sorry, none found.";
	else if ($numRows != 0 && $numRows < 1000)
	{	
		echo "Your search returned $numRows result(s).";
		
		# Retrieve results
		$i = 1;
		while($row = mysql_fetch_row($rs)) {
		
			echo "<p>$i. ";
			switch($adm)
			{
				case "Actor":
					echo "<a href=\"showActorInfo.php?aid=$row[0]\">$row[1] $row[2]</a><br />Date of birth: $row[3]";
					break;
				case "Director":
					echo "<a href=\"showDirectorInfo.php?did=$row[0]\">$row[1] $row[2]</a><br />Date of birth: $row[3]";
					break;
				case "Movie":
					echo "<a href=\"showMovieInfo.php?mid=$row[0]\">$row[1]</a> ($row[2])<br />";
					break;
				case "Company":
					echo "<a href=\"showCompanyInfo.php?company=$row[0]\">$row[0]</a><br />";
					break;
			}	
			echo "</p>";
			$i++;
		}
	}
	else
	{
		echo "Your search found too many results. Please narrow your search.";
	}
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>