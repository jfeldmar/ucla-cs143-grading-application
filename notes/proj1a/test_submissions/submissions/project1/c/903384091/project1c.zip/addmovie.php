<?php include 'top.php'; 
# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);

$rs = mysql_query("SELECT id, last, first, dob FROM Director ORDER BY last;", $db_connection);
?>
 <form action="addmovie.php" method="POST">
<h2 style="text-align:center" >Add Movie</h3>
<div class="input">Title: <input type="text" name="title" maxlength="100" value="<?php echo $_POST["title"]?>" /></div>
<div class="input">Year: <select name="year"><option /><?php for($i=2008;$i>=1800;$i--){echo "<option "; if ($_POST["year"] == $i) echo "selected"; echo "/>$i";} ?></select></div>
<div class="input">Director <select name="director"><option />
<?php
while($row = mysql_fetch_row($rs))
{
echo "<option value=\"$row[0]\" ";
if ($_POST["director"] == $row[0]) echo "selected";
echo "/>$row[1], $row[2] (Birth: $row[3])";
}
?>
</select> <span style="font-weight:normal;font-size:8pt;"><br />Not listed? Add a <a href="addpeople.php">director</a></span>.</div>
<div class="input">Rating: <select name="rating"><option /><option <?php $r = $_POST["rating"]; if ($r == "G") echo "selected "; ?>/>G<option <?php if ($r == "PG") echo "selected "; ?>/>PG<option <?php if ($r == "PG-13") echo "selected "; ?>/>PG-13<option <?php if ($r == "NC-17") echo "selected "; ?>/>NC-17<option <?php if ($r == "R") echo "selected "; ?>/>R</select></div>
<div class="input">Company: <input type="text" name="company" maxlength="50" value="<?php echo $_POST["company"]?>" /></div>
<div class="input">Genre (Check all that apply):
<div style="float:left;width:25%"><input type="checkbox" name="genre_Adult" value="Adult">Adult</input><br />
<input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input><br />
<input type="checkbox" name="genre_Animation" value="Animation">Animation</input><br />
<input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input><br />
<input type="checkbox" name="genre_Crime" value="Crime">Crime</input></div>
<div style="float:left;width:25%"><input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input><br />
<input type="checkbox" name="genre_Drama" value="Drama">Drama</input><br />
<input type="checkbox" name="genre_Family" value="Family">Family</input><br />
<input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input><br />
<input type="checkbox" name="genre_Horror" value="Horror">Horror</input></div>
<div style="float:left;width:25%"><input type="checkbox" name="genre_Musical" value="Musical">Musical</input><br />
<input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input><br />
<input type="checkbox" name="genre_Romance" value="Romance">Romance</input><br />
<input type="checkbox" name="genre_Sci-Fi" value="Sci-Fi">Sci-Fi</input><br />
<input type="checkbox" name="genre_Short" value="Short">Short</input></div>
<div style="float:right;width:25%"><input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input><br />
<input type="checkbox" name="genre_War" value="War">War</input><br />
<input type="checkbox" name="genre_Western" value="Western">Western</input></div>
</div>
<div style="clear:both"><input type="submit" value="Submit" id="submit" /></div></div>
<input type="hidden" name="process">
</form>

<?php
if (isset($_POST["process"]))
{
	# Get input values
	$title = $_POST["title"];
	$year = $_POST["year"];
	$rating = $_POST["rating"];
	$company = $_POST["company"];
	$director = $_POST["director"];
	
	if (empty($title))
	{
		echo "Please specify the title of the movie.<br />";
		$err = true;
	}
	if (empty($year))
	{
		echo "Please specify the movie's year.<br />";
		$err = true;
	}
	if (empty($director))
	{
		echo "Please specify a director.<br />";
		$err = true;
	}
	if (empty($company))
	{
		echo "Please specify the movie's company.<br />";
		$err = true;
	}
	if (!$err)
	{	
		# Get id
		$rs = mysql_query("SELECT id FROM MaxMovieID", $db_connection);
		$row = mysql_fetch_row($rs);
		$id = $row[0];
		$id++;
	
		# Update number of people
		mysql_query("UPDATE MaxMovieID SET id=$id", $db_connection);
		
		# Link movie with director
		mysql_query("INSERT INTO MovieDirector VALUES($id,$director);", $db_connection);
		
		# Add the movie into the database
		mysql_query("INSERT INTO Movie VALUES($id, \"$title\", $year, \"$rating\", \"$company\");", $db_connection);
		
		# Add the movie's genre(s)
		if (isset($_POST["genre_Adventure"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Adventure\");", $db_connection);
		if (isset($_POST["genre_Animation"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Animation\");", $db_connection);
		if (isset($_POST["genre_Comedy"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Comedy\");", $db_connection);
		if (isset($_POST["genre_Crime"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Crime\");", $db_connection);
		if (isset($_POST["genre_Documentary"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Documentary\");", $db_connection);
		if (isset($_POST["genre_Drama"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Drama\");", $db_connection);
		if (isset($_POST["genre_Family"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Family\");", $db_connection);
		if (isset($_POST["genre_Fantasy"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Fantasy\");", $db_connection);
		if (isset($_POST["genre_Horror"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Horror\");", $db_connection);
		if (isset($_POST["genre_Musical"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Musical\");", $db_connection);
		if (isset($_POST["genre_Mystery"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Mystery\");", $db_connection);
		if (isset($_POST["genre_Romance"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Romance\");", $db_connection);
		if (isset($_POST["genre_Sci-Fi"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Sci-Fi\");", $db_connection);
		if (isset($_POST["genre_Short"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Short\");", $db_connection);
		if (isset($_POST["genre_Thriller"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Thriller\");", $db_connection);
		if (isset($_POST["genre_War"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"War\");", $db_connection);
		if (isset($_POST["genre_Western"])) mysql_query("INSERT INTO MovieGenre VALUES($id,\"Western\");", $db_connection);
		
		echo "Your form has successfully been submitted!";
	}
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>