<?php include 'top.php'; ?><form action="addcomments.php" method="POST">
<div id="apcontainer">
<h3 style="text-align:center" >Actors</h3>
<div class="input">First name: <input type="text" name="first" /></div>
<div class="input">Last name: <input type="text" name="last" /></div>
<div class="input">Name of movie: <input type="text" name="movie" /></div>
<div class="input">Rating: <input type="text" name="rating" /></div>
<div class="input">Comments: <textarea name="comments"></textarea></div>
<div class="input"><input type="submit" value="Clear" /><input type="submit" value="Submit" /></div>
</div>
</form>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_POST["process"]))
{
	# Get input values
	$title = $_POST["title"];
	$year = $_POST["year"];
	$rating = $_POST["rating"];
	$company = $_POST["company"];
	
	if (empty($title))
	{
		echo "Please specify the title of the movie.<br />";
		$err = true;
	}
	if (empty($year))
	{
		echo "Please specify the movie's year.<br />";
		$err = true;
	}
	if (empty($company))
	{
		echo "Please specify the movie's company.<br />";
		$err = true;
	}
	if (!$err)
	{	
		# Get id
		$rs = mysql_query("SELECT id FROM MaxMovieID", $db_connection);
		$row = mysql_fetch_row($rs);
		$id = $row[0];
		$id++;
	
		# Update number of people
		mysql_query("UPDATE MaxMovieID SET id=$id", $db_connection);
		
		# Add the movie into the database
		mysql_query("INSERT INTO Movie VALUES($id, \"$title\", $year, \"$rating\", \"$company\");", $db_connection);
		
		echo "Your form has successfully been submitted!";
	}
}
	
# Close database
mysql_close($db_connection);

?>

	</div>
</div>

</body>
</html>