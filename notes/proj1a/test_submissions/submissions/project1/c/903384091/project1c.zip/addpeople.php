<?php include 'top.php'; ?>
<form action="addpeople.php" method="POST">
<h2 style="text-align:center" >Add Actor or Director</h3>
<div class="input">First name: <input type="text" name="first" maxlength="20" value="<?php echo $_POST["first"]?>" /></div>
<div class="input">Last name: <input type="text" name="last" maxlength="20" value="<?php echo $_POST["last"]?>" /></div>
<div class="input">Sex: <input type="radio" name="sex" value="Male" <?php if ($_POST["sex"] == "Male") echo "checked"; ?> /> Male <input type="radio" name="sex" value="Female" <?php if ($_POST["sex"] == "Female") echo "checked"; ?> />Female</div>
<div class="input">Date of birth (Month/Day/Year): <select name="dobmonth"><option /><?php for($i=1;$i<13;$i++){echo "<option "; if ($_POST["dobmonth"] == $i) echo "selected "; echo "/>"; if ($i<10) echo "0"; echo "$i";} ?></select><select name="dobday"><option /><?php for($i=1;$i<32;$i++){echo "<option "; if ($_POST["dobday"] == $i) echo "selected "; echo "/>"; if ($i<10) echo "0"; echo "$i";}?></select><select name="dobyear"><option /><?php for($i=2008;$i>=1800;$i--){echo "<option "; if ($_POST["dobyear"] == $i) echo "selected "; echo "/>$i";}?></select></div>
<div class="input">Dead? <input type="radio" name="dead" value="yes" <?php if ($_POST["dead"] == "yes") echo "checked"; ?>/> Yes <input type="radio" name="dead" value="no" <?php if ($_POST["dead"] == "no") echo "checked"; ?> /> No</div>
<div class="input">If yes, date of death (Month/Day/Year): <select name="dodmonth"><option /><?php for($i=1;$i<13;$i++){echo "<option "; if ($_POST["dodmonth"] == $i) echo "selected "; echo "/>"; if ($i<10) echo "0"; echo "$i";} ?></select><select name="dodday"><option /><?php for($i=1;$i<31;$i++){echo "<option "; if ($_POST["dodday"] == $i) echo "selected "; echo "/>"; if ($i<10) echo "0"; echo "$i";} ?></select><select name="dodyear"><option /><?php for($i=2008;$i>1800;$i--){echo "<option "; if ($_POST["dodday"] == $i) echo "selected "; echo "/>"; if ($i<10) echo "0"; echo "$i";} ?></select></div>
<div class="input"><input type="radio" name="aod" value="actor" <?php if ($_POST["aod"] == "actor") echo "checked"; ?> /> Actor <input type="radio" name="aod" value="director" <?php if ($_POST["aod"] == "director") echo "checked"; ?> /> Director</div>
<input type="submit" value="Submit" id="submit" /></div>
<input type="hidden" name="process">
</form>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_POST["process"]))
{
	# Get input values
	$first = $_POST["first"];
	$last = $_POST["last"];
	$sex = $_POST["sex"];
	$dobmonth = $_POST["dobmonth"];
	$dobday = $_POST["dobday"];
	$dobyear = $_POST["dobyear"];
	$dead = $_POST["dead"];
	$dodmonth = $_POST["dodmonth"];
	$dodday = $_POST["dodday"];
	$dodyear = $_POST["dodyear"];
	$aod = $_POST["aod"];
	
	if (empty($first))
	{
		echo "First name is required!<br />";
		$err = true;
	}
	if (empty($last))
	{
		echo "Last name is required!<br />";
		$err = true;
	}
	if (!empty($aod) && $aod == "actor" && empty($sex))
	{
		echo "Please specify a sex.<br />";
		$err = true;
	}
	if (empty($dobmonth) || empty($dobday) || empty($dobyear))
	{
		echo "Please specify a date of birth!<br />";
		$err = true;
	}
	if (empty($dead))
	{
		echo "Please specify if this individual is dead!<br />";
		$err = true;
	}
	else if ($dead == "yes" && (empty($dodmonth) || empty($dodday) || empty($dodyear)))
	{
		echo "Please specify a date of death!<br />";
		$err = true;
	}
	if (empty($aod))
	{
		echo "Please specify whether this individual is an actor or a director!";	
		$err = true;
	}
	if (!$err)
	{
		$dob = "$dobyear" . "$dobmonth" . "$dobday";
		if ($dead == "yes")
			$dod = "$dodyear" . "$dodmonth" . "$dodday";
		else
			$dod = "\\N";
		
		# Get id
		$rs = mysql_query("SELECT id FROM MaxPersonID", $db_connection);
		$row = mysql_fetch_row($rs);
		$id = $row[0];
		$id++;
		
		if ($aod == "actor")
			$query = "INSERT INTO Actor VALUES($id, \"$last\", \"$first\", \"$sex\", $dob, $dod);";
		else if ($aod == "director")
			$query = "INSERT INTO Director VALUES($id, $last, $first, $dob, $dod);";
	
		# Update number of people
		mysql_query("UPDATE MaxPersonID SET id=$id", $db_connection);
		
		# Add the actor or director
		mysql_query($query, $db_connection);
		
		echo "Your form has successfully been submitted!";
	}
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>