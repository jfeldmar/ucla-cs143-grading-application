<?php include 'top.php'; ?>

<form action="index.php" method="POST">
<div id="apcontainer">
<div class="input">Browse <select name="am"><?php echo "<option "; if ($_POST["am"] == "Actors") echo "selected "; echo "/>"; ?>Actors<?php echo "<option "; if ($_POST["am"] == "Movies") echo "selected "; echo "/>"; ?>Movies</select> starting with <select name="letter"><?php for ($i = 'A'; $i < 'Z'; $i++) echo "<option value=\"^$i\"/>$i"; ?><option value="^z" />Z<option value="^[0-9]"/>Number<option value="^[[:punct:]]" />Punctuation</select> <input type="submit" value="Submit" /></div>
</div>
<input type="hidden" name="process">
</form>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_POST["process"]))
{
	# Get input values
	$am = $_POST["am"];
	$letter = strtolower($_POST["letter"]);
	
	# Send the query to MySQL
	if ($am == "Actors")
		$query = "SELECT id, first, last, dob FROM Actor WHERE last REGEXP '$letter' ORDER BY last;";
	else
		$query = "SELECT id, title, year FROM Movie WHERE title REGEXP '$letter' ORDER BY title ASC;";
		
	$rs = mysql_query($query, $db_connection);
	
	echo "There are " . mysql_num_rows($rs) . " results.";
	
	echo "<ul>";
	
	# Retrieve results
	$i = 1;
	while($row = mysql_fetch_row($rs))
	{
		echo "<li><p>$i. ";
		switch($am)
		{
			case "Actors":
				echo "<a href=\"showActorInfo.php?aid=$row[0]\">$row[1] $row[2]</a><br />Date of birth: $row[3]";
				break;
			case "Movies":
				echo "<a href=\"showMovieInfo.php?mid=$row[0]\">$row[1]</a> ($row[2])<br />";
				break;
		}	
		echo "</p>";
		$i++;
	}
	
	echo "</ul>";
}
	
# Close database
mysql_close($db_connection);

?>

</div>

</body>
</html>
