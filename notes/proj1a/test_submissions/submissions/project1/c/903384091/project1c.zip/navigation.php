<link rel="stylesheet" type="text/css" href="navigation.css" />

<ul>
<li><a href="index.php" class="navigation">Browse</a></li>
<li><a href="addpeople.php" class="navigation">Add actor or director</a></li>
<li><a href="addmovie.php" class="navigation">Add movie</a></li>
<li><a href="addcomments.php" class="navigation">Add a review</a></li>
<li><a href="linkActorMovie.php" class="navigation">Link actor with movie</a></li>
<li><a href="linkDirectorMovie.php" class="navigation">Link director with movie</a></li>
</ul>