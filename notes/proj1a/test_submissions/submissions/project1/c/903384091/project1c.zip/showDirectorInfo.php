<?php include 'top.php'; ?>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_GET["did"]))
{
	# Get input values
	$did = $_GET["did"];
	
	# Send the query to MySQL
	$rs = mysql_query("SELECT first, last, dob, dod FROM Director WHERE id=$did", $db_connection);
	$row = mysql_fetch_row($rs);
	echo "<p>Director: $row[0] $row[1]<br />Date of birth: $row[2]";
	if (!empty($row[3]))
		echo "<br />Date of death: $row[3]";
	echo "</p>";
	
	# Send the query to MySQL
	echo "<p>Movies directed:<br />";
	$rs = mysql_query("SELECT id, title FROM Movie,(SELECT * FROM MovieDirector WHERE did=$did) M WHERE id=M.mid", $db_connection);
	while ($row = mysql_fetch_row($rs))
	{
		echo "<a href=\"showMovieInfo.php?mid=$row[0]\">$row[1]</a><br />";
	}
	echo "</p>";
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>