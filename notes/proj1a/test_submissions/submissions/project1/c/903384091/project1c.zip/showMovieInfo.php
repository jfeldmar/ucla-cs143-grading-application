<?php include 'top.php'; ?>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_GET["mid"]))
{
	# Get input values
	$mid = $_GET["mid"];
	
	# Send the query to MySQL
	$rs = mysql_query("SELECT title, year, rating, company FROM Movie WHERE id=$mid", $db_connection);
	$row = mysql_fetch_row($rs);
	echo "<p>Movie: $row[0]<br />Year: $row[1]<br />MPAA Rating: $row[2]<br />Company: $row[3]<br />Genre(s): ";
	
	$rs = mysql_query("SELECT genre FROM MovieGenre WHERE mid=$mid", $db_connection);
	$numRows = mysql_num_rows($rs);
	$i = 1;
	while ($row = mysql_fetch_row($rs))
	{
		echo $row[0];
		if ($i < $numRows)
		{
			echo ", ";
			$i++;
		}
	}
	
	echo "</p>";
	# Send the query to MySQL
	echo "<p>Directed by:<br />";
	$rs = mysql_query("SELECT id, first, last FROM Director,(SELECT did FROM MovieDirector WHERE mid=$mid) M WHERE id=M.did", $db_connection);
	while ($row = mysql_fetch_row($rs))
	{
		echo "<a href=\"showDirectorInfo.php?did=$row[0]\">$row[1] $row[2]</a><br />";
	}
	echo "</p>";
	
	# Send the query to MySQL
	echo "<p>Actors:<br />";
	$rs = mysql_query("SELECT id, first, last, M.role FROM Actor,(SELECT aid, role FROM MovieActor WHERE mid=$mid) M WHERE id=M.aid", $db_connection);
	while ($row = mysql_fetch_row($rs))
	{
		echo "<a href=\"showActorInfo.php?aid=$row[0]\">$row[1] $row[2]</a> as \"$row[3]\"<br />";
	}
	echo "</p>";
	
	# Reviews
	echo "<p>Reviews:<br />";
	$rs = mysql_query("SELECT name, time, rating, comment FROM Review WHERE mid=$mid ORDER BY time DESC;", $db_connection);
	if (mysql_num_rows($rs) == 0)
		echo "No reviews, yet.";
	else
	{
		$ratingResult = mysql_query("SELECT AVG(rating) FROM Review WHERE mid=$mid", $db_connection);
		$ratingResult = mysql_fetch_row($ratingResult);
		echo "Average rating: $ratingResult[0]";
	}
	while ($row = mysql_fetch_row($rs))
	{
		echo "<p>Name: $row[0]<br />Time: $row[1]<br />Rating: $row[2]/5<br />Comments: $row[3]</p>";
	}
	echo "</p>";
	
	# Add a review
	echo "<p><a href=\"addcomments.php?mid=$mid\">Add a review</a></p>";
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>