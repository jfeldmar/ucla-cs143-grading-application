<?php include 'top.php'; ?>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_GET["company"]))
{
	# Get input values
	$company = $_GET["company"];
	
	echo "<p>Company: $company<br />Movies:<br />";
	
	# Send the query to MySQL
	$rs = mysql_query("SELECT id, UNIQUE(title), year FROM Movie WHERE company='$company' ORDER BY year DESC", $db_connection);
	while ($row = mysql_fetch_row($rs))
	{
		echo "<a href=\"showMovieInfo.php?mid=$row[0]\">$row[1] ($row[2])</a><br />";
	}
	
	echo "</p>";
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>