<?php include 'top.php'; ?>

<?php

# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);


if (isset($_GET["aid"]))
{
	# Get input values
	$aid = $_GET["aid"];
	
	# Send the query to MySQL
	$rs = mysql_query("SELECT first, last, sex, dob, dod FROM Actor WHERE id=$aid", $db_connection);
	$row = mysql_fetch_row($rs);
	echo "<p>Actor: $row[0] $row[1]<br />Sex: $row[2]<br />Date of birth: $row[3]";
	if (!empty($row[4]))
		echo "<br />Date of death: $row[4]";
	echo "</p>";
	
	# Send the query to MySQL
	echo "<p>Acted in:<br />";
	$rs = mysql_query("SELECT M.role,title,id FROM Movie,(SELECT mid, role FROM MovieActor WHERE aid=$aid) M WHERE id=M.mid", $db_connection);
	while ($row = mysql_fetch_row($rs))
	{
		echo "\"$row[0]\" in <a href=\"showMovieInfo.php?mid=$row[2]\">$row[1]</a><br />";
	}
	echo "</p>";
}
	
# Close database
mysql_close($db_connection);

?>

<?php include 'bottom.php'; ?>