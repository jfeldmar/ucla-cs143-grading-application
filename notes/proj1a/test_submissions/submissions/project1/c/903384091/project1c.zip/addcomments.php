<?php include 'top.php';
# Open connection to database
$db_connection = mysql_connect("localhost", "cs143", "");

# Exit if connection cannot be established
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: $errmsg <br />";
    exit(1);
}

# Select database
mysql_select_db("CS143", $db_connection);

$rs = mysql_query("SELECT id, title FROM Movie ORDER BY title;", $db_connection);
?>
<form action="addcomments.php" method="POST">
<div id="apcontainer">
<h3 style="text-align:center" >Add a Review</h3>
<div class="input">Name: <input type="text" name="name" maxlength="20" value="<?php echo $_POST["name"]; ?>" /></div>
<div class="input">Movie: <select name="movie"><option />
<?php
while($row = mysql_fetch_row($rs))	
{
echo "<option value=\"$row[0]\" ";
if ($_GET["mid"] == $row[0]) echo "selected";
echo "/>$row[1]";
}
?>
</select></div>
<div class="input">Rating: <select name="rating"><option /><option />5<option />4<option />3<option />2<option />1</select></div>
<div class="input"><span style="vertical-align:top">Comments:</span> <textarea name="comments" maxlength="500"><?php echo $_POST["comments"]; ?></textarea></div>
<div class="input"><input type="submit" value="Submit" /></div>
<input type="hidden" name="process" />
</div>
</form>

<?php
if (isset($_POST["process"]))
{	
	# Get input values
	$name = $_POST["name"];
	$movie = $_POST["movie"];
	$rating = $_POST["rating"];
	$comments = $_POST["comments"];
	
	if (empty($name))
	{
		echo "Please specify your name.<br />";
		$err = true;
	}
	if (empty($movie))
	{
		echo "Please specify a movie.<br />";
		$err = true;
	}
	if (empty($rating))
	{
		echo "Please provide a rating for the movie.<br />";
		$err = true;
	}
	if (empty($comments))
	{
		echo "Please write comments about the movie.<br />";
		$err = true;
	}
	if (!$err)
	{	
		# Add review
		mysql_query("INSERT INTO Review VALUES(\"$name\", NOW(), $movie, $rating, \"$comments\");", $db_connection);
		
		echo "<p>Your form has successfully been submitted!</p><p><a href=\"showMovieInfo.php?mid=$movie\">Show movie information</a></p>";
	}
}
	
# Close database
mysql_close($db_connection);

?>

</div>

</body>
</html>