<?php print('<?xml version = "1.0" encoding = "utf-8"?>')?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns = "http://www.w3.org/1999/xhtml">
	<head>
		<title>CS143 Movie Database</title>
		<style type = "text/css">
		td	
		{
			padding-top: 2px;
			padding-bottom: 2px;
			padding-left: 10px;
			padding-right: 10px
		}
		div { text-align: center }
		.smalltext {font-size: smaller}
		.largeerror {color: red}
		.error {color: red; font-size: smaller}
		.id  { background-color: blue}
		.name { background-color: blue}
		.sex { background-color: blue}
		.dob {background-color: blue}
		.dod {background-color: blue}
		.title {background-color: blue}
		.company {background-color: blue}
		.year {background-color: blue}
		.director {background-color: blue}
		.rating {background-color: blue}
		.genre {background-color: blue}
		div#navbar
		{
			height: 30px;
			width: 100%;
			border-top: solid #000 1px;
			border-bottom: solid #000 1px;
			background-color: tan;
		}

		div#navbar ul
		{
			margin: 0px;
			padding: 0px;
			font-family: Arial, Helvetica, sans-serif;
			font-size: small;
			color: #FFF;
			line-height: 30px;
			white-space: nowrap;
		}

		div#navbar li
		{
			list-style-type: none;
			display: inline;
		}

		div#navbar li a
		{
			text-decoration: none;
			padding: 7px 10px;
			color: #FFF;
		}

		div#navbar lia:link
		{
			color: #FFF:
		}

		div#navbar lia:visited
		{
			color: #CCC;
		}

		div#navbar lia:hover
		{
			font-weight: bold;
			color: #FFF;
			background-color: #3366FF;
		}
</style>
	</head>
	<body>
		<div id = "navbar">
			<ul>
				<li><a href = "I1.php">Add Actor/Director</a></li>
				<li><a href = "I2.php">Add Comments to a Movie</a></li>
				<li><a href = "I3.php">Add Movie Information</a><li>
				<li><a href = "B1.php">Show Actor Information</a><li>
				<li><a href = "B2.php">Show Movie Information</a><li>
				<li><a href = "S1.php">Search Person/Movie</a><li>
			</ul>
		</div>
		<?php
			function myQuery($q)
			{
				if (! ($db_link = mysql_connect("localhost", "cs143", "")))
					die ("Could not connect to database </body></html>");
				if (! ($db_selected = mysql_select_db("TEST", $db_link)))
					die ("Could not open CS143 database </body></html>");
				if (! ($result = mysql_query($q,$db_link)))
				{
					print ("Could not execute query! ");
					die (mysql_error() . "</body></html>");
				}
				mysql_close($db_link);
				return $result;
			}
			
			extract($_GET);
			
			if(isset($submit))
			{
				$query1 = "SELECT mid, title, year, role FROM ActorMovie WHERE aid = '$aid'";
				$qresults1 = myQuery($query1);
				$query2 = "SELECT first, last, sex, dob, dod FROM Actor WHERE id = '$aid'";
				$qresults2 = myQuery($query2);
				$info = mysql_fetch_row($qresults2);
				
				print("<h3>--Actor Info--</h3>");
				print("Name: ".$info['0']." ".$info['1']."<br />");
				print("Sex: ".$info['2']."<br />");
				print("Date of Birth: ".$info['3']."<br />");
				if($info['4'] == NULL)
					print("Date of Death: --Still Alive--<br />");
				else
					print("Date of Death: ".$info['4']."<br />");
				
				print("<h3>--Filmography--</h3>");
				print("<ol>");
				for ($counter = 0; $row = mysql_fetch_row($qresults1); $counter++)
					print("<li><a href = './B2.php?mid=$row[0]&submit=Submit'>$row[1]</a> ($row[2])....$row[3]</li>");
				print("</ol>");
				print("<hr />");
			}
			
			$query = "SELECT id, first, last, dob FROM Actor";
			$qresults = myQuery($query);
			
			print("<form action = 'B1.php' method = 'get'>");
			print("<label for 'aid'>See Another Actor: </label>");
			print("<select name = 'aid'>");
			for($counter = 0; $row = mysql_fetch_row($qresults); $counter++)
				print("<option value = '$row[0]'>".$row["1"]." ".$row["2"]." (".$row["3"].") </option>");
			print("</select><br />");
			
			print("<input type = 'submit' name = 'submit' value = 'Submit' />");
			print("</form><hr />");
		?>
	</body>
</html>