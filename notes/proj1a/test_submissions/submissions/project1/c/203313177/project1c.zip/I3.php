<?php print('<?xml version = "1.0" encoding = "utf-8"?>')?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns = "http://www.w3.org/1999/xhtml">
	<head>
		<title>CS143 Movie Database</title>
		<style type = "text/css">
		td	
		{
			padding-top: 2px;
			padding-bottom: 2px;
			padding-left: 10px;
			padding-right: 10px
		}
		div { text-align: center }
		.smalltext {font-size: smaller}
		.largeerror {color: red}
		.error {color: red; font-size: smaller}
		.id  { background-color: blue}
		.name { background-color: blue}
		.sex { background-color: blue}
		.dob {background-color: blue}
		.dod {background-color: blue}
		.title {background-color: blue}
		.company {background-color: blue}
		.year {background-color: blue}
		.director {background-color: blue}
		.rating {background-color: blue}
		.genre {background-color: blue}
		div#navbar
		{
			height: 30px;
			width: 100%;
			border-top: solid #000 1px;
			border-bottom: solid #000 1px;
			background-color: tan;
		}

		div#navbar ul
		{
			margin: 0px;
			padding: 0px;
			font-family: Arial, Helvetica, sans-serif;
			font-size: small;
			color: #FFF;
			line-height: 30px;
			white-space: nowrap;
		}

		div#navbar li
		{
			list-style-type: none;
			display: inline;
		}

		div#navbar li a
		{
			text-decoration: none;
			padding: 7px 10px;
			color: #FFF;
		}

		div#navbar lia:link
		{
			color: #FFF:
		}

		div#navbar lia:visited
		{
			color: #CCC;
		}

		div#navbar lia:hover
		{
			font-weight: bold;
			color: #FFF;
			background-color: #3366FF;
		}
</style>
	</head>
	<body>
		<div id = "navbar">
			<ul>
				<li><a href = "I1.php">Add Actor/Director</a></li>
				<li><a href = "I2.php">Add Comments to a Movie</a></li>
				<li><a href = "I3.php">Add Movie Information</a><li>
				<li><a href = "B1.php">Show Actor Information</a><li>
				<li><a href = "B2.php">Show Movie Information</a><li>
				<li><a href = "S1.php">Search Person/Movie</a><li>
			</ul>
		</div>
		<?php
			function myQuery($q)
			{
				if (! ($db_link = mysql_connect("localhost", "cs143", "")))
					die ("Could not connect to database </body></html>");
				if (! ($db_selected = mysql_select_db("TEST", $db_link)))
					die ("Could not open CS143 database </body></html>");
				if (! ($result = mysql_query($q,$db_link)))
				{
					print ("Could not execute!");
					die (mysql_error() . "</body></html>");
				}
				mysql_close($db_link);
				return $result;
			}

			extract($_GET);
			$iserror = false;
			
			$inputlist = array("title" => "Title", "company" => "Company", "year" => "Year");
			$genrelist = array("Action", "Adventure", "Comedy", "Crime/Gangster", "Drama/Epic", "Horror", "Musical", "Science Fiction", "War", "Western");
			$ratings   = array("G","PG","PG-13","R","NC-17");
			$action_genreID = 'unchecked';
			$adventure_genreID = 'unchecked';
			$comedy_genreID = 'unchecked';
			$crimegang_genreID = 'unchecked';
			$dramaepic_genreID = 'unchecked';
			$horror_genreID = 'unchecked';
			$musical_genreID = 'unchecked';
			$scifi_genreID = 'unchecked';
			$war_genreID = 'unchecked';
			$western_genreID = 'unchecked';
			
			if(isset($add))
			{
				if($title == "")
				{
					$formerrors["titleerror"] = true;
					$iserror = true;
				}
				
				if($company == "")
				{
					$formerrors["companyerror"] = true;
					$iserror = true;
				}
				
				if(!ereg("^(((0|1)[0-9]{3})|(200[0-9]))$",$year))
				{
					$formerrors["yearerror"] = true;
					$iserror = true;
				}
				
				if (isset($_GET['action_genre']))
				{
					$action_genreID = $_GET['action_genre'];
					if ($action_genreID == 'Action')
					{
						$action_genreID = 'checked';
					}
				}
				
				if (isset($_GET['adventure_genre']))
				{
					$adventure_genreID = $_GET['adventure_genre'];
					if ($adventure_genreID == 'Adventure')
					{
						$adventure_genreID = 'checked';
					}
				}
				
				if (isset($_GET['comedy_genre']))
				{
					$comedy_genreID = $_GET['comedy_genre'];
					if ($comedy_genreID == 'Comedy')
					{
						$comedy_genreID = 'checked';
					}
				}
				
				if (isset($_GET['crimegang_genre']))
				{
					$crimegang_genreID = $_GET['crimegang_genre'];
					if ($crimegang_genreID == 'Crime/Gangster')
					{
						$crimegang_genreID = 'checked';
					}
				}
				
				if (isset($_GET['dramaepic_genre']))
				{
					$dramaepic_genreID = $_GET['dramaepic_genre'];
					if ($dramaepic_genreID == 'Drama/Epic')
					{
						$dramaepic_genreID = 'checked';
					}
				}
				
				if (isset($_GET['horror_genre']))
				{
					$horror_genreID = $_GET['horror_genre'];
					if ($horror_genreID == 'Horror')
					{
						$horror_genreID = 'checked';
					}
				}
				
				if (isset($_GET['musical_genre']))
				{
					$musical_genreID = $_GET['musical_genre'];
					if ($musical_genreID == 'Musical')
					{
						$musical_genreID = 'checked';
					}
				}
				
				if (isset($_GET['scifi_genre']))
				{
					$scifi_genreID = $_GET['scifi_genre'];
					if ($scifi_genreID == 'Science Fiction')
					{
						$scifi_genreID = 'checked';
					}
				}
				
				if (isset($_GET['war_genre']))
				{
					$war_genreID = $_GET['war_genre'];
					if ($war_genreID == 'War')
					{
						$war_genreID = 'checked';
					}
				}
				
				if (isset($_GET['western_genre']))
				{
					$western_genreID = $_GET['western_genre'];
					if ($western_genreID == 'Western')
					{
						$western_genreID = 'checked';
					}
				}
				
				$genres = array($action_genreID,$adventure_genreID,$comedy_genreID,$crimegang_genreID,$dramaepic_genreID,$horror_genreID,$musical_genreID,$scifi_genreID,$war_genreID,$western_genreID);
				
				if(!$iserror)
				{
					$query = "SELECT id FROM MaxMovieID";
					$qresults = myQuery($query);
					$row = mysql_fetch_row($qresults);
					$MaxMovieID = $row["0"];
					
					$query = "INSERT INTO Movie
						VALUES ($MaxMovieID, '$title', '$year', '$rating', '$company')";
					$qresults = myQuery($query);
					
					for($counter = 0; $counter < 10; $counter++)
						if($genres[$counter] == 'checked')
						{
							$query = "INSERT INTO MovieGenre VALUES ($MaxMovieID, '$genrelist[$counter]')";
							$qresults = myQuery($query);
						}
						
					$updateID = "UPDATE MaxMovieID SET id = id + 1";
					$qresult = myQuery($updateID);
					
						print( "<strong>The following information has been saved 
                  in our Movie Database:</strong><br />
                  <table border = '0.5'><tr>
                  <td class = 'id'>id</td>
                  <td class = 'title'>Title</td>
                  <td class = 'company'>Company</td>
                  <td class = 'director'>Director</td>
									<td class = 'rating'>MPAA Rating</td>
									<td class = 'year'>Year</td>
									<td class = 'genre'>Genres</td>
                  </tr><tr>

                  <!-- print each form field�s value -->
                  <td>$MaxMovieID</td>
									<td>$title</td>
                  <td>$company</td>
                  <td>$did</td>
                  <td>$rating</td>
									<td>$year</td>
									<td>");
					for($counter = 0; $counter < 10; $counter++)
						if($genres[$counter] == 'checked')
							print($genrelist[$counter].", ");
					print( "</td></tr></table>
                  <br /><br /><br />
									<a href = './I3.php'>Add Another Movie!</a>
                  </body></html>" );
					die();
				}
			}
			
			print("<h3>Add New Movie:</h3>");
			
			if($iserror)
			{
				print("<span class = 'largeerror'>
					Fields with * need to be filled in properly.<br /></span>");
			}
			
			$query = "SELECT id, first, last, dob FROM Director";
			$qresults = myQuery($query);

			print("<form name = 'input' action = 'I3.php' method = 'get'>");
			foreach ($inputlist as $inputname => $inputalt)
			{
				$inputtext = $inputvalues[$inputname];
				print("<label>$inputlist[$inputname]: <input type = 'text' name = '$inputname' value = '" . $$inputname . "' /></label>");
				
				if($formerrors[($inputname)."error"] == true)
					print("<span class = 'error'>*</span>");
				
				print("<br />");
			}
			
			print("<label for 'did'>Director: </label>");
			print("<select name = 'did'>");
			for($counter = 0; $row = mysql_fetch_row($qresults); $counter++)
				print("<option value = '$row[0]'>".$row["1"]." ".$row["2"]." (".$row["3"].") </option>");
			print("</select><br />");
			
			print("<label for 'rating'>MPAA Rating: </label>");
			print("<select name = 'rating'>
					<option value = 'G'>G</option>
					<option value = 'PG'>PG</option>
					<option value = 'PG-13'>PG-13</option>
					<option value = 'R'>R</option>
					<option value = 'NC-17'>NC-17</option>");
			print("</select>");
			print("<br />");
			
			print("<input type = 'checkbox' name = 'action_genre' value = 'Action' $action_genreID /> Action ");
			print("<input type = 'checkbox' name = 'adventure_genre' value = 'Adventure' $adventure_genreID /> Adventure ");
			print("<input type = 'checkbox' name = 'comedy_genre' value = 'Comedy' $comedy_genreID /> Comedy ");
			print("<input type = 'checkbox' name = 'crimegang_genre' value = 'Crime/Gangster' $crimegang_genreID /> Crime/Gangster ");
			print("<input type = 'checkbox' name = 'dramaepic_genre' value = 'Drama/Epic' $dramaepic_genreID /> Drama/Epic ");
			print("<input type = 'checkbox' name = 'horror_genre' value = 'Horror' $horror_genreID /> Horror ");
			print("<input type = 'checkbox' name = 'musical_genre' value = 'Musical' $musical_genreID /> Musical ");
			print("<input type = 'checkbox' name = 'scifi_genre' value = 'Science Fiction' $scifi_genreID /> Science Fiction ");
			print("<input type = 'checkbox' name = 'war_genre' value = 'War' $war_genreID /> War ");
			print("<input type = 'checkbox' name = 'western_genre' value = 'Western' $western_genreID /> Western ");
			print("<br />");
			
			print("<input type = 'submit' name = 'add' value = 'Add it!' />");
			print("</form><hr />");
		?>
	</body>
</html>