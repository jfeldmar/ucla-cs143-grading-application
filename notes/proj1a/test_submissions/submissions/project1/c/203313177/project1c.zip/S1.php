<?php print('<?xml version = "1.0" encoding = "utf-8"?>')?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns = "http://www.w3.org/1999/xhtml">
	<head>
		<title>CS143 Movie Database</title>
		<style type = "text/css">
		td	
		{
			padding-top: 2px;
			padding-bottom: 2px;
			padding-left: 10px;
			padding-right: 10px
		}
		div { text-align: center }
		.smalltext {font-size: smaller}
		.largeerror {color: red}
		.error {color: red; font-size: smaller}
		.id  { background-color: blue}
		.name { background-color: blue}
		.sex { background-color: blue}
		.dob {background-color: blue}
		.dod {background-color: blue}
		.title {background-color: blue}
		.company {background-color: blue}
		.year {background-color: blue}
		.director {background-color: blue}
		.rating {background-color: blue}
		.genre {background-color: blue}
		div#navbar
		{
			height: 30px;
			width: 100%;
			border-top: solid #000 1px;
			border-bottom: solid #000 1px;
			background-color: tan;
		}

		div#navbar ul
		{
			margin: 0px;
			padding: 0px;
			font-family: Arial, Helvetica, sans-serif;
			font-size: small;
			color: #FFF;
			line-height: 30px;
			white-space: nowrap;
		}

		div#navbar li
		{
			list-style-type: none;
			display: inline;
		}

		div#navbar li a
		{
			text-decoration: none;
			padding: 7px 10px;
			color: #FFF;
		}

		div#navbar lia:link
		{
			color: #FFF:
		}

		div#navbar lia:visited
		{
			color: #CCC;
		}

		div#navbar lia:hover
		{
			font-weight: bold;
			color: #FFF;
			background-color: #3366FF;
		}
</style>
	<body>
		<div id = "navbar">
			<ul>
				<li><a href = "I1.php">Add Actor/Director</a></li>
				<li><a href = "I2.php">Add Comments to a Movie</a></li>
				<li><a href = "I3.php">Add Movie Information</a><li>
				<li><a href = "B1.php">Show Actor Information</a><li>
				<li><a href = "B2.php">Show Movie Information</a><li>
				<li><a href = "S1.php">Search Person/Movie</a><li>
			</ul>
		</div>
		<?php
			function myQuery($q)
			{
				if (! ($db_link = mysql_connect("localhost", "cs143", "")))
					die ("Could not connect to database </body></html>");
				if (! ($db_selected = mysql_select_db("TEST", $db_link)))
					die ("Could not open CS143 database </body></html>");
				if (! ($result = mysql_query($q,$db_link)))
				{
					print ("Could not execute query!");
					die (mysql_error() . "</body></html>");
				}
				mysql_close($db_link);
				return $result;
			}
			
			extract($_GET);
			$iserror = false;
			
			if(isset($search))
			{
				if($allsearch == "")
				{
					$formerrors['allsearcherror'] = true;
					$iserror = true;
				}
				
				if(!$iserror)
				{
					print("<hr />");
					print("<form action 'S1.php' method = 'get'>");
					print("<label>Search: <input type = 'text' name = 'allsearch' /></label>");
					if($formerrors['allsearcherror'] == true)
						print("<span class = 'error'>*</span>");
					print("<br />");
			
					print("<input type = 'submit' name = 'search' value = 'Search' />");
					print("</form><hr />");
					
					$query1 = "SELECT * FROM ActorMovie WHERE first LIKE '%$allsearch%' OR last LIKE '%$allsearch%' OR role LIKE '%$allsearch%' OR title LIKE '%$allsearch%' GROUP BY first";
					$qresults1 = myQuery($query1);
					print("<h3>--Search Results--</h3>");
					print("<h4>Records matching or containing '$allsearch' in Actor Database:</h4>");
					print("<ul>");
					for($counter = 0; $row = mysql_fetch_row($qresults1); $counter++)
						print("<li><a href = 'B1.php?aid=$row[0]&submit=Submit'>$row[2] $row[3]</a>....$row[4] in <a href = 'B2.php?mid=$row[1]&submit=Submit'>$row[5] ($row[6])</a></li>");
					print("</ul><hr />");
				}
				
				$query2 = "SELECT * FROM DirectorMovie WHERE first LIKE '%$allsearch%' OR last LIKE '%$allsearch%' GROUP BY first";
				$qresults2 = myQuery($query2);
					print("<h3>--Search Results--</h3>");
					print("<h4>Records matching or containing '$allsearch' in Director Database:</h4>");
					print("<ul>");
					for($counter = 0; $row = mysql_fetch_row($qresults2); $counter++)
						print("<li><a href = 'B1.php?did=$row[0]&submit=Submit'>$row[2] $row[3]</a> directed <a href = 'B2.php?mid=$row[1]&submit=Submit'>$row[4] ($row[5])</a></li>");
			}
			
			if($iserror)
			{
				print("<span class = 'largeerror'>
					Fields with * need to be filled in properly.<br /></span>");
			}
			print("<hr />");
			print("<form action 'S1.php' method = 'get'>");
			print("<label>Search: <input type = 'text' name = 'allsearch' /></label>");
			if($formerrors['allsearcherror'] == true)
				print("<span class = 'error'>*</span>");
			print("<br />");
			
			print("<input type = 'submit' name = 'search' value = 'Search' />");
			print("</form><hr />");
		?>
	</body>
</html>