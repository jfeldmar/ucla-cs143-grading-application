<?php print('<?xml version = "1.0" encoding = "utf-8"?>')?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns = "http://www.w3.org/1999/xhtml">
	<head>
		<title>CS143 Movie Database</title>
		<style type = "text/css">
		td	
		{
			padding-top: 2px;
			padding-bottom: 2px;
			padding-left: 10px;
			padding-right: 10px
		}
		div { text-align: center }
		.smalltext {font-size: smaller}
		.largeerror {color: red}
		.error {color: red; font-size: smaller}
		.id  { background-color: blue}
		.name { background-color: blue}
		.sex { background-color: blue}
		.dob {background-color: blue}
		.dod {background-color: blue}
		.title {background-color: blue}
		.company {background-color: blue}
		.year {background-color: blue}
		.director {background-color: blue}
		.rating {background-color: blue}
		.genre {background-color: blue}
		div#navbar
		{
			height: 30px;
			width: 100%;
			border-top: solid #000 1px;
			border-bottom: solid #000 1px;
			background-color: tan;
		}

		div#navbar ul
		{
			margin: 0px;
			padding: 0px;
			font-family: Arial, Helvetica, sans-serif;
			font-size: small;
			color: #FFF;
			line-height: 30px;
			white-space: nowrap;
		}

		div#navbar li
		{
			list-style-type: none;
			display: inline;
		}

		div#navbar li a
		{
			text-decoration: none;
			padding: 7px 10px;
			color: #FFF;
		}

		div#navbar lia:link
		{
			color: #FFF:
		}

		div#navbar lia:visited
		{
			color: #CCC;
		}

		div#navbar lia:hover
		{
			font-weight: bold;
			color: #FFF;
			background-color: #3366FF;
		}
</style>
	</head>
	<body>
		<div id = "navbar">
			<ul>
				<li><a href = "I1.php">Add Actor/Director</a></li>
				<li><a href = "I2.php">Add Comments to a Movie</a></li>
				<li><a href = "I3.php">Add Movie Information</a><li>
				<li><a href = "B1.php">Show Actor Information</a><li>
				<li><a href = "B2.php">Show Movie Information</a><li>
				<li><a href = "S1.php">Search Person/Movie</a><li>
			</ul>
		</div>
		<?php
			function myQuery($q)
			{
				if (! ($db_link = mysql_connect("localhost", "cs143", "")))
					die ("Could not connect to database </body></html>");
				if (! ($db_selected = mysql_select_db("TEST", $db_link)))
					die ("Could not open CS143 database </body></html>");
				if (! ($result = mysql_query($q,$db_link)))
				{
					print ("Could not execute query!");
					die (mysql_error() . "</body></html>");
				}
				mysql_close($db_link);
				return $result;
			}
			
			extract($_GET);
			
			if(isset($submit))
			{
				$query1 = "SELECT title, year, company, rating FROM Movie WHERE id = '$mid'";
				$qresults1 = myQuery($query1);
				$info = mysql_fetch_row($qresults1);
				$dirctr = "SELECT did FROM MovieDirector WHERE mid = '$mid'";
				$dirctrinfo = myQuery($dirctr);
				$dnum = mysql_fetch_row($dirctrinfo);
				$DID = $dnum['0'];
				$nam = "SELECT first, last, dob FROM Director WHERE id = '$dnum[0]'";
				$dnam = myQuery($nam);
				$dName = mysql_fetch_row($dnam);
				$qgenre = "SELECT genre FROM MovieGenre WHERE mid = '$mid'";
				$qgenreresults = myQuery($qgenre);
				
				print("<h3>--Movie Info--</h3>");
				print("Title: ".$info['0']." (".$info['1'].") <br />");
				print("Producer: ".$info['2']."<br />");
				print("MPAA Rating: ".$info['3']."<br />");
				print("Director: $dName[0] $dName[1] ($dName[2])<br />");
				print("Genre: "); 
				for($counter = 0; $row = mysql_fetch_row($qgenreresults); $counter++)
					foreach($row as $value)
						print($value.", ");
				
				$query2 = "SELECT aid, first, last, role FROM ActorMovie WHERE mid = '$mid'";
				$qresults2 = myQuery($query2);
				
				print("<h3>--Cast--</h3>");
				print("<ul>");
				for($counter = 0; $row = mysql_fetch_row($qresults2); $counter++)
					print("<li><a href = './B1.php?aid=$row[0]&submit=Submit'>$row[1] $row[2]</a>....$row[3]</li>");
				print("</ul>");
				
				$query3 = "SELECT * FROM Review WHERE mid = '$mid'";
				$qresults3 = myQuery($query3);
				$query4 = "SELECT AVG(rating), COUNT(rating) FROM Review WHERE mid = '$mid'";
				$qresults4 = myQuery($query4);
				$ratinginfo = mysql_fetch_row($qresults4);
				
				print("<h3>--User Reviews--</h3>");
				print("Average Score: $ratinginfo[0]/5.0000 (5.0000 is best) by $ratinginfo[1] reviewers. <a href = './I2.php?mid=$mid'>Add your comments here!</a><br />");
				print("All Comments in Details:<br />");
				print("<ul>");
				for($counter = 0; $row = mysql_fetch_row($qresults3); $counter++)
					print("<li>In $row[1], $row[0] gave this movie a score of $row[3] and had this to say about it:<br />$row[4]</li>");
				print("</ul>");
				print("<hr />");
			}
			
			$query = "SELECT * FROM Movie";
			$qresults = myQuery($query);
			
			print("<form action = 'B2.php' method = 'get'>");
			print("<label for 'mid'>See Another Movie: </label>");
			print("<select name = 'mid'>");
			for($counter = 0; $row = mysql_fetch_row($qresults); $counter++)
				print("<option value = '$row[0]'>".$row["1"]." (".$row["2"].") </option>");
			print("</select><br />");
			
			print("<input type = 'submit' name = 'submit' value = 'Submit' />");
			print("</form><hr />");
		?>
	</body>
</html>