<?php print('<?xml version = "1.0" encoding = "utf-8"?>')?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns = "http://www.w3.org/1999/xhtml">
	<head>
		<title>CS143 Movie Database</title>
		<style type = "text/css">
		td	
		{
			padding-top: 2px;
			padding-bottom: 2px;
			padding-left: 10px;
			padding-right: 10px
		}
		div { text-align: center }
		.smalltext {font-size: smaller}
		.largeerror {color: red}
		.error {color: red; font-size: smaller}
		.id  { background-color: blue}
		.name { background-color: blue}
		.sex { background-color: blue}
		.dob {background-color: blue}
		.dod {background-color: blue}
		.title {background-color: blue}
		.company {background-color: blue}
		.year {background-color: blue}
		.director {background-color: blue}
		.rating {background-color: blue}
		.genre {background-color: blue}
		div#navbar
		{
			height: 30px;
			width: 100%;
			border-top: solid #000 1px;
			border-bottom: solid #000 1px;
			background-color: tan;
		}

		div#navbar ul
		{
			margin: 0px;
			padding: 0px;
			font-family: Arial, Helvetica, sans-serif;
			font-size: small;
			color: #FFF;
			line-height: 30px;
			white-space: nowrap;
		}

		div#navbar li
		{
			list-style-type: none;
			display: inline;
		}

		div#navbar li a
		{
			text-decoration: none;
			padding: 7px 10px;
			color: #FFF;
		}

		div#navbar lia:link
		{
			color: #FFF:
		}

		div#navbar lia:visited
		{
			color: #CCC;
		}

		div#navbar lia:hover
		{
			font-weight: bold;
			color: #FFF;
			background-color: #3366FF;
		}
</style>
	</head>
	<body>
		<div id = "navbar">
			<ul>
				<li><a href = "I1.php">Add Actor/Director</a></li>
				<li><a href = "I2.php">Add Comments to a Movie</a></li>
				<li><a href = "I3.php">Add Movie Information</a><li>
				<li><a href = "B1.php">Show Actor Information</a><li>
				<li><a href = "B2.php">Show Movie Information</a><li>
				<li><a href = "S1.php">Search Person/Movie</a><li>
			</ul>
		</div>
		<?php
			function myQuery($q)
			{
				if (! ($db_link = mysql_connect("localhost", "cs143", "")))
					die ("Could not connect to database </body></html>");
				if (! ($db_selected = mysql_select_db("TEST", $db_link)))
					die ("Could not open CS143 database </body></html>");
				if (! ($result = mysql_query($q,$db_link)))
				{
					print ("Could not execute query!");
					die (mysql_error() . "</body></html>");
				}
				mysql_close($db_link);
				return $result;
			}

			extract($_GET);
			$iserror = false;
			
			$inputlist = array("yourname" => "Your Name");
			
			if(isset($rate))
			{
				if($yourname == "")
				{
					$formerrors["nameerror"] = true;
					$iserror = true;
				}
				
				if(!$iserror)
				{
					$query = "SELECT NOW()";
					$qresults = myQuery($query);
					
					$time = mysql_fetch_row($qresults);
					$currenttime = $time["0"];
					
					$query = "INSERT INTO Review VALUES ('$yourname','$currenttime','$mid','$rating','$comments')";
					$qresults = myQuery($query);
					print("<br />");
					
					print("Insertion Successful! Thanks for your comments!<br />");
					print("<a href = './B2.php?mid=$mid&submit=Submit'>Click here for Movie Info and reviews.</a><br />");
					print("<a href = './I2.php'>Add more comments!</a>
                  </body></html>");
					die();
				}
			}
			
			print("<h3>Add New Comment:</h3>");
			
			if($iserror)
			{
				print("<span class = 'largeerror'>
					Fields with * need to be filled in properly.<br /></span>");
			}
			
			$query = "SELECT id, title, year FROM Movie";
			$qresults = myQuery($query);
			
			print ("<form action = 'I2.php' method = 'get'>");
			$movieID = !isset($_GET['mid'])?NULL:$_GET['mid'];
			$movieinfoq = "SELECT id, title, year FROM Movie WHERE id = '$movieID'";
			$inforesults = myQuery($movieinfoq);
			$movieinfo = mysql_fetch_row($inforesults);
			print ("<label for = 'mid'>Movie: </label>");
			print ("<select name = 'mid'>");
			print ("<option value = $movieinfo[0] SELECTED>$movieinfo[1] ($movieinfo[2])</option>");
			for ($counter = 0; $row = mysql_fetch_row($qresults); $counter++)
				print("<option value = '$row[0]'>".$row["1"]." (".$row["2"].") </option>");
			print("</select><br />");
			
			print("<label>Your Name: <input type = 'text' name = 'yourname' /></label>");
			if ($formerrors["nameerror"] == true)
				print("<span class = 'error'>*</span>");
			print("<br />");
			
			print("<label for = 'rating'>Rating: </label>");
			print("<select name = 'rating'>
					<option value = '5'>5-Excellent</option>
					<option value = '4'>4-Good</option>
					<option value = '3'>3-It's Ok</option>
					<option value = '2'>2-Not Good</option>
					<option value = '1'>1-Terrible</option>");
			print("</select>");
			print("<br />");
			
			print("Comments:");
			print("<br />");
			print("<textarea name = 'comments' rows = '10' cols = '50'></textarea>");
			print("<br />");
			print("<input type = 'submit' name = 'rate' value = 'Rate it!'>");
			print("</form><hr />");
		?>
	</body>
<html>