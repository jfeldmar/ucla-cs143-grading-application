<html>
<head>
<title>add actor / director</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
Add new actor/director:
<br/>
<form method="get" action="./addActorDirector.php">
Identity:
<input type="radio" checked="true" value="Actor" name="identity"/>
Actor
<input type="radio" value="Director" name="identity"/>
Director
<br/>
<hr/>
First Name:
<input type="text" maxlength="20" name="first" style="background-color: rgb(255, 255, 160);"/>
<br/>
Last Name:
<input type="text" maxlength="20" name="last" style="background-color: rgb(255, 255, 160);"/>
<br/>
Sex:
<input type="radio" checked="true" value="Male" name="sex"/>
Male
<input type="radio" value="Female" name="sex"/>
Female
<br/>
Date of Birth:
<input type="text" name="dob"/>
<br/>
Date of Die:
<input type="text" name="dod"/>
(leave blank if alive now)
<br/>
<input type="submit" value="add it!!"/>
</form>
<?php
if($_GET["first"]){
	$identity=$_GET["identity"];
	$first=$_GET["first"];
	$last=$_GET["last"];
	$sex=$_GET["sex"];
	$dob=$_GET["dob"];
	$dod=$_GET["dod"];
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select id from MaxPersonID;"; 
	$rs = mysql_query($query, $db_connection);
	$row = mysql_fetch_row($rs);
	$id = $row[0];
	$query = "update MaxPersonID set id=id +1;"; 
	$rs = mysql_query($query, $db_connection);
	if($dod && $dod<$dob)
		print "<font color = \"Red\"> DATE OF BIRTH MUST BE BEFORE DATE OF DEATH!</font>";
	else{
		if($identity=="Actor")
			$query = "insert into Actor values('$id','$last','$first','$sex','$dob','$dod');";
		else
			$query = "insert into Director values('$id','$last','$first','$dob','$dod');";
		mysql_query($query, $db_connection);
		print "<font color = \"Blue\"> $identity Succussfully Added.</font>";
	}
}
?>
<hr/>
</body>
</html>