<html>
<head>
<title>Actor Information</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
<?php
	if($_GET["aid"]){
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$query = "select * from Actor where id = ".$_GET["aid"].";";
		$rs = mysql_query($query, $db_connection);
		$row = mysql_fetch_row($rs);
		print "Name: ".$row[2]." ".$row[1]."<br/>";
		print "Sex: ".$row[3]."<br/>";
		print "Date of Birth: ".$row[4]."<br/>";
		print "Date of Death: ";
		if($row[5])
			print $row[4]."<br/>";
		else print "--Still Alive--<br/>";
		print "<br/>--Acted in--<br/>";

		$query = "select MovieActor.role,Movie.id,Movie.title from MovieActor,Movie where MovieActor.aid = ".$_GET["aid"]." and MovieActor.mid= Movie.id;"; 
		$rs = mysql_query($query, $db_connection);
		while($row = mysql_fetch_row($rs)){
			$actorNum = $row[0];
			print "Acts as ".$row[0]." in ";
			print "<a href=\"./showMovieInfo.php?mid=".$row[1]."\">".$row[2]."</a>";
			print "<br/>";
		}
		
	}
?>
<form method="get" action="./showActorInfo.php">
See Another Actor :
<select name="aid">
<br/>
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select * from Actor order by first,last;"; 
	$rs = mysql_query($query, $db_connection);
	while($row = mysql_fetch_row($rs)){
		print "<option value=\"".$row[0]."\">".$row[2]." ".$row[1]."(".$row[4].")";
	}
?>
</select>
<input type="submit" value="Search"/>
</form>
</body>
</html>