<head>
<title>Movie Information</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
<?php
	if($_GET["mid"]){
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$query = "select * from Movie where id = ".$_GET["mid"].";";
		$rs = mysql_query($query, $db_connection);
		$row = mysql_fetch_row($rs);
		$title = $row[1];
		print "Title: ".$title."(".$row[2].")"."<br/>";
		print "Producer: ".$row[4]."<br/>";
		print "MPAA Rating: ".$row[3]."<br/>";
		$query = "select Director.first,Director.last, Director.dob from Director,MovieDirector,Movie where Director.id=MovieDirector.did and MovieDirector.mid=Movie.id and Movie.id = ".$_GET["mid"].";"; 
		$rs = mysql_query($query, $db_connection);
		print "Director:  ";
		while($row = mysql_fetch_row($rs))
			print $row[0]." ".$row[1]."(".$row[2]."). ";
		$query = "select distinct genre from MovieGenre,Movie where MovieGenre.mid = Movie.id and Movie.id =".$_GET["mid"].";";
		$rs = mysql_query($query, $db_connection);
		print "<br/>"."Genre: ";
		while($row = mysql_fetch_row($rs))
			print $row[0].". ";
		print "<br/><br/>--Actors in this movie--<br/>";
		$query = "select Actor.id,Actor.first,Actor.last,MovieActor.role from MovieActor,Actor where MovieActor.mid = ".$_GET["mid"]." and MovieActor.aid = Actor.id;"; 
		$rs = mysql_query($query, $db_connection);
		while($row = mysql_fetch_row($rs)){
			$actorNum = $row[0];
			print "<a href=\"./showActorInfo.php?aid=".$row[0]."\">";
			print $row[1]." ".$row[2]."</a> acts as ".$row[3]."<br/>";
		}
		print "<br/>--User Review--<br/>";
		$query = "select count(rating),avg(rating),max(rating) from Review where  Review.mid =".$_GET["mid"].";";
		$rs = mysql_query($query, $db_connection);
		$row = mysql_fetch_row($rs);
		if($row[0]>0){	
			print "Average score is: ";
			print $row[1];
			print "/5 (";
			print $row[2];
			print " is best) by ";
			print $row[0];
			print " Review(s).";
		}
		else
			print "No Reviews yet on this movie<br/>";
		print "<a href=\"./addComment.php?mid=".$_GET["mid"]."\"> Add your review now!!</a>";
		print "<br/>All Comments in Detail:<br/>";
		$query = "select * from Review where  Review.mid =".$_GET["mid"].";";
		$rs = mysql_query($query, $db_connection);
		while($row = mysql_fetch_row($rs)){
			print "<font color=\"Blue\">In ".$row[1].", <font color=\"Black\">rated ".$title." a "."<font color=\"Red\">".$row[3];
			print "</font>".".<br/>Comment:"."</font></font>";
			print "<br/>".$row[4]."<br/><br/>";
		}
	}
?>

<form method="get" action="./showMovieInfo.php">
See Another Movie :
<select name="mid">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select * from Movie order by title;"; 
	$rs = mysql_query($query, $db_connection);
	while($row = mysql_fetch_row($rs)){
		print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")";
	}
?>
</select>
<br/>
<input type="submit" value="Search"/>
</form>

</body>