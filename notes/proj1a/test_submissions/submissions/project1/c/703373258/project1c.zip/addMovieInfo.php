<html>
<head>
<title>add new movie</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
Add new movie:
<br/>
<form method="get" action="./addMovieInfo.php">
Title :
<input type="text" maxlength="20" name="title"/>
<br/>
Company:
<input type="text" maxlength="50" name="company"/>
<br/>
Year :
<input type="text" maxlength="4" name="year"/>
<br/>
Director :
<select name="did">
</select>
<br/>
MPAA Rating :
<select name="mpaarating">
<option value="G">G</option>
<option value="NC-17">NC-17</option>
<option value="PG">PG</option>
<option value="PG-13">PG-13</option>
<option value="R">R</option>
<option value="surrendere">surrendere</option>
</select>
<br/>
Genre :
<input type="checkbox" value="Action" name="genre_Action"/>
Action
<input type="checkbox" value="Adult" name="genre_Adult"/>
Adult
<input type="checkbox" value="Adventure" name="genre_Adventure"/>
Adventure
<input type="checkbox" value="Animation" name="genre_Animation"/>
Animation
<input type="checkbox" value="Comedy" name="genre_Comedy"/>
Comedy
<input type="checkbox" value="Crime" name="genre_Crime"/>
Crime
<input type="checkbox" value="Documentary" name="genre_Documentary"/>
Documentary
<input type="checkbox" value="Drama" name="genre_Drama"/>
Drama
<input type="checkbox" value="Family" name="genre_Family"/>
Family
<input type="checkbox" value="Fantasy" name="genre_Fantasy"/>
Fantasy
<input type="checkbox" value="Horror" name="genre_Horror"/>
Horror
<input type="checkbox" value="Musical" name="genre_Musical"/>
Musical
<input type="checkbox" value="Mystery" name="genre_Mystery"/>
Mystery
<input type="checkbox" value="Romance" name="genre_Romance"/>
Romance
<input type="checkbox" value="Sci-Fi" name="genre_Sci-Fi"/>
Sci-Fi
<input type="checkbox" value="Short" name="genre_Short"/>
Short
<input type="checkbox" value="Thriller" name="genre_Thriller"/>
Thriller
<input type="checkbox" value="War" name="genre_War"/>
War
<input type="checkbox" value="Western" name="genre_Western"/>
Western
<br/>
<input type="submit" value="Add it!!"/>
</form>
<?php
if($_GET["title"]){
	$title=$_GET["title"];
	$company=$_GET["company"];
	$sex=$_GET["sex"];
	$rating=$_GET["rating"];
	$year = $_GET["year"];
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select id from MaxMovieID;"; 
	$rs = mysql_query($query, $db_connection);
	$row = mysql_fetch_row($rs);
	$id = $row[0];
	$query = "update MaxMovieID set id=id +1;"; 
	$rs = mysql_query($query, $db_connection);
	$query = "insert into Movie values('$id','$title','$year','$rating','$company');";
	mysql_query($query, $db_connection);
	print "<font color = \"Blue\"> $identity Succussfully Added.</font>";
	if($_GET["genre_Action"]){
		$query = "insert into MovieGenre values('$id',\"Action\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Adult"]){
		$query = "insert into MovieGenre values('$id',\"Adult\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Adventure"]){
		$query = "insert into MovieGenre values('$id',\"Adventure\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Animation"]){
		$query = "insert into MovieGenre values('$id',\"Animation\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Comedy"]){
		$query = "insert into MovieGenre values('$id',\"Comedy\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Crime"]){
		$query = "insert into MovieGenre values('$id',\"Crime\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Documentary"]){
		$query = "insert into MovieGenre values('$id',\"Documentary\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Drama"]){
		$query = "insert into MovieGenre values('$id',\"Drama\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Family"]){
		$query = "insert into MovieGenre values('$id',\"Family\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Fantasy"]){
		$query = "insert into MovieGenre values('$id',\"Fantasy\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Horror"]){
		$query = "insert into MovieGenre values('$id',\"Horror\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Musical"]){
		$query = "insert into MovieGenre values('$id',\"Musical\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Mystery"]){
		$query = "insert into MovieGenre values('$id',\"Mystery\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Romance"]){
		$query = "insert into MovieGenre values('$id',\"Romance\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Sci-Fi"]){
		$query = "insert into MovieGenre values('$id',\"Sci-Fi\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Short"]){
		$query = "insert into MovieGenre values('$id',\"Short\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Thriller"]){
		$query = "insert into MovieGenre values('$id',\"Thriller\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_War"]){
		$query = "insert into MovieGenre values('$id',\"War\");";
		mysql_query($query, $db_connection);
	}
	if($_GET["genre_Western"]){
		$query = "insert into MovieGenre values('$id',\"Western\");";
		mysql_query($query, $db_connection);
	}
	print "<br/><a target=\"main\" href=\"./addMovieActor.php?title=".$title."&mid=".$id."\">Add Actor/Role Relation</a>";
}
?>
<hr/>

</body>
</html>