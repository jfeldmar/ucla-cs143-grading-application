<head>
<title>Search Actor / Movie</title>

</head>
<body bgcolor="#FFFF00">
<form method="get" action="./search.php">
Search:
<input type="text" name="keyword"/>
<br/>
Search Type:
<input type="radio" name="searchType" value="Actor" checked="true"/>
Actor
<input type="radio" name="searchType" value="Movie"/>
Movie
<br/>
<input type="submit" value="Search"/>
</form>
<hr/>
<?php
	if($_GET["searchType"]==true)
	{
		$searchType = $_GET["searchType"];
	}	
	if($_GET["keyword"])
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$keyword=$_GET["keyword"];
		echo "Searching in ".$searchType." for ".$keyword;
		if($searchType== Actor){
			list($first, $last) = explode(" ", $keyword);
			$query = "select * from Actor where first like \"%".$first."%\" and last like \"%".$last."%\" or first like \"%".$last."%\" and last like \"%".$first."%\"  order by last, first;"; 
			if(!$last)
			$query = "select * from Actor where first like \"%".$keyword."%\" or last like \"%".$keyword."%\"  order by last, first;"; 
			$rs = mysql_query($query, $db_connection);
			while($row = mysql_fetch_row($rs)){
				$actorNum = $row[0];
				print "<br/> Actor: <a href=\"./showActorInfo.php?aid=".$row[0]."\">";
				print $row[2]." ".$row[1]."(".$row[4].")"."</a><br/>";

			}
	
		}
		else{
			$query = "select * from Movie where title like \"%".$keyword."%\" order by title"; 
			$rs = mysql_query($query, $db_connection);
			while($row = mysql_fetch_row($rs)){
				$actorNum = $row[0];
				print "<br/> Movie: <a href=\"./showMovieInfo.php?mid=".$row[0]."\">";
				print $row[1]."(".$row[2].")"."</a><br/>";
			}
		}
	}

?>
</body>