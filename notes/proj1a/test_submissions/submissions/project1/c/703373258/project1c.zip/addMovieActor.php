	 
<html>
<head>
<title>add actor's role in a movie</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
Add new actor in a movie:
<br/>
<form method="get" action="./addMovieActor.php">
Movie :
<select name="mid">
<?php
	if($_GET["mid"]){
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$query = "select * from Movie where id = ".$_GET["mid"].";"; 
		$rs = mysql_query($query, $db_connection);
		$row = mysql_fetch_row($rs);
		print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")";
	}

	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select * from Movie order by title;"; 
	$rs = mysql_query($query, $db_connection);
	while($row = mysql_fetch_row($rs)){
		print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")";
	}
	if($_GET["mid"])
		print "mid = ".$_GET["mid"];
?>
</select>
<br/>
Actor :
<select name="aid">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select * from Actor order by first,last;"; 
	$rs = mysql_query($query, $db_connection);
	while($row = mysql_fetch_row($rs)){
		print "<option value=\"".$row[0]."\">".$row[2]." ".$row[1]."(".$row[4].")";
	}
?>
</select>
<br/>
Role:
<input type="text" maxlength="50" name="role"/>
<br/>
<input type="submit" value="Add it!!"/>
</form>
<hr/>
<?php
	if($_GET["role"]){
	$roll = $_GET["role"];
	$mid = $_GET["mid"];
	$aid = $_GET["aid"]; 
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "insert into MovieActor values('$mid','$aid','$roll');"; 
	mysql_query($query, $db_connection);
	print "<br/>Successfully Updated!";
	}
?>
</body>
</html>