<html>
<head>
<title>add actor / director</title>
<style type="text/css">
1
2 @import url(cs143style.css);
3
</style>
</head>
<body>
Add new comment:
<br/>
<form method="get" action="./addComment.php">
Movie:
<select name="mid">
<?php
	if($_GET["mid"]){
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$query = "select * from Movie where id = ".$_GET["mid"].";"; 
		$rs = mysql_query($query, $db_connection);
		$row = mysql_fetch_row($rs);
		print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")";
	}

	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$query = "select * from Movie order by title;"; 
	$rs = mysql_query($query, $db_connection);
	while($row = mysql_fetch_row($rs)){
		print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")";
	}
?>
</select>
<br/>
Your Name:
<input type="text" maxlength="20" value="Mr. Anonymous" name="yourname"/>
<br/>
Rating:
<select name="rating">
<option value="5"> 5 - Excellent </option>
<option value="4"> 4 - Good </option>
<option value="3"> 3 - It's ok~ </option>
<option value="2"> 2 - Not worth </option>
<option value="1"> 1 - I hate it </option> 
</select>
<br/>
Comments:
<br/>
<textarea rows="10" cols="80" name="comment">
</textarea>
<br/>
<input type="submit" value="Rate it!!"/>
</form>
<hr/>
<?php
	if($_GET["rating"]){
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	$name = $_GET["yourname"];
	$movie = $_GET["mid"];
	$comment = $_GET["comment"];
	$rating = $_GET["rating"];
	$query = "INSERT INTO Review (name,time,mid,rating,comment)"."VALUES ('$name', CURRENT_TIMESTAMP, '$movie', '$rating', '$comment');"; 
	$rs = mysql_query($query, $db_connection);
	print "<font color=\"Blue\"><b>Thanks your comments We appreciate all your input!</b>";
	print "</font><br/>";
	print "<a href=\"./showMovieInfo.php?mid=".$movie."\">See More Movie Info and More Reviews</a>";
	}
?>
</body>
</html>