Name: Albert Hsieh
SID: 003357346
email: alhsieh@ucla.edu

Name: Bryan Chen
SID: 603506391
email: bryanchen@ucla.edu

We used pair programming for this project.

