DROP TABLE MaxPersonID ;
DROP TABLE MaxMovieID ;
DROP TABLE MovieGenre;
DROP TABLE MovieDirector;
DROP TABLE MovieActor;
DROP TABLE Review;
DROP TABLE Movie;
DROP TABLE Actor;
DROP TABLE Director;

