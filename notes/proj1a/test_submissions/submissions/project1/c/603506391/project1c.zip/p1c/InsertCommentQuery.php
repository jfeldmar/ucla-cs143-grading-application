<html>
<head>
<title>Comment Query Handler</title>
</head>

<body>

<?php
	$db_connection = mysql_connect(localhost, "cs143", "");
	
	mysql_select_db("CS143", $db_connection);
	
	$MovieID = $_GET["MovieID"];
	$Name = $_GET["Name"];
	$Rating = $_GET["Rating"];
	$Comment = $_GET["Comment"];
	$TimeStampQuery = "SELECT NOW()";
	$TimeStampFetch = mysql_query($TimeStampQuery,$db_connection);
	$TimeStampData = mysql_fetch_row($TimeStampFetch);
	 
	if($Comment)
		$InsertCommentQuery = "INSERT INTO Review VALUES ('$Name','$TimeStampData[0]',$MovieID,$Rating,'$Comment')";
	else
		$InsertCommentQuery = "INSERT INTO Review VALUES ('$Name','$TimeStampData[0]',$MovieID,$Rating,NULL)";
	
		
	if(mysql_query($InsertCommentQuery, $db_connection)==1){
		print "<font color = 'FF9900'><b>&nbsp;&nbsp;Thanks! Your review has been added.</b></font>";
		print "<p>";
		print "<font color = 'FF9900'><b>&nbsp;&nbsp;You can view your comment <a href='ShowComments.php?MovieID=$MovieID'>HERE</b></a>!</font>";
		
		}
		
	else{
		$error = mysql_error();
		print "$error";
	}
	
	// disconnect from server
	mysql_close($db_connection);
	
?>

</body>
</html>
