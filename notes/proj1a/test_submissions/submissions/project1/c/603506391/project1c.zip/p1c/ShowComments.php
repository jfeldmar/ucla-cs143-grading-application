<html>
<head>
<title>Display Comments Page</title>
</head>
<body>

<?php 

	$db_connection = mysql_connect("localhost","cs143","");
	
	mysql_select_db("CS143",$db_connection);
	
	$MovieID = $_GET["MovieID"];
	$MovieReviewQuery = "SELECT name, time, rating, comment FROM Review WHERE mid = '$MovieID'";
	$MRQ = mysql_query($MovieReviewQuery,$db_connection);
	$num_fields = mysql_num_fields($MRQ);
	
	$MovieTitleQuery = "SELECT title FROM Movie WHERE id = '$MovieID'";
	$MTQ = mysql_query($MovieTitleQuery,$db_connection);
	$MovieTitle = mysql_fetch_row($MTQ);
	
	
	print "<font color ='FF9900'><b>&nbsp;Comments About the Movie: <font color='4C578D'><a href=ShowMovies.php?SearchType=Movie&Name=$MovieID>".$MovieTitle[0]."</a></font></b></font>";
	print "<br>";
	print "<font color='#FF9900'><b>&nbsp;--------------------------------</b></font>";
	print "<br>";
	
	while($ReviewData = mysql_fetch_row($MRQ)){
	 	
		print "&nbsp;In ".$ReviewData[1].", ";
		if($ReviewData[0])
			print "<font color='#FF9900'><b>&nbsp;Reviewer: </b></font><font color='4C578D'><b>" .$ReviewData[0]. "</b></font>";
		else
			print "<font color='#FF9900'><b>&nbsp;Reviewer: </b></font><font color='#4C578D'><b>Mr. Anonymous</b></font>";
	    print "<br>";
		if($ReviewData[3]){
		print "<font color='#FF9900'><b>&nbsp;Commented: </b></font><font color='#4C578D'><b>".$ReviewData[3]. "</b></font><font color='#FF9900'><b> with a rating of: </b></font><font color='#4C578D'><b>".$ReviewData[2]."</b></font>";
		}
		else{
		print "<font color='#FF9900'><b>&nbsp;Commented: </b></font><font color='#4C578D'><b>N/A</b></font><font color='#FF9900'><b> with a rating of: </b></font><font color='#4C578D'><b>".$ReviewData[2]."</b></font>";
		}
		print "<p>";
			
	}
			
	mysql_close($db_connection);

?>

</body>
</html>