<html>
<head>
<title>Actor's Info Page</title>
</head>

<body>
<?php


	$db_connection = mysql_connect(localhost, "cs143", "");
	
	mysql_select_db("CS143", $db_connection);

	$SearchType = $_GET["SearchType"];
	$Name = $_GET["Name"];
	
	$query = "SELECT * FROM " .$SearchType. " WHERE '$Name'  = id";
	$rs = mysql_query($query, $db_connection);
	$data = mysql_fetch_row($rs);
	
	
	print "<font color='#FF9900'><b>&nbsp;You've Searched </font><font color='#4C578D'>" .$data[2]. " " .$data[1]. " </font><font color='#FF9900'>in the </font><font color='#4C578D'>" .$SearchType. "</font>
	<font color='#FF9900'> Database. </b></font>";
	print "<p>";
	print "<font color='#FF9900'><b>&nbsp;Click <a href='Search.php'>HERE</a> to search again!</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b>&nbsp;Actor's Info:</b></font>";
	print "<br>";
	print "<font color='#FF9900'><b>--------------------------------</b></font>";
	print "<br>";
	print "<font color='#4C578D'><b> &nbsp;Name: </font><font color='#FF9900'>" .$data[2]. " " .$data[1]. "</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b> &nbsp;Gender: </font><font color='#FF9900'>" .$data[3]. "</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b> &nbsp;Date of Birth: </font><font color='#FF9900'>" .$data[4]. "</b></font>";
	print "<p>";
	if($data[5] == "")
	print "<font color='#4C578D'><b> &nbsp;Date of Death: </font><font color='#FF9900'>The Actor is Still Alive!</b></font>";
	else
	print "<font color='#4C578D'><b> &nbsp;Date of Death: </font><font color='#FF9900'>" .$data[5]. "</b></font>";
	
	$ActorId = $data[0];
	
	$MovieQuery = "SELECT M.title,M.id FROM Movie M, MovieActor MA WHERE '$ActorId' = MA.aid AND M.id = MA.mid";
	$ms = mysql_query($MovieQuery, $db_connection);
	$num_fields = mysql_num_fields($ms);	
	print "<br>";
	print "<font color='#FF9900'><b>--------------------------------</b></font>";
	print "<table border = 0>";
	
	while($moviedata = mysql_fetch_row($ms))
	{
	print "<tr>";
			print "<td>";
			print "<font color='#4C578D'><b>Acted in:&nbsp;&nbsp;</b></font>";
			print '<a href="ShowMovies.php?SearchType=Movie&Name='.$moviedata[1].'">'.$moviedata[0].'</a><br>';
			print "</td>";
	print "</tr>";
	}
	mysql_close ($db_connection);

?>
</body>
</html>
