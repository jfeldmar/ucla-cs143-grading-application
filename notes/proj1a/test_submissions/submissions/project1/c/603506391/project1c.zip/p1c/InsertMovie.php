<head>
<title>Create Movie Data Page</title>
</head>
<style type="text/css">

body {background-image: "MovieBgd.jpg"; background-repeat: no-repeat;}

</style>
<body background="MovieBgd.jpg" background-repeat="no-repeat">
	<p><font "size="4" color="#FF9900" face="Arial, Helvetica, sans-serif"><b>&nbsp;Create a New Movie Data:</b></font><br> 
  	<font size="1" color="#FF0000" face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;Please fill all necessary fields!</font>
  	<br>&nbsp;
  	<font size="1" color="#FF9900">---------------------------------------------------------------------</font>

<form action="InsertMovieQuery.php" method="GET">
    
  	<p>
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Movie Title:</b></font>
    <input name="Title" type="text" size="20" maxlength="20">  
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Rating:</b></font>			  
	<select size="1" name="Rating">
			    <option selected value="G">G</option>
			    <option value="PG">PG</option>
			    <option value="PG-13">PG-13</option>
			    <option value="NC-17">NC-17</option>
			    <option value="R">R</option>
	</select> 
    
  	<p>  
   
  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Year:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>
    <input name="Year" type="text" size="4" maxlength="4">

  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Genre:</b></font>			  
	<select size="1" name="Genre">
      <option selected value="Action">Action</option>
      <option value="Adult">Adult</option>
      <option value="Adventure">Adventure</option>
      <option value="Animation">Animation</option>
      <option value="Comedy">Comedy</option>
      <option value="Crime">Crime</option>
      <option value="Documentary">Documentary</option>
      <option value="Drama">Drama</option>
      <option value="Family">Family</option>
      <option value="Fantasy">Fantasy</option>
	  <option value="Horror">Horror</option>
      <option value="Musical">Musical</option>
      <option value="Mystery">Mystery</option>
      <option value="Romance">Romance</option>
      <option value="Sci-Fi">Sci-Fi</option>
	  <option value="Short">Short</option>
	  <option value="Thriller">Thriller</option>
	  <option value="War">War</option>
      <option value="Western">Western</option>
	</select>
    
  	<p>
  
  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Company:&nbsp;&nbsp;</b></font>
  	<input name="Company" type="text" size="20" maxlength="20">    
  	
  	<p> 
    
  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Movie Director's Info:</b></font>
    
    <br>
    
    &nbsp;&nbsp;
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>Last Name:</b></font>
    <input name="DLastName" type="text" size="20" maxlength="20">
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;First Name:</b></font>
    <input name="DFirstName" type="text" size="20" maxlength="20">
  
  	<p>
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Movie Actor's Info:</b></font>
    
    <br>
    
    &nbsp;&nbsp;
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>Last Name:</b></font>
    <input name="ALastName" type="text" size="20" maxlength="20">
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;First Name:</b></font>
    <input name="AFirstName" type="text" size="20" maxlength="20">
    
  	<p>
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;As:</b></font>
  	<input name="Role" type="text" size="50" maxlength="50">
    
    <p>
    
 	&nbsp;&nbsp;
 	<input type="reset" name="reset" value="Reset"> 
  	<INPUT TYPE="submit" VALUE="Submit"> 
  	  
</form>

</body>
</html>
