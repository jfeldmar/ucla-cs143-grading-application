<html>
<head>
<title>Insert Movie Query Page</title>
</head>
<body>
<?php
	
	
	// connect to server
	$db_connection = mysql_connect("localhost", "cs143", "");

	// select CS143 database
	mysql_select_db("CS143", $db_connection);
	
	$UnTitle = $_GET["Title"];
	$Title = mysql_real_escape_string($UnTitle,$db_connection);
	
	$Year = $_GET["Year"];
	
	$UnCompany = $_GET["Company"];
	$Company = mysql_real_escape_string($UnCompany,$db_connection);
	
	$Rating = $_GET["Rating"];
	
	$Genre = $_GET["Genre"];
	
	$UnDFirstName = $_GET["DFirstName"];
	$DFirstName = mysql_real_escape_string($UnDFirstName,$db_connection);
	
	$UnDLastName = $_GET["DLastName"];
	$DLastName = mysql_real_escape_string($UnDLastName,$db_connection);
	
	$UnAFirstName = $_GET["AFirstName"];
	$AFirstName = mysql_real_escape_string($UnAFirstName,$db_connection);
	
	$UnALastName = $_GET["ALastName"];
	$ALastName = mysql_real_escape_string($UnALastName,$db_connection);
	
	$UnRole = $_GET[Role];
	$Role = mysql_real_escape_string($UnRole,$db_connection);
	
	if ($Title && $Year && $Company && $DFirstName && $DLastName && $AFirstName && $ALastName && $Role) {
		
		//valid parameters
		$ValidTitle = "/^.{1,100}$/";
		$ValidY = "/^[0-9]{4,4}$/";
		$ValidCompany = "/^.{1,50}$/";
		$ValidName = "/^.{1,20}$/";
		$ValidRole = "/^.{1,50}$/";
		if(preg_match($ValidTitle,$Title)==1 && preg_match($ValidY,$Year)==1 && preg_match($ValidCompany,$Company)==1 &&
		   preg_match($ValidName,$DFirstName)==1 && preg_match($ValidName,$DLastName)==1 && preg_match($ValidName,$AFirstName)==1 &&
		   preg_match($ValidName,$ALastName)==1 && preg_match($ValidRole,$Role)==1) {
			
			//check if director exists
			$DirectorQuery = "SELECT id FROM Director WHERE first='$DFirstName' AND last='$DLastName'";
		
			$DQ = mysql_query($DirectorQuery, $db_connection);
			$DirectorData = mysql_fetch_row($DQ);
			if($DirectorData){
				$did = $DirectorData[0];
				
				
				$ActorQuery = "SELECT id FROM Actor WHERE first='$AFirstName' AND last='$ALastName'";
			
				$AQ = mysql_query($ActorQuery, $db_connection);
				$ActorData = mysql_fetch_row($AQ);
				if($ActorData){
					$aid = $ActorData[0];
					
					
					//Get new ID for movie
					$MovieIDQuery = "SELECT id FROM MaxMovieID";
					$MIDQ = mysql_query($MovieIDQuery, $db_connection);
					$MovieIDData = mysql_fetch_row($MIDQ);
					$MovieID = $MovieIDData[0];
				
					$UpdateIDQuery = "UPDATE MaxMovieID SET id=id+1";
					mysql_query($UpdateIDQuery, $db_connection);
					
					//Add Movie
					$InsertMovieQuery = "INSERT INTO Movie VALUES($MovieID,'$Title',$Year,'$Rating','$Company')";
					if(mysql_query($InsertMovieQuery, $db_connection)==1){
						print "<font color='#FF9900'><b>Movie </font><font color='#4C578D'>$Title</font><font color='#FF9900'> has been added to the database.</b></font><br>";
						print "<font color='#FF9900'><b>Click <a href='ShowMovies.php?SearchType=Movie&Name=$MovieID'>Here</a> to See the Newly Inserted Movie</b></font>";
						}
					else {
						$error = mysql_error();
						print "$error";
					}
					
					//Add MovieGenre
					$InsertGenreQuery = "INSERT INTO MovieGenre VALUES($MovieID,'$Genre')";
					if(mysql_query($InsertGenreQuery, $db_connection)==1){
					}
					else {
						$error = mysql_error();
						print "$error";
					}
					
					//Add MovieDirector
					$InsertDirQuery = "INSERT INTO MovieDirector VALUES($MovieID,$did)";
					if(mysql_query($InsertDirQuery, $db_connection)==1){
					}
					else {
						$error = mysql_error();
						print "$error";
					}
					
					//Add MovieActor
					$InsertActorQuery = "INSERT INTO MovieActor VALUES($MovieID,$aid,'$Role')";
					if(mysql_query($InsertActorQuery, $db_connection)==1){
					}
					else {
						$error = mysql_error();
						print "$error";
					}
				}
				else
					print "<font color='#FF9900'><b>&nbsp;Invalid Actor. Click <a href='InsertMovie.php'>Here</a> to Add Actor Again</b></font>";
			}
			else
				print "<font color='#FF9900'><b>&nbsp;Invalid Director. Click <a href='InsertMovie.php'>Here</a> to Add Director Again</b></font>";
		}
		else
			print "<font color='#FF9900'><b>&nbsp;Invalid Input. Click <a href='InsertMovie.php'>Here</a> to Try Again</b></font>";
	}
	else
		print "<font color='#FF9900'><b>&nbsp;Please Fill in All Fields. Click <a href='InsertMovie.php'>Here</a> to Try Again</b></font>";
		
	// disconnect from server
	mysql_close($db_connection);
?>
</body>
</html>
