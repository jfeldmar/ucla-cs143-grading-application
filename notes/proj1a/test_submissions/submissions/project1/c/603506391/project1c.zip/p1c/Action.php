<?php
$query = $_GET[selection];
if($query){
	if($query == "Search")
		header('Location: Search.php');
	else if ($query == "InsertMovie")
		header('Location: InsertMovie.php');
	else if ($query == "InsertDirector")
		header('Location: InsertDirector.php');
	else
		print "Unknown Query";
}
?>

<html>
</html>