<html>
<head>
<title>Movie Database</title>
</head>
<frameset rows="324,*" cols="*" framespacing="0" frameborder="no" border="1">
  <frame src="header.php" name="topFrame" scrolling="No" target="mainFrame" noresize="noresize" id="topFrame" title="topFrame" />
  <frame src="Main.php" name="mainFrame" id="mainFrame" title="mainFrame" />
</frameset>
<noframes><body>
</body>
</noframes></html>
