<html>
<head>
<title>Movie Database</title>
</head>
<style type="text/css">

body {background-image: "StartBgd.jpg"; background-repeat: no-repeat;}

</style>

<body background="StartBgd.jpg">
<font size="2" color="#FF9900"> Welcome to our Movie Data Base. Please choose your action from the above menu.</font>
</body>
</html>
