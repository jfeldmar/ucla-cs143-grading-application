<html>
<head>
<title>Insert Actor/Director Page</title>
</head>

<?php
	
	$db_connection = mysql_connect(localhost,"cs143","");
	mysql_select_db("CS143",$db_connection);
	
	$UnLastName = $_GET["LastName"];
	$LastName = mysql_real_escape_string($UnLastName);
	$UnFirstName = $_GET["FirstName"];
	$FirstName = mysql_real_escape_string($UnFirstName);
	$Gender = $_GET["Gender"];
	$DBM = $_GET["BMonth"];
	$DBD = $_GET["BDate"];
	$DBY = $_GET["BYear"];
	$DDM = $_GET["DMonth"];
	$DDD = $_GET["DDate"];
	$DDY = $_GET["DYear"];
	$Actor = $_GET["Actor"];
	$Director = $_GET["Director"];
	
	if($FirstName && $LastName && $DBM && $DBD && $DBY)
		{
			if($Actor=="ON" || $Director=="ON"){
				$ValidName = "/^.{1,20}$/";
					if(preg_match($ValidName, $FirstName)==1 && preg_match($ValidName, $LastName)==1){
						$ValidM = "/^(0[1-9]|1[0-2])$/";
						$ValidD = "/^0[1-9]|[1-2][0-9]|3[0-1]$/";
						$ValidY = "/^[0-9]{4,4}$/";
						
						if(preg_match($ValidM,$DBM)==1 && preg_match($ValidD,$DBD)==1 && preg_match($ValidY,$DBY)==1){
					
							//Get ID from MAXPersonID
							$IDQuery = "SELECT id FROM MaxPersonID";
							$IDQ = mysql_query($IDQuery, $db_connection);
							$IDData = mysql_fetch_row($IDQ);
							$ID = $IDData[0];
							
							//Update the ID since we used one
							$UpdateIDQuery = "UPDATE MaxPersonID SET id=id+1";
							mysql_query($UpdateIDQuery, $db_connection);
	
							//Check if the person has a death date
							if ($DDM && $DDD && $DDY){
								// Check date of death is valid
								if(preg_match($ValidM,$DDM)==1 && preg_match($ValidD,$DDD)==1 && preg_match($ValidY,$DDY)==1){
									if($Actor == "ON"){
										$InsertQuery = "INSERT INTO Actor VALUES($ID,'$LastName','$FirstName','$Gender',$DBY$DBM$DBD,$DDY$DDM$DDD)";
											if(mysql_query($InsertQuery, $db_connection)==1){
												print "<font color='#FF9900'><b>&nbsp;Actor </font><font color='#4C578D'>$FirstName $LastName</font><font color='#FF9900'> has been added to the database with the ID# $ID.<br>";
												print "<font color='#FF9900'><b>&nbsp;Click <a href='InsertDirector.php'>Here</a> to get back to the Insert Page!</b></font>";
												print "<p>";
												
								}
											else{
												$error = mysql_error();
											print "$error";
											}
									}
							
									if($Director == "ON"){
										$InsertQuery = "INSERT INTO Director VALUES($ID,'$LastName','$FirstName',$DBY$DBM$DBD,$DDY$DDM$DDD)";
											if(mysql_query($InsertQuery, $db_connection)==1){
												print "<font color='#FF9900'><b>&nbsp;Director </font><font color='#FF9900'>$FirstName $LastName</font><font color='#FF9900'> has been added to the database with the ID# $ID.<br>";
												print "<font color='#FF9900'><b>&nbsp;Click <a href='InsertDirector.php'>Here</a> to get back to the Insert Page!</b></font>";
								}
											else {
												$error = mysql_error();
											print "$error";
											}	
									}
							}
						
							else{
								//Reset the MaxPersonID because the insertion did not success
								$UpdateIDQuery = "UPDATE MaxPersonID SET id=id-1";
								mysql_query($UpdateIDQuery, $db_connection);
								print "<font color='#FF9900'><b>&nbsp;Please enter valid date of death. Click <a href='InsertDirector.php'>Here</a> to Insert Page.";
							}
					}
					
					// No date of death given
					else{
						if($Actor == "ON"){
								$InsertQuery = "INSERT INTO Actor VALUES($ID,'$LastName','$FirstName','$Gender',$DBY$DBM$DBD,\N)";
								if(mysql_query($InsertQuery, $db_connection)==1){
									print "<font color='#FF9900'><b>&nbsp;Actor <font color='#4C578D'>$FirstName $LastName </font><font color='#FF9900'>has been added to the database with the ID# $ID.</b><br>";
									print "<font color='#FF9900'><b>&nbsp;Click <a href='InsertDirector.php'>Here</a> to get back to the Insert Page!</b></font>";
									print "<p>";
								}
								else{
									$error = mysql_error();
									print "$error";
								}
						}
						if($Director == "ON"){
							$InsertQuery = "INSERT INTO Director VALUES($ID,'$LastName','$FirstName',$DBY$DBM$DBD,\N)";
							if(mysql_query($InsertQuery, $db_connection)==1){
								print "<font color='#FF9900'><b>&nbsp;Director </font><font color='#4C578D'>$FirstName $LastName</font> has been added to the database with the ID# $ID.</b><br>";
								print "<font color='#FF9900'><b>&nbsp;Click <a href='InsertDirector.php'>Here</a> to get back to the Insert Page!</b></font>";
								}
							else {
								$error = mysql_error();
								print "$error";
							}
						}
					}
				}
				
				else
					print "<font color='#FF9900'><b>&nbsp;Invalid Date of Birth. Click <a href='InsertDirector.php'>Here</a> to Insert Page.";
				
			}
			else
				print "<font color='#FF9900'><b>&nbsp;Invalid Names. Click <a href='InsertDirector.php'>Here</a> to Insert Page.";
		}
		else
			print "<font color='#FF9900'><b>&nbsp;Invalid Position. Click <a href='InsertDirector.php'>Here</a> to Insert Page.";
	}
	else
		print "<font color='#FF9900'><b>&nbsp;No Birthday provided. Click <a href='InsertDirector.php'>Here</a> to Insert Page.";
	
		

	mysql_close($db_connection);
	
?>


<body>
</body>
</html>
