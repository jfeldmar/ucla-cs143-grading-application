<html>
<head>
<title>Search Query Handler</title>
</head>

<body vlink="#FF9900" link="#FF9900">

<?php
 
	$db_connection = mysql_connect(localhost, "cs143", "");
	
	mysql_select_db("CS143", $db_connection);
	$SearchType = $_GET["SearchType"];
	$Name = $_GET["Name"];
	$InputName = mysql_real_escape_string($Name,$db_connection);
	//this is for Actor/Director
	if($SearchType == "Actor"){
	print "<font color='#FF9900'><b>&nbsp;You've Searched </font><font color='#4C578D'>" .$Name. " </font><font color='#FF9900'>in the </font><font color='#4C578D'>" .$SearchType. "</font>
	<font color='#FF9900'> Database. </b></font>";
	print "<p>";
	print "<font color='#FF9900'><b>&nbsp;Click <a href='Search.php'>HERE</a> to search again!</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b>&nbsp;Search Result:</b></font>";
	print "<br>";
	print "<font color='#FF9900'><b>--------------------------------</b></font>";
	print "<p>";
	
	//if $Name is empty we select all 
	if($Name == ""){
	$query = "SELECT id FROM $SearchType";
	$display = "SELECT CONCAT(first,' ',last,' (', dob, ')') FROM $SearchType";
	
	//set up the query
	$rs = mysql_query($query, $db_connection);
	$ds = mysql_query($display, $db_connection);
	$num_fields = mysql_num_fields($rs);
	
	print "<table border = 0>";
	
	while($data = mysql_fetch_row($rs))
	{
	$show = mysql_fetch_row($ds);
	print "<tr>";
		for($i=0;$i<$num_fields;$i++)
		{
			print "<td>";
			print "<font color='#4C578D'><b>Actor's Name:&nbsp;&nbsp;</b></font>";
			print '<a href="ShowActors.php?SearchType='.$SearchType.'&Name='.$data[$i].'">'.$show[$i].'</a><br>';
			print "</td>";
		}
	print "</tr>";
	}	
 }
	
	//Otherwise we set up a conditional comparison
	else{
	
	$query = "SELECT id FROM Actor WHERE Actor.first = '$InputName'	 OR Actor.last = '$InputName' OR '$InputName' = CONCAT(first,' ',last)";
	$display = "SELECT CONCAT(first,' ',last,' (', dob, ')') FROM Actor WHERE Actor.first = '$InputName' OR Actor.last = '$InputName' OR '$InputName' = CONCAT(first,' ',last)";
	
	//set up the query
	$rs = mysql_query($query, $db_connection);
	$ds = mysql_query($display, $db_connection);
	$num_fields = mysql_num_fields($rs);
	
	print "<table border = 0>";
	
	while($data = mysql_fetch_row($rs))
	{
	$show = mysql_fetch_row($ds);
	print "<tr>";
		for($i=0;$i<$num_fields;$i++)
		{
			print "<td>";
			print "<font color='#4C578D'><b>Actor's Name:&nbsp;&nbsp;</b></font>";
			print '<a href="ShowActors.php?SearchType='.$SearchType.'&Name='.$data[$i].'">'.$show[$i].'</a><br>';
			print "</td>";
		}
	print "</tr>";
	}	
  }
}

//============================================================================================================================================


//this is for Movie title Search
	if($SearchType == "Movie"){
		print "<font color='#FF9900'><b>&nbsp;You've Searched </font><font color='#4C578D'>" .$Name. " </font><font color='#FF9900'>in the </font><font color='#4C578D'>" .$SearchType. "</font>
		<font color='#FF9900'> Database. </b></font>";
		print "<p>";
		print "<font color='#FF9900'><b>&nbsp;Click <a href='Search.php'>HERE</a> to search again!</b></font>";
		print "<p>";
		print "<font color='#4C578D'><b>&nbsp;Search Result:</b></font>";
		print "<br>";
		print "<font color='#FF9900'><b>--------------------------------</b></font>";
		print "<p>";
	//if $Name is empty we select all 
	if($Name == ""){
	$query = "SELECT title,id FROM " .$SearchType;
	$display = "SELECT CONCAT(title,' ','(', year, ')') FROM " .$SearchType;
	
	//set up the query
	$rs = mysql_query($query, $db_connection);
	$ds = mysql_query($display, $db_connection);
	$num_fields = mysql_num_fields($rs);
	
	print "<table border = 0>";
	
	while($data = mysql_fetch_row($rs))
	{
	$i=0;
	$show = mysql_fetch_row($ds);
	print "<tr>";
			print "<td>";
			print "<font color='#4C578D'><b>Movie Title:&nbsp;&nbsp;</b></font>";
			print '<a href="ShowMovies.php?SearchType='.$SearchType.'&Name='.$data[1].'">'.$show[$i].'</a><br>';
			print "</td>";
	print "</tr>";
	}	
 }
	
	//Otherwise we set up a conditional comparison
	else{
	$query = "SELECT title,id FROM " .$SearchType. " WHERE title LIKE '%$InputName%'";
	$display = "SELECT CONCAT(title,' ', '(', year, ')') FROM " .$SearchType. " WHERE title LIKE '%$InputName%'";

	//set up the query
	$rs = mysql_query($query, $db_connection);
	$ds = mysql_query($display, $db_connection);
	$num_fields = mysql_num_fields($rs);
	
	print "<table border = 0>";
	
	while($data = mysql_fetch_row($rs))
	{
	$show = mysql_fetch_row($ds);
	$i=0;
	print "<tr>";
			print "<td>";
			print "<font color='#4C578D'><b>Movie Title:&nbsp;&nbsp;</b></font>";
			print "$link";
			print '<a href="ShowMovies.php?SearchType='.$SearchType.'&Name='.$data[1].'">'.$show[$i].'</a><br>';
			print "</td>";
	print "</tr>";
	}	
  }
}

mysql_close ($db_connection);
?>

</body>
</html>
