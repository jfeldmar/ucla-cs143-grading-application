
<html>
<head>
<title>Movie Database</title>
</head>
<base target="mainFrame">
<body background="layer.jpg"> 
<form method="GET" action="Action.php">
<table width="456" height="304" background="backgroun2.jpg">

	<tr>
		<td height="2"></td>
	</tr>
	<tr>
		<td height="280"></td>
		<td width="128">
			<p>
			  <select size="1" name="selection">
			    <option selected value="Search">Search</option>
			    <option value="InsertMovie">Insert Movie</option>  
                <option value="InsertDirector">Insert Star/Director</option>
              </select>
			  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <INPUT TYPE="submit" VALUE="GO">
          </p>
		</td>
	</tr>
</table>

</form>
</body>
</html>
