<html>
<head>
<title>Create Movie Star/Director Page</title>
</head>
<style type="text/css">

body {background-image: "DirectorBgd.jpg"; background-repeat: no-repeat;}

</style>
<body background="DirectorBgd.jpg" background-repeat="no-repeat">
<p><font "size="4" color="#FF9900" face="Arial, Helvetica, sans-serif"><b>&nbsp;Create a Movie Star/Director:</b></font><br> 
  <font size="1" color="#FF0000" face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;Please fill all necessary fields!</font><br>
&nbsp;<font size="1" color="#FF9900">---------------------------------------------------------------------</font>

<form action="InsertStarQuery.php" method="get">&nbsp;&nbsp;

  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>Last Name:</b></font>
	<input name="LastName" type="text" size="20" maxlength="20">

  	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;First Name:</b></font>
	<input name="FirstName" type="text" size="20" maxlength="20">
	
  	<p>
    
	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Gender:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>			  
	<select size="1" name="Gender">
	<option selected value="Male">Male</option>
	<option value="Female">Female</option>  
	</select>
	
  	<p>
	
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Date of Birth:&nbsp;(MM/DD/YYYY)&nbsp;</b>
	<input name="BMonth" type="text" size="2" maxlength="2">/<input name="BDate" type="text" size="2" maxlength="2">/<input name="BYear" type="text" size="4" maxlength="4"></font>
	
  	<p>

	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Date of Death:(MM/DD/YYYY)&nbsp;</b>
	<input name="DMonth" type="text" size="2" maxlength="2">/<input name="DDate" type="text" size="2" maxlength="2">/<input name="DYear" type="text" size="4" maxlength="4"></font>

  	<p>

	<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;Position: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Actor</b>
    <INPUT TYPE="checkbox" NAME="Actor" VALUE="ON"><b>Director</b>
    <INPUT TYPE="checkbox" NAME="Director" VALUE="ON"></font>

	<p>

	&nbsp;&nbsp;<input type="reset" name="reset" value="Reset"> <INPUT TYPE="submit" VALUE="Submit"> 

</form>

</body>
</html>
