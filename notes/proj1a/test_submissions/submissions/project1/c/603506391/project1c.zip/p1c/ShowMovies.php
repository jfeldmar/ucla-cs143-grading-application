<html>
<head>
<title>Movie Info Page</title>
</head>

<body>

<?php


	$db_connection = mysql_connect(localhost, "cs143", "");
	
	mysql_select_db("CS143", $db_connection);

	$SearchType = $_GET["SearchType"];
	$InputName = $_GET["Name"];
	$Name = mysql_real_escape_string($InputName);
	
	//query movie info
	
	$query = "SELECT * FROM " .$SearchType. " WHERE '$Name'  = id";
	$rs = mysql_query($query, $db_connection);
	$data = mysql_fetch_row($rs);
	
	print "<font color='#FF9900'><b>&nbsp;You've Searched </font><font color='#4C578D'>" .$data[1]. " </font><font color='#FF9900'>in the </font><font color='#4C578D'>" .$SearchType. "</font>
	<font color='#FF9900'> Database. </b></font>";
	print "<p>";
	print "<font color='#FF9900'><b>&nbsp;Click <a href='Search.php'>HERE</a> to search again!</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b>&nbsp;Movie Info:</b></font>";
	print "<br>";
	print "<font color='#FF9900'><b>--------------------------------</b></font>";
	print "<br>";
	print "<font color='#4C578D'><b> &nbsp;Movie Title: </font><font color='#FF9900'>" .$data[1]. " (" .$data[2]. ") </b></font>";
	print "<p>";
	print "<font color='#4C578D'><b> &nbsp;MPAA Rating: </font><font color='#FF9900'>" .$data[3]. "</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b> &nbsp;Production Company: </font><font color='#FF9900'>" .$data[4]. "</b></font>";
	print "<p>";
	print "<font color='#4C578D'><b> &nbsp;Movie Genre:&nbsp;&nbsp;</b></font>";
	
	$MovieId = $data[0];
	$GenreQuery = "SELECT Genre FROM MovieGenre MG WHERE '$MovieId' = MG.mid";
	$gs = mysql_query($GenreQuery, $db_connection);
	$num_fields = mysql_num_fields($gs);	
	
	print "<table border = 0>";
	
	while($genredata = mysql_fetch_row($gs))
	{
	print "<tr>";
		for($i=0;$i<$num_fields;$i++)
		{
			//print "<td>";
			print  "<font color ='#FF9900'><b>$genredata[$i] </b></font> ";
			//print "</td>";
		}
	print "</tr>";
	}
	
	//query movie director
	$DirectorIdQuery = "SELECT did FROM MovieDirector WHERE '$MovieId' = mid";
	$DQs = mysql_query($DirectorIdQuery, $db_connection);
	$DirectorId = mysql_fetch_row($DQs);
	
	$DirectorQuery = "SELECT CONCAT(first,' ',last,' (',dob,')') FROM Director D, MovieDirector MD WHERE  '$MovieId' = mid AND '$DirectorId[0]' = id";
	$ds = mysql_query($DirectorQuery, $db_connection);
	$DirectorData = mysql_fetch_row($ds);
	
	//query movie avg rating
	$RatingQuery = "SELECT AVG(rating) FROM Review WHERE mid = '$MovieId'";
	$Qrating = mysql_query($RatingQuery, $db_connection);	
	$RatingData = mysql_fetch_row($Qrating);
	
	print "<p>";
	
	//display director
	if ($DirectorData[0] == "")
		print "<font color='#4C578D'><b> &nbsp;Movie Director: </font><font color='#FF9900'> N/A </b></font>";
	else
		print "<font color='#4C578D'><b> &nbsp;Movie Director: </font><font color='#FF9900'>" .$DirectorData[0]. "</b></font>";
	
	print "<p>";
	
	//display rating
	if ($RatingData[0] == 0)
		print "<font color='#4C578D'><b> &nbsp;Average Movie Rating: </font><font color='#FF9900'> No Ratings Yet! </b></font>";
	else 
		print "<font color='#4C578D'><b> &nbsp;Average Movie Rating: </font><font color='#FF9900'>" .$RatingData[0]. "</b></font>";
	
	//display add comment link
	
	print "<p>";
	print '&nbsp;<a href="InsertComment.php?MovieID='.$MovieId.'">Add Comment to this Movie Here!</a><p>';
	print '&nbsp;<font color ="FF9900">OR See What Others Have to Say About This Movie <a href="ShowComments.php?MovieID='.$MovieId.'">Here!</a></font>';
	//query all the actor acted in this movie
	$ActorQuery = "SELECT CONCAT(first,' ',last),id FROM Actor A, MovieActor MA WHERE A.id = MA.aid AND '$MovieId' = MA.mid";
	$as = mysql_query($ActorQuery, $db_connection);
	
	print "<br>";
	print "<font color='#FF9900'><b>--------------------------------</b></font>";
	print "<table border = 0>";
	
	while($Actordata = mysql_fetch_row($as))
	{
	$i=0;
	print "<tr>";
		//for($i=0;$i<$num_fields;$i++)
		//{
			print "<td>";
			print "<font color='#4C578D'><b>Actors in the movie:&nbsp;&nbsp;</b></font>";
			print '<a href="ShowActors.php?SearchType=Actor&Name='.$Actordata[1].'">'.$Actordata[$i].'</a><br>';
			print "</td>";
		//}
	print "</tr>";
	}
	
	
	
	
	mysql_close ($db_connection);

?>
</body>
</html>
