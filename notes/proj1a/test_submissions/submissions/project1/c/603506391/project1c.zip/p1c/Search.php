<html>
<head>
<title>Search Page</title>
</head>

<style type="text/css">

body {background-image: "SearchBgd.jpg"; background-repeat: no-repeat;}

</style>

<body background="SearchBgd.jpg" background-repeat="no-repeat">

	<p>
	
    <font "size="4" color="#FF9900" face="Arial, Helvetica, sans-serif"><b>&nbsp;Search By Actor/Movie Name:</b></font><br> 
	<font size="1" color="#FF0000" face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;Please fill all necessary fields!</font><br>
	&nbsp;
	<font size="1" color="#FF9900">---------------------------------------------------------------------</font>

	<form method="GET" action="SearchQuery.php">
  	&nbsp;&nbsp;<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;Search By:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>			  
  	
    <select size="1" name="SearchType">
    <option selected value="Actor">Name</option>
    <option value="Movie">Movie</option>  
  	</select>
    
  	<p>
    
	&nbsp;&nbsp;&nbsp;<font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>Please enter the actor/movie name:&nbsp;&nbsp;</b></font><input name="Name" type="text" size="20" 			maxlength="40">
	
    <p>
    
	&nbsp;&nbsp;<input type="reset" name="reset" value="Reset"> <INPUT TYPE="submit" VALUE="Submit"> 

	</form>

</body>
</html>
