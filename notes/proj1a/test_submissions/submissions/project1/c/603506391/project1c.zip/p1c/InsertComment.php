<head>
<title>Add Comment Page</title>
</head>
<style type="text/css">

body {background-image: ""; background-repeat: no-repeat;}

</style>
<?php
	$db_connection = mysql_connect(localhost, "cs143", "");
	
	mysql_select_db("CS143", $db_connection);
	
	$MovieID = $_GET["MovieID"];
	$MovieTitleQuery = "Select CONCAT(title, ' (',year,') ') FROM Movie WHERE id = '$MovieID'";
	$qtitle = mysql_query($MovieTitleQuery,$db_connection);
	$MovieTitleData = mysql_fetch_row($qtitle);
	 
?>
<body background="" background-repeat="no-repeat">
	<font size="4" color="#FF9900" face="Arial, Helvetica, sans-serif"><b>&nbsp;Insert Movie Comment:</b></font><br> 
  	<font size="1" color="#FF0000" face="Arial, Helvetica, sans-serif">&nbsp;&nbsp;Please fill all necessary fields!</font>
  	<br>&nbsp;
<font size="1" color="#FF9900">---------------------------------------------------------------------<br>
</font>
    <?php
    print "<font size='1' face='Arial, Helvetica, sans-serif' color='#FF9900'><b>&nbsp;&nbsp;&nbsp;&nbsp; You are inserting a comment to the movie: </font><font size='1' face ='Arial,Helvetica, sans-serif' color='4C578D'>"  .$MovieTitleData[0]. "</font></b></font>"
 	?>
    &nbsp; &nbsp;<a href="Search.php"><font size="1" face="Arial, Helvetica, sans-serif" color="FF9900">Nevermind -- Back to Search</font></a>
    <br>     
  	<form action="InsertCommentQuery.php" method="GET">
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your Name:</b></font>
  	<input name="Name" type="text" size="20" maxlength="40">
    
	<?php
     print "<input type='hidden' name='MovieID' value='$MovieID'>"
    ?>
    
	<br>
    
    <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rating:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font>			  
      <select size="1" name="Rating">
        <option selected value="5">5 - Excellent!</option>
        <option value="4">4 - Good</option>
        <option value="3">3 - OK</option>
        <option value="2">2 - Poor</option>
        <option value="1">1 - Nightmare</option>
      </select> 
        
      <br>
  	  <font size="1" face="Arial, Helvetica, sans-serif" color="#FF9900"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Your Comment:</b></font><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<textarea name="Comment" cols="50" rows="10"></textarea>
    <br>
&nbsp;&nbsp;
 	<input type="reset" name="reset" value="Reset"> 
  	<INPUT TYPE="submit" VALUE="Rateit!">
	</form>
</body>
</html>
