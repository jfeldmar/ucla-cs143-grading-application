<html>
<head><title>add_movie.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add Movie</h2>

<!-- horizontal line -->
<hr>

<form method = "POST" action="add_movie1.php">

<font>Movie Title: </font>
<INPUT TYPE='text' NAME="title" maxlength="100">
<br>

<font>Company: </font>
<INPUT TYPE='text' NAME="company" maxlength="50">
<br>

<font>Director: </font>
<SELECT Name="director">
<?php

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, last, first, dob from Director;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$did = $row[0];
	$last = $row[1];
	$first = $row[2];
	$dob = $row[3];
	echo"<OPTION>$did, $last, $first, ($dob)";
}
// close mysql connection
mysql_close($db_connection);

?>

</SELECT>
<br>
<font>Year: </font>
<INPUT TYPE='text' NAME="year" maxlength="4">
<br>

<font>MPAA Rating: </font>
<SELECT Name="rate">
<OPTION>G
<OPTION>NC-17
<OPTION>PG
<OPTION>PG-13
<OPTION>R
<OPTION>surrendere
</SELECT>
<br>

<font>Genre:</font><br>
<input type='checkbox' name='Action' value='Action'>Action
<input type='checkbox' name='Adult' value='Adult'>Adult
<input type='checkbox' name='Adventure' value='Adventure'>Adventure
<input type='checkbox' name='Animation' value='Animation'>Animation
<input type='checkbox' name='Comedy' value='Comedy'>Comedy
<input type='checkbox' name='Crime' value='Crime'>Crime
<input type='checkbox' name='Documentary' value='Documentary'>Documentary
<br>
<input type='checkbox' name='Drama' value='Drama'>Drama
<input type='checkbox' name='Family' value='Family'>Family
<input type='checkbox' name='Fantasy' value='Fantasy'>Fantasy
<input type='checkbox' name='Horror' value='Horror'>Horror
<input type='checkbox' name='Musical' value='Musical'>Musical
<input type='checkbox' name='Mystery' value='Mystery'>Mystery
<input type='checkbox' name='Romance' value='Romance'>Romance
<br>
<input type='checkbox' name='SciFi' value='SciFi'>Sci-Fi
<input type='checkbox' name='Short' value='Short'>Short
<input type='checkbox' name='Thriller' value='Thriller'>Thriller
<input type='checkbox' name='War' value='War'>War
<input type='checkbox' name='Western' value='Western'>Western


<!-- horizontal line -->
<hr>

<input type="submit" value="ADD!">
</form>

</body>
</html>
