<html>
<head> <title> show_actor1.php </title> </head>
<body bgcolor="99cc99">
<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);


$actor = $_GET['actor'];
$array=explode(",", $actor);
$id = $array[0];

$query = "select* from Actor where id='$id';";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
$id = $row[0];
$last = $row[1];
$first = $row[2];
$sex = $row[3];
$dob = $row[4];
$dod = $row[5];
// free result memory
mysql_free_result($rs);

// close mysql connection
mysql_close($db_connection);


echo "<h2 align='center'>Show Actor Information</h2>";
echo "<!-- horizontal line -->";
echo "<hr>";
echo "Name: ";
echo "$first $last";
echo "<br>";
echo "Sex: ";
echo $sex;
echo "<br>";
echo "Date of Birth: ";
echo $dob;
echo "<br>";
echo "Date of Death: ";
if(dod == null)
	echo "Alive";
else
	echo $dod;
echo "<br><br>";

echo "Act in: ";
echo "<br>";
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = sprintf("select M.id, M.title, MA.role, M.year from MovieActor MA, Movie M where MA.mid=M.id^MA.aid='$id';");
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$mid = $row[0];
	$title = $row[1];
	$role = $row[2];
	$year = $row[3];
	echo "<A href='show_movie1.php?movie=$mid%2C+$title%2C+($year)'>$role in $title</A><br>";
}
// free result memory
mysql_free_result($rs);

// close mysql connection
mysql_close($db_connection);


?>


<!-- horizontal line -->
<hr>

<form method = "GET" action="show_actor1.php">
<font>Select Actor:</font>
<SELECT Name="actor">
<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, last, first, dob from Actor;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$id = $row[0];
	$last = $row[1];
	$first = $row[2];
	$dob = $row[3];
	echo"<OPTION>$id, $last, $first, ($dob)";
}
?>

</SELECT>

<input type="submit" value="Search">
</form>




</body>
</html>
