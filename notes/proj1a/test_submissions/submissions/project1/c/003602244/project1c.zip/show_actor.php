<html>
<head> <title> show_actor.php </title> </head>
<body bgcolor="99cc99">

<h2 align="center">Show Actor Information</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="show_actor1.php">
<font>Select Actor:</font>
<SELECT Name="actor">
<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, last, first, dob from Actor;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$id = $row[0];
	$last = $row[1];
	$first = $row[2];
	$dob = $row[3];
	echo"<OPTION>$id, $last, $first, ($dob)";
}
?>

</SELECT>

<input type="submit" value="Search">
</form>




</body>
</html>