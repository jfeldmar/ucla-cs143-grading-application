<html>
<head><title>add_person.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add new Actor/director</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="add_person1.php">

<font>Identity: </font>
<SELECT Name="identity">
<OPTION>Actor
<OPTION>Director
</SELECT>
<br>

<font>First Name: </font>
<INPUT TYPE='text' NAME="first" maxlength="20">
<br>

<font>Last Name: </font>
<INPUT TYPE='text' NAME="last" maxlength="20">
<br>

<font>Sex: </font>
<SELECT Name="sex">
<OPTION>Male
<OPTION>Female
</SELECT>
<br>

<font>Date of Birth: </font>
<INPUT TYPE='text' NAME="dob" maxlength="8">
<font> (YYYYMMDD)</font>
<br>

<font>Date of Death: </font>
<INPUT TYPE='text' NAME="dod" maxlength="8">
<font> (YYYYMMDD)</font>
<em>*only if applicable</font>

<!-- horizontal line -->
<hr>

<input type="submit" value="ADD!">
</form>


</body>
</html>
