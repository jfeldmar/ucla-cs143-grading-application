<html>
<head><title>add_relation1.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add Movie & Actor Relation</h2>

<!-- horizontal line -->
<hr>

<form method = "POST" action="add_relation1.php">

<font>Movie Title: </font>
<select name = "movie">
<?php

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, title, year from Movie;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$mid = $row[0];
	$title = $row[1];
	$year = $row[2];
	echo"<OPTION>$mid, $title, ($year)";
}
// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);

?>
</SELECT>
<br>


<font>Select Actor: </font>
<select name = "actor">
<?php

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, first, last, (dob) from Actor;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$aid = $row[0];
	$first = $row[1];
	$last = $row[2];
	$dob = $row[2];
	echo"<OPTION>$aid, $first, $last, ($dob)";
}
// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);

?>
</SELECT>
<br>


<font>Role: </font>
<INPUT TYPE='text' NAME="role" maxlength="50">
<br>

<!-- horizontal line -->
<hr>

<input type="submit" value="ADD!">
<?php
$movie=$_POST['movie'];
$array = explode(",", $movie);
$mid=$array[0];
$actor=$_POST['actor'];
$array = explode(",", $actor);
$aid=$array[0];
$role=$_POST['role'];


if($role ==null)
	$msg = " Please input a role.";
else{
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);
// add Role information into MovieActor table
$query = sprintf("INSERT into MovieActor VALUES ('$mid', '$aid', '$role')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
// close mysql connection
mysql_close($db_connection);
	$msg = "Successfully Added to the Database!";
}
?>
<?php 
	echo $msg;
?>
</form>

</body>
</html>
