<html>
<head> <title> show_movie.php </title> </head>
<body bgcolor="99cc99">

<h2 align="center">Show Movie Information</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="show_movie1.php">
<font>Select Movie:</font>
<SELECT Name="movie">
<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, title, year from Movie;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$id = $row[0];
	$title = $row[1];
	$year = $row[2];
	echo"<OPTION>$id, $title, ($year)";
}
// free result memory
//mysql_free_result($result);

// close mysql connection
mysql_close($db_connection);
?>

</SELECT>

<input type="submit" value="Search">
</form>




</body>
</html>