<html>
<head><title>add_review.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add Movie Review</h2>

<!-- horizontal line -->
<hr>
<form method = "POST" action="add_review1.php">

<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select title from Movie;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
echo "<font>Select Movie: </font>";
echo "<SELECT Name='movie'>";
while ($row = mysql_fetch_row($rs)){
	$title = $row[0];
	echo"<OPTION>$title";
}
// close mysql connection
mysql_close($db_connection);

?>

</SELECT>
<br><br>

<font>Your Name: </font>
<INPUT TYPE='text' NAME='name' maxlength='20'>
<br><br>

<font>Rating: </font>
<SELECT Name='rate'>
<option>5
<option>4
<option>3
<option>2
<option>1
</SELECT>
<font> 5 = I love this movie! ... 1 = I hate this movie! </font>
<br><br>

<font> Comments:</font><br>
<TEXTAREA NAME='comment' ROWS=10 COLS=50>
</TEXTAREA>
<font><em> no more than 500 characters. </em></font>
<hr>
<input type='submit' value='ADD'>
</form>


</body>
</html>
