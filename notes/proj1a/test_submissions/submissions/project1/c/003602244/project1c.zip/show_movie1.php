<html>
<head> <title> show_movie1.php </title> </head>
<body bgcolor="99cc99">

<?php
$movie = $_GET['movie'];
$array=explode(",", $movie);
$mid = $array[0];

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

// Movie Info
$query = "select* from Movie where id='$mid';";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
$id = $row[0];
$title = $row[1];
$year = $row[2];
$rating = $row[3];
$company = $row[4];

// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);

// Director name
$query = "select last, first from Director, MovieDirector where id=did^mid='$mid';";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
$last = $row[0];
$first = $row[1];

// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);


echo "<h2 align='center'>Show Movie Information</h2>";
echo "<!-- horizontal line -->";
echo "<hr>";
echo "Movie Title: ";
echo "$title";
echo "<br>";
echo "Year: ";
echo $year;
echo "<br>";
echo "Compnay: ";
echo $company;
echo "<br>";
echo "Rating: ";
echo $rating;
echo "<br>";
echo "Director: ";
echo "$first $last";
echo "<br>";
echo "Genre: ";

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


// Genre
$query = "select genre from MovieGenre where mid='$mid';";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$genre = $row[0];
	echo "$genre ";
}

// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);


echo "<br><br>";
echo "Actor in the Movie";


// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


// Actor
$query = "select id, first, last, role from Actor, MovieActor where id=aid^mid='$mid';";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$id = $row[0];
	$first = $row[1];
	$last = $row[2];
	$role = $row[3];
	echo "<A href='show_actor1.php?actor=$id%2C+$last%2C+$first%2C+($dob)'>$first $last acts as $role in $title</A><br>";
}


// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);


echo "<br><br>";
echo "User Review:";
echo "<br>";

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


// Review
$query = sprintf("select avg(rating), count(*) from Review where mid='$mid' group by mid;");
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
$avg = $row[0];
$count = $row[1];

// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);


if($count==null){
	echo "No Reviews";
	echo "<br>";
}else{
	echo "Average Score: $avg/5.0 (5.0 = I love it!) & There are total of $count reviews";
	echo "<br><br>";

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


	// Review
	$query = "select name, time, rating, comment from Review where mid='$mid';";
	$sanitized_name = mysql_real_escape_string($name, $db_connection);
	$query_to_issue = sprintf($query, $sanitized_name);
	$rs = mysql_query($query_to_issue, $db_connection);
	if(!$rs){
		$message = "Invalid entry: " . mysql_error() . "\n";
		die($message);
	}
	while ($row = mysql_fetch_row($rs)){
		$rname = $row[0];
		$rtime = $row[1];
		$rrating = $row[2];
		$rcomment = $row[3];
		echo "In $rtime:";
		echo "<br>";
		echo "$rname wrote: $rcomment";
		echo "<br>";
		echo "and gave a rating of $rrating";
		echo "<br>";

	}

// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);

}
echo "<A href='add_review.php'>I want to add a review!</A>";
	
		


?>

<!-- horizontal line -->
<hr>

<form method = "GET" action="show_movie1.php">
<font>Select Movie:</font>
<SELECT Name="movie">
<?php


// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


// Movie title
$query = "select id, title, year from Movie;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$id = $row[0];
	$title = $row[1];
	$year = $row[2];
	echo"<OPTION>$id, $title, ($year)";
}


// free result memory
mysql_free_result($rs);
// close mysql connection
mysql_close($db_connection);

?>

</SELECT>

<input type="submit" value="Search">
</form>


</body>
</html>
