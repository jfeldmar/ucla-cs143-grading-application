<html>
<head><title>add_person1.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add new Actor/director</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="add_person1.php">

<font>Identity: </font>
<SELECT Name="identity">
<OPTION>Actor
<OPTION>Director
</SELECT>
<br>

<font>First Name: </font>
<INPUT TYPE='text' NAME="first" maxlength="20">
<br>

<font>Last Name: </font>
<INPUT TYPE='text' NAME="last" maxlength="20">
<br>

<font>Sex: </font>
<SELECT Name="sex">
<OPTION>Male
<OPTION>Female
</SELECT>
<br>

<font>Date of Birth: </font>
<INPUT TYPE='text' NAME="dob" maxlength="8">
<font> (YYYYMMDD)</font>
<br>

<font>Date of Death: </font>
<INPUT TYPE='text' NAME="dod" maxlength="8">
<font> (YYYYMMDD)</font>
<em>*only if applicable</font>

<!-- horizontal line -->
<hr>

<input type="submit" value="ADD!">
</form>


<?php

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

// **** Add Actor/Director ***
$identity = $_GET["identity"];
$first = $_GET["first"];
$last = $_GET["last"];
$sex = $_GET["sex"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];
// error input
if($first==null && $last==null && $dob==null && $dod==null){
	echo "\n  Please make an input \n";
}elseif ($first==null && $last==null)
	echo "Please input at least one Last or First name.";	
elseif ($dob <= 00010101 || $dob >= 20090101)
	echo "Please input a valid date for Date of Birth.";
elseif ($dod > 0 && ($dod < $dob || $dod <= 00010101 || $dod >= 20090101))
	echo "Please input a valid date for Date of Death.";
else{
// get MaxPersonID
$query = "select* from MaxPersonID;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
// free result memory
mysql_free_result($rs);
$mpid = $row[0];

// MaxPersonID ++
$new_mpid = $mpid + 1;

if($identity == "Actor"){
// add Actor information into Actor table
	$query = sprintf("INSERT into Actor VALUES ('$new_mpid', '$last', '$first', '$sex', '$dob', '$dod')");
	$rs = mysql_query($query);
	if(!$rs){
		echo $message = "Invalid entry: " . mysql_error() . "\n";
		$message = "Whole query: " . $query;
		die($message);
	}else{
		echo "Successfully Added to the database!! \n" ;
	}
}elseif ($identity == "Director"){
// add Director information into Director table
	$query = sprintf("INSERT into Director VALUES ('$new_mpid', '$last', '$first', '$dob', '$dod')");
	$rs = mysql_query($query);
	if(!$rs){
		echo $message = "Invalid entry: " . mysql_error() . "\n";
		$message = "Whole query: " . $query;
		die($message);
	}else{
		echo "Successfully Added to the database!! \n" ;
	}

}

// update MaxPersionID
$query = sprintf("update MaxPersonID set id = $new_mpid where id = $mpid");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}


// close mysql connection
mysql_close($db_connection);

?>

</body>
</html>
