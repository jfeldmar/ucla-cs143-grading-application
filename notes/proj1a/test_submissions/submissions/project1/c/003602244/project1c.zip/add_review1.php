<html>
<head><title>add_review1.php</title></head>
<body bgcolor="plum">

<h2 align="center">Add Movie Review</h2>

<!-- horizontal line -->
<hr>
<form method = "POST" action="add_review1.php">
<font>Select Movie:</font>
<SELECT Name='Movie'>
<?php

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);


$query = "select title from Movie;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$title = $row[0];
	echo"<OPTION>$title";
}

// free result memory
mysql_free_result($rs);
//close mysql connection
mysql_close($db_connection);

?>

</SELECT>
<br><br>

<font>Your Name: </font>
<INPUT TYPE='text' NAME='name' maxlength='20'>
<br><br>

<font>Rating: </font>
<SELECT Name='rate'>
<option>5
<option>4
<option>3
<option>2
<option>1
</SELECT>
<font> 5 = I love this movie! ... 1 = I hate this movie! </font>
<br><br>

<font> Comments:</font><br>
<TEXTAREA NAME='comment' ROWS=10 COLS=50>
</TEXTAREA>
<font><em> no more than 500 characters. </em></font>
<hr>
<input type='submit' value='ADD'>
</form>
<?php
$movie = $_POST["movie"];
$name = $_POST["name"];
$rate = $_POST["rate"];
$comment = $_POST["comment"];


if ($name==null && $comment==null)
	echo " Please input comments";
elseif($comment==null)
	echo "Please input some comment!";
else{
	if($name==null)
		$name = "Unknown";
	
	// connect to mysql 
	$db_connection = mysql_connect("localhost", "cs143", "");

	// error msg
	if(!$db_connection) {
		$errmsg = mysql_error($db_connection);
		echo "Connection failed: ".$errmsg;
		exit(1);
	}

	// select database
	mysql_select_db("CS143", $db_connection);


	// get MovieID
	$query = "select id from Movie where title='$title';";
	$sanitized_name = mysql_real_escape_string($name, $db_connection);
	$query_to_issue = sprintf($query, $sanitized_name);
	$rs = mysql_query($query_to_issue, $db_connection);
	if(!$rs){
		$message = "Invalid entry: " . mysql_error() . "\n";
		die($message);
	}
	$row = mysql_fetch_row($rs);
// free result memory
mysql_free_result($rs);
	$mid = $row[0];

	$query = "insert into Review values ('$name', CURRENT_TIMESTAMP, '$mid', '$rate', '$comment')";
	$sanitized_name = mysql_real_escape_string($name, $db_connection);
	$query_to_issue = sprintf($query, $sanitized_name);
	$rs = mysql_query($query_to_issue, $db_connection);
	if(!$rs){
		$message = "Invalid entry: " . mysql_error() . "\n";
		die($message);
	}

	echo "Successfully Added to the database!! \n" ;

	// close mysql connection
	mysql_close($db_connection);

}
?>


</body>
</html>
