<html>
<head><title>add_movie1.php</title></head>


<?php
// **** Add Movie ***
$title = $_POST["title"];
$year = $_POST["year"];
$rating = $_POST["rate"];
$company = $_POST["company"];
$director = $_POST["director"];
$array = explode(",", $director);
$did=$array[0];

$Action = $_POST["Action"];
$Adult = $_POST["Adult"];
$Adventure = $_POST["Adventure"];
$Animation = $_POST["Animation"];
$Comedy = $_POST["Comedy"];
$Crime = $_POST["Crime"];
$Documentary = $_POST["Documentary"];
$Drama = $_POST["Drama"];
$Family = $_POST["Family"];
$Fantasy = $_POST["Fantasy"];
$Horror = $_POST["Horror"];
$Musical = $_POST["Musical"];
$Mystery = $_POST["Mystery"];
$Romance = $_POST["Romance"];
$SciFi = $_POST["SciFi"];
$Short = $_POST["Short"];
$Thriller = $_POST["Thriller"];
$War = $_POST["War"];
$Western = $_POST["Western"];

// error input
if($title==null && $year==null && $company==null)
	$msg = " Please make an input \n";
elseif ($title==null)
	$msg = " Please input a movie title.";
elseif ($year == null)
	$msg = " Please input a year.";
elseif ($company == null)
	$msg = " Please input a company name.";
else{
	

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);



// get MaxMovieID
$query = "select* from MaxMovieID;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
$row = mysql_fetch_row($rs);
// free result memory
mysql_free_result($rs);
$mmid = $row[0];

// MaxMovieID ++
$new_mmid = $mmid + 1;

// add Movie information into Movie table
$query = "INSERT into Movie VALUES ('$new_mmid', '$title', '$year', '$rating', '$company')";
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}


$query = "select id from Director where id=$new_mmid;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$did = $row[0];
}
// free result memory
mysql_free_result($rs);

// add MovieDirector information into MovieDirector table
$query = sprintf("INSERT into MovieDirector VALUES('$new_mmid', '$did')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}


// add Genre information into MovieGenre table
if($Action != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Action')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Adult != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Adult')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Adventure != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Adventure')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Animation != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Animation')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Comedy != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Comedy')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Crime != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Crime')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Documentary != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Documentary')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Drama != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Drama')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Family != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Family')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Fantasy != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Horror')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Musical != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Musical')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Mystery != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Mystery')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Romance != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Romance')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($SciFi != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Sci-Fi')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Short != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Short')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Thriller != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Thriller')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($War != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'War')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}
if($Western != null ){
$query = sprintf("INSERT into MovieGenre VALUES('$new_mmid', 'Western')");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
}

// update MaxMovieID
$query = sprintf("update MaxMovieID set id = $new_mmid where id = $mmid");
$rs = mysql_query($query);
if(!$rs){
	echo $message = "Invalid entry: " . mysql_error() . "\n";
	$message = "Whole query: " . $query;
	die($message);
}
// close mysql connection
mysql_close($db_connection);

$msg = "Successfully added to the Database!";
}

?>

</body>
</html>
<html>
<body bgcolor="plum">

<h2 align="center">Add Movie</h2>

<!-- horizontal line -->
<hr>

<form method = "POST" action="add_movie1.php">

<font>Movie Title: </font>
<INPUT TYPE='text' NAME="title" maxlength="100">
<br>

<font>Company: </font>
<INPUT TYPE='text' NAME="company" maxlength="50">
<br>

<font>Director: </font>
<SELECT Name="director">

<?php
// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");

// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}

// select database
mysql_select_db("CS143", $db_connection);

$query = "select id, last, first, dob from Director;";
$sanitized_name = mysql_real_escape_string($name, $db_connection);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}
while ($row = mysql_fetch_row($rs)){
	$did = $row[0];
	$last = $row[1];
	$first = $row[2];
	$dob = $row[3];
	echo"<OPTION>$did, $last, $first, ($dob)";
}
// close mysql connection
mysql_close($db_connection);

?>

</SELECT>
<br>
<font>Year: </font>
<INPUT TYPE='text' NAME="year" maxlength="4">
<br>

<font>MPAA Rating: </font>
<SELECT Name="rate">
<OPTION>G
<OPTION>NC-17
<OPTION>PG
<OPTION>PG-13
<OPTION>R
<OPTION>surrendere
</SELECT>
<br>

<font>Genre:</font><br>
<input type='checkbox' name='Action' value='Action'>Action
<input type='checkbox' name='Adult' value='Adult'>Adult
<input type='checkbox' name='Adventure' value='Adventure'>Adventure
<input type='checkbox' name='Animation' value='Animation'>Animation
<input type='checkbox' name='Comedy' value='Comedy'>Comedy
<input type='checkbox' name='Crime' value='Crime'>Crime
<input type='checkbox' name='Documentary' value='Documentary'>Documentary
<br>
<input type='checkbox' name='Drama' value='Drama'>Drama
<input type='checkbox' name='Family' value='Family'>Family
<input type='checkbox' name='Fantasy' value='Fantasy'>Fantasy
<input type='checkbox' name='Horror' value='Horror'>Horror
<input type='checkbox' name='Musical' value='Musical'>Musical
<input type='checkbox' name='Mystery' value='Mystery'>Mystery
<input type='checkbox' name='Romance' value='Romance'>Romance
<br>
<input type='checkbox' name='SciFi' value='SciFi'>Sci-Fi
<input type='checkbox' name='Short' value='Short'>Short
<input type='checkbox' name='Thriller' value='Thriller'>Thriller
<input type='checkbox' name='War' value='War'>War
<input type='checkbox' name='Western' value='Western'>Western


<!-- horizontal line -->
<hr>

<input type="submit" value="ADD!">

<?php
	echo $msg;
?>

</form>


</body>
</html>
