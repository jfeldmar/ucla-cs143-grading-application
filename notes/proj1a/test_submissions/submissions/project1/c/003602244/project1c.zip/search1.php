<html>
<head><title>search1.php</title></head>
<body bgcolor="#CCCCFF">

<h2 align="center">Search</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="search1.php">

<font>Search: </font>
<INPUT TYPE='text' NAME="find" maxlength="50">
<input type="submit" value="Search!">
<!-- horizontal line -->
<hr>
</form>

<font>Search Result :</font><br>

<?php 
$find = $_GET["find"];

// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);

if($find == null){
	$query = "select id, first, last, dob from Actor;";
	$sanitized_name = mysql_real_escape_string($name, $db_connection);
	$query_to_issue = sprintf($query, $sanitized_name);
	$rs = mysql_query($query_to_issue, $db_connection);
}
else{
	$query = "select id, first, last, dob from Actor where first like'%$find%' || last like '%$find%';";
//	$sanitized_name = mysql_real_escape_string($name, $db_connection);
//	$query_to_issue = sprintf($query, $sanitized_name);
//	$rs = mysql_query($query_to_issue, $db_connection);
	$rs = mysql_query($query, $db_connection);
}
/*
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	$pattern = "Invalid entry: Query was empty";
	if(preg_match($pattern, $message)) echo "ZWRO";
	else echo "die!";
	//	die($message);
}
*/
while($row = mysql_fetch_row($rs)){
	$aid = $row[0];
	$first = $row[1];
	$last = $row[2];
	$dob = $row[3];
	echo "<A href='show_actor1.php?actor=$aid%2C+$last%2C+$first%2C+($dob)'>$first $last ($dob)</A><br>";
}
// free result memory
mysql_free_result($rs);

// close mysql connection
mysql_close($db_connection);


// connect to mysql 
$db_connection = mysql_connect("localhost", "cs143", "");
// error msg
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    echo "Connection failed: ".$errmsg;
    exit(1);
}
// select database
mysql_select_db("CS143", $db_connection);
if($find == null)
	$query = "select id, title year from Movie;";
else
	$query = "select id, title year from Movie where title like'%$find%';";
//$sanitized_name = mysql_real_escape_string($name, $db_connection);
//$query_to_issue = sprintf($query, $sanitized_name);
//$rs = mysql_query($query_to_issue, $db_connection);
$rs = mysql_query($query, $db_connection);
if(!$rs){
	$message = "Invalid entry: " . mysql_error() . "\n";
	die($message);
}


while($row = mysql_fetch_row($rs)){
	$mid = $row[0];
	$title = $row[1];
	$year = $row[2];
	echo "<A href='show_movie1.php?movie=$mid%2C+$title%2C+($year)'>Movie: $title ($year)</A><br>";
}
// free result memory
mysql_free_result($rs);

// close mysql connection
mysql_close($db_connection);
?>

</body>
</html>
