<html>
<head><title>search.php</title></head>
<body bgcolor="#CCCCFF">

<h2 align="center">Search</h2>

<!-- horizontal line -->
<hr>

<form method = "GET" action="search1.php">

<font>Search: </font>
<INPUT TYPE='text' NAME="find" maxlength="50">
<input type="submit" value="Search!">

<!-- horizontal line -->
<hr>

</form>


</body>
</html>
