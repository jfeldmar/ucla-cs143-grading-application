<?php require("header.inc")?>

<?php
require("database.inc");

$id = $_GET["id"];
$tab = "&nbsp;&nbsp;&nbsp;&nbsp;";

connect();

$movies = query("Movie, MovieDirector", "${movielink}, year", "MovieDirector.mid = Movie.id AND MovieDirector.did = {$id} ORDER BY year");
$moviecolumns = array("Movie", "Year");
$moviecolwidths = array("10cm", "9cm");

$directorinfo = query("Director", "${directorlink}, dob, dod, (SELECT COUNT(DISTINCT mid) FROM MovieDirector where did=${id}), (SELECT COUNT(DISTINCT mid) FROM MovieActor where aid=${id})", "Director.id = ${id}");
disconnect();

if(!verifyData($directorinfo))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing information about the director you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}


$directorinfo = mysql_fetch_row($directorinfo);
$directorname = $directorinfo[0];
$directorbirth = $directorinfo[1];
$directordeath = $directorinfo[2];
$nummovies = $directorinfo[3];
$numacted = $directorinfo[4];

echo "<div id='browsetext'>";

echo "Currently viewing information about director ${directorname}. Click here for <a href='editdirector.php?id=$id&field=all'>advanced editing mode</a>.<br>";
echo "<list class='infolist'>";
if($directorbirth == null)
	echo "<li>Birth date unknown (Do you know it? Help us out by <a href='editdirector.php?id={$id}&field=birth'>adding it</a>!)</li>";
else
	echo "<li>Born ${directorbirth}</li>";
if($actordeath != null)
	echo "<li>Died ${directordeath}</li>";
	
if($nummovies > 0)
{
	echo "<li>Directed <a href = '#movielist'>${nummovies} movie";
	if($nummovies > 1)
		echo "s";
	echo "</a> (that we know about)</li>";
}
else
	echo "<li>Hasn't directed any movies in our database. Help us out by <a href='editdirector.php?id={$id}&field=movies'>adding some</a>!</li>";
	
if($numacted > 0)
{
	echo "<li>Has also <a href='viewactor.php?id={$id}'>acted</a> in ${numacted} movie";
	if($numacted > 1)
		echo "s";
}
	
echo "</list>";

echo "</div>";

echo "<hr>";

if($nummovies > 0)
{
	echo "<div id='browsetext'><a name = 'movielist' class='anchor'>Movies ${directorname} has directed:</a></div>";
	echo "<table id='browsetable'><tr>";

	if($moviecolumns != null)
	{
		foreach($moviecolumns as $i=>$col)
		{
			echo "<td style='width: {$moviecolwidths[$i]};' class='browsetableheader'>$col</td>";
		}
	}

	echo "</tr>";

	while($movies != null && $row = mysql_fetch_row($movies))
	{
		echo "<tr>";
		foreach ($row as $i=>$value)
		{
			echo "<td class='browsetablecell' style='width: {$moviecolwidths[$i]};'>";
			if($value)
				echo $value;
			else
				echo "N/A";
			echo "</td>";
		}
		echo "</tr>";
	}

	echo "</table>";
	echo "<div id='browsetext'>Is a movie missing? Help out by <a href='editdirector.php?id={$id}&field=movies'>adding it</a>!</div>";
}

?>

<?php require('footer.inc'); ?>