<?php require("header.inc")?>

<div id='browsetext'>Welcome to CS143MDb! Please use the links at top to navigate the site.</div>

<?php require("footer.inc")?>