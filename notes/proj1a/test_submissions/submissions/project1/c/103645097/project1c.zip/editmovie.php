<?php require("header.inc")?>

<?php
require("database.inc");
require("search.inc");
require("forms.inc");

$field = $_GET['field'];
$id = $_GET['id'];
$all = $_GET['all'];

if($all == null)
	$all = 0;

if(!strcmp($field, "newmovie"))
{
	echo "<div id='browsetext'>Enter the title and year (if known) of the movie you want to add below. Afterwards you will be taken to a page where you can add actor, director, and other information.</div>";
	printNewMovieForm();
	require("footer.inc");
	return;
}

if(!strcmp($field, "addmovie"))
{
	$title = $_POST['title'];
	$year = $_POST['year'];
	$company = $_POST['company'];
	$rating = $_POST['rating'];
	
	$ratinglist = getRatingList();
	
	if($rating < 0 || $rating > count($ratinglist))
		$rating = 0;
	
	if($rating == 0)
		$rating = "NULL";
	else
	{
		$rating = "'{$ratinglist[$rating-1]}'";
	}
	
	connect();
	
	$title = htmlspecialchars($title);
	$title = mysql_real_escape_string($title);
	
	$company = htmlspecialchars($company);
	$company = mysql_real_escape_string($company);
	
	$yearerror = $year != null && !ereg("([0-9]{4})", $year);
	
	if($title == null || $yearerror)
	{
		disconnect();
		echo "<div id='browsetext'>There was an error creating the new movie. Check the fields marked in red below and verify that they are filled in if required, and that they are in the correct format.</div>";
		printNewMovieForm($title == null, $yearerror);
		require("footer.inc");
		return;
	}
	
	if($year == null || $year == 0)
		$year = "NULL";
		
	prepareField($company);
	
	mysql_query("LOCK TABLES MaxMovieID WRITE, Movie WRITE");
	mysql_query("UPDATE MaxMovieID SET id=id+1");
	mysql_query("INSERT INTO Movie VALUES((SELECT id FROM MaxMovieID), '${title}', $year, $rating, $company)");
	
	$id = mysql_query("SELECT id FROM MaxMovieID");
	$id = mysql_result($id, 0);
	
	mysql_query("UNLOCK TABLES");
	
	disconnect();
	
	echo "<div id='browsetext'>The new movie has been added. You may edit its details below.</div>";
	
	$field = "all";
	$_GET['all'] = 1;
	$_POST['submit'] = null;
	$_GET['id'] = $id;
	
}

connect();

$id = mysql_real_escape_string($id);
$moviename = query("Movie", "${movielink}", "id = ${id}");

disconnect();


$returntext = "Click <a href='viewmovie.php?id=$id'>here</a> to return to the movie info page.";
if($_GET['all'] == 1)
	$edittext = "Click <a href='editmovie.php?id=$id&field=all&all=1'>here</a> to continue editing the movie info.</div>";
else
	$edittext = "</div>";

if(!verifyData($moviename))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing the movie you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}

$moviename = mysql_fetch_row($moviename);
$moviename = $moviename[0];

if(!strcmp($field, 'review'))
{
	connect();
	
	$review = $_POST['review'];
	$review = htmlspecialchars($review);
	$review = mysql_real_escape_string($review);
	
	$rname = $_POST['rname'];
	if($rname == null || strlen($rname) == 0)
		$rname = "Anonymous Coward";
	
	$rname = htmlspecialchars($rname);
	$rname = mysql_real_escape_string($rname);
	
	$rating = $_POST['rating'];
	
	if(!is_numeric($rating))
		$rating = 3;
	
	$result = mysql_query("INSERT INTO Review VALUES('${rname}', NOW(), ${id}, ${rating}, '${review}')");
	
	disconnect();
	
	echo "<div id='browsetext'>Your review of ${moviename} has been submitted! $returntext </div>";
}

if(!strcmp($field, 'director') || !strcmp($field, 'all'))
{
	echo "<div id='browsetext'>Insert director for ${moviename}:";
	
	if($_POST['submit'] == null)
	{
		echo "<form action='editmovie.php?id=${id}&field=director&all=$all' method = 'POST'>";
		echo "<p>Director's name (partial name OK): <input type='text' name='dname'><br>";
		echo "<input type = 'submit' name='submit' value='Find director'></p>";
		echo "</form>";
	}
	else
	{
		connect();
		
		$dname = $_POST['dname'];
		$dname = mysql_real_escape_string($dname);
		
		$rows = mysql_query("SELECT CONCAT('<a href=\'editmovie.php?field=adddirector&all=$all&id={$id}&director=', id, '\'>', first, ' ', last, '</a>'), CONCAT('(Click ', '<a href =\'viewdirector.php?id=', id, '\'>', 'here</a> to view info page)') FROM Director WHERE CONCAT(first, ' ', last) LIKE '%$dname%'".
							" UNION DISTINCT SELECT CONCAT('<a href=\'editmovie.php?field=adddirector&all=$all&id={$id}&director=', id, '\'>', first, ' ', last, '</a>'), '' FROM Actor WHERE CONCAT(first, ' ', last) LIKE '%$dname%'", $conn);
		
		disconnect();
		
		if($rows != null)
		{
			echo "</div>";
			echo "<div id='browsetext'>If the director you were looking for is listed below, click on the name to add him or her as a director of ${moviename}. If not, you will be given the option to add a new director to the database after this list.<br><br>";
			while($row = mysql_fetch_row($rows))
				echo "${row[0]} ${row[1]}<br>";
				
			echo "</div>";
		}
		
		echo "<div id='browsetext'>If we weren't able to find the correct director of ${moviename}, please fill out the following information so it can be added to the database. Fields marked with an asterisk (*) are required.";
		echo "</div>";
		
		printNewMovieDirectorForm();
		
	}
	
	echo "</div>";
}

if(!strcmp($field, 'actor') || !strcmp($field, 'all'))
{
	echo "<div id='browsetext'>Insert actor for ${moviename}:";
	
	if($_POST['submit'] == null)
	{
		echo "<form action='editmovie.php?id=${id}&field=actor&all=$all' method = 'POST'>";
		echo "<p>Actor's name (partial name OK): <input type='text' name='aname'><br>";
		echo "<input type = 'submit' name='submit' value='Find actor'></p>";
		echo "</form>";
	}
	else
	{
		connect();
		
		$aname = $_POST['aname'];
		$aname = mysql_real_escape_string($aname);
		
		$rows = mysql_query("SELECT CONCAT('<a href=\'editmovie.php?field=addactor&all=$all&id={$id}&actor=', id, '\'>', first, ' ', last, '</a>'), CONCAT('(Click ', '<a href =\'viewactor.php?id=', id, '\'>', 'here</a> to view info page)') FROM Actor WHERE CONCAT(first, ' ', last) LIKE '%$aname%'");
		
		disconnect();
		
		if($rows != null)
		{
			echo "</div>";
			echo "<div id='browsetext'>If the actor you were looking for is listed below, click on the name to add him or her as an actor in ${moviename}. If not, you will be given the option to add a new actor to the database after this list.<br><br>";
			while($row = mysql_fetch_row($rows))
				echo "${row[0]} ${row[1]}<br>";
				
			echo "</div>";
		}
		
		echo "<div id='browsetext'>If we weren't able to find the actor you were looking for from ${moviename}, please fill out the following information so it can be added to the database. Fields marked with an asterisk (*) are required.";
		echo "</div>";
		
		printNewMovieActorForm();
		
	}
	
	echo "</div>";
}

if(!strcmp($field, "newactormovie") && $_POST['submit'])
{
	connect();
	$first = $_POST['first'];
	$last = $_POST['last'];
	$dob = $_POST['dob'];
	$dod = $_POST['dod'];
	$sex = $_POST['sex'];
	
	$sexes = array("Male", "Female");
	
	if($sex != 0 && $sex != 1)
		$sex = 0;
	
	$first = htmlspecialchars($first);
	$first = mysql_real_escape_string($first);
	
	$last = htmlspecialchars($last);
	$last = mysql_real_escape_string($last);
	
	if($dob != null)
		$dob = mysql_real_escape_string($dob);
	if($dod != null)
		$dod = mysql_real_escape_string($dod);
	
	if($dob != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		$doberror = true;
	if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		$doderror = true;
	
	if($doberror || $doderror || $first == null || $last == null)
	{
		disconnect();
		echo "<div id='browsetext'>There was an error creating the new actor. Check the fields marked in red below and verify that they are filled in if required, and that they are in the correct format.</div>";
		printNewMovieActorForm($first == null, $last == null, $doberror, $doderror);
		
		require("footer.inc");
		return;
	}
	
	// since this operation isn't atomic, need to lock the db to deal with concurrency
	mysql_query("LOCK TABLES MaxPersonID WRITE, Actor WRITE, MovieActor WRITE");
	mysql_query("UPDATE MaxPersonID SET id=id+1");
	
	if($dob == null)
		$dob = "NULL";
	else
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
	if($dod == null)
		$dod = "NULL";
	else
		$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
	
	$sex = "'{$sexes[$sex]}'";
	
	mysql_query("INSERT INTO Actor VALUES((SELECT id FROM MaxPersonID), '${last}', '${first}', $sex, $dob, $dod)");
	mysql_query("INSERT INTO MovieActor VALUES(${id}, (SELECT id FROM MaxPersonID))");
	
	$newactor = mysql_query("SELECT {$actorlink}, id FROM Actor WHERE id=(SELECT id FROM MaxPersonID)");
	
	mysql_query("UNLOCK TABLES");
	
	disconnect();
	
	if($newactor != null)
	{
		$newactor = mysql_fetch_row($newactor);
		$newid = $newactor[1];
		$newactor = $newactor[0];
	}
	
	if(!strcmp($sex, "'Male'"))
		$pronoun = 'him';
	else
		$pronoun = 'her';
	
	echo "<div id='browsetext'>${newactor} was added to the database. Now fill in the following information to add $pronoun to ${moviename}:</div>";
	$field = "addactor";
	$_GET['actor'] = $newid;
	$_POST['submit'] = null;
}

if(!strcmp($field, "newdirectormovie") && $_POST['submit'])
{
	connect();
	
	$first = $_POST['first'];
	$last = $_POST['last'];
	$dob = $_POST['dob'];
	$dod = $_POST['dod'];
	
	$first = htmlspecialchars($first);
	$first = mysql_real_escape_string($first);
	
	$last = htmlspecialchars($last);
	$last = mysql_real_escape_string($last);
	
	if($dob != null)
		$dob = mysql_real_escape_string($dob);
	if($dod != null)
		$dod = mysql_real_escape_string($dod);
	
	if($dob != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		$doberror = true;
	if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		$doderror = true;
	
	if($doberror || $doderror || $first == null || $last == null)
	{
		disconnect();
		echo "<div id='browsetext'>There was an error creating the new director. Check the fields marked in red below and verify that they are filled in if required, and that they are in the correct format.</div>";
		printNewMovieDirectorForm($first == null, $last == null, $doberror, $doderror);
		
		require("footer.inc");
		return;
	}
	
	// since this operation isn't atomic, need to lock the db to deal with concurrency
	mysql_query("LOCK TABLES MaxPersonID WRITE, Director WRITE, MovieDirector WRITE");
	mysql_query("UPDATE MaxPersonID SET id=id+1");
	
	if($dob == null)
		$dob = "NULL";
	else
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
	if($dod == null)
		$dod = "NULL";
	else
		$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
	
	mysql_query("INSERT INTO Director VALUES((SELECT id FROM MaxPersonID), '${last}', '${first}', $dob, $dod)");
	mysql_query("INSERT INTO MovieDirector VALUES(${id}, (SELECT id FROM MaxPersonID))");
	
	$newdirector = mysql_query("SELECT {$directorlink} FROM Director WHERE id=(SELECT id FROM MaxPersonID)");
	
	mysql_query("UNLOCK TABLES");
	
	disconnect();
	
	if($newdirector != null)
	{
		$newdirector = mysql_fetch_row($newdirector);
		$newdirector = $newdirector[0];
	}
	
	echo "<div id='browsetext'>${newdirector} was added to the database and listed as the director of ${moviename}. $returntext $edittext";
	
}

if(!strcmp($field, 'adddirector'))
{
	$did = $_GET['director'];
	
	connect();
	
	$did = mysql_real_escape_string($did);
	
	$directorname = mysql_query("SELECT $directorlink FROM Director WHERE id=$did");
	if(mysql_num_rows($directorname) == 0) // selected an actor, so make him/her a director too
	{
		mysql_query("INSERT INTO Director (SELECT id, last, first, dob, dod FROM Actor where id=$did)");
		$directorname = mysql_query("SELECT $directorlink FROM Director WHERE id=$did");
	}
	
	mysql_query("INSERT INTO MovieDirector VALUES($id, $did)");
	
	disconnect();
	
	$directorname = mysql_result($directorname, 0);
	
	echo "<div id='browsetext'>$directorname was successfully added as a director of $moviename. $returntext $edittext";
	
}

if(!strcmp($field, 'addactor'))
{
	if($_POST['submit'] == null)
	{
		$aid = $_GET['actor'];
		
		connect();
		
		$aid = mysql_real_escape_string($aid);
		$actorname = mysql_query("SELECT $actorlink FROM Actor WHERE id=$aid");
		disconnect();
		
		$actorname = mysql_result($actorname, 0);
		
		echo "<div id='browsetext'>Please enter $actorname's role in $moviename below.</div>";
		printActorRoleForm();
		echo "</div>";
	}
	else
	{
		$aid = $_GET['actor'];
		$role = $_POST['role'];
		
		connect();
		
		$role = htmlspecialchars($role);
		$role = mysql_real_escape_string($role);
		
		$aid = mysql_real_escape_string($aid);
		
		if($role == null)
		{
			disconnect();
			echo "<div id='browsetext'>You must fill in the role below to add the actor to the movie.</div>";
			printActorRoleForm(true);
			
			require("footer.inc");
			return;
		}
		
		mysql_query("INSERT INTO MovieActor VALUES($id, $aid, '$role')");
		
		$actorname = mysql_query("SELECT $actorlink FROM Actor WHERE id=$aid");
		
		disconnect();
		
		$actorname = mysql_result($actorname, 0);
		
		echo "<div id='browsetext'>$actorname was successfully added to $moviename as \"$role.\" $returntext $edittext";
		
	}
}

if(!strcmp($field, 'genre') || !strcmp($field, 'all'))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Please select all the genres that apply to $moviename below.</div>";
		connect();
		
		$genrequery = mysql_query("SELECT DISTINCT genre FROM MovieGenre WHERE mid=$id");
		disconnect();
		
		$genrelist = getGenreList();
		
		$moviegenres = array();
		
		for($i = 0; $i < count($genrelist); $i++)
			$moviegenres[$i] = false;
		
		while($genrequery && $row = mysql_fetch_row($genrequery))
		{
			$genre = $row[0];
			
			foreach($genrelist as $i=>$g)
			{
				if(!strcmp($genre, $g))
					$moviegenres[$i] = true;
			}
		}
		
		printMovieGenreForm($moviegenres);
	}
	else
	{
		$genrelist = getGenreList();
		connect();
		
		for($i = 0; $i < count($genrelist); $i++)
		{
			if($_POST["genre_$i"] == 1)
				mysql_query("INSERT INTO MovieGenre VALUES($id, '{$genrelist[$i]}')");
			else
				mysql_query("DELETE FROM MovieGenre where mid=$id and genre='{$genrelist[$i]}'");
		}
		
		disconnect();
		echo "<div id='browsetext'>Genre information for $moviename has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, 'rating') || !strcmp($field, 'all'))
{
	if($_POST['submit'] == null)
	{	
		echo "<div id='browsetext'>Please select the MPAA rating of $moviename below.</div>";
		printMovieRatingForm();
	}
	else
	{
		$rating = $_POST['rating'];
		$ratinglist = getRatingList();
		
		if($rating < 0 || $rating > count($ratinglist))
			$rating = 0;
		
		if($rating == 0)
			$rating = "NULL";
		else
			$rating = "'{$ratinglist[$rating-1]}'";
		
		connect();
		
		mysql_query("UPDATE Movie set rating=$rating where id=$id");
		
		disconnect();
		echo "<div id='browsetext'>MPAA rating information for $moviename has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, "year") || !strcmp($field, 'all'))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the year for $moviename below.</div>";
		printMovieYearForm();
	}
	else
	{
		$year = $_POST['year'];
		
		if($year == null || !ereg("([0-9]{4})", $year))
		{
			echo "<div id='browsetext'>You must enter the year in the format YYYY below.</div>";
			printMovieYearForm(true);
			
			require("footer.inc");
			return;
		}
		
		connect();
		mysql_query("UPDATE Movie set year=$year where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The year of $moviename has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, "company") || !strcmp($field, 'all'))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the production company for $moviename below.</div>";
		printMovieCompanyForm();
	}
	else
	{
		$company = $_POST['company'];
		
		connect();
		
		$company = htmlspecialchars($company);
		$company = mysql_real_escape_string($company);
	
		
		if($company == null)
		{
			echo "<div id='browsetext'>You must enter the company name below.</div>";
			printMovieCompanyForm(true);
			
			require("footer.inc");
			return;
		}
		
		mysql_query("UPDATE Movie set company='$company' where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The production company of $moviename has been updated. $returntext $edittext";
	}
}

?>

<?php require("footer.inc")?>