<?php require("header.inc")?>

<?php
require("database.inc");
require("search.inc");

$mode = $_GET["mode"];
$by = $_GET["by"];
$start = $_GET["start"];
$offset = $_GET["offset"];
$displaylimit = $_GET["displaylimit"];

if($offset == null)
	$offset = 0;
if($displaylimit == null)
	$displaylimit = 30;

$limit = $offset + $displaylimit;
$prevpage = max(0, $offset - $displaylimit);
$nextpage = $offset + $displaylimit;

$linkinherit = "mode=$mode&by=$by&displaylimit=$displaylimit";

if($start && !is_numeric($start) && strlen($start) > 1 && strcmp($start, "num")) $start = null;

$columns = null;
$rows = null;
$colwidths = null;

function printHeader($title, $secondarylink, $links)
{
  global $mode, $by;
  echo "<div id='contentheader' style='width: 4.5cm;'>".$title."<br>$secondarylink</div>";
  echo "<div id='contentlinks'";
  
  foreach($links as $i=>$linkName)
  {
    if($i > 0)
	  echo " | ";
    if($by == $i)
	  echo "<b>".$linkName."</b>";
	else
	  echo "<a href='browse.php?mode=".$mode."&by=".$i."'>".$linkName."</a>";
  }
  
  echo "</div>";
}

function printLinkedLetter($letter, $displayletter=null)
{
	global $mode, $by, $linkinherit;
	
	if($displayletter == null)
	  $displayletter = $letter;
	  
	echo "<a href='browse.php?$linkinherit&start=$letter'>$displayletter</a>";
}

function printAlphabet($shownumber)
{
	global $start;
	
	if($shownumber)
	{
		if($start == "num")
			echo "#";
		else
			printLinkedLetter("num", "#");
	}
	
	echo " ";
	
	for($letter = 'A'; $letter <= 'M'; $letter++)
	{
		if($start == $letter)
			echo $letter;
		else
			printLinkedLetter($letter);
		echo " ";
	}
	
	echo "<br>";
	
	for($letter = 'N'; $letter < 'Z'; $letter++)
	{
		if($start == $letter)
			echo $letter;
		else
			printLinkedLetter($letter);
		echo " ";
	}
	if($start == "Z")
		echo "Z";
	else
		printLinkedLetter("Z");
}

if($mode == 0) // actor
{
	printHeader("Browse actors", "<a href='editactor.php?field=newactor'>Add an actor</a>", array("By last name", "By first name"));

	echo "<div id='contentnav-left'><a href='browse.php?start=$start&$linkinherit&offset=$prevpage'><img src='leftarrow.png'></a></div>";
	
	echo "<div id='browseheader'>";
	
	printAlphabet(false);
	
	echo "</div>";
	
	echo "<div id='contentnav-right'><a href='browse.php?start=$start&$linkinherit&offset=$nextpage'><img src='rightarrow.png'></a></div>";
	
	if($start)
	{
		connect();
		if($by == 0)
		{
			$rows = query("Actor", "${actorlink}, sex, dob, dod", "last LIKE '${start}%' ORDER BY last,first LIMIT {$offset},{$displaylimit}");
		}
		if($by == 1)
		{
			$rows = query("Actor", "${actorlink}, sex, dob, dod", "first LIKE '${start}%' ORDER BY first,last LIMIT {$offset},{$displaylimit}");
		}
		
		disconnect();	
		
		$columns = array("Actor", "Sex", "Date of Birth", "Date of Death");
		$colwidths = array("5cm", "2cm", "4cm", "4cm");
	}
}

else if($mode == 1) // movie
{
	printHeader("Browse movies", "<a href='editmovie.php?field=newmovie'>Add a movie</a>", array("By title", "By genre"));

	echo "<div id='contentnav-left'><a href='browse.php?start=$start&$linkinherit&offset=$prevpage'><img src='leftarrow.png'></a></div>";
	echo "<div id='browseheader'>";
	
	if($by == 0)
		printAlphabet(true);
	else if($by == 1)
	{
		$genrelist = getGenreList();
		
		echo "<form method='get' action='browse.php'>";
		echo "<input type='hidden' name='mode' value='$mode'>";
		echo "<input type='hidden' name='by' value='$by'>";
		echo "<input type='hidden' name='displaylimit' value='$displaylimit'>";
		
		$genreList = getGenreList();
		printGenreDropdown('start');
		
		echo "<input type='submit' value='Choose genre'>";
		echo "</form>";
	}
		
	echo "</div>";
	
	echo "<div id='contentnav-right'><a href='browse.php?start=$start&$linkinherit&offset=$nextpage'><img src='rightarrow.png'></a></div>";
	
	if($by == 0)
	{
		if($start != null)
		{
			connect();
			
			if(strcmp($start, "num") == 0)
			{
				$start = "[[:digit:][:punct:]]";
			}
			
			$rows = mysql_query("SELECT {$movielink},year,(SELECT {$directorlinks} FROM MovieDirector, Director WHERE mid=Movie.id AND Director.id=did), (SELECT ${genres} FROM MovieGenre WHERE mid=Movie.id),rating FROM Movie WHERE id in (SELECT id FROM Movie WHERE title REGEXP '^${start}') ORDER BY title,year LIMIT {$offset},{$displaylimit}", $conn);
			
			disconnect();
		}
	}
	else if($by == 1)
	{
		if($start != null)
		{
			connect();
			
			if($start < 0 || $start > count($genrelist))
				$start = 0;
			
			$rows = mysql_query("SELECT {$movielink},year,(SELECT {$directorlinks} FROM MovieDirector, Director WHERE mid=Movie.id AND Director.id=did), (SELECT ${genres} FROM MovieGenre WHERE mid=Movie.id),rating FROM Movie WHERE id in (SELECT id FROM Movie,MovieGenre WHERE genre='{$genrelist[$start]}' AND MovieGenre.mid=Movie.id ORDER BY title,year) LIMIT {$offset},{$displaylimit}", $conn);
			
			disconnect();
		}
	}
	
	$columns = array("Title", "Year", "Director(s)", "Genre(s)", "Rating");
	$colwidths = array("6cm", "2cm", "5cm", "3cm", "1cm");
	
}

else if($mode == 2) // director
{
	printHeader("Browse directors", "<a href='editdirector.php?field=newdirector'>Add a director</a>", array("By last name", "By first name"));

	echo "<div id='contentnav-left'><a href='browse.php?start=$start&$linkinherit&offset=$prevpage'><img src='leftarrow.png'></a></div>";
	
	echo "<div id='browseheader'>";
	
	printAlphabet(false);
	
	echo "</div>";
	
	echo "<div id='contentnav-right'><a href='browse.php?start=$start&$linkinherit&offset=$nextpage'><img src='rightarrow.png'></a></div>";
	
	if($start)
	{
		connect();
		if($by == 0)
		{
			$rows = query("Director", "${directorlink}, dob, dod", "last LIKE '${start}%' ORDER BY last,first LIMIT {$offset},{$displaylimit}");
		}
		if($by == 1)
		{
			$rows = query("Director", "${directorlink}, dob, dod", "first LIKE '${start}%' ORDER BY first,last LIMIT {$offset},{$displaylimit}");
		}
		
		disconnect();	
		
		$columns = array("Actor", "Date of Birth", "Date of Death");
		$colwidths = array("5cm", "4cm", "4cm");
	}
}

if($rows != null && $columns != null)
{
	echo "<br><table id='browsetable'><tr>";
	foreach($columns as $i=>$col)
	{
		echo "<td style='width: {$colwidths[$i]};' class='browsetableheader'>$col</td>";
	}
}

if($rows != null)
	echo "</tr>";

while($rows != null && $row = mysql_fetch_row($rows))
{
	echo "<tr>";
	foreach ($row as $i=>$value)
	{
		echo "<td class='browsetablecell' style='width: {$colwidths[$i]};'>";
		if($value)
			echo $value;
		else
			echo "N/A";
		echo "</td>";
	}
	echo "</tr>";
}

if($rows !=null)
	echo "</table>";

?>

<?php require("footer.inc")?>