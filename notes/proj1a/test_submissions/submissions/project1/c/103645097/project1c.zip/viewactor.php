<?php require("header.inc")?>

<?php
require("database.inc");

$id = $_GET["id"];
$tab = "&nbsp;&nbsp;&nbsp;&nbsp;";

connect();

$movies = query("Movie, MovieActor", "${movielink}, year, GROUP_CONCAT(role SEPARATOR ', ')", "MovieActor.mid = Movie.id AND MovieActor.aid = {$id} GROUP BY MovieActor.mid ORDER BY year");
$moviecolumns = array("Movie", "Year", "Role(s)");
$moviecolwidths = array("8cm", "2cm", "9cm");

$actorinfo = query("Actor", "${actorlink}, dob, dod, (SELECT COUNT(DISTINCT mid) FROM MovieActor where aid=${id}), sex, (SELECT COUNT(DISTINCT mid) FROM MovieDirector where did=${id})", "Actor.id = ${id}");
disconnect();

if(!verifyData($actorinfo))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing information about the actor you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}


$actorinfo = mysql_fetch_row($actorinfo);
$actorname = $actorinfo[0];
$actorbirth = $actorinfo[1];
$actordeath = $actorinfo[2];
$nummovies = $actorinfo[3];
$sex = $actorinfo[4];
$numdirected = $actorinfo[5];

if(!strcmp($sex, "Female"))
	$pronoun = "She";
else if(!strcmp($sex, "Male"))
	$pronoun = "He";
else
	$pronoun = "It";

echo "<div id='browsetext'>";

echo "Currently viewing information about actor ${actorname}. Click here for <a href='editactor.php?id=$id&field=all'>advanced editing mode</a>.<br>";
echo "<list class='infolist'>";
if($actorbirth == null)
	echo "<li>Birth date unknown (Do you know it? Help us out by <a href='editactor.php?id={$id}&field=birth'>adding it</a>!)</li>";
else
	echo "<li>${pronoun} was born ${actorbirth}</li>";
if($actordeath != null)
	echo "<li>${pronoun} died ${actordeath}</li>";
	
if($nummovies > 0)
{
	echo "<li>${pronoun} has acted in <a href = '#movielist'>${nummovies} movie";
	if($nummovies > 1)
		echo "s";
	echo "</a> (that we know about)</li>";
}
else
	echo "<li>${pronoun} hasn't acted in any movies in our database. Help us out by <a href='editactor.php?id={$id}&field=movies'>adding some</a>!</li>";

if($numdirected > 0)
{
	echo "<li>${pronoun} has also <a href='viewdirector.php?id={$id}'>directed</a> ${numdirected} movie";
	if($numdirected > 1)
		echo "s";
}

echo "</list>";

echo "</div>";

echo "<hr>";

if($nummovies > 0)
{
	echo "<div id='browsetext'><a name = 'movielist' class='anchor'>Movies in which ${actorname} has acted:</a></div>";
	echo "<table id='browsetable'><tr>";

	if($moviecolumns != null)
	{
		foreach($moviecolumns as $i=>$col)
		{
			echo "<td style='width: {$moviecolwidths[$i]};' class='browsetableheader'>$col</td>";
		}
	}

	echo "</tr>";

	while($movies != null && $row = mysql_fetch_row($movies))
	{
		echo "<tr>";
		foreach ($row as $i=>$value)
		{
			echo "<td class='browsetablecell' style='width: {$moviecolwidths[$i]};'>";
			if($value)
				echo $value;
			else
				echo "N/A";
			echo "</td>";
		}
		echo "</tr>";
	}

	echo "</table>";
	echo "<div id='browsetext'>Is a movie missing? Help out by <a href='editactor.php?id={$id}&field=movies'>adding it</a>!</div>";
}

?>

<?php require('footer.inc'); ?>