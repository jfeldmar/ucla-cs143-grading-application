<?php require("header.inc")?>

<?php
require("database.inc");

$id = $_GET["id"];

connect();

$actors = query("Actor, MovieActor", "${actorlink}, role", "MovieActor.aid = Actor.id AND MovieActor.mid = {$id}");
$actorcolumns = array("Actor", "Role");
$actorcolwidths = array("10cm", "9cm");

$moviedirectorinfo = query("MovieDirector, Director", "${directorlinks}", "MovieDirector.mid = ${id} AND MovieDirector.did = Director.id GROUP BY MovieDirector.mid");
$movieinfo = query("Movie", "${movielink}, year, company, rating, (SELECT ${genres} FROM MovieGenre WHERE mid=Movie.id), (SELECT count(DISTINCT aid) FROM MovieActor WHERE mid=Movie.id)", "Movie.id = ${id}");
$reviews = query("Review", "name, time, rating, comment", "mid = ${id}");
$reviewinfo = mysql_query("SELECT COUNT(*), AVG(rating) FROM Review WHERE mid = ${id}");

disconnect();

if(!verifyData($movieinfo))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing information about the movie you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;

}

$movieinfo = mysql_fetch_row($movieinfo);

if($moviedirectorinfo != null)
	$moviedirectorinfo = mysql_fetch_row($moviedirectorinfo);
if($reviewinfo != null)
{
	$reviewinfo = mysql_fetch_row($reviewinfo);
	$numreviews = $reviewinfo[0];
	$avgrating = $reviewinfo[1];
}

$moviename = $movieinfo[0];
$year = $movieinfo[1];
$company = $movieinfo[2];

if($company != null)
	$company = "<a href='viewcompany.php?company=".urlencode($company)."'>${company}</a>";

$rating = $movieinfo[3];
$genres = $movieinfo[4];
$numactors = $movieinfo[5];
$director = $moviedirectorinfo[0];

echo "<div id='browsetext'>";

echo "Currently viewing information about ${moviename}. Click here for <a href='editmovie.php?id=$id&field=all&all=1'>advanced editing mode</a>.<br>";
echo "<list class='infolist'>";

if($genres == null)
	echo "<li>Genre(s) unknown (Help out by <a href='editmovie.php?id={$id}&field=genre'>adding that information</a>!)</li>";
else
	echo "<li>${genres}</li>";

if($year == null)
	echo "<li>Release year unknown (Help out by <a href='editmovie.php?id={$id}&field=year'>adding that information</a>!)</li>";
else
	echo "<li>Released in ${year}</li>";

if($company == null)
	echo "<li>Production company unknown (Help out by <a href='editmovie.php?id={$id}&field=company'>adding that information</a>!)</li>";
else
	echo "<li>Produced by ${company}</li>";
	
if($rating == null)
	echo "<li>MPAA rating unknown (Help out by <a href='editmovie.php?id={$id}&field=rating'>adding that information</a>!)</li>";
else
	echo "<li>MPAA rating: ${rating}</li>";

if($director == null)
	echo "<li>Director(s) unknown (Help out by <a href='editmovie.php?id={$id}&field=director'>adding that information</a>!)</li>";
else
	echo "<li>Directed by ${director}</li>";

if($numactors > 0)
	echo "<li>Number of actors: ${numactors}</li>";
else
	echo "<li>Actor(s) unknown. Help out by <a href='editmovie.php?id={$id}&field=actor'>adding some</a>!</li>";

if($numreviews > 0)
{
	echo "<li>Average rating <b>${avgrating}/5</b> from ${numreviews} <a href='#reviews'>review";
	if($numreviews > 1)
		echo "s";
	echo "</a> (<a href='#addreview'>add your own</a>)</li>";
}
else
	echo "<li>Help out by <a href='#addreview'>reviewing this movie</a>!</li>";

echo "</list>";

echo "</div><hr>";

echo "</tr>";

if($numactors > 0)
{
	echo "<table id='browsetable'><tr>";

	if($actorcolumns != null)
	{
		foreach($actorcolumns as $i=>$col)
		{
			echo "<td style='width: {$actorcolwidths[$i]};' class='browsetableheader'>$col</td>";
		}
	}
	
	echo "<div id='browsetext'><a name = 'actorlist' class='anchor'>Actors in ${moviename}:</a></div>";

	while($actors != null && $row = mysql_fetch_row($actors))
	{
			echo "<tr>";
			foreach ($row as $i=>$value)
			{
				echo "<td class='browsetablecell' style='width: {$actorcolwidths[$i]};'>";
				if($value)
					echo $value;
				else
					echo "N/A";
				echo "</td>";
			}
			echo "</tr>";
	}

echo "</table>";
echo "<div id='browsetext'>Is someone missing? Help out by <a href='editmovie.php?id={$id}&field=actor'>adding him/her</a>!</div>";
echo "<hr>";

}

if($numreviews > 0)
{
	echo "<div id='browsetext'><a name = 'reviews' class='anchor'>Reviews of ${moviename}:</div></a>";
	echo "<div id='browsetext'>";
	while($reviews != null && $row = mysql_fetch_row($reviews))
	{
		$name = $row[0];
		$time = $row[1];
		$rating = $row[2];
		$comment = $row[3];
		echo "Review by ${name} (posted ${time}) - <b>${rating}/5</b>";
		echo "<p style='padding-left: 1cm;'>${comment}</p>";
	}
	echo "</div>";
	echo "<hr>";
}

echo "<div id='browsetext'><a name ='addreview' class='anchor'>Add a review of ${moviename}:</div></a>";
echo "<div id='browsetext'>";
echo "<form action='editmovie.php?id=${id}&field=review' method='POST'>";
echo "<p>Your name: <input type = 'text' name='rname'/></p>";
echo "<p>Your rating (out of 5): <select name = 'rating'></p>";
for ($i = 0; $i <=5; $i++)
{
	if($i != 3)
		echo "<option value=$i>$i</option>";
	else
		echo "<option value=$i selected=1>$i</option>";
}
echo "</select><br>";
echo "<p>Comments: <br><textarea style='width: 15cm; height:5cm;' name='review'></textarea></p>";
echo "<p><input type='submit' name='submit' value='Submit review'/></p>";
echo "</form>";
echo "</div>";

?>

<?php require('footer.inc'); ?>