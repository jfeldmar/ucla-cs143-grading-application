<?php require("header.inc")?>

<?php
require("database.inc");

$companyname = $_GET["company"]; // this is automatically decoded by PHP
$company = urlencode($companyname);
connect();

$companysafe = mysql_real_escape_string($companyname);

$movies = query("Movie", "${movielink}, year, rating", "Movie.company='${companysafe}'");
$nummovies = query("Movie", "COUNT(id)", "Movie.company='${companysafe}'");
$moviecolumns = array("Movie", "Year", "MPAA rating");
$moviecolumnwidths = array("10cm", "4cm", "5cm");

disconnect();

$nummovies = mysql_fetch_row($nummovies);
$nummovies = $nummovies[0];

if(!verifyData($movies) || $nummovies < 1)
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing information about the company you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}

echo "<div id='browsetext'>";

echo "Currently viewing information about <a href='viewcompany.php?company=${company}'>${companyname}</a>:<br>";
echo "<list class='infolist'>";
echo "<li>Number of movies produced: ${nummovies}</li>";
echo "</list>";
echo "</div>";

echo "<hr>";

if($nummovies > 0)
{
	echo "<table id='browsetable'><tr>";

	if($moviecolumns != null)
	{
		foreach($moviecolumns as $i=>$col)
		{
			echo "<td style='width: {$moviecolwidths[$i]};' class='browsetableheader'>$col</td>";
		}
	}

	echo "</tr>";

	while($movies != null && $row = mysql_fetch_row($movies))
	{
		echo "<tr>";
		foreach ($row as $i=>$value)
		{
			echo "<td class='browsetablecell' style='width: {$moviecolwidths[$i]};'>";
			if($value)
				echo $value;
			else
				echo "N/A";
			echo "</td>";
		}
		echo "</tr>";
	}

	echo "</table>";
}

?>

<?php require('footer.inc'); ?>