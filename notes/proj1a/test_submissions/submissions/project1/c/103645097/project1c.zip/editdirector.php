<?php require("header.inc")?>

<?php
require("database.inc");
require("search.inc");
require("forms.inc");

$field = $_GET['field'];
$id = $_GET['id'];
$all = $_GET['all'];

if($all == null)
	$all = 0;
	
if(!strcmp($field, "newdirector"))
{
	echo "<div id='browsetext'>Enter information about the director you want to add below. Fields marked with an asterisk (*) are required. Afterwards you will be taken to a page where you can add movie information for this director.</div>";
	printNewDirectorForm();
	require("footer.inc");
	return;
}

if(!strcmp($field, "adddirector"))
{
	connect();
	
	$first = $_POST['first'];
	$last = $_POST['last'];
	$dob = $_POST['dob'];
	$dod = $_POST['dod'];
	
	$first = htmlspecialchars($first);
	$first = mysql_real_escape_string($first);
	
	$last = htmlspecialchars($last);
	$last = mysql_real_escape_string($last);
	
	if($dob != null)
		$dob = mysql_real_escape_string($dob);
	if($dod != null)
		$dod = mysql_real_escape_string($dod);
	
	if($dob != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		$doberror = true;
	if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		$doderror = true;
	
	if($doberror || $doderror || $first == null || $last == null)
	{
		disconnect();
		echo "<div id='browsetext'>There was an error creating the new director. Check the fields marked in red below and verify that they are filled in if required, and that they are in the correct format.</div>";
		printNewDirectorForm($first == null, $last == null, $doberror, $doderror);
		
		require("footer.inc");
		return;
	}
	
	// since this operation isn't atomic, need to lock the db to deal with concurrency
	mysql_query("LOCK TABLES MaxPersonID WRITE, Director WRITE");
	mysql_query("UPDATE MaxPersonID SET id=id+1");
	
	if($dob == null)
		$dob = "NULL";
	else
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
	if($dod == null)
		$dod = "NULL";
	else
		$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
	
	$sex = "'{$sexes[$sex]}'";
	
	mysql_query("INSERT INTO Director VALUES((SELECT id FROM MaxPersonID), '${last}', '${first}', $dob, $dod)");
	
	$newdirector = mysql_query("SELECT {$directorlink}, id FROM Director WHERE id=(SELECT id FROM MaxPersonID)");
	
	mysql_query("UNLOCK TABLES");
	
	disconnect();
	
	if($newdirector != null)
	{
		$newdirector = mysql_fetch_row($newdirector);
		$newid = $newdirector[1];
		$id = $newid;
		$newdirector = $newdirector[0];
	}

	echo "<div id='browsetext'>The new director has been added. You may edit his/her information below.</div>";
	
	$field = "all";
	$all = 1;
	$_GET['all'] = 1;
	$_POST['submit'] = null;
	$_GET['id'] = $id;
}

connect();

$id = mysql_real_escape_string($id);
$directorname = query("Director", "${directorlink}", "id = ${id}");

disconnect();


$returntext = "Click <a href='viewdirector.php?id=$id'>here</a> to return to the director info page.";
if($_GET['all'] == 1)
	$edittext = "Click <a href='editdirector.php?id=$id&field=all&all=1'>here</a> to continue editing the director info.</div>";
else
	$edittext = "</div>";

if(!verifyData($directorname))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing the director you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}

$directorname = mysql_fetch_row($directorname);
$directorname = $directorname[0];

if(!strcmp($field, 'birth') || !strcmp($field, "all"))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the birth date for $directorname below.</div>";
		printDirectorBirthdateForm();
	}
	else
	{
		$dob = $_POST['dob'];
	
		if(!ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		{
			echo "<div id='browsetext'>You must enter the birth date in the format YYYY-M-D below.</div>";
			printDirectorBirthdateForm(true);
			
			require("footer.inc");
			return;
		}
		
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
		
		connect();
		mysql_query("UPDATE Director set dob=$dob where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The birth date of $directorname has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, 'death') || !strcmp($field, "all"))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the death date for $directorname below.</div>";
		printDirectorDeathForm();
	}
	else
	{
		$dod = $_POST['dod'];
	
		if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		{
			echo "<div id='browsetext'>You must enter the death date in the format YYYY-M-D below.</div>";
			printDirectorDeathForm(true);
			
			require("footer.inc");
			return;
		}
		
		if($dod != null)
			$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
		else
			$dod = "NULL";
		
		connect();
		mysql_query("UPDATE Director set dod=$dod where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The birth date of $directorname has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, 'movies') || !strcmp($field, "all"))
{	
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Insert directing credit for ${directorname}:";
		echo "<form action='editdirector.php?id=${id}&field=movies&all=$all' method = 'POST'>";
		echo "<p>Movie title (partial title OK): <input type='text' name='title'><br>";
		echo "<input type = 'submit' name='submit' value='Find movie'></p>";
		echo "</form></div>";
	}
	else
	{
		$title = $_POST['title'];
		
		connect();
		
		$title = mysql_real_escape_string($title);
		
		$rows = mysql_query("SELECT CONCAT('<a href=\'editdirector.php?field=addmovie&all=$all&id={$id}&movie=', id, '\'>', title, '</a>') FROM Movie WHERE title LIKE '%$title%' order by title");
		
		disconnect();
		
		if($rows != null)
		{
			echo "<div id='browsetext'>If the movie you were looking for is listed below, click on the title to add $directorname as a director.<br><br>";
			while($row = mysql_fetch_row($rows))
				echo "${row[0]}<br>";
				
			echo "</div>";
		}
		
		echo "<div id='browsetext'>If we weren't able to find the movie you were looking for, please click <a href='editmovie.php?field=newmovie'>here</a> to add it to our database, then try again.";
		echo "</div>";
	}
}

if(!strcmp($field, 'addmovie'))
{
	$did = $id;
	$mid = $_GET['movie'];
	$role = $_POST['role'];
	
	connect();
	
	$mid = mysql_real_escape_string($mid);
	
	mysql_query("INSERT INTO MovieDirector VALUES($mid, $did)");
	
	$moviename = mysql_query("SELECT $movielink FROM Movie WHERE id=$mid");
	
	disconnect();
	
	$moviename = mysql_result($moviename, 0);
	
	echo "<div id='browsetext'>$directorname was successfully added as a director of $moviename. $returntext $edittext";
}

?>

<?php require("footer.inc")?>