<?php require("header.inc")?>

<?php
require("database.inc");
require("search.inc");

$submit = $_GET['submit'];
$offset = $_GET["offset"];
$displaylimit = $_GET["displaylimit"];
$mode = $_GET["mode"];

$title = $_GET['title'];
$titleURL = urlencode($title);

$name = $_GET['name'];
$nameURL = urlencode($name);

if($offset == null)
	$offset = 0;
if($displaylimit == null)
	$displaylimit = 30;

$limit = $offset + $displaylimit;
$prevpage = max(0, $offset - $displaylimit);
$nextpage = $offset + $displaylimit;

$linkinherit = "mode=$mode&displaylimit=$displaylimit";

$genrelist = getGenreList();

foreach($genrelist as $i=>$genre)
{
	if($_GET["genre_$i"] == 1)
		$linkinherit = $linkinherit."&genre_$i=1";
}

if($_GET["searchdirectors"] == 1)
	$linkinherit = $linkinherit."&searchdirectors=1";
if($_GET["searchactors"] == 1)
	$linkinherit = $linkinherit."&searchactors=1";

$columns = null;
$rows = null;
$colwidths = null;

	echo "<div id='browsetext'>Search for movies:<br>";
	echo "<form action='search.php#movieresults' method='get'>";
	echo "<input type = 'hidden' name='mode' value='0'>";
	if($submit == null || $_GET['searchdirectors'] == 1)
		echo "<p><input type='hidden' name='searchdirectors' value=1>";
	if($submit == null || $_GET['searchactors'] == 1)
		echo "<input type='hidden' name='searchactors' value=1>";
	
	echo "<p>Title keyword: <input type='text' name='title' style='width: 8cm;' value='{$_GET['title']}'></input></p>";

	echo "<p>Genres to include: <br>";
	printGenreCheckboxes();
	echo "</p>";
	echo "<p><input type='submit' name='submit' value='Search Movies'></p>";
	echo "</form></div>";
	
	echo "<div id='browsetext'>Search for people:<br>";
	echo "<form action='search.php?linkinherit#movieresults' method='get'>";
	echo "<input type = 'hidden' name='mode' value='1'>";
	
	foreach($genrelist as $i=>$genre)
	{
		if($submit == null || $_GET["genre_$i"] == 1)
			echo "<input type = 'hidden' name='genre_$i' value='1'";
	}
	
	echo "<p>Name (partial names OK): <input type='text' name='name' style='width: 8cm;' value='{$_GET['name']}'></input></p>";

	if($submit != null && $_GET['searchdirectors'] != 1)
		echo "<p><input type='checkbox' name='searchdirectors' value=1>Directors</input>";
	else
		echo "<p><input type='checkbox' name='searchdirectors' value=1 checked>Directors</input>";
		
	if($submit != null && $_GET['searchactors'] != 1)
		echo "<input type='checkbox' name='searchactors' value=1>Actors</input>";
	else
		echo "<input type='checkbox' name='searchactors' value=1 checked>Actors</input>";
	
	echo "</p>";
	echo "<p><input type='submit' name='submit' value='Search People'></p>";
	echo "</form></div>";
	
	
if($submit != null)
{
	if($mode == 0) // movie
	{	
		$genrelist = getGenreList();

		$excludedgenres = '1=1';
		
		foreach($genrelist as $i=>$genre)
		{
			if($_GET["genre_{$i}"]!=1)
			{
				$excludedgenres = $excludedgenres . " AND genres NOT LIKE '%${genre}%'";
			}
		}
		
		connect();
		$rows = mysql_query("SELECT {$movielink},year,(SELECT {$directorlinks} FROM MovieDirector, Director WHERE mid=Movie.id AND Director.id=did), (SELECT ${genres} FROM MovieGenre WHERE mid=Movie.id) AS genres,rating FROM Movie WHERE id in (SELECT id FROM Movie WHERE title LIKE '%${title}%' ORDER BY title,year) HAVING ({$excludedgenres}) LIMIT {$offset},{$displaylimit}", $conn);
		disconnect();
		
		$columns = array("Title", "Year", "Director(s)", "Genre(s)", "Rating");
		$colwidths = array("6cm", "2cm", "5cm", "3cm", "1cm");
	}
	else if($mode == 1) // person
	{
		
		connect();
		
		$actorquery = "SELECT ${actorlink} as name, sex, dob, dod, 'Actor' FROM Actor WHERE CONCAT(first, ' ', last) LIKE '%$name%'";
		$directorquery = "SELECT ${directorlink}, '(unknown)', dob, dod, 'Director' FROM Director WHERE CONCAT(first, ' ', last) LIKE '%$name%'";
		
		$query = $actorquery; // search actors even if nothing selected
		
		if($_GET['searchactors'] == 1 && $_GET['searchdirectors'] == 1)
		{
			$query = $query . " UNION ALL " . $directorquery;
		}
		else if($_GET['searchdirectors'] == 1)
		{
			$query = $directorquery;
		}
		
		$rows = mysql_query($query . " LIMIT {$offset},{$displaylimit}", $conn);
		
		disconnect();
		
		$columns = array("Actor", "Sex", "Date of Birth", "Date of Death", "Job");
		$colwidths = array("4cm", "2cm", "3cm", "3cm", "3cm");
	}
	
	if($rows != null && $columns != null)
	{
		echo "<hr>";
		if($mode == 0)
			echo "<div id='browsetext'><a name='movieresults' class='anchor'>Movies matching keyword \"${title}\"</a></div>";
		else if($mode == 1)
			echo "<div id='browsetext'><a name='movieresults' class='anchor'>People matching keyword \"${name}\"</a></div>";
			
		echo "<center>";
		echo "<a href='search.php?title=$titleURL&name=$nameURL&$linkinherit&offset=$prevpage&submit=1#movieresults'><img src='leftarrow.png'></a>&nbsp; &nbsp; &nbsp;";
		echo "<a href='search.php?title=$titleURL&name=$nameURL&$linkinherit&offset=$nextpage&submit=1#movieresults'><img src='rightarrow.png'></a>";
		echo "</center>";
		
		echo "<table id='browsetable'><tr>";
		
		foreach($columns as $i=>$col)
		{
			echo "<td style='width: {$colwidths[$i]};' class='browsetableheader'>$col</td>";
		}
	}

	if($rows != null)
		echo "</tr>";

	while($rows != null && $row = mysql_fetch_row($rows))
	{
		echo "<tr>";
		foreach ($row as $i=>$value)
		{
			echo "<td class='browsetablecell' style='width: {$colwidths[$i]};'>";
			if($value)
				echo $value;
			else
				echo "N/A";
			echo "</td>";
		}
		echo "</tr>";
	}

	if($rows != null)
		echo "</table>";
}

?>

<?php require("footer.inc")?>