<?php require("header.inc")?>

<?php
require("database.inc");
require("search.inc");
require("forms.inc");

$field = $_GET['field'];
$id = $_GET['id'];
$all = $_GET['all'];

if($all == null)
	$all = 0;
	
if(!strcmp($field, "newactor"))
{
	echo "<div id='browsetext'>Enter information about the actor you want to add below. Fields marked with an asterisk (*) are required. Afterwards you will be taken to a page where you can add movie information for this actor.</div>";
	printNewActorForm();
	require("footer.inc");
	return;
}

if(!strcmp($field, "addactor"))
{
	connect();
	
	$first = $_POST['first'];
	$last = $_POST['last'];
	$dob = $_POST['dob'];
	$dod = $_POST['dod'];
	$sex = $_POST['sex'];
	
	$sexes = array("Male", "Female");
	
	if($sex != 0 && $sex != 1)
		$sex = 0;
	
	$first = htmlspecialchars($first);
	$first = mysql_real_escape_string($first);
	
	$last = htmlspecialchars($last);
	$last = mysql_real_escape_string($last);
	
	if($dob != null)
		$dob = mysql_real_escape_string($dob);
	if($dod != null)
		$dod = mysql_real_escape_string($dod);
	
	if($dob != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		$doberror = true;
	if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		$doderror = true;
	
	if($doberror || $doderror || $first == null || $last == null)
	{
		disconnect();
		echo "<div id='browsetext'>There was an error creating the new actor. Check the fields marked in red below and verify that they are filled in if required, and that they are in the correct format.</div>";
		printNewActorForm($first == null, $last == null, $doberror, $doderror);
		
		require("footer.inc");
		return;
	}
	
	// since this operation isn't atomic, need to lock the db to deal with concurrency
	mysql_query("LOCK TABLES MaxPersonID WRITE, Actor WRITE");
	mysql_query("UPDATE MaxPersonID SET id=id+1");
	
	if($dob == null)
		$dob = "NULL";
	else
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
	if($dod == null)
		$dod = "NULL";
	else
		$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
	
	$sex = "'{$sexes[$sex]}'";
	
	mysql_query("INSERT INTO Actor VALUES((SELECT id FROM MaxPersonID), '${last}', '${first}', $sex, $dob, $dod)");
	
	$newactor = mysql_query("SELECT {$actorlink}, id FROM Actor WHERE id=(SELECT id FROM MaxPersonID)");
	
	mysql_query("UNLOCK TABLES");
	
	disconnect();
	
	if($newactor != null)
	{
		$newactor = mysql_fetch_row($newactor);
		$newid = $newactor[1];
		$id = $newid;
		$newactor = $newactor[0];
	}
	
	if(!strcmp($sex, "'Male'"))
		$pronoun = 'his';
	else
		$pronoun = 'her';

	echo "<div id='browsetext'>The new actor has been added. You may edit $pronoun information below.</div>";
	
	$field = "all";
	$all = 1;
	$_GET['all'] = 1;
	$_POST['submit'] = null;
	$_GET['id'] = $id;
}

connect();

$id = mysql_real_escape_string($id);
$actorname = query("Actor", "${actorlink}", "id = ${id}");

disconnect();


$returntext = "Click <a href='viewactor.php?id=$id'>here</a> to return to the actor info page.";
if($_GET['all'] == 1)
	$edittext = "Click <a href='editactor.php?id=$id&field=all&all=1'>here</a> to continue editing the actor info.</div>";
else
	$edittext = "</div>";

if(!verifyData($actorname))
{
	echo "<div id='browsetext'>";
	echo "There was a problem accessing the actor you selected. Please press \"back\" in your browser and try again.";
	echo "</div>";
	require("footer.inc");
	return;
}

$actorname = mysql_fetch_row($actorname);
$actorname = $actorname[0];

if(!strcmp($field, 'birth') || !strcmp($field, "all"))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the birth date for $actorname below.</div>";
		printActorBirthdateForm();
	}
	else
	{
		$dob = $_POST['dob'];
	
		if(!ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dob))
		{
			echo "<div id='browsetext'>You must enter the birth date in the format YYYY-M-D below.</div>";
			printActorBirthdateForm(true);
			
			require("footer.inc");
			return;
		}
		
		$dob = "STR_TO_DATE('$dob', '%Y-%m-%d')";
		
		connect();
		mysql_query("UPDATE Actor set dob=$dob where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The birth date of $actorname has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, 'death') || !strcmp($field, "all"))
{
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Enter the death date for $actorname below.</div>";
		printActorDeathForm();
	}
	else
	{
		$dod = $_POST['dod'];
	
		if($dod != null && !ereg("([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})", $dod))
		{
			echo "<div id='browsetext'>You must enter the death date in the format YYYY-M-D below.</div>";
			printActorDeathForm(true);
			
			require("footer.inc");
			return;
		}
		
		if($dod != null)
			$dod = "STR_TO_DATE('$dod', '%Y-%m-%d')";
		else
			$dod = "NULL";
		
		connect();
		mysql_query("UPDATE Actor set dod=$dod where id=$id");
		disconnect();
		
		echo "<div id='browsetext'>The birth date of $actorname has been updated. $returntext $edittext";
	}
}

if(!strcmp($field, 'movies') || !strcmp($field, "all"))
{	
	if($_POST['submit'] == null)
	{
		echo "<div id='browsetext'>Insert acting credit for ${actorname}:";
		echo "<form action='editactor.php?id=${id}&field=movies&all=$all' method = 'POST'>";
		echo "<p>Movie title (partial title OK): <input type='text' name='title'><br>";
		echo "<input type = 'submit' name='submit' value='Find movie'></p>";
		echo "</form></div>";
	}
	else
	{
		$title = $_POST['title'];
		
		connect();
		
		$title = mysql_real_escape_string($title);
		
		$rows = mysql_query("SELECT CONCAT('<a href=\'editactor.php?field=addmovie&all=$all&id={$id}&movie=', id, '\'>', title, '</a>') FROM Movie WHERE title LIKE '%$title%' order by title");
		
		disconnect();
		
		if($rows != null)
		{
			echo "<div id='browsetext'>If the movie you were looking for is listed below, click on the title to add $actorname as an actor.<br><br>";
			while($row = mysql_fetch_row($rows))
				echo "${row[0]}<br>";
				
			echo "</div>";
		}
		
		echo "<div id='browsetext'>If we weren't able to find the movie you were looking for, please click <a href='editmovie.php?field=newmovie'>here</a> to add it to our database, then try again.";
		echo "</div>";
	}
}

if(!strcmp($field, 'addmovie'))
{
	if($_POST['submit'] == null)
	{
		$mid = $_GET['movie'];
		
		connect();
		
		$mid = mysql_real_escape_string($mid);
		$moviename = mysql_query("SELECT $movielink FROM Movie WHERE id=$mid");
		disconnect();
		
		$moviename = mysql_result($moviename, 0);
		echo "<div id='browsetext'>Enter the role of $actorname in $moviename below.";
		printActorMovieRoleForm();
		echo "</div>";
	}
	else
	{
		$aid = $id;
		$mid = $_GET['movie'];
		$role = $_POST['role'];
		
		connect();
		
		$role = htmlspecialchars($role);
		$role = mysql_real_escape_string($role);
		
		$mid = mysql_real_escape_string($mid);
		
		if($role == null)
		{
			disconnect();
			echo "<div id='browsetext'>You must fill in the role below to add the actor to the movie.</div>";
			printActorMovieRoleForm(true);
			
			require("footer.inc");
			return;
		}
		
		mysql_query("INSERT INTO MovieActor VALUES($mid, $aid, '$role')");
		
		$moviename = mysql_query("SELECT $movielink FROM Movie WHERE id=$mid");
		
		disconnect();
		
		$moviename = mysql_result($moviename, 0);
		
		echo "<div id='browsetext'>$actorname was successfully added to $moviename as \"$role.\" $returntext $edittext";
	}
}

?>

<?php require("footer.inc")?>