
<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$mych = $_POST["mych"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
echo "<h3>Select Movie: </h3>";
echo "<table width=600 border=0>";
$ch = 'A';
echo "<form method=\"POST\" ACTION=\"./B2.php\">";
while (true){
echo "<input type=submit name=\"mych\" value=\"$ch\">";
    if($ch=='Z')
        break;
    $ch++;
}
echo "</form>";
if($mych) {
echo "<form method=\"POST\" ACTION=\"./B2_get.php\">";
echo "<tr><td><br></td></tr>";
echo "<tr><td><select name=\"mid\">";
$s2 = mysql_query("select * from Movie where title like '$mych%' order by title",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[id]\">$row[title] ($row[year])</option>";
}
echo "<input type=submit name=\"submit\" value=\"GO\">";
echo "</form>";
echo "</select></td></tr>";
}
echo "</table>";
mysql_close($x);
echo "</div>";
?>

