
<?php
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
echo "<h3>Add New Actor in Movie:</h3>";
echo "<table width=800 border=0>";
echo "<form method=\"POST\" ACTION=\"./I4_get.php\">";
echo "<tr><td width=200>Movie :<select name=\"mid\">";
$s2 = mysql_query("select * from Movie",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[id]\">$row[title] ($row[year])</option>";
}
echo "</select></td></tr>";
echo "<tr><td width=200>Actor : <select name=\"aid\">";
$s2 = mysql_query("select * from Actor",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[id]\">$row[first] $row[last]</option>";
}
echo "</select></td></tr>";
echo "
<tr><td width=400>Role : <input type=\"textbox\" name=\"role\" maxlength=20 size=20></td></tr>
";
echo "<hr>";
echo "<tr><td><input type=\"submit\" value=\"Add Movie\" /></td></tr>";
echo "</td></tr>";
echo "</table>";
echo "</div>";
mysql_close($x);

?>

