<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$title = $_POST["title"];
$company = $_POST["company"];
$year = $_POST["year"];
$did = $_POST["did"];
$rating = $_POST["rating"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
if ($title) {
    $m_id = mysql_query("select max(id)+1 from Movie", $x);
    $row=mysql_fetch_array($m_id);
    $id = $row['max(id)+1'];
    $s = mysql_query("insert into Movie (id,title,year,rating,company) values('$id','$title','$year','$rating','$company')",$x);
    $s = mysql_query("insert into MaxMovieID (id) values('$id')", $x);
    $s = mysql_query("delete from MaxMovieID where id<>'$id'", $x);
    $s = mysql_query("insert into MovieDirector (mid,did) values('$id','$did')",$x);
echo "<h4>Thank you for contributing to our movie database!</h4>";
    $s2 = mysql_query("select genre from MovieGenre group by genre",$x);
    while($row=mysql_fetch_array($s2)){
        if ($_POST["$row[genre]"]){
            $s = mysql_query("insert into MovieGenre (mid,genre) values('$id','$row[genre]')",$x);
        }
    }
}
mysql_close($x);
echo "<a href=\"I3.php\"> Return to Add Movies page</a>";
echo "</div>";

?>
