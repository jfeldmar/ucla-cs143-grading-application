<?php
$type = $_POST["type"];
$first = $_POST["first"];
$last = $_POST["last"];
$dob_month = $_POST["dob_month"];
$dob_day = $_POST["dob_day"];
$dob_year = $_POST["dob_year"];
$dod_month = $_POST["dod_month"];
$dod_day = $_POST["dod_day"];
$dod_year = $_POST["dod_year"];
$sex = $_POST["sex"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
    $a_id = mysql_query("select max(id)+1 from Actor", $x);
    $row=mysql_fetch_array($a_id);
    $id_a = $row['max(id)+1'];
    $d_id = mysql_query("select max(id)+1 from Director", $x);
    $row=mysql_fetch_array($d_id);
    $id_d = $row['max(id)+1'];
    if ($id_a < $id_d)
        $id_a = $id_d;
    $s = mysql_query("insert into MaxPersonID(id) values('$id_a')", $x);
    $s = mysql_query("delete from MaxPersonID where id<>'$id_a'", $x);
    $p_id = mysql_query("select id from MaxPersonID", $x);
    $row=mysql_fetch_array($p_id);
    $id = $row['id'];
if ($type == "Actor" && $first && $last) {
    if($dod_year && $dod_month && $dod_day) {
$s = mysql_query("insert into Actor (id,last,first,sex,dob,dod) values('$id','$last','$first','$sex','$dob_year-$dob_month-$dob_day','$dod_year-$dod_month-$dod_day')",$x);
    } else {
$s = mysql_query("insert into Actor (id,last,first,sex,dob) values('$id','$last','$first','$sex','$dob_year-$dob_month-$dob_day')",$x);
    }
echo "<h4><font color=green>Inserted $type: \"$first $last\" into database.</font></h4>";
}
else if($type == "Director" && $first && $last){
    if($dod_year && $dod_month && $dod_day) {
$s = mysql_query("insert into Director (id,last,first,dob,dod) values('$id','$last','$first','$dob_year-$dob_month-$dob_day','$dod_year-$dod_month-$dod_day')",$x);
    }
    else {
$s = mysql_query("insert into Director (id,last,first,dob) values('$id','$last','$first','$dob_year-$dob_month-$dob_day')",$x);
    }
echo "<h4><font color=green>Inserted $type: \"$first $last\" into database.</font></h4>";
} else if($type){
    echo "<h4><font color=red>Must Include First/Last names</font></h4>";
}
mysql_close($x);

?>
<html>
<head>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<div id="content">
<body>
<h3>Add new Actor/Director </h3>
<p>
<table width=400 border=0>
<form method="POST" ACTION="<?php echo $PHP_SELF;?>">
<tr>
<td width=100>Identity : </td><td><input type="radio" name="type" value="Actor" checked> Actor<br>
<input type="radio" name="type" value="Director"> Director<br></td>
</tr>
<tr><td colspan=2><hr></td></tr>
<tr><td>First Name: </td><td><input type="textbox" name="first" maxlength=20></td></tr>
<tr><td>Last Name: </td><td><input type="textbox" name="last" maxlength=20></td></tr>
<tr><td>Sex :</td><td><input type="radio" name="sex" value="Male" checked> Male<input type="radio" name="sex" value="Female"> Female</td></tr>
<tr><td>Date of Birth: </td><td>
<select name="dob_month">
    <option value="00"></option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
</select>
/
<select name="dob_day">
    <option value="00"></option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
</select>
/
<input type="textbox" name="dob_year" maxlength=4 size=4></td></tr>
<tr><td>Date of Death: </td><td>
<select name="dod_month">
    <option value="00"></option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
</select>
/
<select name="dod_day">
    <option value="00"></option>
    <option value="01">01</option>
    <option value="02">02</option>
    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>
    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
    <option value="13">13</option>
    <option value="14">14</option>
    <option value="15">15</option>
    <option value="16">16</option>
    <option value="17">17</option>
    <option value="18">18</option>
    <option value="19">19</option>
    <option value="20">20</option>
    <option value="21">21</option>
    <option value="22">22</option>
    <option value="23">23</option>
    <option value="24">24</option>
    <option value="25">25</option>
    <option value="26">26</option>
    <option value="27">27</option>
    <option value="28">28</option>
    <option value="29">29</option>
    <option value="30">30</option>
    <option value="31">31</option>
</select>
/
<input type="textbox" name="dod_year" maxlength=4 size=4></td></tr>
<tr><td colspan=2><hr></td></tr>
<tr><td><input type="submit" value="Submit" /></td></tr>
</form>
</p>


</body>
</div>

</html>

