<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$aid2 = $_GET["aid"];
$aid = $_POST["aid"];
if ($aid2) {
    $aid = $aid2;
}
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
    $s2 = mysql_query("select * from Actor where id='$aid'",$x);
    $row = mysql_fetch_array($s2);
    $first = $row[first];
    $last = $row[last];
echo "<h4>Movies that \"$first $last\" have been in:</h4>";
    $s2 = mysql_query("select * from MovieActor where aid='$aid'",$x);
    echo "<table width=600 border=1>";
    echo "<th>Movie</th><th>Role</th>";
    while($row=mysql_fetch_array($s2)){
        $s3 = mysql_query("select * from Movie where id='$row[mid]'",$x);
        $movie = mysql_fetch_array($s3);
        echo "<tr><td><a href=\"./B2_get.php?mid=$movie[id]\">$movie[title]</a></td><td>$row[role]</td></tr>";
    }
    echo "</table>";
mysql_close($x);
echo "<br><a href=\"B1.php\"> Return to Actor Search Page</a>";
echo "</div>";

?>
