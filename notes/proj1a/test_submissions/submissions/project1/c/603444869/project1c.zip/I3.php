
<?php
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
echo "<h3>Add new Movie:</h3>";
echo "<table width=600 border=0>";
echo "<form method=\"POST\" ACTION=\"./I3_get.php\">";
echo "
<tr><td width=400>Title : <input type=\"textbox\" name=\"title\" maxlength=20 size=20></td></tr>
";
echo "
<tr><td width=400>Company : <input type=\"textbox\" name=\"company\" maxlength=20 size=20></td></tr>
";
echo "
<tr><td>Year : <input type=\"textbox\" name=\"year\" maxlength=4 size=4></td></tr>
";
echo "<tr><td width=200>Director : <select name=\"did\">";
$s2 = mysql_query("select id,first,last,dob from Director",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[id]\">$row[first] $row[last] - (Date of Birth: $row[dob])</option>";
}
echo "</select></td></tr>";
echo "<tr><td width=200>MPAA RATING: <select name=\"rating\">";
$s2 = mysql_query("select rating from Movie group by rating",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[rating]\">$row[rating]</option>";
}
echo "</select></td></tr>";
echo "<tr><td width=200>Genre : ";
$s2 = mysql_query("select genre from MovieGenre group by genre",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<input type=\"CHECKBOX\" name=\"$row[genre]\">$row[genre]</option>";
}
echo "<hr>";
echo "<tr><td><input type=\"submit\" value=\"Add Movie\" /></td></tr>";
echo "</td></tr>";
echo "</table>";
echo "</div>";
mysql_close($x);

?>

