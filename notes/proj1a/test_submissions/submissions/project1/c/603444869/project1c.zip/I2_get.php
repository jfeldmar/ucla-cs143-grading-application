<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$mid = $_POST["mid"];
$name = $_POST["name"];
$rating = $_POST["rating"];
$comments = $_POST["comments"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
if ($name && $rating) {
    $s = mysql_query("insert into Review (name,time,mid,rating,comment) values('$name',NOW(),'$mid','$rating','$comments')",$x);
echo "<h4>Thank you! Your review is highly valued!</h4>";
}
mysql_close($x);
echo "<a href=\"B2_get.php?mid=$mid\">See other reviews of this movie</a><br><br>";
echo "<a href=\"I2.php\"> Return to Rate Movies page</a>";
echo "</div>";

?>
