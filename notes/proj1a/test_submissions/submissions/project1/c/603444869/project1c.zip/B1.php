
<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$mych = $_POST["mych"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
echo "<h3>Select Actor: </h3>";
echo "<table width=600 border=0>";
$ch = 'A';
echo "<form method=\"POST\" ACTION=\"./B1.php\">";
while (true){
echo "<input type=submit name=\"mych\" value=\"$ch\">";
    #echo "<a href=\"./B1.php?mych='$ch'\" onclick=\"this.form.submit();\">$ch</a>&nbsp;";
    if($ch=='Z')
        break;
    $ch++;
}
echo "</form>";
if($mych) {
echo "<form method=\"POST\" ACTION=\"./B1_get.php\">";
echo "<tr><td><br></td></tr>";
echo "<tr><td><select name=\"aid\">";
$s2 = mysql_query("select id,first,last,dob from Actor where last like '$mych%' order by last,first",$x);
while($row=mysql_fetch_array($s2)) {
    echo "<option value=\"$row[id]\">$row[last], $row[first] ($row[dob])</option>";
}
echo "<input type=submit name=\"submit\" value=\"GO\">";
echo "</form>";
echo "</select></td></tr>";
}
echo "</table>";
mysql_close($x);
echo "</div>";

?>

