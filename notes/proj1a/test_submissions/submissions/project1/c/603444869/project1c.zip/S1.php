<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
echo "<h3>Search Actor or Movie</h3>";
echo "<table width=400 border=0>";
echo "<form method=\"POST\" ACTION=\"S1.php\">";
echo "<tr><td>&nbsp;</td></tr>";
echo "<tr><td>Search : <input type=\"textbox\" name=\"search\" maxlength=20>&nbsp;<input type=\"submit\" name=\"submit\" value=\"GO\" /></td></tr>";
echo "<tr><td><hr></td></tr>";
echo "</form>";
$search = $_POST["search"];
$submit = $_POST["submit"];
if ($submit) {
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
    $s = mysql_query("select * from Movie where title like '%$search%'", $x);
    echo "<table width=600 border=1>";
    while($row=mysql_fetch_array($s)){
        echo "<tr><td>Movie: <a href=\"./B2_get.php?mid=$row[id]\">$row[title]</a></td></tr>";
    }
    echo "</table>";
    $s = mysql_query("select * from Actor where first like '%$search%' or last like '%$search%'", $x);
    echo "<table width=600 border=1>";
    echo "<tr><td>&nbsp;</td></tr>";
    while($row=mysql_fetch_array($s)){
        echo "<tr><td>Actor: <a href=\"./B1_get.php?aid=$row[id]\">$row[first] $row[last]</a></td></tr>";
    }
    echo "</table>";
mysql_close($x);
}

?>

</div>


