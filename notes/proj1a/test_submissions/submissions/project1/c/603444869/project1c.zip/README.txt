I implemented everything required of the project specifications.

Worked alone.

Name: Sky Lin
ID  : 603444869
