<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$title = $_POST["mid"];
$company = $_POST["aid"];
$year = $_POST["role"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
    $s = mysql_query("insert into MovieActor (mid,aid,role) values('$mid','$aid','$role')",$x);
echo "<h4>Thank you for contributing to our movie/actor database!</h4>";
mysql_close($x);
echo "<a href=\"I4.php\"> Return to Add MovieActors page</a>";
echo "</div>";
?>
