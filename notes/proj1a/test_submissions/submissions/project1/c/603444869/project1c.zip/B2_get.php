<?php
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
$mid2 = $_GET["mid"];
$mid = $_POST["mid"];
if ($mid2) {
    $mid = $mid2;
}
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
    $s = mysql_query("select * from Movie where id='$mid'",$x);
echo '<table width=600 border=0>';
$row=mysql_fetch_array($s);
echo "<h3>Move Info : </h3>";
echo "<tr><td>Title : '$row[title] ($row[year])'</td></tr>";
echo "<tr><td>Producer : '$row[company]'</td></tr>";
echo "<tr><td>MPAA Rating : '$row[rating]'</td></tr>";
    $s = mysql_query("select did from MovieDirector where mid='$mid'",$x);
$row=mysql_fetch_array($s);
    $s = mysql_query("select * from Director where id='$row[did]'",$x);
$row=mysql_fetch_array($s);
echo "<tr><td>Director : '$row[first] $row[last]'</td></tr>";
    $s = mysql_query("select genre from MovieGenre where mid='$mid'",$x);
echo "<tr> <td>Genre: <font color='brown'>";
while($row=mysql_fetch_array($s)){
    echo "$row[genre] &nbsp;";
}
echo "</font></td></tr>";
echo "<tr><td><hr></td></tr>";
echo '</table>';

$row=mysql_fetch_array($s);
echo "<h3>Actor List : </h3>";
echo '<table width=600 border=0>';
    $s = mysql_query("select * from MovieActor where mid='$mid'",$x);
while($row=mysql_fetch_array($s)){
    echo "<tr>";
    $s2 = mysql_query("select * from Actor where id='$row[aid]'",$x);
    $row2=mysql_fetch_array($s2);
    echo "<td><a href=\"./B1_get.php?aid=$row[aid]\">$row2[first] $row2[last]</a> as \"$row[role]\"</td>";
    echo "</tr>";
}
echo "<tr><td><hr></td></tr>";
echo '</table>';
echo "<h3>Average Rating: </h3>";
echo '<table width=600 border=0>';
    $s = mysql_query("select avg(rating) from Review where mid='$mid' group by mid",$x);
    $row=mysql_fetch_array($s);
    if (($avg = $row['avg(rating)']) > 0.0000) {
        echo "<td>Average rating is : $avg</td>";
    } else {
        echo "<td><font color=FFAA00>This movie has not yet been rated!</font></td>";
    }
    echo "</tr>";
    $s = mysql_query("select comment,name from Review where mid='$mid'",$x);
    echo "<tr><td><hr></td></tr>";
    echo "<tr><td><font size=4>Comments : </font></td></tr>";
    $count = 0;
    while($row=mysql_fetch_array($s)){
        if ($row[comment]){
            echo "<tr><td><i>\"$row[comment]\"</i><br>&nbsp;&nbsp;-$row[name]</td></tr>";
            $count++;
        }
    }
    if ($count == 0) {
        echo "<tr><td><font color='00BBBB'>No Comments</font></td></tr>";
    }

    echo "<tr><td><hr><br><a href=./I2.php?selected=$mid>Review This Movie Now</a><br><hr></td></tr>";

echo '</table>';
mysql_close($x);
echo "<br><a href=\"B2.php\"> Return to Movie Search Page</a>";
echo "</div>";
?>
