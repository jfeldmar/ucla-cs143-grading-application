
<?php
$selected=$_GET["selected"];
$x = mysql_connect('localhost','cs143',''); 
mysql_select_db("CS143",$x);
echo "<head>";
echo "<link href=\"default.css\" rel=\"stylesheet\" type=\"text/css\" />";
echo "</head>";
echo "<div id=\"content\">";
echo "<h3>Rate a Movie:</h3>";
echo "<table width=400 border=0>";
echo "<form method=\"POST\" ACTION=\"./I2_get.php\">";
echo "<tr><td>Movie : <select name=\"mid\">";
$s2 = mysql_query("select id,title from Movie",$x);
while($row=mysql_fetch_array($s2)) {
    if ($selected == $row[id]) {
        echo "<option value=\"$row[id]\" selected>$row[id]-$row[title]</option>";
    } else {
        echo "<option value=\"$row[id]\" >$row[id]-$row[title]</option>";
    }
}
echo "</select></td></tr>";
mysql_close($x);

?>
<html>
<body>
<p>
<tr><td>Name : <input type="textbox" name="name" maxlength=20 size=20 value="Anonymous"></td></tr>
<tr><td>Rating : 
<select name="rating">
    <option value="1">1 - It sucked</option>
    <option value="2">2 - Don't watch</option>
    <option value="3">3 - Not bad</option>
    <option value="4">4 - Good</option>
    <option value="5">5 - Excellent</option>
</select>
</td></tr>
<tr><td>Comments : </td>
</tr>
<tr>
<td>
<textarea cols="80" rows="10" name="comments"></textarea>
</td>
</tr>

<tr><td><input type="submit" value="Rate It!" /></td></tr>
</form>
</p>


</body>
</div>

</html>

