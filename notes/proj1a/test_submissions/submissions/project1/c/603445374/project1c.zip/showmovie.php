<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr - View Movie Info</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">
	<h1>View a movie's information</h1><br>
<?php
$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$query="SELECT id, title, year FROM Movie";
$result = mysql_query ($query);
?>

<form action="showmovie.php" method="post">
<select name="movie">
<?php
while($nt=mysql_fetch_array($result)) {
	echo "<option value='$nt[id]'>$nt[title] ($nt[year])</option>";	//populate dropdown menu with data
}
?>
</select>
<input type="submit" value="View Movie">
</form>

<?php
$movie = $_REQUEST['movie'];
if (!isset($movie)) {	//check if a parameter was passed
	include ('footer.php');
	exit;
}
//retrieve all data from db
$query2="SELECT * FROM Movie WHERE id=$movie";
$result = mysql_query($query2, $db_connection) or die(mysql_error());
$query3="SELECT A.id, A.first, A.last, MA.role FROM MovieActor MA, Actor A WHERE MA.mid=$movie AND A.id=MA.aid";
$result2 = mysql_query($query3, $db_connection) or die(mysql_error());
$query4="SELECT * FROM Review WHERE mid=$movie";
$result3 = mysql_query($query4, $db_connection) or die(mysql_error());
$result4=mysql_query("SELECT AVG(rating) FROM Review WHERE mid='$movie'", $db_connection) or die(mysql_error());	//retrieve max id
mysql_close($db_connection);

//output movie info
echo "<br><h1>Movie Info</h1><br>";
$title=mysql_result($result, 0, "title");
$year=mysql_result($result, 0, "year");
$rating=mysql_result($result, 0, "rating");
$comp=mysql_result($result, 0, "company");
echo "<b>Title:</b> " . $title . "<br>";
echo "<b>Release year:</b> " . $year . "<br>";
echo "<b>MPAA rating:</b> " . $rating . "<br>";
echo "<b>Production company:</b> " . $comp . "<br>";

//output actors in movie
echo "<br><h1>Starring</h2><br>";
if (mysql_num_rows($result2) == 0) {	//check to see if actor has been in any movies
	echo "<h2>No one appears in this movie, sadly.</h2>";	//if not, say so
}
else {	//has appeared in movies, so output data
	$i=0;
	while ($row = mysql_fetch_row($result2)) {	//output data
		$id=mysql_result($result2, $i, "id");
		$first=mysql_result($result2, $i, "first");
		$last=mysql_result($result2, $i, "last");
		$role=mysql_result($result2, $i, "role");
		echo '<a href="/~cs143/showactor.php?actor='.$id.'">'.$first.' '.$last.'</a> as '.$role.'<br>';
		$i++;
	}
}

//output reviews of movie
echo "<br><h1>Reviews</h1><br>";
if (mysql_num_rows($result3) == 0) {	//check to see if there are any reviews
	echo "<h2>No one has written a review yet.</h2>";	//if not, say so
}
else {	//there are reviews, so ouput them
	$avg=mysql_result($result4, 0, "AVG(rating)");
	echo 'Average rating: <b>'.$avg.'</b> out of 5<br>';
	$i=0;
	while ($row = mysql_fetch_row($result3)) {	//output data
		$name=mysql_result($result3, $i, "name");
		$time=mysql_result($result3, $i, "time");
		$rating=mysql_result($result3, $i, "rating");
		$comment=mysql_result($result3, $i, "comment");
		echo '<br><b>'.$name.'</b> wrote a review on '.$time.'<br>'; //"[name] wrote a review on [date]"
		echo '<b>Rating: '.$rating.'</b> out of 5<br>'; //rating: [rating] out of 5
		echo '<b>Comment:</b><br>'.$comment.'<br>'; //Comment: [comment]
		$i++;
	}
}

?>
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>