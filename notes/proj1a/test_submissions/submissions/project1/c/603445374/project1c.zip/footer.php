<?php
echo '</div><div id="footer">Copyright &copy; Filmr Inc. Designed and coded by Jono.</div> </div> </body></html>'
?>