<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr - Add Actor/Director</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">

<h1>Input an actor or director</h1><br>
<form action="addactor.php" method="post">
<p>Actor<INPUT TYPE="radio" NAME="type" VALUE="1" CHECKED> Director<INPUT TYPE="radio" NAME="type" VALUE="2"><br></p>
<p>First:<INPUT TYPE="text" NAME="first" SIZE=20 MAXLENGTH=20><br></p>
<p>Last:<INPUT TYPE="text" NAME="last" SIZE=20 MAXLENGTH=20><br></p>
<p>Sex: Male<INPUT TYPE="radio" NAME="sex" VALUE="Male" CHECKED> Female<INPUT TYPE="radio" NAME="sex" VALUE="Female"><br></p>
<p>Date of birth:<INPUT TYPE="text" NAME="dob" SIZE=10 MAXLENGTH=10>(YYYY-MM-DD)<br></p>
<p>Date of death:<INPUT TYPE="text" NAME="dod" SIZE=10 MAXLENGTH=10>(Leave blank if still alive)<br></p>
<input type="submit" value="ADD">
</form>

<?php
$type = $_POST['type'];
$first = $_POST['first'];	//obtain all the values
$last = $_POST['last'];
$sex = $_POST['sex'];
$dob = $_POST['dob'];
$dod = $_POST['dod'];

if (!isset($type, $first, $last, $sex, $dob) OR $first==NULL OR $last==NULL OR $sex==NULL OR $dob==NULL) {	//check if paramters were passed
	echo "<br><h1>Please provide input.</h1>";
	include ('footer.php');
	exit;
}

$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$rs=mysql_query('SELECT id FROM MaxPersonID') or die(mysql_error());	//retrieve max id
$id=mysql_result($rs, 0, "id");
if ($dod != NULL) {	//insert new actor/director into db
	if ($type == 1) {	//for actor
		mysql_query("INSERT INTO Actor VALUES('$id', '$last', '$first', '$sex', '$dob', '$dod')") or die(mysql_error());	//if dod was filled out
	}
	if ($type == 2) {	//for director
		mysql_query("INSERT INTO Director VALUES('$id', '$last', '$first', '$dob', '$dod')") or die(mysql_error());	//if dod was filled out
	}
}
else {
	if ($type == 1) {	//for actor
		mysql_query("INSERT INTO Actor VALUES('$id', '$last', '$first', '$sex', '$dob', NULL)") or die(mysql_error());	//if dod was not filled out
	}
	if ($type == 2) {	//for director
		mysql_query("INSERT INTO Director VALUES('$id', '$last', '$first', '$dob', NULL)") or die(mysql_error());	//if dod was not filled out
	}
}
mysql_query("UPDATE MaxPersonID SET id=id+1") or die(mysql_error());	//increment MaxPersonId for the future
mysql_close($db_connection);

if ($type == 1) {	//for actor
	echo "<br><h1>Actor inserted!</h1>";
}
if ($type == 2) {	//for director
	echo "<br><h1>Director inserted!</h1>";
}

?>
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>