<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr - Add Movie Review</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">
		<h1>Add a movie review</h1><br>
<?php

$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$query="SELECT id, title, year FROM Movie";
$result = mysql_query($query);
?>

<form action="review.php" method="post">

<p>Select movie:
<select name="movie">
<?php
while($nt=mysql_fetch_array($result)) {
	echo "<option value='$nt[id]'>$nt[title] ($nt[year])</option>";	//populate dropdown menu with data
}
?>
</select></p>

<p>Your name:
<INPUT TYPE="text" NAME="name" SIZE=20 MAXLENGTH=20><br></p>

<p>Your rating:
<SELECT NAME="rating">
<OPTION VALUE="5" SELECTED>5
<OPTION VALUE="4">4
<OPTION VALUE="3">3
<OPTION VALUE="2">2
<OPTION VALUE="1">1
</SELECT> (5 = best)<br></p>

<p>Comments:<br> 
<TEXTAREA NAME="comment" ROWS=10 COLS=60></TEXTAREA><br></p>

<input type="submit" value="Review Movie">
</form>

<?php
$movie = $_POST['movie'];
$name = $_POST['name'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];
if (!isset($movie, $name, $rating, $comment) OR $movie == NULL OR $name == NULL OR $rating == NULL OR $comment == NULL) {	//check if paramters were passed
	echo "<br><h1>Please provide input.</h1>";
	include ('footer.php');
	exit;
}

$rs=mysql_query("SELECT NOW()") or die(mysql_error());
$time=mysql_result($rs, 0, "NOW()");

//echo $name." ".$time." ".$movie." ".$rating." ".$comment;

mysql_query("INSERT INTO Review VALUES('$name', '$time', '$movie', '$rating', '$comment')") or die(mysql_error());
mysql_close($db_connection);

echo "<br><h1>Review saved!</h1>";
?>
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>