<html>
<title>Search</title>
<body>

<form action="search.php" method="post">
<INPUT TYPE="text" NAME="search" SIZE=20 MAXLENGTH=50>
<input type="submit" value="Search">
</form>

<?php
$search = $_POST['search'];

if (!isset($search)) {	//check if paramters were passed
	echo "Please enter a search term.";
	exit;
}

$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$query1 = "SELECT id, first, last FROM Actor WHERE first LIKE '%$search%' OR last LIKE '%$search%'";
$actors=mysql_query($query1, $db_connection) or die(mysql_error());
$query2 = "SELECT id, title FROM Movie WHERE title LIKE '%$search%'";
$movies=mysql_query($query2, $db_connection) or die(mysql_error());

echo "<h1>Pulling results from Actor database...</h1><br>";
if (mysql_num_rows($actors) == 0) {
	echo "<b>No results.</b><br>";
}
else {
	$i=0;
	while ($row = mysql_fetch_row($actors)) {
		$id=mysql_result($actors, $i, "id");
		$first=mysql_result($actors, $i, "first");
		$last=mysql_result($actors, $i, "last");
		echo '<a href="/~cs143/showactor.php?actor='.$id.'">'.$first.' '.$last.'</a><br>';
		$i++;
	}
}

echo "<br><h1>Pulling results from Movie database...</h1><br>";
if (mysql_num_rows($movies) == 0) {
	echo "<b>No results.</b><br>";
}
else {
	$i=0;
	while ($row = mysql_fetch_row($movies)) {
		$id=mysql_result($movies, $i, "id");
		$title=mysql_result($movies, $i, "title");
		echo '<a href="/~cs143/showmovie.php?movie='.$id.'">'.$title.'</a><br>';
		$i++;
	}
}


?>

</body>
</html>