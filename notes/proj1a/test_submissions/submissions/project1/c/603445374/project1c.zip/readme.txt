Jonathan B. Lee
603445374
jobolee@gmail.com

I was able to finish all 3 input pages, both browsing pages, and the search page. I added 1 extra input page where an actor is added to a movie.
I tried to make the site as visually pleasing as possible by utilizing CSS and XHTML. I also created a custom logo in Photoshop.
I tried emulating a Web 2.0 feel, and even gave it a cliche company name Filmr, which is similar to Flickr.
Overall, I have never had so much fun doing a CS project! I just wish we had more time. I wanted to explore other options like Javascript and making my forms prettier.