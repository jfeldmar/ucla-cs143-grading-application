<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr - View Actor Info</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">
	
			<h1>View an actor's information</h1><br>
<?php
$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$query="SELECT last, first, id FROM Actor";
$result = mysql_query ($query);
?>

<form action="showactor.php" method="post">
<select name="actor">
<?php
while($nt=mysql_fetch_array($result)) {
	echo "<option value='$nt[id]'>$nt[last], $nt[first]</option>";	//populate dropdown menu with data
}
?>
</select>
<input type="submit" value="View Actor">
</form>

<?php
$actor = $_REQUEST['actor'];

if (!isset($actor)) {	//check if a parameter was passed
	include ('footer.php');
	exit;
}

//pull all info from databases
$query2="SELECT * FROM Actor WHERE id=$actor";
$result = mysql_query($query2, $db_connection);
$query3="SELECT M.id, M.title, MA.role FROM MovieActor MA, Movie M WHERE MA.aid=$actor AND M.id=MA.mid";
$result2 = mysql_query($query3, $db_connection);
mysql_close($db_connection);	//close database connection

//output actor info
echo "<br><h1>Actor Info</h1><br>";
$first=mysql_result($result, 0, "first");
$last=mysql_result($result, 0, "last");
$sex=mysql_result($result, 0, "sex");
$dob=mysql_result($result, 0, "dob");
$dod=mysql_result($result, 0, "dod");
echo "<b>Name:</b> " . $first . " " . $last . "<br>";
echo "<b>Sex:</b> " . $sex . "<br>";
echo "<b>Date of birth:</b> " . $dob . "<br>";
if ($dod == NULL) {
	echo "<b>Date of death:</b> Still Breathing";
}
else {
	echo "<b>Date of death:</b> " . $dod;
}

//output filmography
echo "<br><br><h1>Filmography</h1><br>";
if (mysql_num_rows($result2) == 0) {	//check to see if actor has been in any movies
	echo "<h2>Has not appeared in any movies.</h2>";	//if not, say so
}
else {	//has appeared in movies, so output data
	echo "<table border='0'>\n<tr>";	//create table
	for ($i=1; $i < 3; $i++) {
		echo '<th align="center">'.mysql_field_name($result2, $i).'</th>';	//output field names
	}
	echo "</tr>\n";
	$i=0;
	while ($row = mysql_fetch_row($result2)) {	//output data
		$id=mysql_result($result2, $i, "id");
		$title=mysql_result($result2, $i, "title");
		$role=mysql_result($result2, $i, "role");
		echo '<tr align="center"><td><a href="/~cs143/showmovie.php?movie='.$id.'">'.$title.'</a></td><td>'.$role.'</td></tr>';
		$i++;
	}
	echo "</table>\n";
}
	
?>
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>