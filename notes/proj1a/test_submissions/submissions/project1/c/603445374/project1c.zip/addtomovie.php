<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr - Add Actor/Director</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">
		<?php
		$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
		if(!$db_connection) {
		    $errmsg = mysql_error($db_connection);
		    print "Connection failed:" . $errmsg . "<br />";
		    exit(1);
		}
		mysql_select_db("CS143", $db_connection);	//database selection

		$query="SELECT id, title, year FROM Movie";
		$result = mysql_query ($query);
		$query2="SELECT id, last, first FROM Actor";
		$result2 = mysql_query ($query2);
		?>

		<form action="addtomovie.php" method="post">
		<br><h1>Add actor:</h1>
		<select name="actor">
		<?php
		while($nt=mysql_fetch_array($result2)) {
			echo "<option value='$nt[id]'>$nt[last], $nt[first]</option>";	//populate dropdown menu with data
		}
		?>
		</select>
		<br><h1>To movie:</h1>
		<select name="movie">
		<?php
		while($nt=mysql_fetch_array($result)) {
			echo "<option value='$nt[id]'>$nt[title] ($nt[year])</option>";	//populate dropdown menu with data
		}
		?>
		</select>
		<h1>Role:</h1><INPUT TYPE="text" NAME="role" SIZE=50 MAXLENGTH=50><br>
		<input type="submit" value="ADD">
		</form>
		
		<?php
		$actor = $_POST['actor'];
		$movie = $_POST['movie'];
		$role = $_POST['role'];
		
		if (!isset($actor, $movie, $role) OR $role==NULL) {	//check if paramters were passed
			echo "<br><h1>Please provide input.</h1>";
			include ('footer.php');
			exit;
		}
		
		mysql_query("INSERT INTO MovieActor VALUES('$movie', '$actor', '$role')") or die(mysql_error());
		mysql_close($db_connection);
		
		echo "<br><h1>Actor added to movie!</h1>";
		
		?>
		
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>