<html>
<title>Add Movie Review</title>
<body>
<b>Review a movie:</b><br>

<?php
$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed:" . $errmsg . "<br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);	//database selection

$query="SELECT id, title, year FROM Movie";
$result = mysql_query($query);
?>

<form action="comment.php" method="post">
Select movie:
<select name="movie">
<?php
while($nt=mysql_fetch_array($result)) {
	echo "<option value='$nt[id]'>$nt[title] ($nt[year])</option>";	//populate dropdown menu with data
}
?>
</select>

<input type="submit" value="View Movie">
</form>

<?php

if (!isset()) {	//check if paramters were passed
	echo "Not all necessary parameters were passed";
	exit;
}

mysql_query("INSERT INTO Actor VALUES('$id', '$last', '$first', '$sex', '$dob', '$dod')") or die(mysql_error());	//if dod was filled out


mysql_close($db_connection);

echo "Review saved!";
?>

</body>
</html>