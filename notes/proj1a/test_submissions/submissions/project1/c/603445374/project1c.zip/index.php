<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<title>Filmr</title>
	<meta http-equiv="Content-Language" content="en-us" />
	
	<meta http-equiv="imagetoolbar" content="no" />
	<meta name="MSSmartTagsPreventParsing" content="true" />
	
	<meta name="description" content="Description" />
	<meta name="keywords" content="Keywords" />
	
	<meta name="author" content="Jono" />
	
	<style type="text/css" media="all">@import "css/master.css";</style>
</head>

<body>
<div id="page-container">
	<div id="header">
	<a href="index.php"><span>filmr.com</a>
	</div>
	<div id="nav">
		<ul id="nav">
		<li><a href="addactor.php">Add Actor/Director</a></li>
		<li><a href="addmovie.php">Add Movie</a></li>
		<li><a href="review.php">Add Movie Review</a></li>
		<li><a href="addtomovie.php">Add Actor To Movie</a></li>
		<li><a href="showactor.php">View Actor Info</a></li>
		<li><a href="showmovie.php">View Movie Info</a></li>
		</ul>
	</div>
	<div id="content">
		<form action="index.php" method="post" align="middle">
		<INPUT TYPE="text" NAME="search" SIZE=20 MAXLENGTH=50>
		<input type="submit" value="Search">
		</form>


		<?php
		$search = $_POST['search'];

		if (!isset($search) OR $search==NULL) {	//check if paramters were passed
			echo "<br><h1>Please enter a search term.</h1>";
			include ('footer.php');
			exit;
		}

		$db_connection = mysql_connect("localhost", "cs143", "");	//connect to sql server
		if(!$db_connection) {
		    $errmsg = mysql_error($db_connection);
		    print "Connection failed:" . $errmsg . "<br />";
		    exit(1);
		}
		mysql_select_db("CS143", $db_connection);	//database selection

		$query1 = "SELECT id, first, last FROM Actor WHERE first LIKE '%$search%' OR last LIKE '%$search%'";
		$actors=mysql_query($query1, $db_connection) or die(mysql_error());
		$query2 = "SELECT id, title FROM Movie WHERE title LIKE '%$search%'";
		$movies=mysql_query($query2, $db_connection) or die(mysql_error());

		echo "<br><h1>Pulling results from Actor database...</h1><br>";
		if (mysql_num_rows($actors) == 0) {
			echo "<b>No results.</b><br>";
		}
		else {
			$i=0;
			while ($row = mysql_fetch_row($actors)) {
				$id=mysql_result($actors, $i, "id");
				$first=mysql_result($actors, $i, "first");
				$last=mysql_result($actors, $i, "last");
				echo '<a href="/~cs143/showactor.php?actor='.$id.'">'.$first.' '.$last.'</a><br>';
				$i++;
			}
		}

		echo "<br><h1>Pulling results from Movie database...</h1><br>";
		if (mysql_num_rows($movies) == 0) {
			echo "<b>No results.</b><br>";
		}
		else {
			$i=0;
			while ($row = mysql_fetch_row($movies)) {
				$id=mysql_result($movies, $i, "id");
				$title=mysql_result($movies, $i, "title");
				echo '<a href="/~cs143/showmovie.php?movie='.$id.'">'.$title.'</a><br>';
				$i++;
			}
		}
		?>
	</div>
	<div id="footer">
		Copyright &copy; Filmr Inc. Designed and coded by Jono.
	</div>
</div>
</body>
</html>
