<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="3" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="3" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="3" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="1" align="left" width="217" valign="top">
    										<div id="headingArea"><span class="pageHeader01">Add Movie</span></div>
  										</td>
										<td align="right" valign='top'>
											<a href="movies.php"><img src="saveButn.png"/></a>	
										</td>
										<td align="right" width="80">
											<a href="movies.php"><img src="cancelButn.png"/></a>
  										</td>
									</tr>							
									<tr>
  										<td colspan="3" width="834" height="2" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="3" width="834" align="center" valign="middle">

											<?php
												// Establishing a connection to the database system
												$db_connection = mysql_connect("localhost", "cs143", "");
												if(!$db_connection) {
													$errmsg = mysql_error($db_connection);
													print "Connection failed: $errmsg <br />";
													exit(1);
												}
			
												// Select the CS143 database
												mysql_select_db("CS143", $db_connection);
												
												$movie_id = -1;
												
												// If we just arrived at this page from add_movie_1.php then add
												// the movie to the database
												if($_POST['continue']) {
													// Get form data
													$title=mysql_real_escape_string($_POST['title'], $db_connection);
													$year=mysql_real_escape_string($_POST['year'], $db_connection);
													$rating=mysql_real_escape_string($_POST['rating'], $db_connection);
													$company=mysql_real_escape_string($_POST['company'], $db_connection);
													
													// Make query to get max movie id
													$query = "SELECT id FROM MaxMovieID";
													
													// Get resource containing the results of the query
													$rs = mysql_query($query, $db_connection);
													
													// Get max id
													$row = mysql_fetch_row($rs);
													$movie_id = $row[0] + 1;
													
													//Store new max id value
													$query = "UPDATE MaxMovieID SET id = $movie_id;";
													mysql_query($query, $db_connection);
													
													// Insert new movie
													$query = "INSERT INTO Movie VALUES ($movie_id, '$title', $year, '$rating', '$company');";
													mysql_query($query, $db_connection);
												}
												
												// Close connection to the database
												mysql_close($db_connection);
											?>
											
											<form method='GET'>
											<table cellpadding="0" cellspacing="0" width="814" border="0">
												<tr>
													<td colspan="2" bgcolor="#FFFFFF"><img src="transp.png" /></td>
												</tr>
												<tr>
													<td colspan="2" height="8"><img src="transp.png" /></td>
												</tr>
												<tr>
													<td height="18" colspan="2" valign="middle"><span class="pageHeader02">GENRES</span></td>
												</tr>
												<tr>
													<td colspan="2" height="8"><img src="transp.png" /></td>
												</tr>
												<tr>
													<td bgcolor="2F3E4C" width='250'>
														&nbsp;&nbsp;<span class="fieldLabel">ADD GENRE:</span>&nbsp;&nbsp;&nbsp;
														<select name='genre'>
															<option>Action</option>
															<option>Adult</option>
															<option>Adventure</option>
															<option>Animation</option>
															<option>Comedy</option>
															<option>Crime</option>
															<option>Documentary</option>
															<option>Drama</option>
															<option>Family</option>
															<option>Fantasy</option>
															<option>Horror</option>
															<option>Musical</option>
															<option>Mystery</option>
															<option>Romance</option>
															<option>Sci-Fi</option>
															<option>Short</option>
															<option>Thriller</option>
															<option>War</option>
															<option>Western</option>																												
														</select>
													</td>
													<td bgcolor="2F3E4C">
														<input type="image" src="addButn.png"/>
													</td>
												</tr>
												<tr>
													<td colspan="2" height="8"><img src="transp.png" /></td>
												</tr>
												<?php
													// Establishing a connection to the database system
													$db_connection = mysql_connect("localhost", "cs143", "");
													if(!$db_connection) {
														$errmsg = mysql_error($db_connection);
														print "Connection failed: $errmsg <br />";
														exit(1);
													}
			
													// Select the CS143 database
													mysql_select_db("CS143", $db_connection);

													// Get movie id
													$query = "SELECT id FROM MaxMovieID";
													$rs = mysql_query($query, $db_connection);
													$row = mysql_fetch_row($rs);
													$movie_id = $row[0];

													// Add new genre
													$genre = $_GET['genre'];
													if($genre) {
														$query = "INSERT INTO MovieGenre VALUES ($movie_id, '$genre');";
														mysql_query($query, $db_connection);
													}
													
													// Make query to get genres
													$query = "SELECT * FROM MovieGenre WHERE mid=$movie_id;";
													
													// Get resource containing the results of the query
													$rs = mysql_query($query, $db_connection);
												
													// Display genre info
													$genres = '';
													while($row = mysql_fetch_row($rs)) {
														if($genres != '') {
															$genres = $genres.', '.$row[1];
														} else {
															$genres = $row[1];
														}
													}
													
													echo "<tr><td colspan='2' align='left'>\n";
													echo "	<span class='pageHeader02'>current genres:</span>&nbsp;&nbsp;&nbsp;<span class='colData'>$genres</span>\n";	
													echo "</td></tr>\n";

													// Close connection to the database
													mysql_close($db_connection);
												?>
												<tr>
													<td colspan="2" height="8"><img src="transp.png" /></td>
												</tr>
											</table>
											</form>

											<?php
												// Establishing a connection to the database system
												$db_connection = mysql_connect("localhost", "cs143", "");
												if(!$db_connection) {
													$errmsg = mysql_error($db_connection);
													print "Connection failed: $errmsg <br />";
													exit(1);
												}
	
												// Select the CS143 database
												mysql_select_db("CS143", $db_connection);

												// Get movie id
												$query = "SELECT id FROM MaxMovieID";
												$rs = mysql_query($query, $db_connection);
												$row = mysql_fetch_row($rs);
												$movie_id = $row[0];

												// Add new actor
												$aid = $_GET['aid'];
												$role = $_GET['role'];
												if($aid) {
													$query = "INSERT INTO MovieActor VALUES ($movie_id, $aid, '$role');";
													mysql_query($query, $db_connection);
												}

												echo "<form method='GET'>\n";
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2'><span class='pageHeader02'>ACTORS</span></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td bgcolor='2F3E4C' width='600'>\n";
												echo "		&nbsp;&nbsp;<span class='fieldLabel'>ADD ACTORS:</span>&nbsp;&nbsp;&nbsp;\n";
												echo "		<select name='aid'>\n";
												
												$query = "SELECT * FROM Actor;";
												$rs = mysql_query($query, $db_connection);
												while($row = mysql_fetch_row($rs)) {
													$aid = $row[0];
													$last = $row[1];
													$first = $row[2];
													echo "			<option value='$aid'>$last, $first</option>\n";
												}

												echo "		</select>&nbsp;&nbsp;&nbsp;\n";
												echo "		<span class='fieldLabel'>ROLE</span>&nbsp;&nbsp;&nbsp;\n";
												echo "		<input name='role' value='' class='textBox'>&nbsp;&nbsp;&nbsp;\n";
												echo "		</td>\n";
												echo "		<td bgcolor='2F3E4C'>\n";
												echo "			<input type='image' src='addButn.png'/>\n";
												echo "	</td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' align='center'>\n";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr>\n";
												echo "				<td><span class='colHead'>LAST NAME</span></td>\n";
												echo "				<td><span class='colHead'>FIRST NAME</span></td>\n";
												echo "				<td><span class='colHead'>ROLE</span></td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												
												$query = "SELECT last, first, role FROM MovieActor, Actor where MovieActor.aid = Actor.id AND mid=$movie_id;";
												$rs = mysql_query($query, $db_connection);
												while($row = mysql_fetch_row($rs)) {
													$last = $row[0];
													$first = $row[1];
													$role = $row[2];
													echo "			<tr>\n";
													echo "				<td><span class='colData'>$last</span></td>\n";
													echo "				<td><span class='colData'>$first</span></td>\n";
													echo "				<td><span class='colData'>$role</span></td>\n";
													echo "			</tr>\n";
													echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												}
												
												echo "		</table>\n";
												echo "	</td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "</table>\n";
												echo "</form>\n";
												
												// Add new director
												$did = $_GET['did'];
												if($did) {
													$query = "INSERT INTO MovieDirector VALUES ($movie_id, $did);";
													mysql_query($query, $db_connection);
												}												

												echo "<form method='GET'>\n";
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2'><span class='pageHeader02'>DIRECTORS</span></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td bgcolor='2F3E4C' width='400'>\n";
												echo "		&nbsp;&nbsp;<span class='fieldLabel'>ADD DIRECTORS:</span>&nbsp;&nbsp;&nbsp;\n";
												echo "		<select name='did'>\n";

												$query = "SELECT * FROM Director;";
												$rs = mysql_query($query, $db_connection);
												while($row = mysql_fetch_row($rs)) {
													$did = $row[0];
													$last = $row[1];
													$first = $row[2];
													echo "			<option value='$did'>$last, $first</option>\n";
												}												
												
												echo "		</select>&nbsp;&nbsp;&nbsp;\n";
												echo "		</td>\n";
												echo "		<td bgcolor='2F3E4C'>\n";
												echo "			<input type='image' src='addButn.png'/>\n";
												echo "	</td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' align='center'>\n";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr>\n";
												echo "				<td><span class='colHead'>LAST NAME</span></td>\n";
												echo "				<td><span class='colHead'>FIRST NAME</span></td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												
												$query = "SELECT last, first FROM MovieDirector, Director where MovieDirector.did = Director.id AND mid=$movie_id;";
												$rs = mysql_query($query, $db_connection);
												while($row = mysql_fetch_row($rs)) {
													$last = $row[0];
													$first = $row[1];
													echo "			<tr>\n";
													echo "				<td><span class='colData'>$last</span></td>\n";
													echo "				<td><span class='colData'>$first</span></td>\n";
													echo "			</tr>\n";
													echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												}												
												
												echo "		</table>\n";
												echo "	</td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "</table>\n";
												echo "</form>\n";											
												
												// Close connection to the database
												mysql_close($db_connection);
											?>		
    									</td>
    								</tr>
              						<tr>
                						<td colspan="3" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>