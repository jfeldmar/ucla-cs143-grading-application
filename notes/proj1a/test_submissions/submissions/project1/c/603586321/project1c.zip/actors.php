<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">
            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="3" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="3" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="3" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>								
                					<tr>
  										<td>
											<div id="headingArea">
												<span class="pageHeader01">Actors</span>
											</div>
										</td>
										<td align="right" valign='top'>
											<a href="add_actor.php"><img src="addButn.png"/></a>						
										</td>
										<td align="right" width="220">
											<form method="GET">
												<input name="search" value="" class="searchBox">&nbsp;&nbsp;
												<input type="image" src="searchButtn.png"/>
											</form>
  										</td>
									</tr>
									<tr>
  										<td colspan="3" width="834" height="2" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="3" width="834" align="center" valign="middle">
											<table cellpadding="0" cellspacing="0" width="814" border="0">
												<tr>
													<td height="18" valign="middle"><span class="colHead">LAST NAME</span></td>
													<td height="18" valign="middle"><span class="colHead">FIRST NAME</span></td>
													<td height="18" valign="middle"><span class="colHead">SEX</span></td>
													<td height="18" valign="middle"><span class="colHead">DOB</span></td>
													<td height="18" valign="middle"><span class="colHead">DOD</span></td>
													<td height="18" valign="middle" align="right"><span class="colHead">VIEW</span></td>
												</tr>
												<tr>
													<td colspan="8" bgcolor="#333333"><img src="transp.png" /></td>
												</tr>
												<?php
													// Establishing a connection to the database system
													$db_connection = mysql_connect("localhost", "cs143", "");
													if(!$db_connection) {
														$errmsg = mysql_error($db_connection);
														print "Connection failed: $errmsg <br />";
														exit(1);
													}
				
													// Select the CS143 database
													mysql_select_db("CS143", $db_connection);

													// Add new actor
													if($_POST["save"]) {
														// Get form data
														$last=mysql_real_escape_string($_POST['last'], $db_connection);
														$first=mysql_real_escape_string($_POST['first'], $db_connection);
														$sex=mysql_real_escape_string($_POST['sex'], $db_connection);
														$dob=mysql_real_escape_string($_POST['dob'], $db_connection);
														$dod=mysql_real_escape_string($_POST['dod'], $db_connection);
														
														// Make query to get max person id
														$query = "SELECT id FROM MaxPersonID";
													
														// Get resource containing the results of the query
														$rs = mysql_query($query, $db_connection);
													
														// Get max id
														$row = mysql_fetch_row($rs);
														$actor_id = $row[0] + 1;
													
														//Store new max id value
														$query = "UPDATE MaxPersonID SET id = $actor_id;";
														mysql_query($query, $db_connection);
													
														// Insert new actor
														if(!$dod) {
															$query = "INSERT INTO Actor VALUES ($actor_id, '$last', '$first', '$sex', '$dob', NULL);";
														} else {
															$query = "INSERT INTO Actor VALUES ($actor_id, '$last', '$first', '$sex', '$dob', '$dod');";
														}
														mysql_query($query, $db_connection);
													}
													
													// Get start index for table
													$start_index = $_GET["start_index"];
													if(!$start_index) {
														$start_index = 0;
													}
													
													// Get the search results
													$search = mysql_real_escape_string($_GET["search"], $db_connection);
													
													// Create query string
													if($search) {
														$query = "SELECT * FROM Actor WHERE last LIKE '%$search%' OR first LIKE '%$search%' ORDER BY last ASC LIMIT $start_index, 20";
													} else {
														$query = "SELECT * FROM Actor ORDER BY last ASC LIMIT $start_index, 20";
													}	
														
													// Get resource containing the results of the query
													$rs = mysql_query($query, $db_connection);
																
													// Display tuples
													while($row = mysql_fetch_row($rs)) {
														echo "	<tr>\n";
														$aid = $row[0];
														$last = $row[1];
    													$first = $row[2];
    													$sex = $row[3];
    													$dob = $row[4];
    													$dod = $row[5];
														
														echo "		<td height='18' valign='middle'><span class='colData'>$last</span></td>\n";
														echo "		<td height='18' valign='middle'><span class='colData'>$first</span></td>\n";
														echo "		<td height='18' valign='middle'><span class='colData'>$sex</span></td>\n";
														echo "		<td height='18' valign='middle'><span class='colData'>$dob</span></td>\n";
														echo "		<td height='18' valign='middle'><span class='colData'>$dod</span></td>\n";
														echo "		<td height='18' valign='middle' align='right'><a href='view_actor.php?id=$aid'><img src='viewButn.png' /></a></td>\n";																																										
														echo "	</tr>\n";
														echo "	<tr>\n";
														echo "		<td colspan='8' bgcolor='#333333'><img src='transp.png' /></td>\n";
														echo "	</tr>\n";
													}				
													$next_index = $start_index+20;
													$prev_index = max($start_index-20,0);
													$search_url = '';
													if($search) {
														$search_url = "&search=$search";
													}
													echo "	<tr>\n";
													echo "		<td colspan='1' align='left'><a href='actors.php?start_index=".$prev_index.$search_url."'>&lt;&lt;Prev</a></td>\n";
													echo "		<td colspan='8' align='right'><a href='actors.php?start_index=".$next_index.$search_url."'>Next&gt;&gt;</a></td>\n";
													echo "	</tr>\n";
													
													// Close connection to the database
													mysql_close($db_connection);												
												?>
											</table>
  										</td>
									</tr>
              						<tr>
                						<td colspan="3" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>