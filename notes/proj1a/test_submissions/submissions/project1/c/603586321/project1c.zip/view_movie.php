<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">
            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="3" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="2" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="2" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>

									<tr>
  										<td colspan="1" align="left" width="217" valign="top">
    										<div id="headingArea"><span class="pageHeader01">View Movie</span></div>
  										</td>
  										<td colspan="1" align="right" width="617" valign="middle">
      										<a href="movies.php"><img src="cancelButn.png"/></a>
  										</td>
									</tr>
									<tr>
  										<td colspan="2" width="834" height="2" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="2" width="834" align="center" valign="middle">

											<?php
												// Establishing a connection to the database system
												$db_connection = mysql_connect("localhost", "cs143", "");
												if(!$db_connection) {
													$errmsg = mysql_error($db_connection);
													print "Connection failed: $errmsg <br />";
													exit(1);
												}
			
												// Select the CS143 database
												mysql_select_db("CS143", $db_connection);
												
												// Create query for movie
												$movie_id = $_GET["id"];
												$query = "SELECT * FROM Movie WHERE id = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);
															
												// Display movie info
												$row = mysql_fetch_row($rs);
												$title = $row[1];
    											$year = $row[2];
    											$rating = $row[3];
    											$company = $row[4];
    											
    											echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
    											echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>TITLE</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$title</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
      											echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>YEAR</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$year</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>MPAA RATING</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$rating</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
      											echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>PRODUCTION COMPANY</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$company</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "</table>\n";
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
  												
												// Create query for movie genre
												$query = "SELECT * FROM MovieGenre WHERE mid = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);
															
												// Display genre info
												$genres = '';
												while($row = mysql_fetch_row($rs)) {
													if($genres != '') {
														$genres = $genres.', '.$row[1];
													} else {
														$genres = $row[1];
													}
												}
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td valign='middle'>\n";
												echo "		<span class='colHead'>GENRES</span>&nbsp;&nbsp;&nbsp;<span class='colData'>$genres</span>\n";	
												echo "	</tr></td>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";		
												echo "</table>\n";
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
												
												// Create query for movie actors
												$query = "SELECT * FROM MovieActor WHERE mid = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);													
												
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
												echo "		<td colspan='2' valign='middle'><span class='pageHeader02'>ACTORS</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' align='center'>\n";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr>\n";
												echo "				<td><span class='colHead'>LAST NAME</span></td>\n";
												echo "				<td><span class='colHead'>FIRST NAME</span></td>\n";
												echo "				<td><span class='colHead'>ROLE</span></td>\n";
												echo "				<td><span class='colHead'>SEX</span></td>\n";
												echo "				<td><span class='colHead'>DOB</span></td>\n";
												echo "				<td><span class='colHead'>DOD</span></td>\n";
												echo "				<td align='right'><span class='colHead'>VIEW</span></td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												while($row = mysql_fetch_row($rs)) {
													$aid = $row[1];
													$role = $row[2];
													
													// Create query for actor
													$query = "SELECT * FROM Actor WHERE id = $aid";
												
													// Get resource containing the results of the query
													$rs2 = mysql_query($query, $db_connection);
															
													// Display actor info
													$row2 = mysql_fetch_row($rs2);
													$last = $row2[1];
    												$first = $row2[2];
    												$sex = $row2[3];
    												$dob = $row2[4];
    												$dod = $row2[5];
													
													echo "			<tr>\n";
													echo "				<td><span class='colData'>$last</span></td>\n";
													echo "				<td><span class='colData'>$first</span></td>\n";
													echo "				<td><span class='colData'>$role</span></td>\n";
													echo "				<td><span class='colData'>$sex</span></td>\n";
													echo "				<td><span class='colData'>$dob</span></td>\n";
													echo "				<td><span class='colData'>$dod</span></td>\n";
													echo "				<td align='right'><a href='view_actor.php?id=$aid'><img src='viewButn.png' /></a></td>\n";
													echo "			</tr>\n";
													echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";														
												}
												echo "			<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "		</table>\n";
												echo "	</td></tr>\n";
												echo "</table>\n";
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
												
												// Create query for movie directors
												$query = "SELECT * FROM MovieDirector WHERE mid = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);													
												
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
												echo "		<td colspan='2' valign='middle'><span class='pageHeader02'>DIRECTORS</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' align='center'>\n";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr>\n";
												echo "				<td><span class='colHead'>LAST NAME</span></td>\n";
												echo "				<td><span class='colHead'>FIRST NAME</span></td>\n";
												echo "				<td><span class='colHead'>DOB</span></td>\n";
												echo "				<td><span class='colHead'>DOD</span></td>\n";
												echo "				<td align='right'><span class='colHead'>VIEW</span></td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												while($row = mysql_fetch_row($rs)) {
													$did = $row[1];
													
													// Create query for actor
													$query = "SELECT * FROM Director WHERE id = $did";
												
													// Get resource containing the results of the query
													$rs2 = mysql_query($query, $db_connection);
															
													// Display actor info
													$row2 = mysql_fetch_row($rs2);
													$last = $row2[1];
    												$first = $row2[2];
    												$dob = $row2[3];
    												$dod = $row2[4];
													
													echo "			<tr>\n";
													echo "				<td><span class='colData'>$last</span></td>\n";
													echo "				<td><span class='colData'>$first</span></td>\n";
													echo "				<td><span class='colData'>$dob</span></td>\n";
													echo "				<td><span class='colData'>$dod</span></td>\n";
													echo "				<td align='right'><a href='view_director.php?id=$did'><img src='viewButn.png' /></a></td>\n";
													echo "			</tr>\n";
													echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";														
												}
												echo "			<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "		</table>\n";
												echo "	</td></tr>\n";
												echo "</table>\n";												
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";

												// Review	
												if($_POST['submit_x'] || $_POST['submit_y']) {
													$name=mysql_real_escape_string($_POST['name'], $db_connection);
													$rating=mysql_real_escape_string($_POST['rating'], $db_connection);
													$comment=mysql_real_escape_string($_POST['comment'], $db_connection);
													
													// Create insert query
													$query = "INSERT INTO Review values('$name', current_timestamp, $movie_id, $rating, '$comment');";
													// Submit query
													mysql_query($query, $db_connection);
												}
												
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
												echo "		<td colspan='2' valign='middle'><span class='pageHeader02'>USER REVIEWS</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' bgcolor='2F3E4C'>\n";
												echo "		<form action='view_movie.php?id=$movie_id' method='POST'>";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												echo "			<tr><td colspan='8' height='8'><img src='transp.png' /></td></tr>\n";
												echo "			<tr>\n";
												echo "				<td>\n";
												echo "					<span class='fieldLabel'>&nbsp;&nbsp;NAME</span>\n";
												echo "				</td>\n";
												echo "				<td>\n";
												echo "					<input name='name' value='' class='textBox'>\n";
												echo "				</td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' height='8'><img src='transp.png' /></td></tr>\n";
												echo "			<tr>\n";
												echo "				<td>\n";
												echo "					<span class='fieldLabel'>&nbsp;&nbsp;RATING</span>\n";
												echo "				</td>\n";
												echo "				<td>\n";
												echo "					<select name='rating'>\n";
												echo "						<option value='5'>5 - Excellent!</option>\n";
												echo "						<option value='4'>4 - Good</option>\n";
												echo "						<option value='3'>3 - OK</option>\n";
												echo "						<option value='2'>2 - Not Worth</option>\n";
												echo "						<option value='1'>1 - Hate It!</option>\n";
												echo "					</select>\n";
												echo "				</td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' height='8'><img src='transp.png' /></td></tr>\n";
												echo "			<tr>\n";
												echo "				<td>\n";
												echo "					<span class='fieldLabel'>&nbsp;&nbsp;COMMENTS</span>\n";
												echo "				</td>\n";
												echo "				<td>\n";
												echo "					<textarea name='comment' rows='5' cols='50' class='textArea'></textarea>\n";
												echo "				</td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' height='8'><img src='transp.png' /></td></tr>\n";
												echo "			<tr>\n";
												echo "				<td></td>\n";
												echo "				<td>\n";
												echo "					<input type='image' name='submit' src='addButn.png'/>\n";
												echo "				</td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' height='8'><img src='transp.png' /></td></tr>\n";
												echo "		</table>\n";
												echo "		</form>\n";
												echo "	</tr></td>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												
												// Create query for average rating
												$query = "SELECT AVG(rating), count(rating) FROM Review WHERE mid = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);
												
												// Get average rating
												$row = mysql_fetch_row($rs);
												$avg_rating = $row[0];
												if(!$avg_rating) {
													$avg_rating = 'N/A';
												}
												$rating_count = $row[1];
												if(!$rating_count) {
													$rating_count = 0;
												}												
												
												echo "	<tr>\n";
												echo "		<td colspan='2'>\n";
												echo "			<span class='pageHeader02'>AVERAGE SCORE: $avg_rating/5 ($rating_count VOTES)</span>\n";
												echo "		</td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												
												// Create query for reviews
												$query = "SELECT * FROM Review WHERE mid = $movie_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);
															
												// Display movie info
												while($row = mysql_fetch_row($rs)) {
													$name = $row[0];
    												$time = $row[1];
    												$rating = $row[3];
    												$comment = $row[4];	
 													echo "	<tr>\n";
													echo "		<td colspan='2'>\n";
													echo "			<span class='colHead'>On $time $name gave this movie a rating of $rating/5 and said:</span>\n";
													echo "		</td>\n";
													echo "	</tr>\n";
													echo "	<tr>\n";
													echo "		<td colspan='2'>\n";
													echo "			<span class='colData'>$comment</span>\n";
													echo "		</td>\n";
													echo "	</tr>\n";
													echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
													echo "	<tr><td colspan='2' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";   												
												}																										
												echo "</table>\n";	
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
																																																
												// Close connection to the database
												mysql_close($db_connection);												
											?>
											
    									</td>
    								</tr>
              						<tr>
                						<td colspan="2" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>