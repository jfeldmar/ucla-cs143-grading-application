<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">
            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="2" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="2" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="2" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>
                					<tr>
  										<td colspan="1" width="417">
    										<div id="mktgText">
      											Welcome to
      											<br />Javier's Movie Database!
												<br />
												<span class="subText">
												<br />You can use JMDB to add
												<br />movies, actors, and directors
												<br />to the database.
												<br /><br />You can also use JMDB to view
												<br />and search for information on
												<br />movies, actors, and directors.
												</span>
											</div>
  										</td>
  										<td colspan="1" align="center" width="417">
  											<img src="main.jpg" />
  										</td>
									</tr>
              						<tr>
                						<td colspan="2" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>
