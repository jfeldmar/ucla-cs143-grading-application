<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">
            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="3" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="3" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="3" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="1" align="left" width="217" valign="top">
    										<div id="headingArea"><span class="pageHeader01">View Actor</span></div>
  										</td>
  										<td colspan="1" align="right" width="617" valign="middle">
      										<a href="actors.php"><img src="cancelButn.png"/></a>
  										</td>
									</tr>
									<tr>
  										<td colspan="3" width="834" height="2" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="3" width="834" align="center" valign="middle">

											<?php
												// Establishing a connection to the database system
												$db_connection = mysql_connect("localhost", "cs143", "");
												if(!$db_connection) {
													$errmsg = mysql_error($db_connection);
													print "Connection failed: $errmsg <br />";
													exit(1);
												}
			
												// Select the CS143 database
												mysql_select_db("CS143", $db_connection);
												
												// Create query for actor
												$actor_id = $_GET["id"];
												$query = "SELECT * FROM Actor WHERE id = $actor_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);
															
												// Display movie info
												$row = mysql_fetch_row($rs);
												$last = $row[1];
    											$first = $row[2];
    											$sex = $row[3];
    											$dob = $row[4];
    											$dod = $row[5];
    											
    											echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
    											echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>LAST NAME</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$last</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
      											echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>FIRST NAME</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$first</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>SEX</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$sex</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
      											echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>DATE OF BIRTH</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$dob</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
      											echo "	<tr>\n";
        										echo "		<td valign='middle'><span class='fieldLabel'>DATE OF DEATH</span></td>\n";
        										echo "		<td valign='middle'><span class='colData'>$dod</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";												
												echo "</table>\n";
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
  												
												// Create query for movies
												$query = "SELECT * FROM MovieActor WHERE aid = $actor_id";
												
												// Get resource containing the results of the query
												$rs = mysql_query($query, $db_connection);													
												
												echo "<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "	<tr><td colspan='2' bgcolor='#FFFFFF'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr>\n";
												echo "		<td colspan='2' valign='middle'><span class='pageHeader02'>MOVIES</span></td>\n";
												echo "	</tr>\n";
												echo "	<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "	<tr><td colspan='2' align='center'>\n";
												echo "		<table cellpadding='0' cellspacing='0' width='814' border='0'>\n";
												echo "			<tr>\n";
												echo "				<td><span class='colHead'>TITLE</span></td>\n";
												echo "				<td><span class='colHead'>ROLE</span></td>\n";
												echo "				<td><span class='colHead'>YEAR</span></td>\n";
												echo "				<td><span class='colHead'>MPAA RATING</span></td>\n";
												echo "				<td><span class='colHead'>PRODUCTION COMPANY</span></td>\n";
												echo "				<td align='right'><span class='colHead'>VIEW</span></td>\n";
												echo "			</tr>\n";
												echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";
												while($row = mysql_fetch_row($rs)) {
													$mid = $row[0];
													$role = $row[2];
													
													// Create query for actor
													$query = "SELECT * FROM Movie WHERE id = $mid";
												
													// Get resource containing the results of the query
													$rs2 = mysql_query($query, $db_connection);
															
													// Display actor info
													$row2 = mysql_fetch_row($rs2);
													$title = $row2[1];
    												$year = $row2[2];
    												$rating = $row2[3];
    												$company = $row2[4];
													
													echo "			<tr>\n";
													echo "				<td><span class='colData'>$title</span></td>\n";
													echo "				<td><span class='colData'>$role</span></td>\n";
													echo "				<td><span class='colData'>$year</span></td>\n";
													echo "				<td><span class='colData'>$rating</span></td>\n";
													echo "				<td><span class='colData'>$company</span></td>\n";
													echo "				<td align='right'><a href='view_movie.php?id=$mid'><img src='viewButn.png' /></a></td>\n";
													echo "			</tr>\n";
													echo "			<tr><td colspan='8' bgcolor='#333333'><img src='transp.png' /></td></tr>\n";														
												}
												echo "			<tr><td colspan='2' height='8'><img src='transp.png' /></td></tr>\n";
												echo "		</table>\n";
												echo "	</td></tr>\n";
												echo "</table>\n";
												echo "</td>\n";
												echo "</tr>\n";
												echo "<tr>\n";
												echo "<td colspan='2' width='834' align='center' valign='middle'>";
																																																
												// Close connection to the database
												mysql_close($db_connection);												
											?>

    									</td>
    								</tr>
              						<tr>
                						<td colspan="3" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>