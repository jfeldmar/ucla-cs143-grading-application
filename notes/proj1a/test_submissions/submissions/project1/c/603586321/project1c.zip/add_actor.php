<html>
	<head>
		<title>
			JMDB: Javier's Movie Database
		</title>
  		<link href="jmdb_css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<table cellpadding="0" cellspacing="0" border="0" width="100%" height="100%">
  			<tr>
    			<td width="100%" height="100%" valign="top" align="center">
      				<table cellpadding="0" cellspacing="0" width="900" height="100%" border="0" bgcolor="#1A1A1A">
        				<tr>
          					<td width="900" valign="top" align="center">
          						<form action='actors.php' method='POST'>
            					<table cellpadding="0" cellspacing="0" width="834" border="0">
 									<tr>
   										<td colspan="3" width="417" align="left" valign="middle">
   											<br />
   											<div id="logo">
   												<a href="jmdb.php">
   													<img src="logo.png" border="0" />  Javier's Movie Database
   												</a>
   											</div>
   										</td>
 									</tr>
 									<tr>
										<td colspan="3" width="834" height="36" background="mainBarBkg.png" valign="middle">
     										<div id="mainNav">
     											<a href="jmdb.php"> Home</a> | <a href="movies.php"> Movies</a> | <a href="actors.php"> Actors</a> | <a href="directors.php"> Directors</a>
     										</div>
   										</td>
 									</tr>
									<tr>
   										<td colspan="3" width="834" height="10" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="1" align="left" width="217" valign="top">
    										<div id="headingArea"><span class="pageHeader01">Add Actor</span></div>
  										</td>
										<td align="right" valign='top'>
											<input type="image" name='save' value='save' src="saveButn.png"/>
										</td>
										<td align="right" width="80">
											<a href="actors.php"><img src="cancelButn.png"/></a>
  										</td>
									</tr>
									<tr>
  										<td colspan="3" width="834" height="2" valign="middle"><!-- spacer row --><br /></td>
									</tr>
									<tr>
  										<td colspan="3" width="834" align="center" valign="middle">

    										<table cellpadding="0" cellspacing="0" width="814" border="0">
      											<tr>
        											<td colspan="2" bgcolor="#333333"><img src="transp.png" /></td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8"><img src="transp.png" /></td>
      											</tr>
      											<tr>
        											<td height="18" width="80" valign="middle">
        												<span class="fieldLabel">LAST NAME</span>
        											</td>
        											<td height="18" width="734" valign="middle">
														<input name="last" value="" class='textBox'>
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8">
        												<img src="transp.png" />
        											</td>
      											</tr>
      											<tr>
        											<td height="18" width="80" valign="middle">
        												<span class="fieldLabel">FIRST NAME</span>
        											</td>
        											<td height="18" width="734" valign="middle">
														<input name="first" value="" class='textBox'>
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8">
        												<img src="transp.png" />
        											</td>
      											</tr>
      											<tr>
        											<td height="18" width="80" valign="middle">
        												<span class="fieldLabel">SEX</span>
        											</td>
        											<td height="18" width="734" valign="middle">
        												<select name='sex'>
															<option>Male</option>
															<option>Female</option>
														</select>
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8">
        												<img src="transp.png" />
        											</td>
      											</tr>
      											<tr>
        											<td height="18" width="200" valign="middle">
        												<span class="fieldLabel">DATE OF BIRTH (yyyy-mm-dd)</span>
        											</td>
        											<td height="18" width="734" valign="middle">
														<input name="dob" value="" class='textBox'>
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8">
        												<img src="transp.png" />
        											</td>
      											</tr>
       											<tr>
        											<td height="18" width="200" valign="middle">
        												<span class="fieldLabel">DATE OF DEATH (yyyy-mm-dd)</span>
        											</td>
        											<td height="18" width="734" valign="middle">
														<input name="dod" value="" class='textBox'>
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" height="8">
        												<img src="transp.png" />
        											</td>
      											</tr>
      											<tr>
        											<td colspan="2" bgcolor="#333333">
        												<img src="transp.png" />
        											</td>
      											</tr>
      										</table>

    									</td>
    								</tr>
              						<tr>
                						<td colspan="3" width="834" height="10" valign="middle">
                							<img src="transp.png" />
                						</td>
              						</tr>
 	    						</table>
 	    						</form>
          					</td>
        				</tr>
      				</table>
    			</td>
  			</tr>
		</table>
	</body>
</html>