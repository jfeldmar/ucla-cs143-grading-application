<html>
<body>

<form action="addComments.php" method="GET">

<?php

echo '<table border="0" width="100%" cellpadding="10">
<tr>

<td width="20%" valign="top" bgcolor = "0033FF">

<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br />

<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A><br />

<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add
Comments</FONT></A><br />

<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /> <br /><br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />


</td>

<td width="80%" valign="top" bgcolor="CCFF00">';

$x = mysql_connect ("localhost", "cs143", "");

        if (!$x)
        {
                die('Could not connect: ' . mysql_error());
        }
        $db_selected = mysql_select_db("CS143",$x);

	echo'<b><font size="5">Add the Information Below to Add Your Comment: </font><br></b>';

        echo '<b><i>Movie Title: <br /> </b></i>';
        echo '<select name="movie">';
        $query = mysql_query("SELECT title FROM Movie", $x);
        while ($users = mysql_fetch_array($query))
        {
               echo '<option>'.$users[0].'</option>';
        }
               echo '</select> <br /> <br />';

        echo '<b><i>Name: </b></i><input type="TEXT" name="name" value="Anonymous"><br />';

        echo '<b><i>Rating:(5=Excellent & 1=Very Bad) </b></i>';
        echo '<select name="rating">';
        echo '<option>1</option>';
        echo '<option>2</option>';
        echo '<option>3</option>';
        echo '<option>4</option>';
        echo '<option>5</option>';
        echo '</select> <br /> <br />';

        echo '<b><i>Enter your review of the movie below: <br /></b></i>';

         echo '<TEXTAREA Rows = 10 Cols = 60 NAME = "review">
</TEXTAREA> <br />';

        echo '<input type="submit">';

	echo '</form>';

        if(isset($_GET["movie"], $_GET["name"], $_GET["rating"], $_GET["review"]))
        {
                $time = mysql_query("SELECT CURTIME()", $x);
                $timestamp = mysql_fetch_row($time);

                $date = mysql_query("SELECT CURDATE()", $x);
                $datestamp = mysql_fetch_row($date);

                $movie=$_GET["movie"];
                $name=$_GET["name"];
                $rating=$_GET["rating"];
                $review=$_GET["review"];

                $movieid;
                $insertquery = "SELECT * FROM Movie";
                $query = mysql_query($insertquery, $x);
                while ($fetch = mysql_fetch_row($query))
                {
                        if($movie == $fetch[1])
                        {
                                $movieid = $fetch[0];
                        }

                }

                $stamp = $datestamp[0].' '.$timestamp[0];
                $insertquery = "INSERT INTO Review VALUES ('$name', '$stamp', $movieid, $rating, '$review')";
                $query = mysql_query($insertquery, $x);
                if($query)
                {
                        echo "<br /><br /><font color='#FF0000'>Your Review has been submitted successfully!</font>";
                }

        }

mysql_close($x);

echo '
</td>

</tr>
</table>

</body>
</html>';

?>
