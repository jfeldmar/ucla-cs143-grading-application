<html>
<body>

<table border="0" width="100%" cellpadding="10"><tr>

<td width="20%" valign="top" bgcolor="#0033FF">
<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br
 />

<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A>
<br />

<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add Comments</FONT></A>
<br />

<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /><br /> <br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />
</td>

<td width="80%" valign="top" bgcolor="#CCFF00">


<form action="search.php" method="GET">

<?php

	$x = mysql_connect ("localhost", "cs143", "");
        if (!$x)
        {                die('Could not connect: ' . mysql_error());}
        $db_selected = mysql_select_db("CS143", $x);

if((isset($_GET["search"]) || ($_GET["search"] == " ")) && ($_GET["search"] != "  ") && ($_GET["search"] != ""))
{
	echo 'SEARCH AGAIN: <br />';
        echo '<input type="TEXT" name="search" /> <br /> <br />
        <input type="submit" /> <br /> <br />';

	echo "<b><i><font size='4'><u>Results of your Search: </font></i></u></b><br /><br />";	
	$key = $_GET["search"];
	$insertquery = "SELECT * FROM Movie";
        $query = mysql_query($insertquery, $x);
        while ($fetch = mysql_fetch_row($query))
        {
		if(stristr($fetch[1], $key) == TRUE)
		{
			$actoroutput = $fetch[1]. "(".$fetch[2].")";
                        echo "Movie: ";
			$actoroutput2=str_replace("&","%26",$fetch[1]);
			$actoroutput3=str_replace(" ","+",$actoroutput2);
			echo '<A HREF="./showMovie.php?movie='.$actoroutput3.'">'.$actoroutput.'</A> <br />';

		}
	}
	
	$insertquery = "SELECT * FROM Actor";
        $query = mysql_query($insertquery, $x);
	while ($fetch = mysql_fetch_row($query))
        {
                 if(stristr($fetch[2]." ".$fetch[1], $key) == TRUE)
                 {
			 $actoroutput = $fetch[2]. " ".$fetch[1]. "(".$fetch[4].")";
                         $actoroutput2 = $fetch[2]." ".$fetch[1];
			 $actoroutput3 = str_replace(" ","+",$actoroutput2);
			 echo "Actor: ";
                      	 echo '<A HREF="./showActor.php?actor='.$actoroutput3.'">'.$actoroutput.'</A> <br />';
                   }       
        }       		
}
else
{
	echo "<font size='5'><b>Please Enter Information to Search for Actor/Movie: <br /><br /></b></font>";
	echo '<b><i>Search: </i></b>';	
	echo '<input type="TEXT" name="search" /> <br /> <br />
	<input type="submit" />';		
}

mysql_close($x);
?>

</form>

</td>

</tr>
</table>


</body>
</html>
