<html>
<body>

<table border="0" width="100%" cellpadding="10">
<tr>

<td width="20%" valign="top" bgcolor="#0033FF">
<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br
 />
<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A>
<br />
<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add 
Comments</FONT></A>
<br />
<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /><br /> <br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />

</td>

<td width="80%" valign="top" bgcolor="CCFF00">

<form action="addMovie.php" method="GET">
<font size="5"><b>Enter the following information to add a new Movie: <br /> <br /></font>

<?php

echo '

<b><i>Title: </b></i>
<input type="text" name="title" > <br />

<b><i>Company: </b></i>
<input type="text" name = "company"> <br />

<b><i>Year: </b></i>
<input type="text" name = "year"> <br />

<b><i>Director: </b></i>
<select name="directors">';

$x = mysql_connect ("localhost", "cs143", "");
if (!$x)
        {                die('Could not connect: ' . mysql_error());
        }


$db_selected = mysql_select_db("CS143",$x);

$query = mysql_query("SELECT first, last FROM Director", $x);
while ($users = mysql_fetch_array($query))
{
echo '<option>'.$users[0], " " ,$users[1].'</option>';
}

echo '</select>

<br />

<b><i>Rating: </b></i>
<select name="rating">
<option>PG</option>
<option>PG-13</option>
<option>G</option>
<option>R</option>
</select>
<br />

<b><i>Genre: </b></i>
<select name="genre">
<option>Action</option>
<option>Adult</option>
<option>Adventure</option>
<option>Animation</option>
<option>Comedy</option>
<option>Crime</option>
<option>Documentary</option>
<option>Drama</option>
<option>Family</option>
<option>Fantasy</option>
<option>Horror</option>
<option>Musical</option>
<option>Mystery</option>
<option>Romance</option>
<option>Sci-Fi</option>
<option>Short</option>
<option>Thriller</option>
<option>War</option>
<option>Western</option>
</select>
<br />

<input type="submit" />

<br />

</form>';

if(isset($_GET["title"], $_GET["company"], $_GET["year"]))
{
	if($_GET["title"] && $_GET["company"] && $_GET["year"])
	{
	$title = $_GET["title"];
	$company = $_GET["company"];
	$year = $_GET["year"];
	$director = $_GET["directors"];
	$rating = $_GET["rating"];
	$genre = $_GET["genre"];

	$result = mysql_query("SELECT * FROM MaxMovieID", $x);
        $id = mysql_fetch_row($result);
        eval("\$newid= $id[0]+1;");
	$delete = "DELETE FROM MaxMovieID WHERE id=$id[0]";
        $delresult = mysql_query($delete, $x);
        $insertid = "INSERT INTO MaxMovieID VALUES ($newid)";
        $query = mysql_query($insertid, $x);

	$insertquery = "INSERT INTO Movie VALUES ($newid, '$title', $year, '$rating','$company')";
	$query = mysql_query($insertquery, $x);

	$insertquery = "INSERT INTO MovieGenre VALUES($newid, '$genre')";
 	$query = mysql_query($insertquery, $x);

	$insertquery = "SELECT * FROM Director";
	$query = mysql_query($insertquery, $x);
	while ($fetch = mysql_fetch_row($query))
        {
		if(($director == $fetch[2]. "".$fetch[1]) || ($director == $fetch[2]. " ".$fetch[1]))
		{	
			$insertquery = "INSERT INTO MovieDirector VALUES ($newid, $fetch[0])";		
			$querynew = mysql_query($insertquery, $x); 
			if($querynew) 
			{
				echo "Movie ";
				echo $movie;
				echo " Added Successfully";
			}
		}

         }


	}
	else
	{
		echo "<font color='#FF0000'>All the information needs to be filled in to add a Movie <br /></font>";
	}

}

mysql_close($x);

?>

</td>

</tr>
</table>


</body>
</html>

