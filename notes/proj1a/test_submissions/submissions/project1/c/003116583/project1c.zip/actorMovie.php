<html>
<body>

<table border="0" width="100%" cellpadding="10">
<tr>
<td width="20%" valign="top" bgcolor="#0033FF">

<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br
 />
<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A>
<br />
<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add 
Comments</FONT></A><br />

<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /><br /> <br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />
</td>

<td width="80%" valign="top" bgcolor="#CCFF00">

<?php

	echo '<form action="actorMovie.php" method="GET">';
	
	$x = mysql_connect ("localhost", "cs143", "");
        if (!$x)
        {
	        die('Could not connect: ' . mysql_error());
        }
 
                $db_selected = mysql_select_db("CS143",$x);

		echo "<font size='5'><b>Enter the Information Before to add an Actor/Director Relation: </b></font> <br /><br />";	

		echo '<b><i>Choose a Movie: </i></b>';
		echo '<br />';

		echo '<select name="movie">';
		$query = mysql_query("SELECT title FROM Movie", $x);
		while ($users = mysql_fetch_array($query))
		{	
			echo '<option>'.$users[0].'</option>';
		}
		echo '</select> <br /> <br />';

		echo '<b><i>Choose an Actor: </b></i>';
		echo '<br />';

		echo '<select name="actor">';
               	$query = mysql_query("SELECT id, last, first FROM Actor", $x);      
		while ($users = mysql_fetch_array($query))
                {
                       	echo '<option>'.$users[2], " ",$users[1].'</option>';
                }
                echo '</select> <br /> <br />';
		
		echo "Actor's Role: ";
		echo '<input type="TEXT" name="role" /> <br /> <br />';
			
		echo '<input type="submit" />';

		if(isset($_GET["movie"], $_GET["actor"], $_GET["role"]))
		{
		$insertquery = "SELECT * FROM Movie";
        	$query = mysql_query($insertquery, $x);
        	while ($fetch = mysql_fetch_row($query))
        	{
		        if($_GET["movie"] == $fetch[1])
        	        {
                	        $movieid = $fetch[0];
                	}

         	}

		$insertquery = "SELECT * FROM Actor";
	        $query = mysql_query($insertquery, $x);
        	while ($fetch = mysql_fetch_row($query))
        	{
	           	if(($_GET["actor"] == $fetch[2]. "".$fetch[1]) || ($_GET["actor"] == $fetch[2]. " ".$fetch[1]))
                	{
	                     	$actorid = $fetch[0];
				$role = $_GET["role"];
				
				$insertquery = "SELECT * FROM MovieActor";
		                $queryab = mysql_query($insertquery, $x);
                		$duplicatecheck=0;
				while ($fetcher = mysql_fetch_row($queryab))                		    {
					if(($fetcher[0] == $movieid) && ($fetcher[1] == $actorid))
					{
						$duplicatecheck=1;
					}
				}
				if($duplicatecheck == 1)
				{
					echo "<br /><br /><b><font color='#FF0000'>This Actor has already been added to the Movie</font></b>";
				}
				else
				{
                        		$insertquery = "INSERT INTO MovieActor VALUES ($movieid, $actorid, '$role')";
					$querynew = mysql_query($insertquery, $x);
                        		if($querynew)
                        		{
						$actorname = $_GET["actor"];
						$moviename = $_GET["movie"];
                                		echo "<font color='#0000FF'>Actor ";
                                		echo $actorname."</font>";
	                         		echo " has been added to <font color='#0000FF'>";
						echo $moviename."</font>"; 
						echo "<font color='#FF000
0'> Successfully</font>";
                        		}
				}
                	}

         	}
	}
		
	mysql_close($x);
?>

</form>

</td>

</tr>
</table>


</body>
</html>

