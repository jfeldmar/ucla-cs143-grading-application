<html>
<body>

<table border="0" width="100%" cellpadding="10" bgcolor="#7777777" font="yellow">
<tr>

<td width="20%" valign="top" bgcolor="#0033FF">

<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br />

<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A><br />

<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add 
Comments</FONT></A><br />

<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /> <br /><br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />

</td>

<td width="80%" valign="top" bgcolor="CCFF00">

<form action="addAorD.php" method="GET">
<font size="5"><b>Enter the following information to add a new Actor or Director <br /> </b></font>

<b><i> Type of Person to Add: </i></b>
<input type="radio" name="typeofperson" value="actor"> Actor
<input type="radio" name="typeofperson" value="director"> Director
<br />

<b><i>First Name: </b></i>
<input type="text" name="firstname" > <br />

<b><i>Last Name: </b></i>
<input type="text" name = "lastname"> <br />

<b><i>Sex: </b></i>
<input type="radio" name="sex" value="male"> Male
<input type="radio" name="sex" value="female"> Female
<br>
 
<b><i>Date of Birth: </b></i>
<input type="text" name="dateofbirth"> <br />
 
<b><i>Date of Death: </b></i>
<input type="text" name="dateofdeath"> (If Actor/Director is still alive, leave blank) <br />


<input type="submit" />

</form>

<?php

if(isset($_GET["firstname"], $_GET["lastname"], $_GET["dateofbirth"]))
{
	if($_GET["firstname"] && $_GET["typeofperson"] && $_GET["lastname"] && $_GET["sex"] && $_GET["dateofbirth"])
	{
	$typeofperson = $_GET["typeofperson"];
	$firstname = $_GET["firstname"];
	$lastname = $_GET["lastname"];
	$sex = $_GET["sex"];
	$dateofbirth = $_GET["dateofbirth"];
	$dateofdeath = $_GET["dateofdeath"];

	$x = mysql_connect ("localhost", "cs143", "");

        if (!$x)
        {
                die('Could not connect: ' . mysql_error());
        }
        $db_selected = mysql_select_db("CS143",$x);

	$result = mysql_query("SELECT * FROM MaxPersonID", $x);
	$id = mysql_fetch_row($result);	      
 	eval("\$newid= $id[0]+1;");
	$delete = "DELETE FROM MaxPersonID WHERE id=$id[0]";
	$delresult = mysql_query($delete, $x);
	$insertid = "INSERT INTO MaxPersonID VALUES ($newid)";
	$query = mysql_query($insertid, $x);

	$duplicate = 0;
	if($typeofperson == "actor")
	{
		$res = mysql_query("SELECT * FROM Actor", $x);
                while($resact = mysql_fetch_row($res))
		{ 
			if(($resact[1] == $lastname) && ($resact[2] == $firstname) && ($resact[3] == $sex))
			{
				echo "<font color='#FF0000'>This Actor Already Exists!</font>";	
				$duplicate += 1;
			}
		}
		if($duplicate == 0)
		{
			$insert1 = "INSERT INTO Actor VALUES ($newid, '$lastname', '$firstname', '$sex', '$dateofbirth', '$dateofdeath')";
			$query1 = mysql_query($insert1, $x);
			echo "<font color='#FF0000'>Actor Successfully added!</font>";
		}
	}
	else
	{
		
	    	$res = mysql_query("SELECT * FROM Director", $x);
                 while($resact = mysql_fetch_row($res))
                 {
                         if(($resact[1] == $lastname) && ($resact[2] == $firstname))
                         {
                                 echo "<font color='#FF0000'>This Director Already Exists!</font>";
        			$duplicate += 1;  
	                 }
                 }      
		if($duplicate == 0)
		{ 
			$insert2 = "INSERT INTO Director VALUES ($newid, '$lastname', '$firstname', '$dateofbirth', '$dateofdeath')";
			$query2 = mysql_query($insert2, $x);
			echo "<font color='#FF0000'>Director Successfully added!</font>";
		}
	}
	mysql_close($x);
	} 
	else
	{
		echo "<font color='#FF0000'> Please fill in all the information to add an Actor or Director</font>";
	}
}

?>

</td>

</tr>
</table>


</body>
</html>
