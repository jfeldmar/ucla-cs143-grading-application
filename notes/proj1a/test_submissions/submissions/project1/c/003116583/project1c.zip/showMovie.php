<html>
<body>

<table border="0" width="100%" cellpadding="10"><tr>

<td width="20%" valign="top" bgcolor="#0033FF">

<FONT COLOR="#000066"> TO ADD INFORMATION, CLICK A LINK BELOW:</FONT> <br /> <br
 />

<A HREF="./addAorD.php"><FONT COLOR="#CCFF00">Add Actor/Director Information</FONT></A>
<br />

<A HREF="./addComments.php"><FONT COLOR="#CCFF00">Add 
Comments</FONT></A>
<br />

<A HREF="./addMovie.php"><FONT COLOR="#CCFF00">Add Movie Information</FONT></A>
<br />

<A HREF="./actorMovie.php"><FONT COLOR="#CCFF00">Add Actor to Movie</FONT></A>
<br /> <br /> <br />

<FONT COLOR="000066">TO VIEW A MOVIE OR ACTOR, CLICK A LINK BELOW</FONT> <br /> <br />

<A HREF="./showMovie.php"><FONT COLOR="#CCFF00">View Movie Information</FONT></A>
<br />

<A HREF="./showActor.php"><FONT COLOR="#CCFF00">View Actor Information</FONT></A>
<br /><br /> <br />

<FONT COLOR="000066">TO SEARCH BY KEYWORD, CLICK THE LINK BELOW</FONT> <br /> <br />

<A HREF="./search.php"><FONT COLOR="#CCFF00">Search</FONT></A>
<br /> <br />
</td>

<td width="80%" valign="top" bgcolor="#CCFF00">

<form action="showMovie.php" method="GET">
<?php

$x = mysql_connect ("localhost", "cs143", "");
if (!$x)
        {                die('Could not connect: ' . mysql_error());
        }

$db_selected = mysql_select_db("CS143",$x);

if(isset($_GET["movie"]))
{	
	$insertquery = "SELECT * FROM Movie";
        $query = mysql_query($insertquery, $x);
  	$movieidcomment;
        while ($fetch = mysql_fetch_row($query))
        {
		$movieidcomment = $fetch[0];
                if($_GET["movie"] == $fetch[1])
                {
			echo "<font size='5'><b>Information regarding the movie you requested:</b></font>";
		        echo "<br />";

        		echo "<b><i>Title: </b></i>";
        		echo $fetch[1];
        		echo "<br />";

        		echo "<b><i>Year: </b></i>";
        		echo $fetch[2];
       			echo "<br />";

        		echo "<b><i>Rating: </b></i>";
        		echo $fetch[3];
        		echo "<br />";

        		echo "<b><i>Company: </b></i>";
        		echo $fetch[4];
        		echo "<br />";

			$x = mysql_connect ("localhost", "cs143", "");
	        	if (!$x)
        		{
                		die('Could not connect: ' . mysql_error());
        		}

        		$db_selected = mysql_select_db("CS143",$x);
        		$insertquery = "SELECT * FROM MovieDirector";
        		$query = mysql_query($insertquery, $x);
       			echo "<b><i>Director: </b></i>";
			$directorcheck = 0;
			while ($fetchx = mysql_fetch_row($query))
        		{
				
                        	if($fetch[0] == $fetchx[0])
                		{	
	                   		$insertquery = "SELECT * FROM Director";
                        		$query1 = mysql_query($insertquery, $x);
                        		while ($fetchnew = mysql_fetch_row($query1))
                        		{
                                		if($fetchx[1] == $fetchnew[0])
                                		{
                                               		echo $fetchnew[2]." ".$fetchnew[1];
                                			echo "<br />";
							$directorcheck+=1;
						}
                        			
					}
                		}
        		}
			if($directorcheck == 0)
			{
				echo "<br />";
			}			
			$insertgenre = "SELECT * FROM MovieGenre";
                        $querybb = mysql_query($insertgenre, $x);
                        echo "<b><i>Genre: </b></i>";
                        while ($fetchbb = mysql_fetch_row($querybb))
                        {
				if($fetch[0] == $fetchbb[0])
				{
					echo $fetchbb[1];
					echo ", ";
				}				
			}			
			/* ACTORS IN THIS MOVIE*/
			$queryabc = "SELECT * FROM MovieActor";
			$queryactor = mysql_query($queryabc, $x);
			echo "<font size='4'><b><br /> Actors who acted in this movie: </b></font>";
			echo "<br />";
			while ($fetchy = mysql_fetch_row($queryactor))
                        {
				if($fetch[0] == $fetchy[0])
				{
					$queryabc1 = "SELECT * FROM Actor";
		                        $queryactor1 = mysql_query($queryabc1, $x);
                         		while ($fetchy1 = mysql_fetch_row($queryactor1))
                         		{
						if($fetchy[1] == $fetchy1[0])
						{
							$actoroutput = $fetchy1[2]. " ".$fetchy1[1]. "(".$fetchy[2].")";
							$actoroutput2 = $fetchy1[2]. "+".$fetchy1[1];
							echo '<A HREF="./showActor.php?actor='.$actoroutput2.'">'.$actoroutput.'</A> <br />';
						}
					}						
				}			
			}		       	
                }
         }

	/*REVIEWS*/
	
	echo '<br /><font size="4"><b>Reviews for this movie: <br /></b></font>';
	$getreview = mysql_query("SELECT * FROM Review", $x);
	$reviewtotal =0;
	$reviewcount=0;
	$checkreview=0;
	while ($gotreview = mysql_fetch_array($getreview))
        {	
		if($gotreview[2] == $movieidcomment)
		{ 
			$checkreview+=1;
			$reviewtotal += $gotreview[3];		
			$reviewcount+=1;			
			echo "<font color='#080080'>".$gotreview[0]. "</font> reviewed this movie on <font color='#FF0000'>".$gotreview[1]." </font>giving a rating of <font color='#3EA99F'>".$gotreview[3]." </font>saying : " .$gotreview[4]."<br /> <br />";
		}
	}
	if($checkreview ==0)
	{
		echo "NO Reviews at this time.<br /><br /> ";
	}
	if($reviewcount != 0)
	{
		eval("\$ans= $reviewtotal/$reviewcount;");	
	}
	else
	{
		$ans=0;
	}
	echo "<b><i>The average rating for this movie is: </i></b>";
	echo "<font color='#52D017'>".$ans."</font><br />";

	echo '<A HREF="./addComments.php"><FONT COLOR="#FF0000">Add a Review!!</FONT></A>
<br />';
	
	echo '<br /><font size="3"><b>Search Another Movie: </b></font>
	<br /> 
	<select name="movie">';
        $query = mysql_query("SELECT title FROM Movie", $x);
        while ($users = mysql_fetch_array($query))
        {
	        echo '<option>'.$users[0].'</option>';
        }
  
 	       echo '</select><br />
  	       <input type="submit" />';
}
else
{
	 echo '<font size="5"><b>Please Select a Movie Below: </b></font><br /><br />';
	echo "<b><i>Movie : </i></b>";
	echo '<select name="movie">';
	$query = mysql_query("SELECT title FROM Movie", $x);
	while ($users = mysql_fetch_array($query))
	{
		echo '<option>'.$users[0].'</option>';
	}

	echo '</select><br /><br />
	<input type="submit" />';
}

mysql_close($x);

?>

</form>

</td>

</tr>
</table>

</html>
</body>
