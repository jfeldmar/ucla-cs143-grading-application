David Hwang
603401718
d.hw4ng@gmail.com

I implemented this site similarly to the demo site.  However, I did not use frames.  I did minimal inteface improvements, but it works.