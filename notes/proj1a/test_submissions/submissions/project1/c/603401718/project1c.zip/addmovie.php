<html>
<head>
<title>Add Movie</title>
</head>
<body>
  <h1>Add Movie</h1>

  <form action="./addmovie.php" method="GET">
    Title: <input type="text" name="title" maxlength="100"><br/>
    Company: <input type="text" name="company" maxlength="50"><br/>
    Year: <input type="text" name="year" maxlength="4"><br/>
    MPAA Rating : <select name="rating">
					<option value="G">G</option>
          <option value="NC-17">NC-17</option>
          <option value="PG">PG</option>
          <option value="PG-13">PG-13</option>
          <option value="R">R</option></select><br/>
      
    <!-- Do director? -->
    Director: <select name="did">
    <?php   
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT last,first,id FROM Director ORDER BY last";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        $last = $row[0];
        $first = $row[1];
        $dirid = $row[2];
        echo "<option value=\"" . $dirid . "\">" . $last . ", " . $first . "</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>  
    
    Genre:
    <select name="genre">
    <option value="Action">Action</option>
    <option value="Adult">Adult</option>
    <option value="Adventure">Adventure</option>
    <option value="Animation">Animation</option>
    <option value="Comedy">Comedy</option>
    <option value="Crime">Crime</option>
    <option value="Documentary">Documentary</option>
    <option value="Drama">Drama</option>
    <option value="Family">Family</option>
    <option value="Fantasy">Fantasy</option>
    <option value="Horror">Horror</option>
    <option value="Musical">Musical</option>
    <option value="Mystery">Mystery</option>
    <option value="Romance">Romance</option>
    <option value="Sci-Fi">Sci-Fi</option>
    <option value="Short">Short</option>
    <option value="Thriller">Thriller</option>
    <option value="War">War</option>
    <option value="Western">Western</option>
    </select><br/>
    
    <input type="submit" value="Submit" /><br/>
  </form>
  
  <?php
  //If there is nothing in GET, output nothing
  if (!$_GET) {}
  //See if there's title
  else if (!$_GET["title"]) {
    echo "<p>Error: Please insert title.</p>\n";  
  }
  //See if there's company
  else if (!$_GET["company"]) {
    echo "<p>Error: Please insert company name.</p>\n";  
  }
  //See if there's a year
  else if (!$_GET["year"]){
    echo "<p>Error: Please insert year.</p>\n";
  }
  else {
    //Create the connection
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
    
    //Retrieving mysql id
    $idquery = "SELECT id FROM MaxMovieID";
    $idrs = mysql_query($idquery, $db_connection);
    $idrow = mysql_fetch_row($idrs);
    $id = $idrow[0];
    
    //New max id
    $id = $id + 1;
    
    //Update the id
    $idquery2 = "UPDATE MaxMovieID SET id=" . $id;
    mysql_query($idquery2, $db_connection);
    
    //Form the query
    $query = "INSERT INTO Movie VALUES(" . $id . ",'" 
      . mysql_real_escape_string($_GET["title"]) . "','" 
      . mysql_real_escape_string($_GET["year"]) . "','"
      . mysql_real_escape_string($_GET["rating"]) . "','"
      . mysql_real_escape_string($_GET["company"]) . "')";
    
    //If the addition succeeds
    if (mysql_query($query, $db_connection) == TRUE){
      echo "<p>Successfully added movie.</p>\n";
    }
    //If it doesn't succeed
    else {
      echo "<p>Error: Please try again</p>\n";
      echo "<p>" . mysql_error() . "</p>\n";
    }
    
    //Insert Director
    $dquery = "INSERT INTO MovieDirector VALUES(" . $id . "," . $_GET["did"] . ")";
    mysql_query($dquery, $db_connection);
    //echo $dquery;
    
    //Insert Genre
    $gquery = "INSERT INTO MovieGenre VALUES(" . $id . ",'" . $_GET["genre"] . "')";
    mysql_query($gquery, $db_connection);
    //echo $gquery;
    
    //Close the connection
    mysql_close($db_connection);
  }
  
  ?>

  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>