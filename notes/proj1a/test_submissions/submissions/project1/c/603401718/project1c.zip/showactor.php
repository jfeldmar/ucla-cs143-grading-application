<html>
<head>
<title>Show Actor</title>
</head>
<body>
  <h1>Show Actor</h1>

  <form action="./showactor.php" method="GET">
   Choose an Actor: <select name="id">
    <?php
   
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT last,first,id FROM Actor ORDER BY last";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        $last = $row[0];
        $first = $row[1];
        $actor = $row[2];
        echo "<option value=\"" . $actor . "\">" . $last . ", " . $first . "</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>
    <input type="submit" value="Submit" /><br/>
  </form>

  <?php
  if (!$_GET) {}
  else {
    //Create the connection
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
    
    //Actor Information
    echo "<h2>Actor Information</h2>\n";
    
    $infoquery = "SELECT * FROM Actor WHERE id=" . $_GET["id"];
    //echo $infoquery;
    $infors = mysql_query($infoquery, $db_connection);
    $inforow = mysql_fetch_row($infors);
    $id = $inforow[0];
    
    echo "<p><strong>Name:</strong> " . $inforow[2] . " " . $inforow[1] . "<br/>\n";
    echo "<p><strong>Sex:</strong> " . $inforow[3] . "<br/>\n";
    echo "<p><strong>Date of Birth:</strong> " . $inforow[4] . "<br/>\n";
    if ($inforow[5] == "0000-00-00" || $inforow[5] == NULL) {
      echo "<p><strong>Date of Death:</strong> " . " N/A<br/>\n";
    }
    else {
      echo "<p><strong>Date of Death:</strong> " . $inforow[5] . "<br/>\n";
    }
    echo "</p>\n";
    
    //Movie Information
    echo "<h2>Movie Information</h2>\n";
    $query = "SELECT DISTINCT title,role,M.id FROM
      Movie M, MovieActor A WHERE M.id=A.mid AND A.aid=" . $_GET["id"];
    //echo $query;
    $rs = mysql_query($query, $db_connection);
    while ($row = mysql_fetch_row($rs)) {
      echo "<p>Appeared in <a href=\"./showmovie?id=" . $row[2] . "\"><strong>" 
      . $row[0] . "</a></strong> as <strong>" . $row[1] . "</strong>.</p>\n";      
    }
    
    mysql_close($db_connection);
	}
  
  ?>
  
  <h3>Links</h3><p>
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>