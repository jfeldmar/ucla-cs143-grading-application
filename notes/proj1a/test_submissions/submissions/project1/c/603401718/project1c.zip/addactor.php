<html>
<head>
<title>Add Actor</title>
</head>
<body>
  <h1>Add Actor/Director</h1>

  <form action="./addactor.php" method="GET">
    Identity: <input type=radio name="identity" value="Actor" checked="true">Actor
      <input type="radio" name="identity" value="Director">Director</br>
    First Name: <input type="text" name="first" maxlength="20"></br>
    Last Name: <input type="text" name="last" maxlength="20"></br>
    Sex: <input type="radio" name="sex" value="Male" checked="true">Male
      <input type="radio" name="sex" value="Female">Female</br>
    Date of Birth: <input type="text" name="dob"> YYYY-MM-DD</br>
    Date of Death: <input type="text" name="dod"> YYYY-MM-DD or
      (Please leave blank if person is stil alive)</br>
    <input type="submit" value="Sumbit" />
  </form>
  
  <?php
  $validdate = "/\d\d\d\d-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])/";
  //If there is nothing in GET, output nothing
  if (!$_GET) {}
  //Check if name is there
  else if (!$_GET["first"] && !$_GET["last"]) {
    echo "<p>Error: Need to input a name</p>\n";
  }
  //Check if date of birth there 
  else if (!$_GET["dob"]) {
    echo "<p>Error: Need to input date of birth</p>\n";  
  }
  //Check if the date of birth and death have correct regular expressions
  else if (!preg_match($validdate, $_GET["dob"]) || 
    (!preg_match($validdate, $_GET["dod"]) && $_GET["dod"] != "")){
    echo "<p>Error: Illegal form. Date must be input as YYYY-MM-DD</p>\n";  
  }  
  //Otherwise if all is legal
  else {
    //Create the connection
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
    
    //Retrieving mysql id
    $idquery = "SELECT id FROM MaxPersonID";
    $idrs = mysql_query($idquery, $db_connection);
    $idrow = mysql_fetch_row($idrs);
    $id = $idrow[0];
    
    //New max id
    $id = $id + 1;
    
    //Update the id
    $idquery2 = "UPDATE MaxPersonID SET id=" . $id;
    mysql_query($idquery2, $db_connection);
    
    //Form the query for actor
    if ($_GET["identity"] == "Actor") {
      $query = "INSERT INTO "
      . mysql_real_escape_string($_GET["identity"])
      . " VALUES(" . $id . ",'" 
      . mysql_real_escape_string($_GET["last"]) . "','" 
      . mysql_real_escape_string($_GET["first"]) . "','"
      . mysql_real_escape_string($_GET["sex"]) . "','"
      . mysql_real_escape_string($_GET["dob"]) . "','"
      . mysql_real_escape_string($_GET["dod"]) . "')";
    }
    else if ($_GET["identity"] == "Director") {
      $query = "INSERT INTO "
      . mysql_real_escape_string($_GET["identity"])
      . " VALUES(" . $id . ",'" 
      . mysql_real_escape_string($_GET["last"]) . "','" 
      . mysql_real_escape_string($_GET["first"]) . "','"
      . mysql_real_escape_string($_GET["dob"]) . "','"
      . mysql_real_escape_string($_GET["dod"]) . "')";
    
    }
    
    //If the addition succeeds
    if (mysql_query($query, $db_connection) == TRUE){
      echo "<p>Added actor/director information successfully</p>\n";
    }
    //If it doesn't succeed
    else {
      echo "<p>Error: Unexpected error.  Gracefully exiting...please try again</p>\n";
      echo "<p>" . mysql_error() . "</p>\n";
    }
    
    //Close the connection
    mysql_close($db_connection);
  }
  ?>

  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>