<html>
<head>
<title>Show Movie</title>
</head>
<body>
  <h1>Show Movie</h1>

  <form action="./showmovie.php" method="GET">
   Choose a Movie: <select name="id">
    <?php
   
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT id,title,year FROM Movie ORDER BY title";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        echo "<option value=\"" . $row[0] . "\">" . $row[1] . " (" . $row[2] . ")</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>
    <input type="submit" value="Submit" /><br/>
  </form>

  <?php
  if (!$_GET) {}
  else {
    //Create the connection
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
    
    //Movie Information
    echo "<h2>Movie Information</h2>\n";
    
    $infoquery = "SELECT id,title,company,rating,year FROM Movie WHERE id=" . $_GET["id"];
    //echo $infoquery;
    $infors = mysql_query($infoquery, $db_connection);
    $inforow = mysql_fetch_row($infors);
    $id = $inforow[0];
    
    echo "<p><strong>Title:</strong> " . $inforow[1] . "<br/>\n";
    echo "<strong>Year:</strong> " . $inforow[4] . "<br/>\n";
    echo "<strong>Producer:</strong> " . $inforow[2] . "<br/>\n";
    echo "<strong>MPAA Rating:</strong> " . $inforow[3] . "<br/>\n";
    
    //Actor Information
    $query = "SELECT DISTINCT * FROM MovieDirector M, Director D WHERE M.did=D.id AND
      M.mid=" . $_GET["id"];
    //echo $query;
    $rs = mysql_query($query, $db_connection);
    $row = mysql_fetch_row($rs);
    if ($row) {
      echo "<strong>Director:</strong> " . $row[4] . " " . $row[3] . "<br/>\n";
    }
    else {
      echo "<strong>Director:</strong><br/>\n";
    }
    
    $query = "SELECT genre FROM MovieGenre WHERE mid=" . $_GET["id"];
    $rs = mysql_query($query, $db_connection);
    $row = mysql_fetch_row($rs);
    if ($row) {
      echo "<strong>Genre:</strong> " . $row[0] . "<br/>\n";
    }
    else {
      echo "<strong>Genre:</strong><br/>\n";
    }
    
    echo "<h2>Actors</h2>";
    $query = "SELECT DISTINCT last,first,role,A.id FROM Actor A, MovieActor M
    WHERE A.id = M.aid AND M.mid = " . $_GET["id"];
    $rs = mysql_query($query, $db_connection);
    //echo $query;
    while ($row = mysql_fetch_row($rs)) {
      echo "<p><a href=\"./showactor.php?id=" . $row[3] . "\"><strong>" . $row[1] . " " . $row[0]
      . "</strong></a> as <strong> " . $row[2] . "</strong></p>\n";      
    }
    
    //Show the user Revies
    echo "<h2>User Review</h2>\n";
    echo "<p><a href=\"./addcomment.php?mid=" . $_GET["id"] . "\">Add a review!</a></p>";
    $query = "SELECT AVG(rating), COUNT(rating) FROM Review WHERE mid=" . $_GET["id"];
    $rs = mysql_query($query, $db_connection);
    $row = mysql_fetch_row($rs);
    if ($row[1] == 0) {
      echo "<p>No reviews found</p>\n";
    }
    else {
      echo "<p>\n";
      echo "Average Score: " . $row[0] . " from " . $row[1] . " review(s).<br/><br/>";
      $query = "SELECT * FROM Review WHERE mid=" . $_GET["id"];
      $rs = mysql_query($query, $db_connection);
      while ($row = mysql_fetch_row($rs)) {
        echo "<p>In " . $row[1] . ", " . $row[0] . " rated this <strong>" 
          . $row[3] . "</strong> out of 5 and said: </p><blockquote>"
          . $row[4] . "</blockquote></p>\n";
      }
      echo "</p>\n";
      
    }    
    mysql_close($db_connection);
	}
  
  ?>
  
  
  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>