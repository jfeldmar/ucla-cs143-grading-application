<html>
<head>
<title>Add Comment</title>
</head>
<body>
  <h1>Add Comment</h1>

  <form action="./addcomment.php" method="GET">
    Movie: <select name="mid">
    <?php
      //The template should be
      //<option value="4737">Title</option>
      //SELECT id, title FROM Movie;
      
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT id,title,year FROM Movie ORDER BY title";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        $id = $row[0];
        $title = $row[1];
        $year = $row[2];
        echo "<option value=\"" . $id . "\"";
        if (!$_GET["mid"]) {}
        else if ($id == $_GET["mid"]){
          echo " selected=selected ";          
        }          
                   
        echo ">" . $title . " (" . $year . ")" . "</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>
    Your Name: <input type="text" name="name" value="Mr. Anonymous" maxlength="20"><br/>
    Rating: <select name="rating">
              <option value="5">5 - Excellent</option>
              <option value="4">4 - Good</option>
              <option value="3">3 - It's OK</option>
              <option value="2">2 - Not worth it</option>
              <option value="1">1 - Bad</option>
            </select><br/>
    Comments: <br/>
    <textarea name="comment" cols="50" rows="10"></textarea><br/>
    <input type="submit" value="Submit" />
  </form>
  
  <?php
  if (!$_GET) {}
  //If there is no name, do nothing
  else if (!$_GET["name"]) {}
  //If no comment, do nothing
  else if (!$_GET["comment"]) {}
  //Otherwise
  else {
    //Create the connection
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
    
    //Retrieve the timestamp
    $timequery = "SELECT CURRENT_TIMESTAMP";
    $timers = mysql_query($timequery,$db_connection);      
    $row = mysql_fetch_row($timers);
    $time = $row[0];

    //Form the query
    $query = "INSERT INTO Review VALUES('" 
      . mysql_real_escape_string($_GET["name"]) . "','" 
      . $time . "','"
      . mysql_real_escape_string($_GET["mid"]) . "','"
      . mysql_real_escape_string($_GET["rating"]) . "','"
      . mysql_real_escape_string($_GET["comment"]) . "')";
    
    //echo $query;
    
    //If the addition succeeds
    if (mysql_query($query, $db_connection) == TRUE){
      echo "<p>Added comment</p>\n";
    }
    //If it doesn't succeed
    else {
      echo "<p>Error: Unexpected error.  Please try again.</p>\n";
      echo "<p>" . mysql_error() . "</p>\n";
    }
    
    //Close the connection
    mysql_close($db_connection);
  }
  
  ?>
 
  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>

</body>
</html>