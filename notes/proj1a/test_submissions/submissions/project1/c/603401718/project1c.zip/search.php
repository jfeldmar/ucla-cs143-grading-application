<html>
<head>
<title>Search</title>
</head>
<body>
  <h1>Search Actor/Movie</h1>
  
  <?php
  if ($_GET == NULL) {}
  else {
  
    $db_connection = mysql_connect("localhost","cs143","");
    mysql_select_db("CS143", $db_connection);
  
    $search = mysql_real_escape_string($_GET["search"]);
    $searcharray = explode(" ",$search);
    
    //Search Actor
    //First, we will try one word look ups
    echo "<h2>Actors</h2>\n";
    if (count($searcharray) == 1){
      $query = "(SELECT * FROM Actor WHERE first LIKE '%" . $searcharray[0] . "%') "
        . " UNION "
        . "(SELECT * FROM Actor WHERE last LIKE '%" . $searcharray[0] . "%') ";
      //echo $query;
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        echo "<a href=./showactor.php?id=" . $row[0] . ">" . $row[2] . " "
          . $row[1] . " (" . $row[4] . ")</a><br/>\n";
      }   
    }
    //Else use two word look ups
    else {
      $query = "(SELECT * FROM Actor WHERE first LIKE '%" . $searcharray[0] . "%' "
        . " AND last LIKE '%" . $searcharray[1] . "%')"
        . " UNION "
        . "(SELECT * FROM Actor WHERE first LIKE '%" . $searcharray[1] . "%' "
        . "AND last LIKE '%" . $searcharray[0] . "%')";
      //echo $query;
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        echo "<a href=./showactor.php?id=" . $row[0] . ">" . $row[2] . " "
          . $row[1] . " (" . $row[4] . ")</a><br/>\n";
      }    
    }
    
    echo "<br/>\n<h2>Movies</h2>\n";
      
    //Search Movie
    $query = "SELECT * FROM Movie WHERE title LIKE '%" . $search . "%'";
    //echo $query;
    $rs = mysql_query($query,$db_connection);
    //Output results
    while ($row = mysql_fetch_row($rs)) {
      echo "<a href=./showmovie.php?id=" . $row[0] . ">" . $row[1]
        . " (" . $row[2] . ")</a><br/>\n";
    }
    echo "<br/>\n";
  }
  
  ?>
  
  <form action="./search.php" method="GET">
  <strong>Search Actor/Movie:</strong>
  <input type="text" name="search" maxlength="20">
  <input type="submit" value="Submit" />
  </form>

  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>