<html>
<head>
<title>Add Actor/Movie Relation</title>
</head>
<body>
  <h1>Add Actor/Movie Relation</h1>

  <form action="./addrelation.php" method="GET">
   Choose a Movie: <select name="mid">
    <?php   
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT title, id, year FROM Movie ORDER BY title";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        $title = $row[0];
        $id = $row[1];
        $year = $row[2];
        echo "<option value=\"" . $id . "\">" . $title
          . " (" . $year . ")</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>
    Choose an Actor: <select name="aid">
    <?php   
      //Open connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143",$db_connection);      
      //Get query
      $query = "SELECT last,first,id,dob FROM Actor ORDER BY last";
      $rs = mysql_query($query,$db_connection);      
      //Output results
      while($row = mysql_fetch_row($rs)) {
        $last = $row[0];
        $first = $row[1];
        $actor = $row[2];
        $dob = $row[3];
        echo "<option value=\"" . $actor . "\">" . $last . ", " . $first
          . " (" . $dob . ")</option>\n";
      }      
      //Close connection
      mysql_close($db_connection);    
    ?>
    </select><br/>
    Role: <input type="text" name="role" maxlength="50"></br>
    <input type="submit" value="Submit" /><br/>
  </form>
  
  <?php
  if (!$_GET) {}
  else {
    //If no role chosen , output error
    if ($_GET["role"] == NULL) {
      echo "<p>Error: Please add a role!</p>";
    }
    
    //Otherwise
    else {  
      //Create the connection
      $db_connection = mysql_connect("localhost","cs143","");
      mysql_select_db("CS143", $db_connection);
      
      //Create the role
      $role = mysql_real_escape_string($_GET["role"]);
      
      //Form the query
      $query = "INSERT INTO MovieActor"
        . " VALUES(" . $_GET["mid"] . "," . $_GET["aid"] . ",'" 
        . $role . "')";
      //echo $query;
      
      //If the addition succeeds
      if (mysql_query($query, $db_connection) == TRUE){
        echo "<p>Successfully added Actor/Movie Relation</p>\n";
      }
      //If it doesn't succeed
      else {
        echo "<p>Please input valid inputs</p>";
        echo "<p>" . mysql_error() . "</p>\n";
      }
    
      //Close the connection
      mysql_close($db_connection);
    }
  }
  
  ?>
  
  <h3>Links</h3><p>  
  <a href="./addactor.php">Add Actor/Director</a><br/>
  <a href="./addcomment.php">Add Comments To Movie</a><br/>
  <a href="./addmovie.php">Add Movie Information</a><br/>
  <a href="./addrelation.php">Add Actor/Movie Relation</a><br/>
  <a href="./showactor.php">Show Actor Information</a><br/>
  <a href="./showmovie.php">Show Movie Information</a><br/>
  <a href="./search.php">Search</a><br/>
  </p>
  
</body>
</html>