<html>
<head>
	<title>
		Browse Actors<?php
			$db_name = "CS143";
			$mySQL = mysql_connect("localhost", "cs143", "");
			if ($mySQL)
				mysql_selectdb($db_name, $mySQL);

			if ($_GET["actorID"] && $_GET["actorID"]!=-1)
			{
				$aid = $_GET["actorID"];
				$getActorTuple = "SELECT * FROM Actor WHERE id=$aid";
				$resource = mysql_query($getActorTuple, $mySQL);
				if ($resource)
				{
					$row = mysql_fetch_row($resource);
					if ($row)
					{
						echo ": $row[2] $row[1]";
					}
				}
			}
		?>
	</title>
</head>

<body style="margin:0;">
	<table width="100%" height="100%" cellspacing=0 cellpadding=15>
	<tr><td bgcolor="yellow" valign="top" width="200px">
		<table>
		<tr><td>Add New Content
			<ul>
				<li><a href="input1.php">Add Actor/Director</a></li>
				<li><a href="input2.php">Add Movie Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Browsing Content
			<ul>
				<li>Show Actor Information</li>
				<li><a href="browsing2.php">Show Movie Information</a></li>
				<li><a href="browsing3.php">Show Director Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Search Actors/Movies
			<ul style="list-style-type: none; padding-left: 25px;">
				<li>
					<form action="search1.php" method="GET">
						<input type="text" name="query">
						<input type="submit" name="navSearchSubmit" value="Search"/>
					</form>
				</li>
			</ul>
		</td></tr>
		</table>
	</td>
	<td bgcolor="skyblue" valign="top">
		<?php
			//Show the actor's information
			if ($_GET["actorID"] && $_GET["actorID"]!=-1)
			{
				$aid = $_GET["actorID"];
				$getActorTuple = "SELECT * FROM Actor WHERE id=$aid";
				$getMovieTuples = "SELECT title Title, role Role, mid, year FROM MovieActor, Movie WHERE aid=$aid AND mid=id ORDER BY year DESC";
						
				$resource = mysql_query($getActorTuple, $mySQL);
				if ($resource)
				{
					$row=mysql_fetch_row($resource);
					if ($row)
					{
						echo "<h3>$row[1], $row[2]</h3>";
						
						echo "<table border=1 cellspacing=1 cellpadding=2 Style='empty-cells: show'>";
						$headers= array("ID", "Last Name", "First Name", "Sex", "Date of Birth", "Date of Death");
						
						for ($i = 1; $i < count($headers); $i++)
						{
							echo "<tr align=center>";							
							echo "<td><strong>$headers[$i]</strong></td>";
							
							echo "<td>$row[$i]</td>";
							echo "</tr>\n";
						}
						echo "</table>\n";
					}
					else
						echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
				}
				else
				{
					echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
				}
				
				//Add a movie that the actor appeared in
				echo "<h4>Add Movie Role</h4>\n";
				echo "<form action='browsing1.php?orderby=".$_GET['orderby']."&actorID=".$_GET['actorID']."' method='POST'>\n";
				echo "<table>\n<tr><td>Movie:</td><td> <select  name ='movieID'>";
				
				$indexResource = mysql_query("SELECT id, title, year FROM Movie ORDER BY title", $mySQL);
				while($index = mysql_fetch_row($indexResource))
				{
					echo "<option value = '$index[0]'>$index[1] ($index[2])</option>";
				}
								
				echo "</select></td></tr>";
				echo "<tr><td>Role:</td>\n";
				echo "<td><input type='text' name='role' maxlength='50'/>\n";
				echo "</td></tr>\n";
				echo "<tr><td>&nbsp;</td>\n";
				echo "<td><input type='Submit' value='Add Role' /> ";
				if ($_POST["role"])
				{
					//echo "<tr><td>Status:</td>\n";
					$mid = $_POST["movieID"];
					$addRole = "INSERT INTO MovieActor VALUES ($mid, $aid, '".substr($_POST["role"],0, 50)."')";
					$resource = mysql_query($addRole, $mySQL);
					if ($resource)
						echo "Successfully Added";
					else
						echo "<p>mySQL Error: <em>".mysql_error()."</em>";
					echo "</tr>\n";
				}
				echo "</td></tr>\n";
				echo "</table></form>\n";

				//Get the list of movies that the actor appeared in
				$resource = mysql_query($getMovieTuples, $mySQL);
				if ($resource)
				{
					echo "<h4>Filmography</h3>";

					echo "<table border=1 cellspacing=1 cellpadding=2 Style='empty-cells: show'>\n";
				
					$length = 2;
					echo "<tr align=center>";
					for ($i = 0; $i < $length; $i++)
					{
						$header=mysql_field_name($resource, $i);
						echo "<td><strong>$header</strong></td>";
					}
					echo "</tr>".$endl;

					$row=mysql_fetch_row($resource);
					while ($row)
					{
						echo "<tr align=center>";
						for ($i = 0; $i < $length; $i++)		//last col is mid
						{
							if ($i == 0)
								echo "<td><a href='browsing2.php?movieID=$row[2]'>$row[$i]</a> ($row[3])</td>";
							else
								echo "<td>$row[$i]</td>";
						}
						echo "</tr>\n";
						$row=mysql_fetch_row($resource);
					}
					echo "</table>".$endl;
				}
				else
					echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
				
			}
		?>
		<h3>Look for Actor Information</h3>
		<form action="browsing1.php" method="GET">
			Order Actors by: 
			<select name="orderby">
				<option value="last" >Last name</option>
				<option value="first" <?php if ($_GET["orderby"]=="first") echo "selected='selected'"; ?>>First name</option>
				<option value="dob" <?php if ($_GET["orderby"]=="dob") echo "selected='selected'"; ?>>Date of birth</option>
				<option value="dod" <?php if ($_GET["orderby"]=="dod") echo "selected='selected'"; ?>>Date of death</option>
				<option value="id" <?php if ($_GET["orderby"]=="id") echo "selected='selected'"; ?>>Actor ID</option>
			</select>
			<input type="submit" value="Update"/>
			<br>
			<select name="actorID">
			<!--actor must return an Actor id!-->
			<!-- To interface with browsing2.php, use browsing2.php?movieID=mid-->
				<!--<option value="1">A, Isabelle</option>-->
				<option value="-1"></option>
				<?php
					//Create the drop-down table of actors
					
					if (!$_GET["orderby"])
						$orderby="last";
					else
						$orderby=$_GET["orderby"];

					//DEBUG:
					$getAllActors="SELECT * FROM Actor ORDER BY $orderby";
					//$getAllActors="SELECT * FROM Actor WHERE id < 100 ORDER BY $orderby";
					
					if ($mySQL)
					{
						$resource = mysql_query($getAllActors, $mySQL);
						
						if ($resource)
						{
							$row = mysql_fetch_row($resource);
							while ($row)
							{
								$defaultSelection="";
								if ($aid==$row[0])
									$defaultSelection="selected='selected'";
								

								if ($_GET["orderby"] == "first")
									echo "<option value=$row[0] $defaultSelection>$row[2] $row[1], ($row[4])</option>\n";
								else
									echo "<option value=$row[0] $defaultSelection>$row[1], $row[2], ($row[4])</option>\n";
								$row = mysql_fetch_row($resource);								
							}							
						}
						else
							echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
					}
					
				?>
			</select>
			<input type="submit" value="Select" />
		</form>
	</td>
	</tr>
	</table>
</body>
