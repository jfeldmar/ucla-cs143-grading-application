<html>
<head>
	<title>Browse Movies<?php
		$movieID = $_GET["movieID"];
		$rName = $_POST["reviewName"];
		$rRating = $_POST["reviewRating"];
		$rComment = $_POST["reviewComment"];
		$db_name = "CS143";
		$endl = "\n";
		
		$rComment = htmlspecialchars($rComment, ENT_QUOTES);
		$rName = htmlspecialchars($rName, ENT_QUOTES);
		
		$mySQL = mysql_connect("localhost","cs143","");
		
		if($mySQL)
		{
			mysql_selectdb($db_name, $mySQL);
			$indexResource = mysql_query("SELECT id, title, year FROM Movie ORDER BY title", $mySQL);
			$movieResource = mysql_query("SELECT * FROM Movie WHERE id = $movieID", $mySQL);
			$genreResource = mysql_query("SELECT genre FROM MovieGenre WHERE mid = $movieID", $mySQL);
			$directorResource = mysql_query("SELECT first, last FROM MovieDirector, Director WHERE mid = $movieID AND id = did", $mySQL);
			$actorResource = mysql_query("SELECT aid, first, last, role FROM MovieActor, Actor WHERE mid = $movieID AND id = aid", $mySQL);
						
			//$movie = mysql_fetch_row($movieResource);
			//$genre = mysql_fetch_row($genreResource);
			//$movie = mysql_fetch_row($movieResource);	
			
			if($movieResource)
				$movie = mysql_fetch_row($movieResource);
						
			$id = $movie[0];
			$title = $movie[1];
			$year = $movie[2];
			$rating = $movie[3];
			$producer = $movie[4];
						
			$successfulPost = mysql_query("INSERT INTO Review VALUES('$rName', '".date('Y-m-d H:i:s')."', $id, $rRating, '$rComment')", $mySQL);
			$reviewResource = mysql_query("SELECT * FROM Review WHERE mid = $movieID", $mySQL);
			$reviewAvgResource = mysql_query("SELECT AVG(rating) FROM Review WHERE mid = $movieID", $mySQL);
			
			if($reviewAvgResource)
				$reviewAvg = mysql_fetch_row($reviewAvgResource);
			
			$avg = $reviewAvg[0];
			
			if($movie)
				echo ": $title";
		}
		?>
		
		
		
	</title>
</head>
<body style="margin:0;">
	<table width="100%" height="100%" cellspacing=0 cellpadding=15>
	<tr><td bgcolor="yellow" valign="top" width="200px">
		<table>
		<tr><td>Add New Content
			<ul>
				<li><a href="input1.php">Add Actor/Director</a></li>
				<li><a href="input2.php">Add Movie Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Browsing Content
			<ul>
				<li><a href="browsing1.php">Show Actor Information</a></li>
				<li>Show Movie Information</a></li>
				<li><a href="browsing3.php">Show Director Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Search Actors/Movies
			<ul style="list-style-type: none; padding-left: 25px;">
				<li>
					<form action="search1.php" method="GET">
						<input type="text" name="query">
						<input type="submit" name="navSearchSubmit" value="Search"/>
					</form>
				</li>
			</ul>
		</td></tr>
		</table>
	</td>
	<td bgcolor="skyblue" valign="top">
		<table>
		<tr><td>
		
	<h3>Look for Actor Information</h3>
	<p><form action="Browsing2.php" method="GET">
	
	<?php
		echo "Movie: <select  name = 'movieID'>";
		
		while($index = mysql_fetch_row($indexResource))
		{
			echo "<option value = '$index[0]'>$index[1] ($index[2])</option>";
		}
						
		echo "</select>";
	?>
	
		<input type="submit" value="Submit" />
		</form>	</p>
	
	<?php
	if($_GET["movieID"])
	{		
		if($mySQL)
		{
			if($movieResource && $movie)
			{
				echo "<h2><big>$title</big> <small>($year)</small></h2> 
				<p>User rating: ";
				
				if($avg)
					echo "$avg out of 5</p>";
				else
					echo "No user ratings yet.</p>";				
				
				if($director = mysql_fetch_row($directorResource))			//do first director
				{
					echo "Directed by $director[0] $director[1]";
									
					while($director = mysql_fetch_row($directorResource))			//subsequent directors
					{
						echo ", $director[0] $director[1]";
					}
					echo "<br>";
				}
					 
				echo "Produced by $producer <br>";
						
				if($genre = mysql_fetch_row($genreResource))			//do first genre
				{
					echo "Genre: $genre[0]";
									
					while($genre = mysql_fetch_row($genreResource))			//subsequent genres
					{
						echo ", $genre[0]";
					}
					
					echo "<br>";
				}				
						
				echo "Rated $rating </p>";
						
				echo "<h3>Cast</h3>";
				
				while($actor = mysql_fetch_row($actorResource))			//actors
				{
					echo "<a href=\"./browsing1.php?actorID=$actor[0]\">$actor[1] $actor[2]</a> ... $actor[3]<br>";
				}
				
				echo "<h3>Reviews:</h3>";
				
				while($review = mysql_fetch_row($reviewResource))			//reviews
				{
					echo "<p><strong>At $review[1], $review[0] rated this movie a $review[3] out of 5 and said: </strong><br>
						$review[4]</p>";
				}
				
				echo "<p><strong>Post a review</strong><br>
						<form action= 'Browsing2.php?movieID=$id' method= 'POST' >
							Name:   <input type = 'text' name= 'reviewName'> </input>
							Rating: <select  name = 'reviewRating'>
									<option value = '0'>0</option>
									<option value = '1'>1</option>
									<option value = '2'>2</option>
									<option value = '3'>3</option>
									<option value = '4'>4</option>
									<option value = '5'>5</option>
									</select> out of 5<br>

							Comment:<br><textarea name = 'reviewComment' cols= '60' rows= '8'></textarea>	<input type= 'submit' value= 'Submit' />";
				
				if($successfulPost)
					echo "<strong>Post successful!</strong>";
						
					echo "</form></p>";				
			}
				
			else
				echo "<p>mySQL Error: <em>".mysql_error()."</em>".$endl;
		}
		else
			echo "Error".$endl;
		mysql_close($mySQL);
	}
	?>
	
	</td></tr>
		</table>
	</td>
	</tr>
	</table>
</body>

</html>