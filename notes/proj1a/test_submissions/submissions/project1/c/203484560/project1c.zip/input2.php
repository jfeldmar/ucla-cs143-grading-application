<html>
<head>
	<title>Add Movie Information</title>
	
	<?php
		$title = $_POST["title"];
		$year = $_POST["year"];
		$rating = $_POST["rating"];
		$company = $_POST["company"];
		$directorID = $_POST["director"];
		$action = $_POST["genre_Action"];
		$adult = $_POST["genre_Adult"];
		$adventure = $_POST["genre_Adventure"];
		$animation = $_POST["genre_Animation"];
		$biography = $_POST["genre_Biography"];
		$comedy = $_POST["genre_Comedy"];
		$crime = $_POST["genre_Crime"];
		$documentary = $_POST["genre_Documentary"];
		$drama = $_POST["genre_Drama"];
		$family = $_POST["genre_Family"];
		$fantasy = $_POST["genre_Fantasy"];
		$horror = $_POST["genre_Horror"];
		$musical = $_POST["genre_Musical"];
		$mystery = $_POST["genre_Mystery"];
		$romance = $_POST["genre_Romance"];
		$scifi = $_POST["genre_Sci-Fi"];
		$short = $_POST["genre_Short"];
		$thriller = $_POST["genre_Thriller"];
		$war = $_POST["genre_War"];
		$western = $_POST["genre_Western"];
		$db_name = "CS143";
		$endl = "\n";
		
		$title = htmlspecialchars($title, ENT_QUOTES);
		$company = htmlspecialchars($company, ENT_QUOTES);
		
		$mySQL = mysql_connect("localhost","cs143","");
		mysql_selectdb($db_name, $mySQL);
	
		$maxMovieIDResource = mysql_query("SELECT * FROM MaxMovieID", $mySQL);
		$directorResource = mysql_query("SELECT id, last, first FROM Director ORDER BY last", $mySQL);
		
		$newMovieID = mysql_fetch_row($maxMovieIDResource);
		
		if($title)
		{
			$successfulAdd = mysql_query("INSERT INTO Movie VALUES($newMovieID[0], '$title', $year, '$rating', '$company')", $mySQL);
			
			if($successfulAdd)
			{
				mysql_query("UPDATE MaxMovieID SET id = id+1", $mySQL);
				
				mysql_query("INSERT INTO MovieDirector VALUES($newMovieID[0], $directorID)", $mySQL);
				
				if($action)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$action')", $mySQL);
					
				if($adult)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$adult')", $mySQL);
					
				if($adventure)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$adventure')", $mySQL);
					
				if($animation)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$animation')", $mySQL);
					
				if($biography)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$biography')", $mySQL);
					
				if($comedy)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$comedy')", $mySQL);
					
				if($crime)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$crime')", $mySQL);
					
				if($documentary) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$documentary')", $mySQL);
					
				if($drama)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$drama')", $mySQL);
					
				if($family)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$family')", $mySQL);
					
				if($fantasy) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$fantasy')", $mySQL);
					
				if($horror)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$horror')", $mySQL);
					
				if($musical)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$musical')", $mySQL);
					
				if($mystery)
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$mystery')", $mySQL);
					
				if($romance) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$romance')", $mySQL);
					
				if($scifi) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$scifi')", $mySQL);
					
				if($short) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$short')", $mySQL);
					
				if($thriller) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$thriller')", $mySQL);
					
				if($war) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$war')", $mySQL);
					
				if($western) 
					mysql_query("INSERT INTO MovieGenre VALUES($newMovieID[0], '$western')", $mySQL);
			}
		}
	?>
	
</head>
<body style="margin:0;">
	<table width="100%" height="100%" cellspacing=0 cellpadding=15>
	<tr><td bgcolor="yellow" valign="top" width="200px">
		<table>
		<tr><td>Add New Content
			<ul>
				<li><a href="input1.php">Add Actor/Director</a></li>
				<li>Add Movie Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Browsing Content
			<ul>
				<li><a href="browsing1.php">Show Actor Information</a></li>
				<li><a href="browsing2.php">Show Movie Information</a></li>
				<li><a href="browsing3.php">Show Director Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Search Actors/Movies
			<ul style="list-style-type: none; padding-left: 25px;">
				<li>
					<form action="search1.php" method="GET">
						<input type="text" name="query">
						<input type="submit" name="navSearchSubmit" value="Search"/>
					</form>
				</li>
			</ul>
		</td></tr>
		</table>
	</td>
	<td bgcolor="skyblue" valign="top">
		<table>
		<tr><td>
		<h3>Add New Movie</h3>
		
		<form action= 'input2.php' method= 'POST' ><table border = 2>  
		<tr><td><font color='red'>*</font>Movie Title:</td><td><input type = 'text' name= 'title'></td></tr>
		
		<tr><td>Release Year:</td><td><input type = 'text' maxlength = 4 name= 'year'></td></tr>
		
		<tr><td>Director:</td><td><select  name = 'director'>
			<?php
				while($director = mysql_fetch_row($directorResource))
				{
					echo "<option value = '$director[0]'>$director[1], $director[2]</option>";
				}
			?>
		</select></td></tr>
									
		<tr><td>Production Company:</td><td><input type = 'text' name= 'company'></td></tr>
		
		<tr><td>MPAA Rating:</td><td><select  name = 'rating'>
									<option value = 'G'>G</option>
									<option value = 'PG'>PG</option>
									<option value = 'PG-13'>PG-13</option>
									<option value = 'R'>R</option>
									<option value = 'NC-17'>NC-17</option>
									</select></td></tr>
		<tr><td>Genre:</td>
		<td>
		<table>
		<tr><td><input type="checkbox" name="genre_Action" value="Action">Action</input></td>
		<td><input type="checkbox" name="genre_Adult" value="Adult">Adult</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input></td>
		<td><input type="checkbox" name="genre_Animation" value="Animation">Animation</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Biography" value="Biography">Biography</input></td>
		<td><input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Crime" value="Crime">Crime</input></td>
		<td><input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Drama" value="Drama">Drama</input></td>
		<td><input type="checkbox" name="genre_Family" value="Family">Family</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input></td>
		<td><input type="checkbox" name="genre_Horror" value="Horror">Horror</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Musical" value="Musical">Musical</input></td>
		<td><input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Romance" value="Romance">Romance</input></td>
		<td><input type="checkbox" name="genre_Sci-Fi" value="Sci-Fi">Sci-Fi</input></td></tr>
		<tr><td><input type="checkbox" name="genre_Short" value="Short">Short</input></td>
		<td><input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input></td></tr>
		<tr><td><input type="checkbox" name="genre_War" value="War">War</input></td>
		<td><input type="checkbox" name="genre_Western" value="Western">Western</input></td></tr>
		</td></tr>
		</table>
		
		</table>
		<input type= 'submit' value= 'Submit' />
		</form>		
	<p><small><font color='red'>*</font> indicates required field</small></p>
	
	<?php
		if($successfulAdd)
			echo "<strong>Movie successfully added!</strong>";
	?>
	
	</td></tr>
		</table>
	</td>
	</tr>
	</table>
</body>

</html>