<html>
<head>
	<title>Add Actor/Director</title>
</head>

<body style="margin:0;">
	<table width="100%" height="100%" cellspacing=0 cellpadding=15>
	<tr><td bgcolor="yellow" valign="top" width="200px">
		<table>
		<tr><td>Add New Content
			<ul>
				<li>Add Actor/Director</li>
				<li><a href="input2.php">Add Movie Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Browsing Content
			<ul>
				<li><a href="browsing1.php">Show Actor Information</a></li>
				<li><a href="browsing2.php">Show Movie Information</a></li>
				<li><a href="browsing3.php">Show Director Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Search Actors/Movies
			<ul style="list-style-type: none; padding-left: 25px;">
				<li>
					<form action="search1.php" method="GET">
						<input type="text" name="query">
						<input type="submit" name="navSearchSubmit" value="Search"/>
					</form>
				</li>
			</ul>
		</td></tr>
		</table>
	</td>
	<td bgcolor="skyblue" valign="top">
		<table>
		<tr><td>
			<h3>Add New Actor/Director</h3>
		<form action="input1.php" method="GET">
			<table align="center" border="1">
			<tr valign=middle>
				<td>
					Identity:
				</td>
				<td>
					<select name="actorOrDirector">
						<option value="actor">Actor</option>
						<option value="director">Director</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					<font color='red'>*</font> Last Name:
				</td>
				<td>
					<input type="text" name="lastName" />
				</td>
			<tr>
				<td>
					First Name:
				</td>
				<td>
					<input type="text" name="firstName" />
				</td>
			</tr>
			</tr>
			<tr>
				<td>
					Sex:
				</td>
				<td>
					<select name="sex">
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>
					Date of Birth:
				</td>
				<td>
					<input type="text" name="dob" />
					<small>(YYYY-MM-DD)</small>
				</td>
			</tr>
			<tr>
				<td>
					Date of Death:
				</td>
				<td>
					<input type="text" name="dod" />
					<small>(leave blank if still living)</small>
				</td>
			</tr>
			<tr>
				<td>
					&nbsp;
				</td>
				<td>
					<input type="submit" name="done" value="Add Actor/Director"/>						
				</td>
			</tr>
			<?php
				$db_name = "CS143";
				
				
				if ($_GET["lastName"])
				{
					$firstName = $_GET["firstName"];
					$firstName = htmlspecialchars($firstName, ENT_QUOTES);
					$lastName = $_GET["lastName"];
					$lastName = htmlspecialchars($lastName, ENT_QUOTES);
					$sex = $_GET["sex"];
					$dob = $_GET["dob"];
					$dod = $_GET["dod"];
					$getNextID = "SELECT id FROM MaxPersonID";
					
					if ($firstName=="")	$firstName = "NULL";
					if ($sex=="")		$sex = "NULL";
					if ($dob=="")		$dob = "NULL";
					if ($dod=="")		$dod = "NULL";
					
					//$getNextID = "SELECT * FROM Actor WHERE id < 20";
					
					$mySQL = mysql_connect("localhost", "cs143", "");
					if ($mySQL)
					{
						mysql_selectdb($db_name, $mySQL);
						$nextIDResource = mysql_query($getNextID, $mySQL);
						
						if ($nextIDResource)
						{
							$row = mysql_fetch_row($nextIDResource);
							$nextID = $row[0];

							if ($_GET["actorOrDirector"]=="director")
								$resource = mysql_query("INSERT INTO Director VALUES ($nextID, '$lastName', '$firstName', '$dob', '$dod')", $mySQL);
							else
								$resource = mysql_query("INSERT INTO Actor VALUES ($nextID, '$lastName', '$firstName', '$sex', '$dob', '$dod')", $mySQL);
								
							if ($resource)
							{
								$nextID= $nextID+1;
								$resource = mysql_query("UPDATE MaxPersonID SET id=$nextID");
								if (!$resource)
									echo "<tr><td>&nbsp;</td><td>mySQL Error: <em>".mysql_error()."</em></td></tr>";
								else
									echo "<tr><td>&nbsp;</td><td>Successfully Added!</td></tr>";
							}
							else
							{
								echo "<tr><td>&nbsp;</td><td>mySQL Error: <em>".mysql_error()."</em></td></tr>";
							}
							
						}
						else
							echo "<tr><td>&nbsp;</td><td>mySQL Error: <em>".mysql_error()."</em></td></tr>";
					}
				}
			?>
			</table>
			</form>
			<p><small><font color='red'>*</font> indicates required field</small></p>
		</td></tr>
		</table>
	</td>
	</tr>
	</table>
</body>
