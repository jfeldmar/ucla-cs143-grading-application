<html>
<head>
	<?php
	$db_name = "CS143";
	$mySQL = mysql_connect("localhost", "cs143", "");
	if ($mySQL)
		mysql_selectdb($db_name, $mySQL);
	
	if ($_GET["query"])
		echo "<title>Search for ".$_GET["query"]."</title>";
	else
		echo "<title>Search for an Actor</title>";
	?>
</head>

<body style="margin:0;">
	<table width="100%" height="100%" cellspacing=0 cellpadding=15>
	<tr><td bgcolor="yellow" valign="top" width="200px">
		<table>
		<tr><td>Add New Content
			<ul>
				<li><a href="input1.php">Add Actor/Director</a></li>
				<li><a href="input2.php">Add Movie Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Browsing Content
			<ul>
				<li><a href="browsing1.php">Show Actor Information</a></li>
				<li><a href="browsing2.php">Show Movie Information</a></li>
				<li><a href="browsing3.php">Show Director Information</a></li>
			</ul>
		</td></tr>
		<tr><td>Search Actors/Movies
			<ul style="list-style-type: none; padding-left: 25px;">
				<li>
					<form action="search1.php" method="GET">
						<input type="text" name="query">
						<input type="submit" name="navSearchSubmit" value="Search"/>
					</form>
				</li>
			</ul>
		</td></tr>
		</table>
	</td>
	<td bgcolor="skyblue" valign="top">
		<h3>Search for an Actor or Movie</h3>
		<form action="search1.php" method="GET">
			<input type="text" name = "query" width="25" value="<?php echo $_GET['query']; ?>"/>
			<input type="submit" value="Search" />
		</form>
		<?php
			if ($_GET["query"])
			{
				//Separate earch keyword into its own array field
				$query=$_GET["query"];
				$searchTerms = explode(" ", strtolower($query));
				$searchTerms = array_unique($searchTerms);
				$numTerms = count($searchTerms);
				
				//TODO: Beware of punctuation!
				
				//Get a list of fields to search through
				$actorResults = array();
				$idCol = 0;		//Actor id
				$lastCol = 1;	//last name
				$firstCol = 2;	//first name
				$dobCol = 4;	//Date of birth
				
				$getActors = "SELECT * FROM Actor";
				$resource = mysql_query($getActors, $mySQL);
				
				if ($resource)
				{
					$row = mysql_fetch_row($resource);
					while($row)
					{
						$score = 0;
						$row[$lastCol] = strtolower($row[$lastCol]);
						$row[$firstCol] = strtolower($row[$firstCol]);
						for ($i = 0; $i < $numTerms; $i++)
						{
							if ($searchTerms[$i] == $row[$lastCol] || $searchTerms[$i] == $row[$firstCol])
								$score += 1;
						}
						$last = count($searchTerms)-1;
						if ($numTerms > 1 && $searchTerms[0] == $row[$lastCol] && $searchTerms[1] == $row[$firstCol])
							$score += 10;
						if ($numTerms > 1 && $searchTerms[$last] == $row[$lastCol] && $searchTerms[0] == $row[$firstCol])
							$score += 10;
							
						if ($score > 0)
							$actorResults[$row[$idCol]] = -$score;		//PHP sors in ascending order, but we want descending order
						
						$row = mysql_fetch_row($resource);
					}
				}
				else
					echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
					
				if (count($actorResults) > 0)
				{
					asort($actorResults);
					echo "<h4>Actor Results</h4>\n";
					echo "<ol>\n";
					foreach ($actorResults as $key => $val)
					{
						$getActorInfo = "SELECT * FROM Actor WHERE id=$key";
						$resource = mysql_query($getActorInfo, $mySQL);
						if ($resource)
						{
							$row = mysql_fetch_row($resource);
							echo "<li><a href='browsing1.php?actorID=$row[$idCol]'>$row[$lastCol], $row[$firstCol]</a> ($row[$dobCol])</li>";
						}
						else
							echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
					}
					echo "</ol>\n";
				}
				
				$directorResults = array();
				
				//Get a list of movies to search through
				$movieResults = Array();
				$idCol = 0;		//Movie id
				$titleCol = 1;	//last name
				$yearCol = 2;	//first name
				
				for ($i = 0; $i < $numTerms; $i++)
				{
					$getMovies = "SELECT * FROM Movie WHERE title LIKE '% $searchTerms[$i] %' OR title LIKE '$searchTerms[$i] %' OR title LIKE '% $searchTerms[$i]' OR title LIKE '$searchTerms[$i]'";
					$resource = mysql_query($getMovies, $mySQL);
				
					if ($resource)
					{
						$row = mysql_fetch_row($resource);
						while ($row)
						{
							if ($movieResults[$row[$idCol]])
								$movieResults[$row[$idCol]] -= 1;
							else
								$movieResults[$row[$idCol]] = -1;
							$row = mysql_fetch_row($resource);
						}
					}
				}
					
				if (count($movieResults) > 0)
				{
					asort($movieResults);
					echo "<h4>Movie Results</h4>\n";
					echo "<ol>\n";
					foreach ($movieResults as $key => $val)
					{
						$getMovieInfo = "SELECT * FROM Movie WHERE id=$key";
						$resource = mysql_query($getMovieInfo, $mySQL);
						if ($resource)
						{
							$row = mysql_fetch_row($resource);
							echo "<li><a href='browsing2.php?movieID=$row[$idCol]'>$row[$titleCol]</a> ($row[$yearCol])</li>";
						}
						else
							echo "<p>mySQL Error: <em>".mysql_error()."</em>\n";
					}
					echo "</ol>\n";
				}

				if (count($actorResults)+count($directorResults) + count($movieResults) == 0)
					echo "<p>No results found.  Please try again.</p>\n";

			}
		?>
	</td>
	</tr>
	</table>
</body>
