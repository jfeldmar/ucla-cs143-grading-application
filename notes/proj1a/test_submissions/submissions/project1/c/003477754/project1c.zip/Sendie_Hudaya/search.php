<html>
	<head>
		<title>Search</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		Search: 
		<form action="./search.php" method="GET">
		<input type="text" name="searchQuery" maxlength="30">
		<br/>
		<input type="submit" value="Search">
		</form>
	
		<!-- execute search --> 
		<?php
		
			if($_GET["searchQuery"])
			{
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
						
				$a = explode(" ",$_GET["searchQuery"]) ;
											
				$queryActor = "SELECT id, last, first, dob FROM Actor WHERE ";
				$queryMovie = "SELECT id, title, year FROM Movie WHERE title LIKE \"%". $_GET["searchQuery"]. "%\"  ";
				
				$a_size = count($a);
				
				//Match first and last for every word
				foreach ($a as $value)
				{
					if($a_size == 1)
						$queryActor = $queryActor. "(last like \"%". $value. "%\" OR first like \"%". $value ."%\") ";
					else
						$queryActor = $queryActor. "(last like \"%". $value. "%\" OR first like \"%". $value ."%\") AND ";
					
					$a_size = $a_size - 1;
				}
					
				$rsActor = mysql_query($queryActor, $db_connection);	 
				$rsMovie = mysql_query($queryMovie, $db_connection);
				
				
				if(!$Actor && !$rsMovie)
				{
					echo mysql_error();
					exit;
				}				
							
							
				//***** Start outputing query result ******
				
				echo "<hr>"; 
				echo "Search results for: <u>". $_GET["searchQuery"]. "</u><br><br>";
								
				//Actors
				if( mysql_num_rows($rsActor) == 0)
				{	
					echo "Found no matching record in Actor table. <br>";
				}
				else
				{
					echo "Matching records in Actor table: <br>";
					
					while($row = mysql_fetch_row($rsActor))
					{
						echo "<a href = \"./showActorInfo.php?aid=". $row[0]. "\">". $row[1]. " ". $row[2]. " (". $row[3]. ")</a> <br>";					
					}
				}
				echo "<br>";
			
				//Movies
				if( mysql_num_rows($rsMovie) == 0)
				{
					echo "Found no matching record in Movie table. <br>";
				}
				else
				{
					echo "Matching records in Movie table: <br>";
					while($row = mysql_fetch_row($rsMovie))
					{
						echo "<a href = \"./showMovieInfo.php?mid=". $row[0]. "\">". $row[1]. " (". $row[2]. ")</a> <br>";					
					}
					
				}
			
				mysql_close($db_connection);
		
			}
			else
			{
				echo "Please enter a search query.";
			}
			
		?>
	
	
	</body>
</html>