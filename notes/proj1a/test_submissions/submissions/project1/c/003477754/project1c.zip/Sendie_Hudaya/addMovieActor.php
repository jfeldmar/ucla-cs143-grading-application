<html>
	<head>
		<title>Add Movie Actor</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		Add a new actor role to a movie: <br>
		<form action="./addMovieActor.php" method="GET">
		<table>
			<tr>
				<td>
					Movie: 
				</td>
				<td>
				
					<select name="mid">
					<!-- Populate dropdown menu with movies and select mid -->
					<?php
					
						$db_connection = mysql_connect("localhost", "cs143", "");
						mysql_select_db("CS143",$db_connection);
						
						//four attributes: id, title, and year 
						$query = "SELECT id, title, year FROM Movie GROUP BY title;";
						$rs = mysql_query($query, $db_connection);
						
						if(!$rs)
						{
							echo mysql_error();
							exit;
						}		
						
						//lengths is the number of columns returned in result set $rs 
						//$lengths = mysql_num_fields($rs);
													
						//populate dropdown menu with movie titles and year
						while($row = mysql_fetch_row($rs)) 
						{
							echo "<option value=". $row[0]; 
									
							if($_GET["mid"] == $row[0] )
								echo " SELECTED> ";
							else
								echo "> ";
								
							echo $row[1]. " (". $row[2]. ") </option>";
						}

						mysql_close($db_connection);
						
					?>
				</td>
			</tr>
		
			<tr>
				<td>
					Actor/Actress: 
				</td>
				<td>				
					<select name="aid">
					<!-- Populate dropdown menu with actors and select aid -->
					<?php
					
						$db_connection = mysql_connect("localhost", "cs143", "");
						mysql_select_db("CS143",$db_connection);
						
						//four attributes: id, first and last name, and date of birth 
						$query = "SELECT id, first, last, dob FROM Actor GROUP BY first, last;";
						$rs = mysql_query($query, $db_connection);
						
						if(!$rs)
						{
							echo mysql_error();
							exit;
						}		
						
						//populate dropdown menu with actor names and date of birth
	
						while($row = mysql_fetch_row($rs)) 
						{	
							echo "<option value=". $row[0]; 
									
							if($_GET["aid"] == $row[0] )
								echo " SELECTED> ";
							else
								echo "> ";
								
							echo $row[1]. " ". $row[2]. " (". $row[3]. ") </option>";
										
						}

						mysql_close($db_connection);
				
					?>
				</td>
			</tr>
			
			<tr>
				<td>
					Role: 
				</td>
				<td>
					<input type="" name="role">
				</td>
			</tr>
		</table>
		
		<input type="submit" value="Add role" />
		</form>
		
		<?php 
			
			if($_GET["aid"] && $_GET["mid"] && $_GET["role"])
			{
				
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
				
				//four attributes: id, first and last name, and date of birth 
				$query = "INSERT INTO MovieActor VALUES(". $_GET["mid"]. ", ". $_GET["aid"]. ", \"". $_GET["role"]. "\")";
				$rs = mysql_query($query, $db_connection);
				
				//echo $query;
				
				echo "<hr>";
				
				if($rs == NULL)
				{
					echo "Insertion Failed!";
				}
				else
				{
					echo "Insertion Success!";
				}
				
				
				mysql_close($db_connection);
			}
			else
			{
				echo "<hr>";
				echo "Please note that role may not be empty.";
			}
		
		?>
	
	
	</body>
</html>