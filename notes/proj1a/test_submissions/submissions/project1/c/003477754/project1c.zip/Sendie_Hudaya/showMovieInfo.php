<html>
	<head>
		<title>Show Movie Info</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		<!--  Display information about the selected movie -->
		<?php
			
			//If a movie id is selected
			if($_GET["mid"])
			{
			
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
			
				//Get information about movie
				$query 	= "SELECT title, year, company, rating 
						   FROM Movie 
						   WHERE id = ". $_GET["mid"];
				$query2 = "SELECT genre 
						   FROM MovieGenre 
						   WHERE mid = ". $_GET["mid"];
				$query3 = "SELECT first, last, dob 
					       FROM Director 
						   WHERE id IN (SELECT did 
						                FROM MovieDirector 
										WHERE mid = ".$_GET["mid"]. ")";
				
				$rs  = mysql_query($query, $db_connection);
				$rs2 = mysql_query($query2, $db_connection);
				$rs3 = mysql_query($query3, $db_connection);
				
				if(!$rs || !$rs2 || !$rs3)
				{
					echo mysql_error();
					exit;
				}	
				
				while($row1 = mysql_fetch_row($rs)) 
				{	
					$title = $row1[0];
					$year = $row1[1];
					$producer = $row1[2];
					$rating = $row1[3];
				}	
									
				while($row3 = mysql_fetch_row($rs3)) 
				{	
					$first = $row3[0];
					$last  = $row3[1];
					$dob   = $row3[2];
				}	

				//SHOW MOVIE INFO
				echo " -- Show Movie Info -- <br>";					
				echo "Title: ". $title. " (". $year. ")<br>";
				echo "Producer: ". $producer. "<br>";
				echo "MPAA Rating: ". $rating. "<br>";
				
				//Check if a tuple is returned from Director table
				if( mysql_num_rows($rs3) == 0 )
					echo "Director: N/A<br>";
				else
					echo "Director: ". $first. " ". $last. " (". $dob. ")<br>";
				
				echo "Genre: ";
					
				//Get the number of genres returned
				$genreCounter = mysql_num_rows($rs2);	
													
				if($genreCounter == 0)
					echo "N/A";		
				
				while($row2 = mysql_fetch_row($rs2)) 
				{	
					if($genreCounter > 1)
						echo $row2[0]. ", ";
					else 
						echo $row2[0];
					
					$genreCounter = $genreCounter - 1;
				}	
				
				echo "<br>";
				
				//Get the actor info
				$query_Actor = "SELECT id, first, last, role 
								FROM Actor, (SELECT aid, role 
											 FROM MovieActor
											 WHERE mid = ". $_GET["mid"]. ") Actor2
								WHERE Actor.id = Actor2.aid";
				
				$rs_Actor = mysql_query($query_Actor, $db_connection);
				
				if(!$rs_Actor)
				{
					echo mysql_error();
					exit;
				}	
				
				//ACTOR IN THIS MOVIE
				echo "<br>";
				echo " -- Actor in this movie -- <br>";
				
				if( mysql_num_rows($rs_Actor) == 0)
					echo "No role is currently assigned.  <a href=\"./addMovieActor.php\"> Add a role </a><br>";
				
				while($row = mysql_fetch_row($rs_Actor))
				{
					echo "<a href=\"./showActorInfo.php?aid=". $row[0]. "\">". $row[1]. " ". $row[2]. "</a> act as \"". $row[3]. "\"<br>"; 
				}

				//Get avg review
				$query_avg = "SELECT AVG(rating)
									 FROM Review";
				//Get reviews
				$query_review = "SELECT time, name, rating, comment 
								 FROM Review WHERE mid = ". $_GET["mid"];
								
				$rs_avg	   = mysql_query($query_avg, $db_connection);
				$rs_review = mysql_query($query_review, $db_connection);
				
				if(!$rs_review || !$rs_avg)
				{
					echo mysql_error();
					exit;
				}	
				//Check there are no tuples returned				
				$review_tuples = mysql_num_rows($rs_review);
					
				//USER REVIEW
				echo "<br>";
				echo " -- User Review -- <br>";	
				echo "Average Score: "; 
				if( $review_tuples == 0 )
				{
					echo "(Sorry, but no one has submitted a review yet). <a href=\"./addComment.php?mid=". $_GET["mid"]. "\">Add your comment </a><br>";
					echo "Comments for this movie: <br>";
				}
				else
				{

					while($avg = mysql_fetch_row($rs_avg))
					{
						echo $avg[0]. "/5 (5.0 is best) by ". $review_tuples. " reviewer(s). <a href=\"./addComment.php\">Add your comment </a><br>";
					}
					
					echo "Comments for this movie: <br><br>";	
					
					while($row = mysql_fetch_row($rs_review))
					{
						echo "In ". $row[0]. ", ". $row[1]. " rates this movie ". $row[2]. " point(s). <br> ";
						echo $row[3]. "<br><br>";
					}
				
				}
	
				echo "<hr>";				
				mysql_close($db_connection);
			}
		
		?>
	
		<form action="./showMovieInfo.php" method="GET">
		Select a movie for more information: <select name="mid">
		<!-- Populate dropdown menu with movies and select mid -->
		<?php
		
			$db_connection = mysql_connect("localhost", "cs143", "");
			mysql_select_db("CS143",$db_connection);
			
			//four attributes: id, title, and year 
			$query = "SELECT id, title, year FROM Movie GROUP BY title, year;";
			$rs = mysql_query($query, $db_connection);
			
			if(!$rs)
			{
				echo mysql_error();
				exit;
			}		
			
			//lengths is the number of columns returned in result set $rs 
			$lengths = mysql_num_fields($rs);
			
			//populate dropdown menu with movie titles and year
			while($row = mysql_fetch_row($rs)) 
			{
				echo "<option value=". $row[0]; 
						
				if($_GET["mid"] == $row[0] )
					echo " SELECTED> ";
				else
					echo "> ";
					
				echo $row[1]. " (". $row[2]. ") </option>";
			}

			mysql_close($db_connection);
	
		?>
		
		<br>		
		<input type="submit" value="Submit" />
		
		</form>
		
		
	</body>
	
</html>