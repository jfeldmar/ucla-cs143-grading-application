<html>
	<head>
		<title>Add Movie Info</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		Add new movie:
		<form action="./addMovieInfo.php" method="GET">
			<table>
				<tr>
					<td>Title: </td>
					<td><input type="text" name="title" maxlength="20"></td>
				</tr>
				
				<tr>
					<td>Company: </td>
					<td><input type="text" name="company" maxlength="50"></td>
				</tr>
			
				<tr>
					<td>Year: </td>
					<td><input type="text" name="year" maxlength="4"></td>
				</tr>
			
				<tr>
					<td>Director: </td>
					<td>
						<select name="did">
						
						<!-- populate director table -->
						<?php
							
							$db_connection = mysql_connect("localhost", "cs143", "");
							mysql_select_db("CS143",$db_connection);
						
							//four attributes: id, title, and year 
							$query = "SELECT id, last, first, dob FROM Director GROUP BY last, first;";
							$rs = mysql_query($query, $db_connection);	
						
							if(!$rs)
							{
								echo mysql_error();
								exit;
							}	
							
							//populate dropdown menu with actor names and date of birth
							while($row = mysql_fetch_row($rs)) 
							{
								echo "<option value=". $row[0]. "> ". $row[1]. " ". $row[2]. " (". $row[3]. ") </option>";
							}
							
							mysql_close($db_connection);						
						?>
					</td>
				</tr>
				
				
				<tr>
					<td>MPAA Rating: </td>
					<td>
						<select name="mpaaRating">					
							<option value="G"> 		G 		</option>
							<option value="PG">		PG 		</option>
							<option value="PG-13"> 	PG-13 	</option>
							<option value="R"> 		R 		</option>
							<option value="NC-17"> 	NC-17	</option>
					</td>
				</tr>
			</table>
			
			<table>
			
				<tr>
					<td ROWSPAN=3>Genre: </td>
					
						<td><input type="checkbox" name="genre[]" 	value="Action">		Action</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Adult">		Adult</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Adventure">	Adventure</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Animation">	Animation</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Comedy">		Comedy</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Crime">		Crime</input></td>
				</tr>
				<tr>					
						<td><input type="checkbox" name="genre[]" 	value="Documentary">Documentary</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Drama">		Drama</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Family">		Family</input></td>
						<td><input type="checkbox" name="genre[]"	value="Fantasy">	Fantasy</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Horror">		Horror</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Musical">	Musical</input></td>
				</tr>
				<tr>
						<td><input type="checkbox" name="genre[]" 	value="Mystery">	Mystery</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Romance">	Romance</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Sci-Fi">		Sci-Fi</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Short">		Short</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Thriller">	Thriller</input></td>
						<td><input type="checkbox" name="genre[]" 	value="War">		War</input></td>
						<td><input type="checkbox" name="genre[]" 	value="Western">	Western</input></td>
				</tr>
-	
	</table>
	
		<input type="submit" value="Submit" />
		</form>
		
		
		<!--  Execute query -->
		<?php
			
			if($_GET["title"] && $_GET["year"] && $_GET["did"])
			{
				echo "<hr>";
			
				//***** Error Checking *****
				if(is_numeric($_GET["year"]))
				{
					$year = intval($_GET["year"]);
					if($year < 0 || $year > 2100)
					{
						echo "Please enter a valid year.<br>";
					}
					else
					{
						$db_connection = mysql_connect("localhost", "cs143", "");
						mysql_select_db("CS143",$db_connection);
					
					
						//***** Retrieve MovieID *****
						$queryMaxMovieID = "SELECT * FROM MaxMovieID";
						$rsMovieID		 = mysql_query($queryMaxMovieID, $db_connection);
						
						if(!$rsMovieID)
						{
							echo mysql_error();
							exit;
						}	
						
						$maxMovieID;
						
						while($row = mysql_fetch_row($rsMovieID))
						{
							$maxMovieID = $row[0];
						}
						
						
						//***** Add Movie *****
						$addMovie = "INSERT INTO Movie VALUES (". ($maxMovieID+1). ",\"". $_GET["title"]. "\", ". $_GET["year"]. ",\"".
																 $_GET["mpaaRating"]. "\",\" ". $_GET["company"] ."\")";
																 
						//echo $addMovie. "<br>";
						$rsMovie = mysql_query($addMovie, $db_connection);
						
						if(!rsMovie)
						{
							echo mysql_error();
							exit;
						}	
						
						
						//**** Add MovieDirector *****
						$addDirector = "INSERT INTO MovieDirector VALUES (". ($maxMovieID+1). ",". $_GET["did"]. ")";
						
						//echo $addDirector. "<br>";
						$rsDirector = mysql_query($addDirector, $db_connection);
						
						if(!rsDirector)
						{
							echo mysql_error();
							exit;
						}	
						
						
						//***** Add MovieGenre  *****
						$addGenreProto = "INSERT INTO MovieGenre VALUES(". ($maxMovieID+1). ",";
										
						if( count($_GET["genre"]) > 0)
						{
							foreach ($_GET["genre"] as $value)
							{
								$addGenre = $addGenreProto. "\"". $value. "\")";
								
								//echo $addGenre. "<br>";
								$rsGenre = mysql_query($addGenre, $db_connection);
						
								if(!rsGenre)
								{
									echo mysql_error();
									exit;
								}	
							}	 
						}
						else
						{
							$addGenre = "INSERT INTO MovieGenre (mid) VALUES (". ($maxMovieID+1). ")";
							
							//echo $addGenre;
							
							$rsGenre = mysql_query($addGenre, $db_connection);
						
							if(!rsGenre)
							{
								echo mysql_error();
								exit;
							}	
						}
									
									
						//***** Update MaxMovieID *****
						$updateMaxMovieID = "UPDATE MaxMovieID SET id = ". ($maxMovieID+1). " WHERE id = ". $maxMovieID; 
	
						//echo $updateMaxMovieID. "<br>";
						$rsUpdate = mysql_query($updateMaxMovieID, $db_connection);
						if(!$rsUpdate)
						{
							echo mysql_error();
							exit;
						}	
						
									
						mysql_close($db_connection);
						
						echo "<hr>";
						echo "Add successfull! <br>";
						echo "<a href=\"./addMovieActor.php?mid=". ($maxMovieID+1). "\"> Add Movie/Actor relation </a><br>";
						echo "<a href=\"./showMovieInfo.php?mid=". ($maxMovieID+1). "\"> Go to Movie Info </a><br>";
					}
				}
				else
				{
					echo "Please enter a valid year.<br>";
				}
			}
			else
			{
				echo "Please enter all the necessary information.";
			}
			
		?>
		
		
	</body>
</html>