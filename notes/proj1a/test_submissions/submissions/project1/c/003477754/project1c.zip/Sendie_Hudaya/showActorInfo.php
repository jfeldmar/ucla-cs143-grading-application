<html>
	<head>
		<title>Show Actor Info</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		<?php
			
			//If an actor id is selected
			if($_GET["aid"])
			{
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
			
				//Get more info to display for selected actor id
				$query = "SELECT first, last, sex, dob, dod FROM Actor WHERE id = ". $_GET["aid"];
				$rs = mysql_query($query, $db_connection);
			
				if(!$rs)
				{
					echo mysql_error();
					exit;
				}	
			
				echo " -- Show Actor Info -- <br>";
				
				while($row = mysql_fetch_row($rs)) 
				{			
				
					echo "Name: ". $row[0]. " ". $row[1]. "<br>";
					echo "Sex: ". $row[2]. "<br>";
					echo "Date of Birth: ". $row[3]. "<br>";
					
					if( $row[4] == NULL)
						echo "Date of Death: -- Still Alive -- <br><br>";
					else
						echo "Date of Death: ". $row[4]. "<br> <br>";
		
				}	
				
				//Get more info on which movies the Actor/Actress act in
				$query = "SELECT role, mid, Movie.title FROM MovieActor, Movie WHERE aid = ".$_GET["aid"]. " AND MovieActor.mid = Movie.id";	
				$rs = mysql_query($query, $db_connection);
									
				if(!$rs)
				{
					echo mysql_error();
					exit;
				}		
				
				echo " -- Act in -- <br>";
				
				if( mysql_num_rows($rs) == 0)
					echo "No acting listed. <a href=\"./addMovieActor.php?aid=". $_GET["aid"]. "\"> Add a role </a><br>";
					
					
				
				while($row = mysql_fetch_row($rs)) 
				{	
					echo "As \"". $row[0]. "\" in ". "<a href=\"./showMovieInfo.php?mid=". $row[1]. "\">". $row[2]. "</a> <br>";	
				}
				
				echo "<br> <hr>";
				mysql_close($db_connection);
			}
			
		?>
	
	
		<form action="./showActorInfo.php" method="GET">
		Select an actor for more information: 
		<table>
			<tr>
				<td>
					<select name="aid">
					<!-- Populate dropdown menu with actors and select aid -->
					<?php
					
						$db_connection = mysql_connect("localhost", "cs143", "");
						mysql_select_db("CS143",$db_connection);
						
						//four attributes: id, first and last name, and date of birth 
						$query = "SELECT id, last, first, dob FROM Actor GROUP BY last, first;";
						$rs = mysql_query($query, $db_connection);
						
						if(!$rs)
						{
							echo mysql_error();
							exit;
						}		
						
						//populate dropdown menu with actor names and date of birth
						while($row = mysql_fetch_row($rs)) 
						{
							echo "<option value=". $row[0]. "> ". $row[1]. " ". $row[2]. " (". $row[3]. ") </option>";
						}

						mysql_close($db_connection);
				
					?>
				</td>
			</tr>
			
			<tr>
				<td>
					<input type="submit" value="Submit" />
				</td>
			</tr>
		</table>
		
		</form>
		
	</body>
</html>