<html>
	<head>
		<title>Add Comment</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		Add new comment:
		<form action="./addComment.php" method="GET">
		<table>
			<tr>
				<td>Movie:</td>
				<td>
				<select name="mid">
				
					<!-- Populate dropdown menu with movies and select mid -->
					<?php
										
						$db_connection = mysql_connect("localhost", "cs143", "");
						mysql_select_db("CS143",$db_connection);
						
						//four attributes: id, title, and year 
						$query = "SELECT id, title, year FROM Movie GROUP BY title;";
						$rs = mysql_query($query, $db_connection);
						
						if(!$rs)
						{
							echo mysql_error();
							exit;
						}		
						
						//lengths is the number of columns returned in result set $rs 
						$lengths = mysql_num_fields($rs);
						
						//populate dropdown menu with movie titles and year
						while($row = mysql_fetch_row($rs)) 
						{
							echo "<option value=". $row[0]; 
							
							if($_GET["mid"] == $row[0] )
								echo " SELECTED> ";
							else
								echo "> ";
								
							echo $row[1]. " (". $row[2]. ") </option>";
						}

						mysql_close($db_connection);
						
					?>
				
				</td>
			</tr>
			
			<tr>
				<td>Your Name: </td>
				<td><input type="text" name="name" value="Mr. Anonymous" maxlength="20"></td>
			</tr>
		
			<tr>
				<td>Rating:</td>
				<td>
					<select name="rating">
					<option value="5"> 5 - Excellent </option>
					<option value="4"> 4 - Good		 </option>
					<option value="3"> 3 - Average	 </option>
					<option value="2"> 2 - Fair		 </option>
					<option value="1"> 1 - Poor		 </option>
				</td>
			</tr>
			
			<tr>
				<td>Comments:</td>
			</tr>
		
		</table>		
		
		<textarea name="comment" cols="80" rows="10"></textarea>
		<br/>
		<input type="submit" value="Add comment" />
		</form>
		
		<!-- Process insertion -->
		<?php
		
			if($_GET["name"] && $_GET["mid"] && $_GET["rating"] && $_GET["comment"])
			{
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
				
				//four attributes: id, first and last name, and date of birth 
				$query = "INSERT INTO Review (name, mid, rating, comment) 
						  VALUES(\"". $_GET["name"]. "\", ". $_GET["mid"]. ", ". $_GET["rating"]. ",\"". $_GET["comment"]. "\")";
				$rs = mysql_query($query, $db_connection);				
				
				mysql_close($db_connection);
				
				echo "<hr>";
				
				echo "Thank you for your review!<br>";
				echo "<a href=\"./showMovieInfo.php?mid=". $_GET["mid"]. "> Return to movie info </a><br>";
			}
			else 
			{
				echo "<hr>";
				
				if(!$_GET["comment"])
					echo "Please note that comment cannot be blank";
			}
			
		?>		
	
	</body>
</html>