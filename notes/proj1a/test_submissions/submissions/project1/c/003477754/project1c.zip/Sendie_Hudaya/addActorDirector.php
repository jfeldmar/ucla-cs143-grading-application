<html>
	<head>
		<title>Add Actor/Director</title>
	</head>
	
	<body bgcolor="#f0f0e0">
	
		Add new actor/director: <br>
		<form action ="./addActorDirector.php" method="GET">
			Identity: <input type="radio" name="identity" value="Actor" checked>Actor
			   		  <input type="radio" name="identity" value="Director">Director <br>
			<hr>
			
			<table>
				<tr>
					<td> First Name: </td>
					<td><input type="text" name="first" maxlength="20"></td>
				</tr>
			
				<tr>
					<td> Last Name: </td>
					<td><input type="text" name="last" maxlength="20"></td>
				</tr>
				
				<tr>
					<td> Sex: </td>
					<td><input type="radio" name="sex" value="Male" checked>Male
						<input type="radio" name="sex" value="Female">Female</td>
				</tr>
				
				<tr>
					<td></td>
					<td>Year &nbsp &nbsp Month &nbsp Day</td>
				</tr>
				
				<tr>
					<td> Date of Birth: </td>
					<td><input type="text" name="dobY" maxlength="4" size="4">
						<input type="text" name="dobM" maxlength="2" size="2">
						<input type="text" name="dobD" maxlength="2" size="3">
					</td>
				</tr>

				<tr>
					<td> Date of Death:
					<td><input type="text" name="dodY" maxlength="4" size="4">
						<input type="text" name="dodM" maxlength="2" size="2">
						<input type="text" name="dodD" maxlength="2" size="3">(leave blank if still alive)
					</td>
					
				</tr>
			
			</table>
			<input type="submit" value="Add selected">
	
		</form>
		
		
		<!--  Execute query -->
		<?php 
			echo "<hr>";
			
			if($_GET["last"] && $_GET["first"] && $_GET["dobY"] && $_GET["dobM"] && $_GET["dobD"])
			{
			
				$db_connection = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143",$db_connection);
			
				$dod;
				$dob;
				
				$deathFlag;
				//If day of death is filled
				if($_GET["dodY"] && $_GET["dodM"] && $_GET["dodD"])
				{
					$yearD 	= intval($_GET["dodY"]);
					$monthD = intval($_GET["dodM"]);
					$dayD 	= intval($_GET["dodD"]);
					
					if(checkdate($monthD, $dayD, $yearD))
					{
						$deathFlag = 1;
						$deathDate = date("Y-m-d", mktime(0, 0, 0, $monthD, $dayD, $yearD));
					}
					else
					{
						$deathFlag = 0;
					}
				}
				else
				{
					$deathFlag = 1;
					$deathDate = NULL;
				}	
					
				//Check date of birth
				$yearB	= intval($_GET["dobY"]);
				$monthB = intval($_GET["dobM"]);
				$dayB  	= intval($_GET["dobD"]);
					
				if( ($deathFlag == 1) && checkdate($monthB,$dayB,$yearB) )
				{
					$dob = date("Y-m-d", mktime(0, 0, 0, $monthB, $dayB, $yearB));
					
					//***** Retrieve PersonID *****
					$queryMaxPersonID = "SELECT * FROM MaxPersonID";
					$rsPersonID		  = mysql_query($queryMaxPersonID, $db_connection);	
						
					if(!$rsPersonID)
					{
						echo mysql_error();
						exit;
					}	
						
					$maxPersonID;
					
					while($row = mysql_fetch_row($rsPersonID))
					{
						$maxPersonID = $row[0];
					}				
					
					//echo $maxPersonID;
					
					$first = $_GET["first"];
					$last  = $_GET["last"];
					$sex   = $_GET["sex"];			
					
					//***** Actor *****			
					if($_GET["identity"] == "Actor")
					{
						$addActor = "INSERT INTO Actor ";
					
						//If there is a death date
						if($deathDate == NULL)
						{
							$addActor = $addActor. "(id, last, first, sex, dob) VALUES (". ($maxPersonID+1). ",\"". 
														$last. "\",\"". $first. "\",\"". $sex. "\",'". $dob. "')";
						}
						else
						{	
							$addActor = $addActor. "VALUES (". ($maxPersonID+1). ",\"". 
														$last. "\",\"". $first. "\",\"". $sex. "\",'". $dob. "','". $dod. "')";
						}
						
						//echo $addActor;
						
						$rsAddActor = mysql_query($addActor, $db_connection);	
						
						if(!$rsAddActor)
						{	
							echo mysql_error();
							exit;
						}	
						
						if($sex == "Male")
						{
							echo "Actor has been added to the database.<br>";
							echo "<a href=\"./showActorInfo.php?aid=". ($maxPersonID+1). "\"> Go to Actor Info </a><br>";
						}
						else
						{
							echo "Actress has been added to the database.<br>";	
							echo "<a href=\"./showActorInfo.php?aid=". ($maxPersonID+1). "\"> Go to Actress Info </a><br>";
						}						
						
					}
					else
					{
						$addDirector = "INSERT INTO Director ";
					
						//If there is a death date
						if($deathDate == NULL)
						{
							$addDirector = $addDirector. "(id, last, first, dob) VALUES (". ($maxPersonID+1). ",\"". 
														       $last. "\",\"". $first. "\",'". $dob. "')";
						}
						else
						{	
							$addDirector = $addDirector. "VALUES (". ($maxPersonID+1). ",\"". 
														       $last. "\",\"". $first. "\",'". $dob. "','". $dod. "')";
						}
						
						//echo $addDirector;
						
						$rsAddDirector = mysql_query($addDirector, $db_connection);	
						
						if(!$rsAddDirector)
						{	
							echo mysql_error();
							exit;
						}	
						
						echo "Director has been added to the database.<br>";
						
					}
					
					//***** Update MaxPersonID *****
					$updateMaxPersonID = "UPDATE MaxPersonID SET id = ". ($maxPersonID+1). " WHERE id = ". $maxPersonID; 
	
					//echo $updateMaxPersonID. "<br>";
					
					$rsUpdate = mysql_query($updateMaxPersonID, $db_connection);
					if(!$rsUpdate)
					{
						echo mysql_error();
						exit;
					}	
					
				}
				else
				{
					echo "Please enter a valid birthdate.<br>";
				}				

				mysql_close($db_connection);

			}
			else
			{
				echo "Please enter all the necessary fields.";
			}
		
		?>
				
	</body>
</html>