<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Browse Movies in the Database:</u></h2>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// query
$result = mysql_query("select * from Movie order by Title ASC", $con);

// set up a nice looking table
echo "<table border=1 cellspacing=3 cellpadding=3>
	<tr>
	<th>Title</th>
	<th>Year</th>
	<th>Rating</th>
	<th>Company</th>	
	<th>Cast</th>
	</tr>";
	
while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 5; $i++)
	{
		if ($i == 0)
			$id = $row[$i];
		if ($i == 1)
			$title = $row[$i];
		if ($i != 0)
			echo "<td>".$row[$i]."</td>";
	}
	echo "<td><a href='./movieDetail.php?id=$id&title=$title'>Movie Detail</td>";
	echo "</tr>";
}
echo "</table>";
mysql_close($con);
?>

</div>
</body>
</html>
