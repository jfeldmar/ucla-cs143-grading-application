<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Add a New Movie to the Database:</u></h2>

<form action="./addMovie.php" method="get">
<table>
<tr><td>Movie Title:</td>
<td><input type="text" name="title"></td></tr>

<tr><td>Genre:</td>
<td><input type="text" name="genre"></td></tr>

<tr><td>Year:</td>
<td><input type="text" name="year"></td></tr>

<tr><td>Company:</td>
<td><input type="text" name="company"></td></tr>

<tr><td>Rating:</td><td>
<input type="radio" name="rating" value="G">G
<input type="radio" name="rating" value="PG">PG
<input type="radio" name="rating" value="PG-13">PG-13
<input type="radio" name="rating" value="R">R
<input type="radio" name="rating" value="NC-17">NC-17
<input type="radio" name="rating" value="UR">Not Rated
</td></tr>
<tr><td><input type='submit' name='SubmitForm' value='Add Movie'></td></tr>
</form>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// get the query data
$title = $_GET['title'];
$year = $_GET['year'];
$company = $_GET['company'];
$rating = $_GET['rating'];
$genre = $_GET['genre'];

// get the max movie id
$result = mysql_query("select * from MaxMovieID", $con);
$max = mysql_fetch_array($result);
$newmax = $max[0] + 1;

// if movie data has been submitted
if(($title!=null) && ($year!=null) && ($company!=null) && ($rating!=null))
{
	// try to add the movie
	$ins = "insert into Movie VALUES ('$newmax','$title','$year','$rating','$company')";
	
	// if the insert failed
	if (!mysql_query($ins, $con))
		// display a graceful error message
		die('Invalid Values; Please try again. The error was: ' . mysql_error());
	else
	{
		// add a MovieGenre object as well
		$gen = "insert into MovieGenre VALUES ('$newmax','$genre')";
		// if the insert failed
		if (!mysql_query($gen, $con))
			// display a graceful error message
			die('Invalid Values; Please try again. The error was: ' . mysql_error());
		else
		{
			echo "<h3>Movie added successfully!</h3>";
			echo "<a href='./movieDetail.php?id=$newmax&title=$title'>Go to Movie Detail for $title</a>";
			// update the MaxMovieID
			mysql_query("update MaxMovieID set id=$newmax", $con);
		}
	}
}
mysql_close($con);
?>

</div>
</body>
</html>
