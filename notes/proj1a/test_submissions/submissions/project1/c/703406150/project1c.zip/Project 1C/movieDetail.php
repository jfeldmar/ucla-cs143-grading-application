<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Movie Detail:</u></h2>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// get the link input
$title = $_GET['title'];
$id = $_GET['id'];

// display the movie information
$result = mysql_query("select * from Movie where id=$id", $con);

// set up a nice looking table
echo "<table border='2'><tr>
	<th>Title</th>
	<th>Year</th>
	<th>Rating</th>
	<th>Company</th>
	<th>Overall Rating</th></tr>";
	
// get the overall rating
$getOverallRating = mysql_query("select AVG(rating) from Review where mid=$id", $con);
$avg = mysql_fetch_array($getOverallRating);

while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 5; $i++)
	{
		if ($i != 0)
			echo "<td>".$row[$i]."</td>";
	}
	if ($avg[0] != null)
		echo "<td>".$avg[0]."</td>";
	else
		echo "<td>No Ratings Yet</td>";
	echo "</tr>";
}
echo "</table>";

// display the name
echo "<h3>Actors that appeared in ",$title,":</h3>";

// display the actors in the movie
$result = mysql_query("
	select *
	from Actor a, MovieActor ma
	where a.id=ma.aid AND ma.mid=$id
	order by a.last ASC
	", $con);

// set up a nice looking table
echo "<table border='2'>
	<tr>
	<th>Last Name</th>
	<th>First Name</th>
	<th>Gender</th>
	<th>Date of Birth</th>
	<th>Date of Death</th>
	<th>Movies Appeared In</th>
	</tr>";
	
while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 6; $i++)
	{
		if ($i == 0)
			$id = $row[$i];
		else if ($i == 1)
			$lname = $row[$i];
		else if ($i == 2)
			$fname = $row[$i];
		if ($i != 0)
		{
			if ($row[$i] != null)
				echo "<td>".$row[$i]."</td>";
			else if ($i == 5)
				echo "<td>Still Alive</td>";
		}
	}
	echo "<td><a href='./actorDetail.php?id=$id&fname=$fname&lname=$lname'>Actor Detail</td>";
	echo "</tr>";
}
echo "</table>";

echo "<h3>Reviews for $title:";
// set up a nice looking table
echo "<table border='2'>
	<tr>
	<th>Name</th>
	<th>Date and Time Submitted</th>
	<th>Rating</th>
	<th>Comment</th>
	</tr>";

// get the current movie id
$id = $_GET['id'];

// display the reviews for this movie
$result = mysql_query("
	select *
	from Review
	where mid=$id
	order by time DESC
	", $con);

while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 5; $i++)
	{
		if ($i != 2)
			echo "<td>".$row[$i]."</td>";
	}
	echo "</tr>";
}
echo "</table>";

mysql_close($con);
?>

<h3>Review this Movie:</h3>

<table><form action='./addReview.php' method='get'>
<tr><td>Your Name:</td>
<td><input type="text" name="name"></td></tr>

<tr><td>Your Rating:</td><td>
<input type="radio" name="rating" value="5">Awesome!(5)
<input type="radio" name="rating" value="4">Good(4)
<input type="radio" name="rating" value="3">It was Ok(3)
<input type="radio" name="rating" value="2">Pretty Bad(2)
<input type="radio" name="rating" value="1">This movie REALLY sucked!(1)
</td></tr>

<tr><td>Your Comments:</td>
<td><textarea name="comment" cols="50" rows="12">
</textarea></td></tr>

<?php
// get the movie id and title and query
$id = $_GET['id'];
$title = $_GET['title'];
$ts = date(timestamp);

// took me several hours to figure this out
// that you can embed HTML inside PHP with echo "HTML CODE";
echo "<tr><td><input type='hidden' name='id' value='$id'></tr></td>";
echo "<tr><td><input type='hidden' name='timestamp' value='$ts'></tr></td>";
echo "<tr><td><input type='hidden' name='title' value='$title'></tr></td>";
echo "<tr><td><input type='submit' value='Sumbit Review'></td></tr>";
echo "</table></form>";
?>

</div>
</body>
</html>
