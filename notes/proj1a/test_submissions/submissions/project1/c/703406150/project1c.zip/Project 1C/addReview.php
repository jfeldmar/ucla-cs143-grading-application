<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico"></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<?php
// get the query data
$title = $_GET['title'];
$name = $_GET['name'];
$ts = date('Y-m-d h:i:s');
$id = $_GET['id'];
$rating = $_GET['rating'];
$comment = $_GET['comment'];

// connect to the database
$con = mysql_connect("localhost","cs143","");

if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// try the query
$ins = "insert into Review VALUES ('$name','$ts','$id','$rating','$comment')";

// if the insert failed
if (!mysql_query($ins,$con))
	die('Invalid Values; Please try again. The error was: ' . mysql_error());
else
{
	echo "<h3>Review added successfully!</h3>";
	echo "<a href='./movieDetail.php?id=$id&title=$title'>Back to Movie Detail for $title</a>";
}
mysql_close($con);
?>

</div>
</body>
</html>
