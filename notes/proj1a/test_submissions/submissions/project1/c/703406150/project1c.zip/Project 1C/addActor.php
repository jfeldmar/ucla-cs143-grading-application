<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">&nbsp &nbsp;
<br><hr>

<h2><u>Add a New Actor/Director to the Database:</u></h2>

<form action="./addActor.php" method="get">
<table>

<tr><td></td><td><input type="checkbox" name="isact">Actor
<input type="checkbox" name="isdir">Director
<small>(Must choose at least one)</small></td></tr>
<tr><td>First Name:</td>
<td><input type="text" name="first"></td></tr>

<tr><td>Last Name:</td>
<td><input type="text" name="last"></td></tr>

<tr><td>Gender:</td><td>
<input type="radio" name="sex" value="Male">Male
<input type="radio" name="sex" value="Female">Female

<tr><td>Date of Birth:</td>
<td><input type="text" name="dob"><small>(YYYY-MM-DD)</small></td></tr>
<tr><td>Date of Death:</td>
<td><input type="text" name="dod"><small>(Leave blank if still alive)</small></td></tr>

</td></tr>
<tr><td><input type="submit" name="SubmitForm" value="Add Actor"></td></tr>
</form>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// get the query data
$first = $_GET['first'];
$last = $_GET['last'];
$sex = $_GET['sex'];
$dob = $_GET['dob'];
$dod = $_GET['dod'];
$isact = $_GET['isact'];
$isdir = $_GET['isdir'];

// get the max actor id
$result = mysql_query("select * from MaxPersonID", $con);
$max = mysql_fetch_array($result);
$newmax = $max[0] + 1;

// if actor data has been submitted
if (($last!=null) && ($first!=null) && ($sex!=null) && ($dob!=null) &&(($isact!=null)||($isdir!=null)))
{
	// if we're adding actor data
	if ($isact != null)
	{
		// try to add the actor
		if ($dod == null)
			$ins = "insert into Actor VALUES ('$newmax','$last','$first','$sex','$dob',null)";
		else
			$ins = "insert into Actor VALUES ('$newmax','$last','$first','$sex','$dob','$dod')";
			
		// if the insert failed
		if (!mysql_query($ins, $con))
			// display a graceful error message
		die('Invalid Values; Please try again. The error was: ' . mysql_error());
		else
		{
			echo "<h3>Actor added successfully!</h3>";
			echo "<a href='./actorDetail.php?id=$newmax&fname=$first&lname=$last'>Go to Actor Detail for $first $last</a>";
			// update the MaxPersonID
			mysql_query("update MaxPersonID set id=$newmax", $con);
		}
	}
	// if we're adding director data
	if ($isdir != null)
	{
		// try to add the director
		if ($dod == null)
			$ins = "insert into Director VALUES ('$newmax','$last','$first','$dob',null)";
		else
			$ins = "insert into Director VALUES ('$newmax','$last','$first','$dob','$dod')";
			
		// if the insert failed
		if (!mysql_query($ins, $con))
			// display a graceful error message
		die('Invalid Values; Please try again. The error was: ' . mysql_error());
		else
		{
			echo "<h3>Director added successfully!</h3>";
			// update the MaxPersonID
			mysql_query("update MaxPersonID set id=$newmax", $con);
		}
	}
}
mysql_close($con);
?>

</div>
</body>
</html>
