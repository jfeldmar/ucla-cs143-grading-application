<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Search the Database:</u></h2>

<form action="./search.php" method="get">
Search in: 
<select name="category">
<option value="1">Actors
<option value="2">Directors
<option value="3">People
<option value="4">Movies
<option value="5">All
</select>
For:<input type="text" name="data">
<input type="submit" value="Find it!">
</form>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");

if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

$data = $_GET['data'];
$cat = $_GET['category'];

if ($data != null)
{
	// ACTOR TABLE
	if (($cat==1) || ($cat==3) || ($cat==5))
	{
		// query
		$result = mysql_query("
			select *
			from Actor
			where first='$data' OR last='$data'
			order by last ASC
			", $con);
		
		// display actor table
		echo "<b>Here are the Actors matching your search:</b><br>";
		// display the actor information
		echo "<table border='2'><tr>
			<th>Last Name</th>
			<th>First Name</th>
			<th>Gender</th>
			<th>Date of Birth</th>
			<th>Date of Death</th>
			<th>Movies Appeared In</th>
			</tr>";
	
		while($row = mysql_fetch_array($result))
		{
			echo "<tr>";
			for ($i=0; $i < 7; $i++)
			{
				if ($i == 0)
					$id = $row[$i];
				if ($i == 1)
					$lname = $row[$i];
				if ($i == 2)
					$fname = $row[$i];
				if (($i != 0) && ($row[$i] != null))
					echo "<td>".$row[$i]."</td>";
				else if ($i == 5)
					echo "<td>Still Alive</td>";
			}
			echo "<td><a href='./actorDetail.php?id=$id&fname=$fname&lname=$lname'>Actor Detail</td>";
			echo "</tr>";
		}
		echo "</table><br>";
	}
	// DIRECTOR TABLE
	if (($cat==2) || ($cat==3) || ($cat==5))
	{		
		// query
		$result = mysql_query("
			select *
			from Director
			where first='$data' OR last='$data'
			order by last ASC
			", $con);
		
		// display the director table
		echo "<b>Here are the Directors matching your search:</b><br>";
		// display the actor information
		echo "<table border='2'><tr>
			<th>Last Name</th>
			<th>First Name</th>
			<th>Date of Birth</th>
			<th>Date of Death</th>
			</tr>";
	
		while($row = mysql_fetch_array($result))
		{
			echo "<tr>";
			for ($i=0; $i < 6; $i++)
			{
				if ($i != 0)
				{
					if ($row[$i] != null)
						echo "<td>".$row[$i]."</td>";
					else if ($i == 5)
						echo "<td>Still Alive</td>";
				}
			}
			echo "</tr>";
		}
		echo "</table><br>";		
	}
	// MOVIE TABLE
	if (($cat==4) || ($cat==5))
	{
		// query
		$result = mysql_query("
			select * 
			from Movie 
			where title LIKE '%$data%'
			order by title ASC", $con);
		
		// display movie table
		echo "<b>Here are the Movies matching your search:</b><br>";
		
		// set up a nice looking table
		echo "<table border='2'><tr>
			<th>Title</th>
			<th>Year</th>
			<th>Rating</th>
			<th>Company</th>
			<th>Cast</th></tr>";
	
		while($row = mysql_fetch_array($result))
		{
			echo "<tr>";
			for ($i=0; $i < 5; $i++)
			{
				if ($i == 0)
					$id = $row[$i];
				if ($i == 1)
					$title = $row[$i];
				if ($i != 0)
					echo "<td>".$row[$i]."</td>";
			}
			echo "<td> <a href='./movieDetail.php?id=$id&title=$title'>Movie Detail</td>";
			echo "</tr>";
		}
		echo "</table><br>";
	}
}
mysql_close($con);
?>

</div>
</body>
</html>
