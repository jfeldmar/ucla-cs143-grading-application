<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Browse Actors in the Database:</u></h2>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// query
$result = mysql_query("select * from Actor order by Last ASC", $con);

// set up a nice looking table
echo "<table border=1 cellspacing=3 cellpadding=3>
	<tr>
	<th>Last Name</th>
	<th>First Name</th>
	<th>Gender</th>
	<th>Date of Birth</th>
	<th>Date of Death</th>
	<th>Movies Appeared In</th>
	</tr>";
	
while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 6; $i++)
	{
		if ($i == 0)
			$id = $row[$i];
		else if ($i == 1)
			$lname = $row[$i];
		else if ($i == 2)
			$fname = $row[$i];
		if ($i != 0)
		{
			if ($row[$i] != null)
				echo "<td>".$row[$i]."</td>";
			else if ($i == 5)
				echo "<td>Still Alive</td>";
		}
	}
	echo "<td><a href='./actorDetail.php?id=$id&fname=$fname&lname=$lname'>Actor Detail</td>";
	echo "</tr>";
}
echo "</table>";
mysql_close($con);
?>

</div>
</body>
</html>
