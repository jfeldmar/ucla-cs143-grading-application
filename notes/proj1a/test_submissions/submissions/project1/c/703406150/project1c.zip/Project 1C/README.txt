Mike Nichols
703406150
UCLA Fall 2008
CS 143 - Project 1C
November 1st 2008

Here are the pages included in my website:

First, all my pages have a banner with the title of my website, MIMDb, which stands
for "My Internet Movie Database". All my pages also have buttons that link to the
pages for search, browse movies, add a new movie, browse actors, and add a new
actor / director.

search.php: Does a keyword search for actors,directors,people,movies,or all of these.
Searches first and last names for people, titles for movies. Unfortunately, does not
work for searching first and last names. Ex:"Bob Smith" would return only people whose
first name is "Bob Smith" or whose last name is "Bob Smith".

browseActors.php: Displays a table with all the actors in the database listed in
alphabetical order by last name. The last column in this table has links to the
actorDetail page for each actor, which I will explain shortly.

browseMovies.php: Displays a table with all the movies in the database listed in
alphabetical order by title. The last column has links to the movieDetail page
for each movie.

actorDetail.php: Displays the details for a chosen actor in one table and all the movies
the actor has been in in another table. This other movie table has links in the
last column that link to the movieDetail page for that movie. This design makes it
very easy to find an actor, find a movie they were in, and find all the actors that
were in that movie with them.

movieDetail.php: Displays the details for a chosen movie including the average review
score in one table and all the actors that were in that movie in another table.
Also has a table with all the reviews for the movie listed from most recent to
oldest. At the bottom, there is space to add a review for the movie and a button
to sumbit a review. When a review is subitted, it links to the addReview page.

addReview.php: This page does the actual insertion of a movie review. If the tuple
was inserted successfully, it displays a success message and a link back to the
movieDetail page. If there was an error, it display a graceful error message.

addActor.php: Allows the user to add actor and/or director information. If
there were not enough fields filled in when the submit button was pressed, the page
will just refresh and clear the forms. If the data was added successfully, it will
display a success message and link to the newly created actorDetail page. If there
was enough input, and the insert failed, it will display a graceful error message.

addMovie.php: Allows the users to add movie information. If there were not enough fields
filled in when the submit button was pressed, the page will just refresh and clear
the forms. If the data was added successfully, it will display a success message
and link to the newly created movieDetail page. If there was enough input, and the
insert failed, it will display a graceful error message.
