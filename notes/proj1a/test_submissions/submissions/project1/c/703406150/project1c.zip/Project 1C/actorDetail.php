<html>
<title>MIMDb - My Internet Movie Database</title>
<head><link rel="shortcut icon" href="icon.ico" ></head>
<body BACKGROUND="background.gif"
      BGCOLOR="#FFFFFF"
      TEXT="#000000"
      LINK="#0000FF"
      VLINK="#FF66FF"
      ALINK="#FF0000"
>
<div align=center>
<img src="mimdb2.jpg" width="85%" border=10 alt="Image not available">
<br><br>
<input type=button onClick="parent.location='./search.php'" value="Search the MIMDb" />&nbsp &nbsp;
<input type=button onClick="parent.location='./browseMovies.php'"value="Browse Movies">&nbsp &nbsp;
<input type=button onClick="parent.location='./addMovie.php'" value="Add a New Movie">&nbsp &nbsp;
<input type=button onClick="parent.location='./browseActors.php'" value="Browse Actors">&nbsp &nbsp;
<input type=button onClick="parent.location='./addActor.php'" value="Add a New Actor / Director">
<br><hr>

<h2><u>Actor Detail:</u></h2>

<?php
// connect to the database
$con = mysql_connect("localhost","cs143","");
if (!$con)
	die('Could not connect: ' . mysql_error());

// use the CS143 database
mysql_select_db("CS143", $con);

// get the link input
$id = $_GET['id'];
$fname = $_GET['fname'];
$lname = $_GET['lname'];

// query
$result = mysql_query("select * from Actor where id=$id", $con);

// display the actor information
echo "<table border='2'><tr>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Gender</th>
	<th>Date of Birth</th>
	<th>Date of Death</th>
	</tr>";
	
while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 6; $i++)
	{
		if ($i == 1)
			echo "<td>".$fname."</td>";
		else if ($i == 2)
			echo "<td>".$lname."</td>";
		else if ($i > 2)
		{
			if ($row[$i] != null)
				echo "<td>".$row[$i]."</td>";
			else if ($i == 5)
				echo "<td>Still Alive</td>";
		}
	}
	echo "</tr>";
}
echo "</table>";

// display the name
echo "<h3>Movies that ",$fname," ", $lname, " has appeared in:</h3>";

// query
$result = mysql_query("
	select * 
	from Movie m, MovieActor ma
	where m.id=ma.mid AND ma.aid=$id
	order by m.year DESC
	", $con);

// set up a nice looking table
echo "<table border='2'>
	<tr>
	<th>Title</th>
	<th>Year</th>
	<th>Rating</th>
	<th>Company</th>	
	<th>Cast</th>
	</tr>";
	
while($row = mysql_fetch_array($result))
{
	echo "<tr>";
	for ($i=0; $i < 5; $i++)
	{
		if ($i == 0)
			$id = $row[$i];
		if ($i == 1)
			$title = $row[$i];
		if ($i != 0)
			echo "<td>".$row[$i]."</td>";
	}
	echo "<td> <a href='./movieDetail.php?id=$id&title=$title'>Movie Detail</td>";
	echo "</tr>";
}
echo "</table>";
mysql_close($con);
?>

</div>
</body>
</html>
