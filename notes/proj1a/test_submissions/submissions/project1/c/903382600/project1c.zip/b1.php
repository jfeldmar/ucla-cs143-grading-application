<html>
<body>

<form action="b1.php" method="get">

<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getactors="SELECT id, first, last, dob FROM Actor ORDER BY last ASC;";
$result=mysql_query($getactors, $db_connection);
$options="";

while ($row=mysql_fetch_array($result)) {
	$id=$row["id"];
	$first=$row["first"];
	$last=$row["last"];
	$dob=$row["dob"];
	$options.="<option value=\"$id\">".$last.", ".$first."(Birth: $dob)"."</option>";
}
mysql_close($db_connection);
?>
Actor: <select name="actor">
<option value=0>Choose an Actor
<?=$options?>
</select>
<input type="submit" value="Search!"><br><hr>
</form>

<?php
$aid = $_GET["actor"];

if($aid){
$getactor = "SELECT * FROM Actor WHERE id = $aid;";
$getroles = "SELECT ma.role, m.title, m.year, m.id FROM MovieActor ma, Movie m WHERE ma.aid = $aid
 AND ma.mid = m.id order by year desc;";

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$result=mysql_query($getactor, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$last = $row[1];
	$first = $row[2];
	$sex = $row[3];
	$dob = $row[4];
	$dod = $row[5];
}
print "-- Actor Info --<br>";
print "Name: $first $last<br>";
print "Sex: $sex<br>";
print "Date of Birth: $dob<br>";
if ($dod == NULL)
print "Date of Death: Still Alive<br><br>";
else
print "Date of Death: $dod<br><br>";

print "-- $first $last" . "'s Movie Roles --<br>";
$result=mysql_query($getroles, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$role = $row[0];
	$title = $row[1];
	$year = $row[2];
	$mid = $row[3];
	print "\"$role\" in <a href=\"b2.php?movie=$mid\">$title</a> ($year)<br>";
}

mysql_close($db_connection);
}
?>



</body>
</html>