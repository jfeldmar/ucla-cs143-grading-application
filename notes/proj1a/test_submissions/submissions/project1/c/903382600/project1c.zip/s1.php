<html>
<body>

You can search our database for any actors, directors, or movies.  Simply type into the text box and we'll search through our database for any names and titles that contain your search phrase.  Or if you know the name of what you're looking for, you can click on the box to search for the exact phrase.<br><br>

<form action="s1.php" method="get">
<input type="text" name="search">
<input type="checkbox" name="exact"> Exact Phrase <br>
<input type="submit" value="Search!"><br><hr>
</form>

<?php
$search = $_GET["search"];
$exact = $_GET["exact"];


if($search){
	if($exact){
		print "Searching exact phrase [$search].<br><br>";
		$search = "\"^".$search."$\"";
	}
	else {
		print "Searching phrase [$search].<br><br>";
		$search = "\"".$search."\"";
	}

$searchactor = "SELECT first, last, dob, id FROM Actor WHERE first REGEXP $search OR last REGEXP $search OR concat_ws(' ', first, last) regexp $search;";
$searchdirector = "SELECT first, last, dob, id FROM Director WHERE first REGEXP $search OR last REGEXP $search OR concat_ws(' ', first, last) regexp $search;";
$searchmovie = "SELECT title, year, id FROM Movie WHERE title REGEXP $search;";
$getmovie = "SELECT title FROM Movie WHERE id = 1074;";

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);



print "Searching Actors...<br>";
$result = mysql_query($searchactor, $db_connection);
if ( mysql_num_rows($result) == 0)
	print "No actors found<br>";
while($row=mysql_fetch_row($result)){
	$first = $row[0];
	$last = $row[1];
	$dob = $row[2];
	$aid = $row[3];
	print "<a href=\"b1.php?actor=$aid\">$first $last (Born: $dob)</a><br>";
}

print "<br>Searching Directors...<br>";
$result = mysql_query($searchdirector, $db_connection);
if (mysql_num_rows($result) == 0)
	print "No directors found<br>";
while($row=mysql_fetch_row($result)){
	$first = $row[0];
	$last = $row[1];
	$dob = $row[2];
	$did = $row[3];
	print "<a href=\"b3.php?director=$did\">$first $last (Born: $dob)</a><br>";
}

print "<br>Searching Movies...<br>";
$result = mysql_query($searchmovie, $db_connection);
if (mysql_num_rows($result) == 0)
	print "No movies found<br>";
while($row=mysql_fetch_row($result)){
	$title = $row[0];
	$year = $row[1];
	$mid = $row[2];
	print "<a href=\"b2.php?movie=$mid\">$title ($year)</a><br>";

mysql_close($db_connection);
}


}

?>


</body>
</html>