<html>
<body>

<form action="b3.php" method="get">

<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getdirectors="SELECT id, first, last, dob FROM Director ORDER BY last ASC;";
$result=mysql_query($getdirectors, $db_connection);
$options="";

while ($row=mysql_fetch_array($result)) {
	$id=$row["id"];
	$first=$row["first"];
	$last=$row["last"];
	$dob=$row["dob"];
	$options.="<option value=\"$id\">".$last.", ".$first."(Birth: $dob)"."</option>";
}
mysql_close($db_connection);
?>
Director: <select name="director">
<option value=0>Choose a Director
<?=$options?>
</select><br>
<input type="submit" value="Search!"><br><hr>
</form>

<?php
$did = $_GET["director"];

if($did){
$getdirector = "SELECT * FROM Director WHERE id = $did;";
$getmovies = "SELECT m.title, m.year, m.id FROM MovieDirector md, Movie m WHERE md.did = $did
 AND md.mid = m.id order by year desc;";

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$result=mysql_query($getdirector, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$last = $row[1];
	$first = $row[2];
	$dob = $row[3];
	$dod = $row[4];
}
print "-- Director Info --<br>";
print "Name: $first $last<br>";
print "Date of Birth: $dob<br>";
if ($dod == NULL)
print "Date of Death: Still Alive<br><br>";
else
print "Date of Death: $dod<br><br>";

print "-- $first $last" . "'s Directed Movies --<br>";
$result=mysql_query($getmovies, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$title = $row[0];
	$year = $row[1];
	$mid = $row[2];
	print "<a href=\"b2.php?movie=$mid\">$title</a> ($year)<br>";
}

mysql_close($db_connection);
}
?>



</body>
</html>