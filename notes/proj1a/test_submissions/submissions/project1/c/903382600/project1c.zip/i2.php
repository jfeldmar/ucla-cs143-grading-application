<html>
<body>

Adding a new movie: <br><br>
<form action="i2.php" method="post">
Title:<input type="text" name="title" maxlength="100"><br>
Year of release:<input type="text" name="year" maxlength="4"><br>
MPAA rating: <select name="rating">
<option value="G">G</option>
<option value="PG">PG</option>
<option value="PG-13">PG-13</option>
<option value="R">R</option>
<option value="NC-17">NC-17</option>
</select><br>
Production company:<input type="text" name="company" maxlength="50"><br>
<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getdirectors="SELECT id, first, last, dob FROM Director ORDER BY last ASC;";
$result=mysql_query($getdirectors, $db_connection);
$options="";

while ($row=mysql_fetch_array($result)) {
	$id=$row["id"];
	$first=$row["first"];
	$last=$row["last"];
	$dob=$row["dob"];
	$options.="<option value=\"$id\">".$last.", ".$first."(Birth: $dob)"."</option>";
}
mysql_close($db_connection);
?>
Director: <select name="director">
<option value=0>Choose a Director
<?=$options?>
</select><br>
Genre:<br>
<input type="checkbox" name="action" value="Action">Action<br>
<input type="checkbox" name="adult" value="Adult">Adult<br>
<input type="checkbox" name="adventure" value="Adventure">Adventure<br>
<input type="checkbox" name="animation" value="Animation">Animation<br>
<input type="checkbox" name="comedy" value="Comedy">Comedy<br>
<input type="checkbox" name="crime" value="Crime">Crime<br>
<input type="checkbox" name="documentary" value="Documentary">Documentary<br>
<input type="checkbox" name="drama" value="Drama">Drama<br>
<input type="checkbox" name="family" value="Family">Family<br>
<input type="checkbox" name="fantasy" value="Fantasy">Fantasy<br>
<input type="checkbox" name="horror" value="Horror">Horror<br>
<input type="checkbox" name="musical" value="Musical">Musical<br>
<input type="checkbox" name="mystery" value="Mystery">Mystery<br>
<input type="checkbox" name="romance" value="Romance">Romance<br>
<input type="checkbox" name="scifi" value="Sci-Fi">Sci-Fi<br>
<input type="checkbox" name="short" value="Short">Short<br>
<input type="checkbox" name="thriller" value="Thriller">Thriller<br>
<input type="checkbox" name="war" value="War">War<br>
<input type="checkbox" name="western" value="Western">Western<br>
<input type="submit" value="Add Movie">
</form>

<?php
$title = $_POST["title"];
$year = $_POST["year"];
$rating = $_POST["rating"];
$company = $_POST["company"];
$director = $_POST["director"];
$yearcheck = '/^[0-9]{4}$/';
$valid = 1;

if($director){

if(!$title){
$valid = 0;
print "ERROR: Movie must have a title.<br>";
}

if(!preg_match($yearcheck, $year)){
$valid = 0;
print "ERROR: Invalid year (must be in form YYYY).<br>";
}

if(!$company){
$valid = 0;
print "ERROR: Movie must have a production company.<br>";
}

if($director == 0) {
$valid = 0;
print "ERROR: Movie must have a valid Director. <br>";
}


$title = "\"" . $title . "\"" ;
$company = "\"" . $company . "\"" ;
$rating = "\"" . $rating . "\"" ;

if($valid == 1) {
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getid = "select * from MaxMovieID";
$result = mysql_query($getid, $db_connection);
while($row = mysql_fetch_row($result)) {
$id = $row[0];
}

$insertsql = "INSERT INTO Movie VALUES ($id, $title, $year, $rating, $company);";
$updateid = "UPDATE MaxMovieID set id = id+1;";
$insertmd = "INSERT INTO MovieDirector VALUES ($id, $director);";

mysql_query($insertsql, $db_connection);
$affected = mysql_affected_rows($db_connection);

if($affected == 1) {
mysql_query($updateid, $db_connection);
mysql_query($insertmd, $db_connection);

if($_POST["action"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Action\");");
if($_POST["adult"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Adult\");");
if($_POST["adventure"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Adventure\");");
if($_POST["animation"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Animation\");");
if($_POST["comedy"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Comedy\");");
if($_POST["crime"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Crime\");");
if($_POST["documentary"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Documentary\");");
if($_POST["drama"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Drama\");");
if($_POST["family"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Family\");");
if($_POST["fantasy"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Fantasy\");");
if($_POST["horror"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Horror\");");
if($_POST["musical"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Musical\");");
if($_POST["mystery"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Mystery\");");
if($_POST["romance"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Romance\");");
if($_POST["scifi"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Sci-Fi\");");
if($_POST["short"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Short\");");
if($_POST["thriller"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Thriller\");");
if($_POST["war"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"War\");");
if($_POST["western"])
mysql_query("INSERT INTO MovieGenre VALUES ($id, \"Western\");");

print "Movie added! Thank you for contributing.<br>";
}
else
print "Error with uploading data, please check your inputs and try again.<br>";

mysql_close($db_connection);
}
else
print "Invalid data entered.<br>";

}
?>

</body>
</html>