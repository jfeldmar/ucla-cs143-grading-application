<html>
<body>

Adding a new actor or director:<br><br>

<form action="i1.php" method="post">
I want to add a new:
<select name="actdir">
<option value="Actor">Actor</option>
<option value="Director">Director</option>
</select>
<br>
First Name:<input type="text" name="first" maxlength="20"><br>
Last Name:<input type="text" name="last" maxlength="20"><br>
Sex:<select name="sex">
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
<br>
Date of Birth (YYYYMMDD):<input type="text" name="dob" maxlength="8"><br>
Date of Death (YYYYMMDD or blank if still alive):<input type="text" name="dod" maxlength="8"><br>
<input type="submit" value="Submit">
</form>


</select>
<br>
<br>

<?php
$actdir = $_POST["actdir"];
$first = $_POST["first"];
$last = $_POST["last"];
$sex = $_POST["sex"];
$dob = $_POST["dob"];
$dod = $_POST["dod"];
$datecheck = '/^[0-9]{8}$/';
$valid = 1;

if($actdir){

if(!$first || !$last){
$valid = 0;
print "ERROR: Actor/Director must have a first and last name.<br>";
}


$first = "\"" . $first . "\"" ;
$last = "\"" . $last . "\"" ;
$sex = "\"" . $sex . "\"" ;

if(!preg_match($datecheck, $dob)){
print "ERROR: Invalid date for DoB. <br>";
$valid = 0;
}

if(!$dod){
$dod = "NULL";
}
elseif(!preg_match($datecheck, $dod)){
print "ERROR: Invalid date for DoD. <br>";
$valid = 0;
}

if ($valid == 1){
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getid = "select * from MaxPersonID";
$result = mysql_query($getid, $db_connection);
while($row = mysql_fetch_row($result)) {
$id = $row[0];
}

$insertsql = "INSERT INTO $actdir VALUES ($id, $last, $first, $sex, $dob, $dod);";
$updateid = "UPDATE MaxPersonID set id = id+1;";

mysql_query($insertsql, $db_connection);
$affected = mysql_affected_rows($db_connection);

if($affected == 1) {
mysql_query($updateid, $db_connection);
print "Person added! Thank you for contributing.<br>";
}
else
print "Error with uploading data, please check your input and try again.<br>";

mysql_close($db_connection);
}

else
print "Invalid data entered.<br>";
}
?>

</body>
</html>