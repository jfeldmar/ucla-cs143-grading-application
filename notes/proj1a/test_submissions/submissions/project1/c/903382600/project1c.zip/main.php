<html>

<frameset cols="20%, *">

<frame src="index.htm">
<frame src="title.htm" name="frame2">

</frameset>
</html>