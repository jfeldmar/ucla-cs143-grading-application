<html>
<body>

<?php
print "<a href=\"1c.php\" target=\"frame2\">lol</a>";
?>

</body>
</html>