<html>
<body>

Add a review:<br><br>
<form action="i3.php" method="get">
<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getmovie="SELECT id, title, year FROM Movie ORDER BY title ASC;";
$result=mysql_query($getmovie, $db_connection);
$options="";

while ($row=mysql_fetch_array($result)) {
	$id=$row["id"];
	$title=$row["title"];
	$year=$row["year"];
	if ($_GET["startid"] == $id)
	$options.="<option value=\"$id\" SELECTED>".$title."($year)"."</option>";
	else
	$options.="<option value=\"$id\">".$title."($year)"."</option>";
}
mysql_close($db_connection);
?>
Movie: <select name="movie">
<option value=0>Select a movie</option>
<?=$options?>
</select><br>
Your Name:<input type="text" name="name" value="Anonymous" maxlength=20><br>
Rating: <select name="rating">
<option value=5>5 - Cream of the crop!</option>
<option value=4>4 - A cut above the rest</option>
<option value=3>3 - Just another average movie</option>
<option value=2>2 - Try to avoid this one</option>
<option value=1>1 - Only for masochists</option>
</select><br>
Comments:<br>
<textarea name="comment" rows=10 cols=60 maxlength=5></textarea><br>
<input type="submit" value="Add your review!"><br>
</form>

<?php

$name = $_GET["name"];
$movie = $_GET["movie"];
$rating = $_GET["rating"];
$comment = $_GET["comment"];
if($movie){

if(!$name)
$name = "\"Anonymous\"";
else
$name = "\"" . $name . "\"" ;

$comment = "\"" . $comment . "\"" ;

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$insertsql = "INSERT INTO Review VALUES ($name, now(), $movie, $rating, $comment);";

mysql_query($insertsql, $db_connection);
$affected = mysql_affected_rows($db_connection);

if($affected == 1) {
print "Review added! Thank you for contributing.<br>";
}
else
print "Error with uploading data, please check your input and try again.<br>";

mysql_close($db_connection);
}
?>




</body>
</html>