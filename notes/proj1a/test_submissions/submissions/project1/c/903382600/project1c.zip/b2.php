<html>
<body>

<form action="b2.php" method="get">

<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$getmovies="SELECT id, title, year FROM Movie ORDER BY title ASC;";
$result=mysql_query($getmovies, $db_connection);
$options="";

while ($row=mysql_fetch_array($result)) {
	$id=$row["id"];
	$title=$row["title"];
	$year=$row["year"];
	$options.="<option value=\"$id\">"."$title"." ($year)"."</option>";
}
mysql_close($db_connection);
?>
Movie: <select name="movie">
<option value=0>Choose a Movie
<?=$options?>
</select>
<input type="submit" value="Search!"><br><hr>
</form>

<?php
$mid = $_GET["movie"];

if($mid){
$getmovie = "SELECT * FROM Movie WHERE id = $mid;";
$getdirector = "SELECT d.first, d.last FROM Director d, MovieDirector md WHERE md.mid=$mid AND md.did =d.id;";
$getgenre = "SELECT genre FROM MovieGenre WHERE mid = $mid;";
$getroles = "SELECT ma.role, a.first, a.last, a.id FROM MovieActor ma, Actor a WHERE ma.mid = $mid
 AND ma.aid = a.id order by role asc;";
$getrating = "SELECT avg(rating), count(rating) FROM Review WHERE mid=$mid;";
$getreviews = "SELECT name, time, rating, comment FROM Review WHERE mid=$mid;"; 

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$result=mysql_query($getmovie, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$title = $row[1];
	$year = $row[2];
	$rating = $row[3];
	$company = $row[4];
}
print "-- Movie Info --<br>";
print "Title: $title<br>";
print "Year of Release: $year<br>";
print "MPAA: $rating<br>";
print "Production Company: $company<br>";
print "Directed by: ";
$result=mysql_query($getdirector, $db_connection);
if (mysql_num_rows($result) == 0)
	print "Director is not known for this movie.<br>";
else{
	while ($row=mysql_fetch_row($result)){
		$first = $row[0];
		$last = $row[1];
		print "$first $last<br>";
        }
}
print "Genre: ";
$result=mysql_query($getgenre, $db_connection);
while ($row=mysql_fetch_row($result))
	print "$row[0], ";
print "<br><br>";

print "-- Actors in $title --<br>";
$result=mysql_query($getroles, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$role = $row[0];
	$first = $row[1];
	$last = $row[2];
	$aid = $row[3];
	print "<a href=\"b1.php?actor=$aid\">$first $last</a> as \"$role\"<br>";
}

print "<br> -- User Reviews -- <a href=\"i3.php?startid=$mid\" target=\"frame2\">(Add your own review!)</a><br>";

$result=mysql_query($getrating, $db_connection);
while ($row=mysql_fetch_row($result)){
$avg = $row[0];
$count = $row[1];
if ($count > 0)
	print "$title has an average rating of $avg from $count users.<br><br>";
else
	print "$title has no user reviews yet.<br><br>";
}

$result=mysql_query($getreviews, $db_connection);
while ($row=mysql_fetch_row($result)) {
	$name = $row[0];
	$time = $row[1];
	$rating = $row[2];
	$comment = $row[3];
	if (!$comment)
		$comment = "No Comment.";
	print "$name gave $title $rating out of 5 on $time:<br>$comment<br><br>";
}

mysql_close($db_connection);
}
?>

</body>
</html>