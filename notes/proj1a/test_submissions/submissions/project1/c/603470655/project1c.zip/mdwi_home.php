<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
			<div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="color: #006666;">
	<h1><?php print "Click one of the tabs above and start using the" ?></h1>
	<h1><?php print "Movie Database Web Interface!" ?></h1>
	<h4><marquee><?php print "Note: Click the title \"Movie Database Web Interface\" at the top to return to this page." ?></h4>
	<img src="movie_reel.jpg" />
	<h2><?php print "Beayna Grigorian" ?><br /><?php print "CS 143 Fall 2008" ?></h2>
</div>

</body>
</html>
