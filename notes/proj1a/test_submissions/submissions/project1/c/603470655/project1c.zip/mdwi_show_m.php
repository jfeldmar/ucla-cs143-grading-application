<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_show_m.php">
	<?php print "Movie:" ?>
	<select name="movie_select">
		<?php
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Get Movie Names */
			$query = "SELECT id, title, year FROM Movie ORDER BY title;";
			if (!$rs = $db->query($query)) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to acquire Movie Names: $error";
				exit(1);
			}
			while ($row = $rs->fetch_assoc()) {
				$id = $row['id'];
				$title = $row['title'];
				$year = $row['year'];
				echo "<option value=\"$id\">$title ($year)</option>";
			} 
			mysqli_free_result($rs);	// --> Free Result Set
			
			$db->close();	// --> Close Connection
		?>
	</select>
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Submit" />
	<input type="hidden" name="submitted" value="1" />
	</form>
	
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$mid = $_REQUEST["movie_select"];
			
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Get Basic Movie Info */
			$stmt = $db->prepare("SELECT title, year, rating, company FROM Movie WHERE id = ?");
			$stmt->bind_param("s", $mid);
			$stmt->execute();
			$stmt->bind_result($title, $year, $rating, $company);
			if(!$stmt->fetch()) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to show Movie Information: $error";
				exit(1);
			}
			$stmt->close();	// --> Close statement
			
			/* Get Genre Info */
			$stmt = $db->prepare("SELECT DISTINCT genre FROM MovieGenre WHERE mid = ?;");
			$stmt->bind_param("s", $mid);
			$stmt->execute();
			$stmt->bind_result($genre);
			if($stmt->fetch())
				$genres = $genres . $genre;
			while ($stmt->fetch())
				$genres = $genres . "  |  " . $genre;
			$stmt->close();	// --> Close statement
			
			/* Get Director Info */
			$stmt = $db->prepare("SELECT first, last FROM Director WHERE id in "
							   . "(SELECT DISTINCT did FROM MovieDirector WHERE mid = ?);");
			$stmt->bind_param("s", $mid);
			$stmt->execute();
			$stmt->bind_result($first, $last);
			if($stmt->fetch())
				$directors = $directors . $first . " " . $last;
			while ($stmt->fetch())
				$directors = $directors . "  |  " . $first . " " . $last;
			$stmt->close();	// --> Close statement
			
			echo "<strong><u><h3>Information On $title:</h3></u></strong>";
			
			echo "<br /> Title: $title"
			   . "<br /> Year: $year"
			   . "<br /> MPAA Rating: $rating"
			   . "<br /> Company: $company"
			   . "<br /> Director(s): $directors"
			   . "<br /> Genre(s): $genres";
			
			echo "<br /><br /><br /><strong><u><h3>Actors/Roles Played In $title:</h3></u></strong>";
			
			/* Find Actors and Create Links */
			$query1 = "SELECT aid, role FROM MovieActor WHERE mid = $mid GROUP BY aid, role;";
			if (!$rs1 = $db->query($query1)) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to show Actor Information: $error";
				exit(1);
			}
			while ($row1 = $rs1->fetch_assoc()) {
				$aid = $row1['aid'];
				$role = $row1['role'];
				$query2 = "SELECT first, last FROM Actor WHERE id = $aid;";
				if (!$rs2 = $db->query($query2)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to show Actor Information: $error";
					exit(1);
				}
				while ($row2 = $rs2->fetch_assoc()) {
					$first = $row2['first'];
					$last = $row2['last'];
					echo "<br /><a href=\"mdwi_show_a.php?actor_select=$aid&submitted=1\""
					   . "	   	   style=\"font-weight: bold; text-decoration: none; font-style: italic; color: #FF9900;\">"
					   . "$first $last</a> -- $role";
				}
				mysqli_free_result($rs2);	// --> Free Result Set
			} 
			mysqli_free_result($rs1);	// --> Free Result Set
			
			echo "<br /><br /><br /><strong><u><h3>Actors/User Reviews for $title:</h3></u></strong>";
			
			/* Get User Review Information */
			$stmt = $db->prepare("SELECT AVG(rating) FROM Review WHERE mid = ? GROUP BY mid;");
			$stmt->bind_param("s", $mid);
			$stmt->execute();
			$stmt->bind_result($avgrating);
			$stmt->fetch();			
			$stmt->close();	// --> Close statement
			
			echo "<br /> Average User Rating: ";
			if ($avgrating != "")
				echo "$avgrating / 5.0";
			else
				echo "(No User Reviews Have Been Submitted)";
			
			echo "<br /><a href=\"mdwi_add_mc.php\""
			   . "	 style=\"font-weight: bold; text-decoration: none; font-style: italic; color: #FF9900;\">"
			   . "Add User Review!</a>";
			
			echo "<br /><br /> User Comments:";
			
			$stmt = $db->prepare("SELECT name, time, rating, comment FROM Review WHERE mid = ? ORDER BY time DESC;");
			$stmt->bind_param("s", $mid);
			$stmt->execute();
			$stmt->bind_result($username, $time, $rating, $comment);
			while($stmt->fetch()) {
				if ($username == "")
					$username = "(Anonymous)";
				echo "<br /><br /> $time -- $username gave rating of $rating with the following comment(s):"
				   . "<br /> $comment";
			}			
			$stmt->close();	// --> Close statement
			
			$db->close();	// --> Close Connection
		}
	?>
</div>

</body>
</html>
