<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_show_a.php">
	
	<?php print "Actor:" ?>
	<select name="actor_select">
		<?php
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Get Actor Names */
			$query = "SELECT id, first, last FROM Actor ORDER BY last, first;";
			if (!$rs = $db->query($query)) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to acquire Actor Names: $error";
				exit(1);
			}
			while ($row = $rs->fetch_assoc()) {
				$id = $row['id'];
				$first = $row['first'];
				$last = $row['last'];
				echo "<option value=\"$id\">$last, $first</option>";
			} 
			mysqli_free_result($rs);	// --> Free Result Set
			
			$db->close();	// --> Close Connection
		?>
	</select>
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Submit" />
	<input type="hidden" name="submitted" value="1" />
	</form>
	
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$aid = $_REQUEST["actor_select"];
			
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Create and Execute Statements */
			$stmt = $db->prepare("SELECT last, first, sex, dob, dod FROM Actor WHERE id = ?;");
			$stmt->bind_param("s", $aid);
			$stmt->execute();
			$stmt->bind_result($last, $first, $sex, $dob, $dod);
		
			if(!$stmt->fetch()) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to show Actor Information: $error";
				exit(1);
			}
			
			$stmt->close();	// --> Close statement
			
			echo "<strong><u><h3>Information On $first $last:</h3></u></strong>";
			
			if ($dod == "")
				$dod = "(Still Alive)";
			
			echo "<br /> First Name: $first"
			   . "<br /> Last Name: $last"
			   . "<br /> Sex: $sex"
			   . "<br /> Date of Birth (YYYYMMDD): $dob"
			   . "<br /> Date of Death (YYYYMMDD): $dod";
			
			echo "<br /><br /><br /><strong><u><h3>Movies/Roles $first $last Has Played:</h3></u></strong>";
			
			/* Find Movies and Create Links */
			$query1 = "SELECT mid, role FROM MovieActor WHERE aid = $aid GROUP BY mid, role;";
			if (!$rs1 = $db->query($query1)) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to show Actor Information: $error";
				exit(1);
			}
			while ($row1 = $rs1->fetch_assoc()) {
				$mid = $row1['mid'];
				$role = $row1['role'];
				$query2 = "SELECT title, year FROM Movie WHERE id = $mid;";
				if (!$rs2 = $db->query($query2)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to show Actor Information: $error";
					exit(1);
				}
				while ($row2 = $rs2->fetch_assoc()) {
					$title = $row2['title'];
					$year = $row2['year'];
					echo "<br /><a href=\"mdwi_show_m.php?movie_select=$mid&submitted=1\""
					   . "	   	   style=\"font-weight: bold; text-decoration: none; font-style: italic; color: #FF9900;\">"
					   . "$title ($year)</a> -- $role";
				}
				mysqli_free_result($rs2);	// --> Free Result Set
			} 
			mysqli_free_result($rs1);	// --> Free Result Set
			
			$db->close();	// --> Close Connection
		}
	?>
</div>

</body>
</html>
