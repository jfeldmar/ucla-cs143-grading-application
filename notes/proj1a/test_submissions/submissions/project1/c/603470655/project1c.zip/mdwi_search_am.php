<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_search_am.php">
	<?php print "Search For:" ?>
	<input type="radio" name="searchfor_radio" value="actor" checked />
	<?php print "Actor" ?>
	<input type="radio" name="searchfor_radio" value="movie" />
	<?php print "Movie" ?>
	<br /><br />
	
	<?php print "Search:" ?>
	<input type="text" name="search_text" size=30 maxlength=100 />
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Search" />
	<input type="hidden" name="submitted" value="1" />
	
    <?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$searchfor = $_REQUEST["searchfor_radio"];
			$searchval = $_REQUEST["search_text"];
			$searchval = "%" . $searchval . "%";
			
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Create and Execute Statements */
			if ($searchfor == "actor") {
				$stmt = $db->prepare("SELECT id, last, first FROM Actor WHERE last LIKE ? OR first LIKE ? ORDER BY last, first");
				$stmt->bind_param("ss", $searchval, $searchval);
				$stmt->execute();
				$stmt->bind_result($aid, $last, $first);
				echo "<br /><br />";
				while($stmt->fetch()) {
					echo "<br /><a href=\"mdwi_show_a.php?actor_select=$aid&submitted=1\""
					   . "	   	   style=\"font-weight: bold; text-decoration: none; font-style: italic; color: #FF9900;\">"
					   . "$last, $first</a>";
				}
			}
			else {
				$stmt = $db->prepare("SELECT id, title, year FROM Movie WHERE title LIKE ? ORDER BY title;");
				$stmt->bind_param("s", $searchval);
				$stmt->execute();
				$stmt->bind_result($mid, $title, $year);
				echo "<br /><br /><br />";
				while($stmt->fetch()) {
					echo "<br /><a href=\"mdwi_show_m.php?movie_select=$mid&submitted=1\""
					   . "	   	   style=\"font-weight: bold; text-decoration: none; font-style: italic; color: #FF9900;\">"
					   . "$title ($year)</a>";
				}
			}
			$stmt->close();	// --> Close statement
			
			$db->close();	// --> Close Connection
		}
	?>
</div>

</body>
</html>
