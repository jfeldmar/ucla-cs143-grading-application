<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<form method="post" action="./mdwi_add_mr.php">
<?php
	/* Connect to MySQLI */
	$host_name = "localhost";
	$user_name = "cs143";
	$password = "";
	$db_name = "CS143";
	$db = new mysqli($host_name, $user_name, $password, $db_name);
	
	/* Check Connection */
	if ($error = mysqli_connect_errno()) {
		echo("<br />ERROR -- Connection failed: $error");
		exit(1);
	}
?>

<table vspace="0" width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td valign="top" align="center" style="font-weight: bold; font-size: 20px; color: #006666">
			<br /><br />
			<?php print "Relate Movie to Actor" ?>
			<input type="radio" name="relation_radio" value="ma" checked />
			<br /><br />
			
			<?php print "Actor:" ?>
			<select name="actor_select">
				<?php
					/* Get Actor Names */
					$query = "SELECT id, first, last FROM Actor ORDER BY last, first;";
					if (!$rs = $db->query($query)) {
						$error = $db->error;
						echo "<br />ERROR -- Failed to add new Movie Relation: $error";
						exit(1);
					}
					while($row = $rs->fetch_assoc()) {
						$id = $row['id'];
						$first = $row['first'];
						$last = $row['last'];
						echo "<option value=\"$id\">$last, $first</option>";
					} 
					mysqli_free_result($rs);	// --> Free Result Set
				?>
			</select>
			<br /><br />
			
			<?php print "Role:" ?>
			<input type="text" name="role_text" size=20 maxlength=50 />
			<br /><br />
		</td>
		<td valign="top" align="center" style="font-weight: bold; font-size: 20px; color: #006666">
			<br /><br />
			<?php print "Relate Movie to Director" ?>
			<input type="radio" name="relation_radio" value="md" />
			<br /><br />
			
			<?php print "Director:" ?>
			<select name="director_select">
				<?php
					/* Get Director Names */
					$query = "SELECT id, first, last FROM Director ORDER BY last, first;";
					if (!$rs = $db->query($query)) {
						$error = $db->error;
						echo "<br />ERROR -- Failed to add new Movie Relation: $error";
						exit(1);
					}
					while($row = $rs->fetch_assoc()) {
						$id = $row['id'];
						$first = $row['first'];
						$last = $row['last'];
						echo "<option value=\"$id\">$last, $first</option>";
					} 
					mysqli_free_result($rs);	// --> Free Result Set
				?>
			</select>
			<br /><br />
		</td>
		<td valign="top" align="center" style="font-weight: bold; font-size: 20px; color: #006666">
			<br /><br />
			<?php print "Relate Movie to Genre" ?>
			<input type="radio" name="relation_radio" value="mg" />
			<br /><br />
			
			<?php print "Genre:" ?>
			<select name="genre_select">
				<option selected>Action</option>
				<option>Adult</option>
				<option>Adventure</option>
				<option>Animation</option>
				<option>Comedy</option>
				<option>Crime</option>
				<option>Documentary</option>
				<option>Drama</option>
				<option>Family</option>
				<option>Fantasy</option>
				<option>Horror</option>
				<option>Musical</option>
				<option>Mystery</option>
				<option>Romance</option>
				<option>Sci-Fi</option>
				<option>Short</option>
				<option>Thriller</option>
				<option>War</option>
				<option>Western</option>
			</select>
			<br /><br />
		</td>
	</tr>
	<tr>
		<td  colspan="3" align="center" style="font-weight: bold; font-size: 20px; color: #006666">
			<br /><br />
			<?php print "Movie:" ?>
			<select name="movie_select">
				<?php
					/* Get Movie Names */
					$query = "SELECT id, title, year FROM Movie ORDER BY title;";
					if (!$rs = $db->query($query)) {
						$error = $db->error;
						echo "<br />ERROR -- Failed to add new Movie Relation: $error";
						exit(1);
					}
					while($row = $rs->fetch_assoc()) {
						$id = $row['id'];
						$title = $row['title'];
						$year = $row['year'];
						echo "<option value=\"$id\">$title ($year)</option>";
					} 
					mysqli_free_result($rs);	// --> Free Result Set
				?>
			</select>
			<br /><br />
			
			<input type="reset" value="Reset" />
			<input type="submit" value="Submit" />
			<input type="hidden" name="submitted" value="1" />
		</td>
	</tr>
</table>

<?php
	$db->close();	// --> Close Connection
?>
</form>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$relation = $_REQUEST["relation_radio"];
			$actor = $_REQUEST["actor_select"];
			$role = $_REQUEST["role_text"];
			$director = $_REQUEST["director_select"];
			$genre = $_REQUEST["genre_select"];
			$movie = $_REQUEST["movie_select"];
			
			if ($relation == ma and $role == "") {
				echo "<br />ERROR -- Cannot Relate Movie To Actor Without a Role.";
				exit(1);
			}
			else {
				/* Connect to MySQLI */
				$host_name = "localhost";
				$user_name = "cs143";
				$password = "";
				$db_name = "CS143";
				$db = new mysqli($host_name, $user_name, $password, $db_name);
				
				/* Check Connection */
				if ($error = mysqli_connect_errno()) {
					echo("<br />ERROR -- Connection failed: $error");
					exit(1);
				}
				
				/* Create and Execute Statements */
				if ($relation == "ma") {
					$stmt = $db->prepare("INSERT INTO MovieActor (mid, aid, role) "
									   . "VALUES (?, ?, ?);");
					$stmt->bind_param("sss", $movie, $actor, $role);
				}
				else if ($relation == "md") {
					$stmt = $db->prepare("INSERT INTO MovieDirector (mid, did) "
									   . "VALUES (?, ?);");
					$stmt->bind_param("ss", $movie, $director);
				}
				else {	// Relating Movie to Genre
					$stmt = $db->prepare("INSERT INTO MovieGenre (mid, genre) "
										. "VALUES (?, ?);");
					$stmt->bind_param("ss", $movie, $genre);
				}
				
				$stmt->execute();
				if ($stmt->affected_rows != 1) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Movie Relation: $error";
					exit(1);
				}
				$stmt->close();	// --> Close statement
				
				echo "<br />Successfully Created New Movie Relation!";
				
				$db->close();	// --> Close Connection
			}
		}
	?>
</div>

</body>
</html>
