<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_add_mc.php">
	
	<?php print "Your Name:" ?>
	<input type="text" name="name_text" size=20 maxlength=20>
	<br /><br />
	
	<?php print "Movie:" ?>
	<select name="movie_select">
		<?php
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Get Movie Names */
			$query = "SELECT id, title, year FROM Movie ORDER BY title;";
			if (!$rs = $db->query($query)) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to add new Movie Comment: $error";
				exit(1);
			}
			while($row = $rs->fetch_assoc()) {
				$id = $row['id'];
				$title = $row['title'];
				$year = $row['year'];
				echo "<option value=\"$id\">$title ($year)</option>";
			} 
			mysqli_free_result($rs);	// --> Free Result Set
			
			$db->close();	// --> Close Connection
		?>
	</select>
	<br /><br />
	
	<?php print "Rating:" ?>
	<select name="rating_select">
		<option value="5">5 (Excellent)</option>
		<option value="4">4 (Good)</option>
		<option value="3">3 (Average)</option>
		<option value="2">2 (Inadequate)</option>
		<option value="1">1 (Horrible)</option>
	</select>
	<br /><br />
	
	<?php print "Comment:" ?>
	<textarea name="comment_textarea" rows="10" cols="50"></textarea>
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Submit" />
	<input type="hidden" name="submitted" value="1" />
	</form>
	
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$name = $_REQUEST["name_text"];
			$movie = $_REQUEST["movie_select"];
			$rating = $_REQUEST["rating_select"];
			$comment = $_REQUEST["comment_textarea"];
			
			/* Connect to MySQLI */
			$host_name = "localhost";
			$user_name = "cs143";
			$password = "";
			$db_name = "CS143";
			$db = new mysqli($host_name, $user_name, $password, $db_name);
			
			/* Check Connection */
			if ($error = mysqli_connect_errno()) {
				echo("<br />ERROR -- Connection failed: $error");
				exit(1);
			}
			
			/* Create and Execute Statements */
			$stmt = $db->prepare("INSERT INTO Review (name, time, mid, rating, comment) "
							   . "VALUES (?, now(), ?, ?, ?)");
			$stmt->bind_param("ssss", $name, $movie, $rating, $comment);
			$stmt->execute();
			if ($stmt->affected_rows != 1) {
				$error = $db->error;
				echo "<br />ERROR -- Failed to add new Movie Comment: $error";
				exit(1);
			}
			$stmt->close();	// --> Close statement
			
			echo "<br />Successfully Added Your Comment!";
			
			$db->close();	// --> Close Connection
		}
	?>
</div>

</body>
</html>
