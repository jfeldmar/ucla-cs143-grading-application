<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs_active">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_add_m.php">
	<?php print "Title:" //EVERY MOVIE MUST HAVE A TITLE!!! ?>
	<input type="text" name="title_text" size=20 maxlength=100 />
	<br /><br />
	
	<?php print "Company:" ?>
	<input type="text" name="company_text" size=20 maxlength=50 />
	<br /><br />
	
	<?php print "Year:" ?>
	<select name="year_select">
		<?php
			$i = 1800;
			for (; $i < 2008; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<br /><br />
	
	<?php print "MPAA Rating:" ?>
	<select name="rating_select">
		<option value="G">G</option>
		<option value="PG">PG</option>
		<option value="PG-13" selected>PG-13</option>
		<option value="R">R</option>
		<option value="NC-17">NC-17</option>
		<option value="surrendere">surrendere</option>
	</select>
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Submit" />
	<input type="hidden" name="submitted" value="1" />
	</form>
	
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_POST["reset"]) {
			$title = $_REQUEST["title_text"];
			$company = $_REQUEST["company_text"];
			$year = $_REQUEST["year_select"];
			$rating = $_REQUEST["rating_select"];
			
			if ($title != "" and $company != "") {
				/* Connect to MySQLI */
				$host_name = "localhost";
				$user_name = "cs143";
				$password = "";
				$db_name = "CS143";
				$db = new mysqli($host_name, $user_name, $password, $db_name);
				
				/* Check Connection */
				if ($error = mysqli_connect_errno()) {
					echo("<br />ERROR -- Connection failed: $error");
					exit(1);
				}
				
				/* Get MaxMovieId and Increment It */
				$query = "SELECT id FROM MaxMovieID;";
				if (!$rs = $db->query($query)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Movie: $error";
					exit(1);
				}
				if (!$row = $rs->fetch_assoc()) {
    			    $error = $db->error;
					echo "<br />ERROR -- Failed to add new Movie: $error";
					exit(1);
    			} 
   				mysqli_free_result($rs);	// --> Free Result Set
				
				$maxid = $row['id'];
				$newid = $maxid + 1;
				$query = "UPDATE MaxMovieID SET id = $newid;";
				if(!$db->query($query)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Movie: $error";
					exit(1);
				}
				
				/* Create and Execute Statements */
				$stmt = $db->prepare("INSERT INTO Movie (id, title, year, rating, company) "
								   . "VALUES (?, ?, ?, ?, ?)");
				$stmt->bind_param("sssss", $newid, $title, $year, $rating, $company);
				$stmt->execute();
				if ($stmt->affected_rows != 1) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Movie: $error";
					$query = "UPDATE MaxMovieID SET id = $maxid;";
					$db->query($query);
					exit(1);
				}
				$stmt->close();	// --> Close statement
				
				echo "<br />Successfully Added New Entry for $title";
				
				$db->close();	// --> Close Connection
			}
			else {
				echo "<br />ERROR -- Cannot ADD Movie Without Title/Company Name.";
				exit(1);
			}
		}
	?>
</div>

</body>
</html>