<html>

<head>
<title><?php print "Movie Database Web Interface"; ?></title>
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="100%" bgcolor="#006666" cellpadding="0" cellspacing="0">
	<tr>
		<td>
            <div align="center">
				<a href="mdwi_home.php" class="title_style">Movie Database Web Interface</a>
			</div>
			<br />
			
			<div align="center">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td class="menu_tabs_active" height="45">
							<a href="mdwi_add_ad.php">Add Actor/Director</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_m.php">Add Movie</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mc.php">Add Movie Review</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_add_mr.php">Add Movie Relation</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_a.php">Show Actor Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_show_m.php">Show Movie Info</a>
						</td>
						<td class="menu_tabs_spaces"></td>
						<td class="menu_tabs">
							<a href="mdwi_search_am.php">Search Actor/Movie</a>
						</td>
					</tr>
				</table>
			</div>
		</td>
	</tr>
</table>

<div align="center" style="font-weight: bold; font-size: 20px; color: #006666">
	<br /><br />
	<form method="post" action="./mdwi_add_ad.php">
	<?php print "Position:" ?>
	<input type="radio" name="pos_radio" value="actor" checked />
	<?php print "Actor" ?>
	<input type="radio" name="pos_radio" value="director" />
	<?php print "Director" ?>
	<input type="radio" name="pos_radio" value="both" />
	<?php print "Both" ?>
	<br /><br />
	
	<?php print "First Name:" ?>
	<input type="text" name="fname_text" size=20 maxlength=20 />
	<br /><br />
	
	<?php print "Last Name:" ?>
	<input type="text" name="lname_text" size=20 maxlength=20 />
	<br /><br />
	
	<?php print "Sex:" ?>
	<input type="radio" name="sex_radio" value="Male" checked />
	<?php print "Male" ?>
	<input type="radio" name="sex_radio" value="Female" />
	<?php print "Female" ?>
	<br /><br />
	
	<?php print "Date of Birth (YYYYMMDD):" ?>
	<select name="dobM_select">
		<?php
			$i = 1;
			for (; $i < 12; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<select name="dobD_select">
		<?php
			$i = 1;
			for (; $i < 31; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<select name="dobY_select">
		<?php
			$i = 1800;
			for (; $i < 2008; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<br /><br />
	
	<?php print "Date of Death (YYYYMMDD):" ?>
	<select name="dodM_select">
		<?php
			$i = 1;
			for (; $i < 12; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<select name="dodD_select">
		<?php
			$i = 1;
			for (; $i < 31; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<select name="dodY_select">
		<?php
			$i = 1800;
			for (; $i < 2008; $i++)
				echo "<option value=\"$i\">$i</option>";
			echo "<option value=\"$i\">$i</option>";
		?>
	</select>
	<input type="checkbox" name="isAlive_checkbox" value="on">
	<?php print " -- Check this box if person is still alive" ?>
	<br /><br />
	
	<input type="reset" value="Reset" />
	<input type="submit" value="Submit" />
	<input type="hidden" name="submitted" value="1" />
	</form>
	
	<?php
		if ($_REQUEST["submitted"] == 1 and !$_REQUEST["reset"]) {
			$pos = $_REQUEST["pos_radio"];
			$fname = $_REQUEST["fname_text"];
			$lname = $_REQUEST["lname_text"];
			$sex = $_REQUEST["sex_radio"];
			$dobM = $_REQUEST["dobM_select"];
			$dobD = $_REQUEST["dobD_select"];
			$dobY = $_REQUEST["dobY_select"];
			$dodM = $_REQUEST["dodM_select"];
			$dodD = $_REQUEST["dodD_select"];
			$dodY = $_REQUEST["dodY_select"];
			$isAlive = $_REQUEST["isAlive_checkbox"];
			
			if ($dobD < 10)
				$dobD = "0" . $dobD;
			if ($dobM < 10)
				$dobM = "0" . $dobM;
			$dob = $dobY . $dobM . $dobD;
			
			if ($dodD < 10)
				$dodD = "0" . $dodD;
			if ($dodM < 10)
				$dodM = "0" . $dodM;
			$dod = $dodY . $dodM . $dodD;
			
			if($isAlive == "on")
				$dod = "NULL";
			else if ($dob > $dod) {
				echo "<br />ERROR -- Cannot ADD Actor/Director Who Died Before They Were Born.";
				exit(1);
			}
			
			if ($fname != "" and $lname != "") {
				/* Connect to MySQLI */
				$host_name = "localhost";
				$user_name = "cs143";
				$password = "";
				$db_name = "CS143";
				$db = new mysqli($host_name, $user_name, $password, $db_name);
				
				/* Check Connection */
				if ($error = mysqli_connect_errno()) {
					echo("<br />ERROR -- Connection failed: $error");
					exit(1);
				}
				
				/* Get MaxPersonId and Increment It */
				$query = "SELECT id FROM MaxPersonID;";
				if (!$rs = $db->query($query)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Actor/Director: $error";
					exit(1);
				}
				if (!$row = $rs->fetch_assoc()) {
    			    $error = $db->error;
					echo "<br />ERROR -- Failed to add new Actor/Director: $error";
					exit(1);
    			} 
   				mysqli_free_result($rs);	// --> Free Result Set
				
				$maxid = $row['id'];
				$newid = $maxid + 1;
				$query = "UPDATE MaxPersonID SET id = $newid;";
				if(!$db->query($query)) {
					$error = $db->error;
					echo "<br />ERROR -- Failed to add new Actor/Director: $error";
					exit(1);
				}
				
				/* Create and Execute Statements */
				if ($pos == "actor") {
					if ($dod == "NULL") {
						$stmt = $db->prepare("INSERT INTO Actor (id, last, first, sex, dob, dod) "
										   . "VALUES (?, ?, ?, ?, ?, NULL);");
						$stmt->bind_param("sssss", $newid, $lname, $fname, $sex, $dob);
					}
					else {
						$stmt = $db->prepare("INSERT INTO Actor (id, last, first, sex, dob, dod) "
										   . "VALUES (?, ?, ?, ?, ?, ?);");
						$stmt->bind_param("ssssss", $newid, $lname, $fname, $sex, $dob, $dod);
					}
				}
				else if ($pos == "director") {
					if ($dod == "NULL") {
						$stmt = $db->prepare("INSERT INTO Director (id, last, first, dob, dod) "
										   . "VALUES (?, ?, ?, ?, NULL);");
						$stmt->bind_param("ssss", $newid, $lname, $fname, $dob);
					}
					else {
						$stmt = $db->prepare("INSERT INTO Director (id, last, first, dob, dod) "
										   . "VALUES (?, ?, ?, ?, ?);");
						$stmt->bind_param("sssss", $newid, $lname, $fname, $dob, $dod);
					}
				}
				else {	// Both
					if ($dod == "NULL") {
						$stmt1 = $db->prepare("INSERT INTO Actor (id, last, first, sex, dob, dod) "
										    . "VALUES (?, ?, ?, ?, ?, NULL);");
						$stmt1->bind_param("sssss", $newid, $lname, $fname, $sex, $dob);
						$stmt2 = $db->prepare("INSERT INTO Director (id, last, first, dob, dod) "
										    . "VALUES (?, ?, ?, ?, NULL);");
						$stmt2->bind_param("ssss", $newid, $lname, $fname, $dob);
					}
					else {
						$stmt1 = $db->prepare("INSERT INTO Actor (id, last, first, sex, dob, dod) "
										    . "VALUES (?, ?, ?, ?, ?, ?);");
						$stmt2 = $db->prepare("INSERT INTO Director (id, last, first, dob, dod) "
										    . "VALUES (?, ?, ?, ?, ?);");
						$stmt1->bind_param("ssssss", $newid, $lname, $fname, $sex, $dob, $dod);
						$stmt2->bind_param("sssss", $newid, $lname, $fname, $dob, $dod);
					}
				}
				
				if ($pos == "actor" || $pos == "director") {
					$stmt->execute();
					if ($stmt->affected_rows != 1) {
						$error = $db->error;
						echo "<br />ERROR -- Failed to add new Actor/Director: $error";
						$query = "UPDATE MaxPersonID SET id = $maxid;";
						$db->query($query);
						exit(1);
					}
					$stmt->close();	// --> Close statement
				}
				else {
					$stmt1->execute();
					$stmt2->execute();
					if ($stmt1->affected_rows != 1 || $stmt2->affected_rows != 1) {
						$error = $db->error;
						echo "<br />ERROR -- Failed to add new Actor/Director: $error";
						$query = "UPDATE MaxPersonID SET id = $maxid;";
						$db->query($query);
						exit(1);
					}
					$stmt1->close();	// --> Close statement 1
					$stmt2->close();	// --> Close statement 2
				}
				
				echo "<br />Successfully Added New Entry for $fname $lname";
				
				$db->close();	// --> Close Connection
			}
			else {
				echo "<br />ERROR -- Cannot ADD Actor/Director Without First/Last Name.";
				exit(1);
			}
		}
	?>
</div>

</body>
</html>
