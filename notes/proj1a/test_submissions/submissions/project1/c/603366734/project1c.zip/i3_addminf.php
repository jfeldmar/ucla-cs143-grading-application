<?php
// TODO:
// format the director so it parses all of them, same with the previous ones
// make the genre parse the possibilities
// also make it so it processes an insert
?>
<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=FF4500>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p><font size=2>
The following fields are for you to <b>ADD</b> a new <b>Movie</b> into the CS143MDB.  Please fill out the following fields accordingly and hit <b>"Add!"</b><p>

<form action="i3_addminf.php" method="GET">
<?php
echo "<b>Title </b><br><input type=\"text\" name=\"movietitle\" maxlength=\"45\"></input><p>";
echo "<b>Production Company<br></b> <input type=\"text\" name=\"procomp\" maxlength=\"35\"></input><p>";
echo "<b>Year<br></b> <input type=\"text\" name=\"myear\" maxlength=\"4\"></input><p>";
echo "<b>Director<br></b> ";


$getdirs = "SELECT first, last, id FROM Director";
echo "<select name=\"dirname\" value=\"\">";
echo "<option selected value=\"\">Pick a Director!</option>";
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$rs = mysql_query($getdirs, $db_connection);
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"$row[2]\">";
			// foreach ($row as $value) 
			// {
				echo "$row[0] $row[1]";
			// }
			echo "</option>";
		}
		unset($value);
		mysql_close($db_connection);
echo "</select><p>";
					
echo "<b>MPAA Rating<br></b> <select name=\"mpaarating\">
					<option value=\"G\">G</option>
					<option value=\"PG\">PG</option>
					<option value=\"PG-13\">PG-13</option>
					<option value=\"R\">R</option>
					<option value=\"NC-17\">NC-17</option>
					</select><p>";

echo "<b>Genre</b><br> 
					<input type=radio name=genre value=Action>Action</input>
<input type=radio name=genre value=Adult>Adult </input>
<input type=radio name=genre value=Adventure>Adventure </input>
<input type=radio name=genre value=Animation>Animation </input>
<input type=radio name=genre value=Comedy>Comedy </input>

<input type=radio name=genre value=Crime>Crime </input>
<input type=radio name=genre value=Documentary>Documentary </input>
<input type=radio name=genre value=Drama>Drama </input>
<input type=radio name=genre value=Family>Family </input>
<input type=radio name=genre value=Fantasy>Fantasy </input>
<input type=radio name=genre value=Horror>Horror </input>
<input type=radio name=genre value=Musical>Musical </input>
<input type=radio name=genre value=Mystery>Mystery </input>
<input type=radio name=genre value=Romance>Romance </input>

<input type=radio name=genre value=Sci-Fi>Sci-Fi </input>
<input type=radio name=genre value=Short>Short </input>
<input type=radio name=genre value=Thriller>Thriller </input>
<input type=radio name=genre value=War>War </input>
<input type=radio name=genre value=Western>Western </input>";
echo "<p>";
echo "<input type=\"submit\" value=\"Add!\"/><p>";

$valid = "/^[0-9]*$/";
$c_movietitle = $_GET["movietitle"];
$c_procomp = $_GET["procomp"];
$c_myear = $_GET["myear"];
$c_dirname = $_GET["dirname"];
$c_mpaarating = $_GET["mpaarating"];
$c_genre = $_GET["genre"];

if ($c_movietitle=="" && $c_procomp=="" && $c_myear=="" && $c_dirname=="" && $c_genre=="")
{
	
}
else if ($c_movietitle=="")
{
	echo "<font color=red><b>FAILURE to Insert!  Must at least enter a movie title!</b><font color=black>";
}
else if (preg_match($valid,$c_myear,$matches)!= 1)
{
	echo "<font color=red><b>FAILURE to Insert!  Year must be a valid number!</b><font color=black>";
}
else
{
	$get_val_mid = "SELECT id FROM MaxMovieID";
	$update_mmid = "update MaxMovieID set id = id + 1";
	
	$ami_con = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $ami_con);
	$parsee = mysql_query($get_val_mid, $ami_con);
	while($basic = mysql_fetch_row($parsee))
	{
		$maxid = $basic[0];
	}
	$ins_com = "INSERT INTO Movie VALUES($maxid, '$c_movietitle', $c_myear, '$c_mpaarating', '$c_procomp')";
	//echo $maxid;
	//echo $c_movietitle;
	mysql_query($ins_com, $ami_con);
	mysql_query($update_mmid, $ami_con);
	echo "<font color=blue><b>Success!</b><font color=black>";
	mysql_close($ami_con);
}




echo "</form>";
?>





</body>
</html>