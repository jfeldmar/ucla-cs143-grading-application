<?php
// TODO:
// format the dropdown list for all movies
// make a nice display table if an actor is selected
// maybe include links in the display table?
?>
<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=EEC900>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p>
<font size=2>

<form action="b2_movinf.php" method="GET">
<br>

<font size=1><b>begin movie information</b>
<hr width=600 align=left>
<font size=2>
<?php
$movieid = $_GET["pickmovie"];
if ($movieid=="")
{
	echo "No Movie Selected!";
}
else
{
	$getmovieinfo = "select title, year, company, rating from Movie where id=$movieid";
	$getactual = "select first, last, role, Actor.id from Actor, Movie, MovieActor where Actor.id=MovieActor.aid and MovieActor.mid=Movie.id and Movie.id=$movieid";
	$getrating = "";
	$basic_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $basic_connection);
	$bas1c = mysql_query($getmovieinfo, $basic_connection);
	while($basic = mysql_fetch_row($bas1c))
	{
		echo "<font size=4><b>$basic[0]</b> ($basic[1])<font size=2><br>";
		echo "<b>Production Company:</b> $basic[2]<br>";
		echo "<b>MPAA Rating:</b> $basic[3]<br>";
	}
	echo "<br>";
	echo "<b><font size=3>Featuring...</b><font size=2><br>";
	$starring = mysql_query($getactual, $basic_connection);
	while($parsebaby = mysql_fetch_row($starring))
	{
		echo "<a href=\"b1_ainf.php?pickactor=$parsebaby[3]\">$parsebaby[0] $parsebaby[1]</a> as <b>$parsebaby[2]</b><br>";
	}
	echo "<p>";
	echo "<b><font size=3>Reviews</b><font size=2><br>";
	$getreview = "select name, time, rating, comment from Review where mid=$movieid";
	$prevs = mysql_query($getreview, $basic_connection);
	while($prevx = mysql_fetch_row($prevs))
	{
		echo "On <b><font color=blue>$prevx[1]</b><font color=black>, <font color=green><b>
		$prevx[0]</b><font color=black> rated this movie a <b>$prevx[2]</b> and said:<br>
		$prevx[3]<p>";
	}
	echo "Add your <a href=\"i2_addc.php\">own comment</a> to this movie as well as others!";
	mysql_close($basic_connection);

}
?>
<hr width=600 align=left></center>

<?php
$getactors = "select title, id from Movie";
echo "<form action=b2_movinf.php method=GET><br>";
echo "<b>Select a New Movie<br></b>";


echo "<select name=\"pickmovie\" value=\"\">";
echo "<option selected value=\"\">Pick a Movie!</option>";
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$rs = mysql_query($getactors, $db_connection);
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"$row[1]\">";
			// foreach ($row as $value) 
			// {
				echo "$row[0]";
			// }
			echo "</option>";
		}
		unset($value);
		mysql_close($db_connection);

echo "</select><br>	<input type=submit value=Select></input> </form>";



?>








</body>
</html>