<?php
// TODO:
// format the movie field so it does a select on ALL movie titles and parses each individual one in the movie tab
// also make it so it processes an insert
//<img src="http://bp2.blogger.com/_0O9XLxGZBXw/Rqi4xDNEQWI/AAAAAAAAAK0/qNzrdEPw3wo/s320/megan-fox-transformers.jpg">
?>
<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=00BB23>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p><font size=2>
The following fields are for you to <b>ADD</b> new comments for a <b>Movie</b> into the CS143MDB.  Please fill out the following fields accordingly and hit <b>"Add!"</b><p>

<form action="i2_addc.php" method="GET">

<b>Your Name </b><br><input type="text" name="yourname" maxlength="25"><p>
<b>Movie</b> <br>

<?php
$getactors = "select title, id from Movie";
echo "<select name=\"pickmovie\" value=\"\">";
echo "<option selected value=\"\">Pick a Movie!</option>";
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$rs = mysql_query($getactors, $db_connection);
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"$row[1]\">";
			// foreach ($row as $value) 
			// {
				echo "$row[0]";
			// }
			echo "</option>";
		}
		mysql_close($db_connection);
	echo "</select><p>";
		?>
<b>Your Rating<br></b> <select name="rating">
						<option value="5"> 5 - Excellent </option>
						<option value="4"> 4 - Good </option>
						<option value="3"> 3 - It's ok </option>

						<option value="2"> 2 - Not worth </option>
						<option value="1"> 1 - I hate it </option>
					</select><p>
<b>Your Comments<br></b> <textarea name="comment" cols="80" rows="10"></textarea>
<p>

<input type="submit" value="Add!"/><p>
</form>

<?php
$uname = $_GET["yourname"];
$mid = $_GET["pickmovie"];
$urating = $_GET["rating"];
$ucomments = $_GET["comment"];

if ($uname=="" && $mid=="" && $urating=="" && $ucomments=="")
{
}
else if ($mid=="" || $uname=="")
{
	echo "<font color=red><b>FAILURE to Insert!  Must provide at least a name and movie!</b><font color=black>";

}
else
{
	$addreview = "insert into Review VALUES('$uname', now(), $mid, $urating, '$ucomments')";
	$db_connecti0n = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connecti0n);
	mysql_query($addreview, $db_connecti0n);
	echo "<font color=blue><b>Success!</b><font color=black><p>";
	mysql_close($db_connecti0n);
}
?>




</body>
</html>