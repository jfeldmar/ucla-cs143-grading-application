<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=141414>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><br>
<font size=2>
<br>
<form action="search.php" method="GET">
<b>Search Phrase</b> <input type="text" name="keyword"></input><br>
<input type="submit" value="Search"/></input><p>
</form>
<hr width=600 align=left>
<?php
$searchq = $_GET["keyword"];
if ($searchq=="")
{
	echo "";
}
else
{
	echo "<font size=3>SEARCH RESULTS FOR [<b>$searchq</b>]</b><p><font size=2>";
	echo "<b>Actor DB</b><br>";
	$search_conn = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $search_conn);
	$searchact = "select first, last, id from Actor where last='$searchq' OR first='$searchq'";
	$sq = mysql_query($searchact, $search_conn);
	while($parse = mysql_fetch_row($sq))
	{
		echo "<a href=\"b1_ainf.php?pickactor=$parse[2]\">$parse[0] $parse[1]</a><br>";
	}
	echo "<p>";
	echo "<b>Movie DB</b><br>";
	$searchmov = "select title, year, id from Movie where title like '%$searchq%'";
	$sq2 = mysql_query($searchmov, $search_conn);
	while($parsee = mysql_fetch_row($sq2))
	{
		echo "<a href=\"b2_movinf.php?pickmovie=$parsee[2]\">$parsee[0] ($parsee[1])</a><br>";
	}
	mysql_close($search_conn);
}


?>










</body>
</html>