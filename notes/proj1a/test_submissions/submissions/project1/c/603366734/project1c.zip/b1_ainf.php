<?php
// TODO:
// format the dropdown list for all actors
// make a nice display table if an actor is selected
// maybe include links in the display table?
?>
<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=4B0082>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>
<hr width=100 align=left><br><font size=2><br>
<font size=1><b>begin actor information</b>
<hr width=600 align=left>
<font size=2>

<?php
$aid = $_GET["pickactor"];
if ($aid=="")
{
	echo "No Actor or Actress Selected!";
}
else
{
	$getactorinfo = "select first, last, sex, dob, dod from Actor where Actor.id=$aid";
	$getactual = "select title, role, Movie.id from Actor, Movie, MovieActor where Actor.id=MovieActor.aid and MovieActor.mid=Movie.id and Actor.id=$aid";
	$basic_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $basic_connection);
	$bas1c = mysql_query($getactorinfo, $basic_connection);
	while($basic = mysql_fetch_row($bas1c))
	{
		echo "<font size=4><b>$basic[0] $basic[1]</b><font size=2><br>";
		echo "<b>Sex:</b> $basic[2]<br>";
		echo "<b>DOB:</b> $basic[3]<br>";
		if ($basic[4] == "")
		{
			echo "<br>";
		}
		else
		{
			echo "<b>DOD:</b> $basic[4]<p>";
		}
	}
	echo "<b><font size=3>Starring As...</b><font size=2><br>";
	$starring = mysql_query($getactual, $basic_connection);
	while($parsebaby = mysql_fetch_row($starring))
	{
		echo "<b>$parsebaby[1]</b> in <a href=\"b2_movinf.php?pickmovie=$parsebaby[2]\">$parsebaby[0]</a><br>";
	}
	mysql_close($basic_connection);

}
?>
</center>

<hr width=600 align=left>

<?php
$getactors = "select last, first, id from Actor";
echo "<form action=b1_ainf.php method=GET><br>";
echo "<b>Select a New Actor<br></b>";


echo "<select name=\"pickactor\" value=\"\">";
echo "<option selected value=\"\">Pick an Actor!</option>";
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$rs = mysql_query($getactors, $db_connection);
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"$row[2]\">";
			// foreach ($row as $value) 
			// {
				echo "$row[0], $row[1]";
			// }
			echo "</option>";
		}
		mysql_close($db_connection);

echo "</select><br>	<input type=submit value=Select></input> </form>";



?>





</body>
</html>