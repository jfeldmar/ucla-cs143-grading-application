<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=E2003>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p><font size=2>
Welcome to the CS143 Movie Database!  For your convenience, please use the links at the top to direct you to your desired location!  <p>
For <b>INVESTOR INFORMATION</b> please email me at <b>EDWARD.CHANG AT UCLA DOT EDU</b>.<p>
<img src="http://nicedeb.files.wordpress.com/2007/12/chuck_norris.jpg">



</body>
</html>