<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=3399FF>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p><font size=2>
The following fields are for you to <b>ADD</b> a new relation between a <b>Movie</b> and an <b>Actor</b> into the CS143MDB.  Please fill out the following fields accordingly and hit <b>"Add!"</b><p>

<form action="i4_addrel.php" method="GET">

<font size=3><b>Add a new Actor in a Movie</b><font size=2><p>

<?php
echo "<b>Movie</b><br>";
$getmovies = "select title, id from Movie";
echo "<select name=\"pickmovie\" value=\"\">";
echo "<option selected value=\"\">Pick a Movie!</option>";
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);
$rs = mysql_query($getmovies, $db_connection);
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"$row[1]\">";
			// foreach ($row as $value) 
			// {
				echo "$row[0]";
			// }
			echo "</option>";
		}
	echo "</select><p>";
	
	
	
	echo "<b>Actor</b><br>";
	echo "<select name=\"aid\" value=\"\">";
	echo "<option selected value=\"\">Pick an Actor!</option>";
	$getactors = "select last, first, id from Actor";
	$rs2 = mysql_query($getactors, $db_connection);
		while($row2 = mysql_fetch_row($rs2))
		{
			echo "<option value=\"$row2[2]\">";
			// foreach ($row as $value) 
			// {
				echo "$row2[0], $row2[1]";
			// }
			echo "</option>";
		}
	echo "</select>";
	
	
	echo "<p>";
	mysql_close($db_connection);
		?>

<b>Role<br></b> <input type="text" name="role" maxlength="30" width=30></input>
<p>

<input type="submit" value="Add!"/><p>
</form>

<?php
$rmid = $_GET["pickmovie"];
$raid = $_GET["aid"];
$rrole = $_GET["role"];

if ($rmid=="" && $raid=="" && $rrole=="")
{
}
else if ($rmid=="" || $raid=="" || $rrole=="")
{
	echo "<font color=red><b>FAILURE to Insert!  All fields need to be filled out!</b><font color=black>";

}
else
{
	$addrelat = "insert into MovieActor VALUES($rmid, $raid, '$rrole')";
	$db_connecti0n = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connecti0n);
	mysql_query($addrelat, $db_connecti0n);
	echo "<font color=blue><b>Success!</b><font color=black><p>";
	mysql_close($db_connecti0n);
}
?>




</body>
</html>