<?php
# this is the add actor/director info page
# need to do: format the params once theyre passed in
# so you can do a simple select type INSERT thing
# <img src="http://poplicks.com/images/dark-knight-interrogation.jpg">
?>
<html>
<head>
<title>CS143MDB v1.0 - by Edward Chang</title>
</head>
<body bgcolor=DCDCDC>
<h1><font face=verdana><font color=0047D6>CS143MDB</h1><font color=black>
<hr width=100 align=left>
<font face=verdana size=1><b>Add New Content</b> [ <a href="i1_addadinfo.php">Add Actor/Director Info</a> ] - [ <a href="i2_addc.php">Add Comments</a> ] - [ <a href="i3_addminf.php">Add Movie Info</a> ] - [ <a href="i4_addrel.php">Add Actor/Movie Relation</a> ]<br>
<b>Browsing Pages</b> [ <a href="b1_ainf.php">Actor Info</a> ] - [ <a href="b2_movinf.php">Movie Info</a> ]<br>
<b>Search Page</b> [ <a href="search.php">Search Actor/Actress/Movie</a> ]<br>

<hr width=100 align=left><p><font size=2>
The following fields are for you to <b>ADD</b> a new <b>Actor</b> or <b>Director</b> into the CS143MDB.  Please fill out the following fields accordingly and hit <b>"Add!"</b><p>

<form action="i1_addadinfo.php" method="GET">
<b><font size=2> Actor</b> or <b>Director</b>?<br>
<input type="radio" name="identity" value="Actor" checked="true"></input><font color=0A0045>Actor &nbsp; &nbsp; &nbsp;
<input type="radio" name="identity" value="Director"></input>Director<p> <font color=black>

<b><font size=2> Full Name</b><br>
<font color=0A0045>First <input type="text" name="firstName" maxlength="20"></input><br>
Last <input type="text" name="lastName" maxlength="20"></input><p>
<font color=black>

<b><font size=2> Sex</b><br>
<input type="radio" name="sex" value="Male" checked="true"></input><font color=0A0045>Male &nbsp; &nbsp; &nbsp;
<input type="radio" name="sex" value="Female"></input>Female<p> <font color=black>

<b><font size=2> DOB </b>and <b>DOD</b><br>
<font color=0A0045>Date of Birth&nbsp;&nbsp;&nbsp;&nbsp; <input type="text" name="dob" maxlength="20"></input><br>
Date of Death* <input type="text" name="dod" maxlength="20"></input><p>

<input type="submit" value="Add!"/><p>
</form>
<?php
$valid_name = "/^[A-Za-z]*$/";
$valid_date = "/^[0-2][0-9][0-9][0-9][-][0-1][0-2][-][0-3][0-9]$/";
$c_identity = $_GET["identity"];
$c_first = $_GET["firstName"];
$c_last = $_GET["lastName"];
$c_sex = $_GET["sex"];
$c_dob = $_GET["dob"];
$c_dod = $_GET["dod"];
if ($c_first=="" && $c_last=="" && $c_dod=="" && $c_dob=="")
{
}
else if ($c_first=="" || $c_last=="" || $c_dob=="")
{
	echo "<font color=red><b>FAILURE to Insert!  Full name and DOB must be filled out!</b><font color=black><p>";
}
else if (preg_match($valid_name,$c_first,$matches)!= 1)
{
	echo "<font color=red><b>FAILURE to Insert!  Name must be valid!</b><font color=black><p>";
}
else if (preg_match($valid_name,$c_last,$matches)!= 1)
{
	echo "<font color=red><b>FAILURE to Insert!  Name must be valid!</b><font color=black><p>";
}
else if (preg_match($valid_date,$c_dob,$matches)!= 1)
{
	echo "<font color=red><b>FAILURE to Insert!  Date must be in the form of YYYY-MM-DD!</b><font color=black><p>";
}
else
{
	$get_val_pid = "SELECT id FROM MaxPersonID";
	$update_mpid = "update MaxPersonID set id = id + 1";
	
	$aadi_con = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $aadi_con);
	$getit = mysql_query($get_val_pid, $aadi_con);
	while($basc = mysql_fetch_row($getit))
	{
		$maxpid = $basc[0];
	}
	$ins_act = "INSERT INTO Actor VALUES($maxpid, '$c_last', '$c_first', '$c_sex', '$c_dob', NULL)";
	$ins_actd = "INSERT INTO Actor VALUES($maxpid, '$c_last', '$c_first', '$c_sex', '$c_dob', '$c_dod')";
	$ins_dir = "INSERT INTO Director VALUES($maxpid, '$c_last', '$c_first', '$c_dob', NULL)";
	$ins_dird = "INSERT INTO Director VALUES($maxpid, '$c_last', '$c_first', '$c_dob', '$c_dod')";
	

	
	if ($c_identity == "Actor")
	{
		if ($c_dod=="")
		{
			mysql_query($ins_act, $aadi_con);
		}
		else
		{
			mysql_query($ins_actd, $aadi_con);
		}
	}
	else if ($c_identity == "Director")
	{
		if ($c_dod == "")
		{
			mysql_query($ins_dir, $aadi_con);
		}
		else
		{
			mysql_query($ins_dird, $aadi_con);
		}
	}
	mysql_query($update_mpid, $aadi_con);
	echo "<font color=blue><b>Success!</b><font color=black><p>";
	mysql_close($aadi_con);
}
?>

<font color=black>

<font size=1>
* : Please leave blank if person is still alive
<p>



</body>
</html>