Name: Tetsuya Takahashi
SID: 503-638-523
Email: enashiro@gmail.com

I used a command "mysql CS143 -uroot -ppassword < load.sql" to load the data.
Also, I used an absolute path '/home/cs143/www/data/~.del' in load.sql.
When I use './data/~.del' to load, it causes "ERROR 13 (HY000) at line 1: Can't get stat of './data/actor1.del' (Errcode: 2)". I asked TA about it and he said that I can use an absolute path instead of a relative and it doesn't matter because TA's and professor's systems should put the data file in the same directory. That's why I am using an absolute path '/home/cs143/www/data/~.del' in load.sql.

