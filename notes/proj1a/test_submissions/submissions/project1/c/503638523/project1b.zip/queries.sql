SELECT DISTINCT last, first
FROM Actor, MovieActor, Movie 
WHERE title='Die Another Day' AND Actor.id = MovieActor.aid AND MovieActor.mid = Movie.id;

-- the names of all the actors in the movie 'Die Another Day'. 
-- I choose three tables Actor, MovieActor, and Movie, and I pick up the same ids in the movie 'Die Another Day'.

SELECT COUNT(*)
FROM (SELECT aid FROM MovieActor GROUP BY aid HAVING COUNT(*)>1) M

-- the count of all the actors who acted in multiple movies. 
-- Using Correlated subqueries
-- I choose ids which same ids come out more than 1 in the subquery, and count it.

SELECT COUNT(*)
FROM Actor
GROUP BY sex
-- How many actors are in each gender.

