<html>
<head>
	<title>Actor Information</title>
</head>

<body>
<form action="./showActorInfo.php" method="GET">See Actor : 
<select name="aid">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }
	
	$query = "SELECT id, first, last, dob FROM Actor ORDER BY first";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($query, $db_connection);
	if (!$result) {	echo 'Could not run query.'; exit;}

	while($row = mysql_fetch_row($result)) {
		if($_GET["aid"] == $row[0])
		{
			print "<option value=\"".$row[0]."\" selected>".$row[1]." ".$row[2]."(".$row[3].")</option>";
		}else{
			print "<option value=\"".$row[0]."\">".$row[1]." ".$row[2]."(".$row[3].")</option>";
		}
	}

?>
</select>
<br/>
<input type="submit" value="Search"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$actorID = $_GET["aid"];

if($actorID){

	mysql_select_db("CS143", $db_connection);
	
	print "<table border='1' cellspacing='0' cellpadding='1' bordercolorlight='#FF9900' bordercolordark='#FFFFFF' bgcolor='#FFC266'><tr><td>";
	print "<table border='1' cellspacing='0' cellpadding='2' bordercolorlight='#FF9900' bordercolordark='#FFFFFF' bgcolor='#FFC266'><tr><td>";

	print "<div align='center'> -- Show Actor Info -- </div>";
	/////////// Actor Infomation /////////////
	$queryActor = "SELECT * FROM Actor WHERE id=".$actorID;
	$resultActor = mysql_query($queryActor, $db_connection);
	if (!$resultActor){ echo 'Could not run Actor query.'; exit; }
	$rowActor = mysql_fetch_row($resultActor);
	
	print "Name : ".$rowActor[2]." ".$rowActor[1]."<br/>";
	print "Sex : ".$rowActor[3]."<br/>";
	print "Date Of Birth : ".$rowActor[4]."<br/>";
	print "Date Of Death : ";
	if($rowActor[5] == NULL){ print "--Still Alive--<br/>"; }
						else{ print $rowActor[5]."<br/>"; }
						
	print "</td></tr><tr><td bgcolor='#ffffff'>";

	print "<div align='center'> -- Act in -- </div>";
	/////////// Actor & MovieActor Infomation //////////
	$queryMovieActor = "SELECT mid, aid, role, title FROM MovieActor MA, Movie M WHERE MA.mid = M.id AND aid=".$actorID;
	$resultMovieActor = mysql_query($queryMovieActor, $db_connection);
	if (!$resultMovieActor){ echo 'Could not run MovieActor query.'; exit; }
	while($rowMovieActor = mysql_fetch_row($resultMovieActor)) {
		print "Act \"".$rowMovieActor[2]."\" in <a href ='./showMovieInfo.php?mid=".$rowMovieActor[0]."'>".$rowMovieActor[3]."</a><br/>";
	}
	print "</td></tr></table></td></tr></table>";

}//end if($movieID)

mysql_close($db_connection);
?>

</body>
</html>