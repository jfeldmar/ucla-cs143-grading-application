<html>
<head>
	<title>Movie Information</title>
</head>

<body>
<form action="./showMovieInfo.php" method="GET">See Movie : 

<select name="mid">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	$query = "SELECT id, title, year FROM Movie ORDER BY title";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($query, $db_connection);
	if (!$result) {
	    echo 'Could not run query.';
	    exit;
	}

	while($row = mysql_fetch_row($result)) {
		if($_GET["mid"] == $row[0])
		{
			print "<option value=\"".$row[0]."\" selected>".$row[1]."(".$row[2].")</option>";
		}else{
			print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")</option>";
		}
	}
?>
</select>

<br/>
<input type="submit" value="Search"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$movieID = $_GET["mid"];

if($movieID){
//	$queryMovieInfo = "SELECT * FROM Movie M, Director D WHERE M.id=".$movieID." AND D.id = (SELECT did FROM MovieDirector WHERE mid=".$movieID." )";
	
	mysql_select_db("CS143", $db_connection);
	
	print "<table border='1' cellspacing='0' cellpadding='1' bordercolorlight='#0000FF' bordercolordark='#FFFFFF' bgcolor='#B2B2FF'>";
	print "<tr><td>";
	print "<table width='100%' border='1' cellspacing='0' cellpadding='2' bordercolorlight='#0000FF' bordercolordark='#FFFFFF' bgcolor='#B2B2FF'>";

	print "<tr><td align='center'> -- Show Movie Info -- <br/></td></tr><tr><td bgcolor='#ffffff'>";
	/////////// Movie Infomation /////////////
	$queryMovie = "SELECT * FROM Movie WHERE id=".$movieID;
	$resultMovie = mysql_query($queryMovie, $db_connection);
	if (!$resultMovie){ echo 'Could not run Movie query.'; exit; }
	$rowMovie = mysql_fetch_row($resultMovie);
	
	/////////// Director Infomation //////////
	$queryDirector = "SELECT * FROM Director D, MovieDirector M WHERE D.id = M.did AND mid=".$movieID;
	$resultDirector = mysql_query($queryDirector, $db_connection);
	if (!$resultDirector){ echo 'Could not run Director query.'; exit; }
//	$rowDirector = mysql_fetch_row($resultDirector);
	
	/////////// Movie Genre Infomation //////////
	$queryMovieGenre = "SELECT genre FROM MovieGenre WHERE mid=".$movieID;
	$resultMovieGenre = mysql_query($queryMovieGenre, $db_connection);
	if (!$resultMovieGenre){ echo 'Could not run MovieGenre query.'; exit; }
//	$rowMovieGenre = mysql_fetch_row($resultMovieGenre);
	
	print "Title : ".$rowMovie[1]." (".$rowMovie[2].")<br/>";
	print "Company : ".$rowMovie[4]."<br/>";
	print "MPAA Rating : ".$rowMovie[3]."<br/>";
	print "Director : ";
// if($rowDirector[1] == NULL && $rowDirector[2] == NULL){ print "<br/>"; }
	while($rowDirector = mysql_fetch_row($resultDirector)){
		print"<font color='Green'>".$rowDirector[2]." ".$rowDirector[1]." (".$rowDirector[3].")&nbsp;&nbsp;</font>";
	}
	print "<br/>";
	print "Genre : <font color='Brown'>";
	while($rowMovieGenre = mysql_fetch_row($resultMovieGenre)) {
		print $rowMovieGenre[0]." ";
	}
	print "</font></td></tr></table></td></tr></table><br/>";
	
	print "<table border='1' cellspacing='0' cellpadding='2' bordercolorlight='#FF9900' bordercolordark='#FFFFFF' bgcolor='#FFC266'>";

	print "<tr><td align='center'> -- Actor in this movie -- </td></tr><tr><td bgcolor='#ffffff'>";
	/////////// Actor & MovieActor Infomation //////////
	$queryActor = "SELECT * FROM Actor A, MovieActor M WHERE A.id = M.aid AND mid=".$movieID;
	$resultActor = mysql_query($queryActor, $db_connection);
	if (!$resultActor){ echo 'Could not run Actor query.'; exit; }
	while($rowActor = mysql_fetch_row($resultActor)) {
		print "<a href=\"./showActorInfo.php?aid=".$rowActor[0]."\">".$rowActor[2]." ".$rowActor[1]."</a> act as \"".$rowActor[8]."\"<br/>";
	}
	print "</td></tr></table><br />";
	
	print "<hr color='#999999' style='filter:alpha(opacity=100,finishopacity=0,style=1);'><br />";
	
	print "<table  style='border-color:#7E7EFF; border-width:1px; border-style:solid;'>";

	print "<tr><td align='center'> -- User Review -- <br />";
	print "</td></tr></table>";
	/////////// Review Infomation ////////////
	$queryReview = "SELECT * FROM Review WHERE mid=".$movieID;
	$resultReview = mysql_query($queryReview, $db_connection);
	if (!$resultReview){ echo 'Could not run Review query.'; exit; }
	
	$queryReviewAvg = "SELECT AVG(rating), COUNT(rating) FROM Review WHERE mid=".$movieID;	
	$resultReviewAvg = mysql_query($queryReviewAvg, $db_connection);
	if (!$resultReviewAvg){ echo 'Could not run ReviewAvg query.'; exit; }
	$rowReviewAvg = mysql_fetch_row($resultReviewAvg);
	
	print "<h4>Average Score: ";
	if($rowReviewAvg[1] == 0){ 
		print "(Sorry, no review for this movie)</h4>";
	}else{ 
		print $rowReviewAvg[0]."/5 (5.0 is best) by ".$rowReviewAvg[1]." review(s).</h4><br />";
		print "All Comments in Details:<br/>";
	}
	while($rowReview = mysql_fetch_row($resultReview)){
		print "<div style='padding:2px;background:#FAFCC7;border-color:#9C9F44;border-width:1px;border-style:solid;'>";
		print "<div style='padding:5px;background:#FCFDE0;border-color:#9C9F44;border-width:1px;border-style:solid;'>";
		print "<font color='Blue'>In ".$rowReview[1].", <font color='Red'>".$rowReview[0]."</font> said: <br/>";
		print "I rate this move score <font color='Red'>".$rowReview[3]."</font> point(s), here is my comment.</font>";
		print "<br/>\"".$rowReview[4]."\"";
		print "</div></div><br/>";
	}
	print "<a href='./addComment.php?mid=".$movieID."'>  Add your review now!!</a><br/><br/>";

}//end if($movieID)

mysql_close($db_connection);
?>

</body>
</html>
