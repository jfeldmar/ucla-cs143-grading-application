<html>
<head>
	<title>add Actor / Director</title>
</head>

<body>
Add new actor/director: <br/>
<form action="./addActorDirector.php" method="GET">
	Identity:<input type="radio" name="identity" value="Actor" checked="true">Actor
			 <input type="radio" name="identity" value="Director">Director<br/>
<hr style="background-color:#B6D6F9; border:none;" />
	First Name:	<input type="text" name="first" maxlength="20"><br/>
	Last Name:	<input type="text" name="last" maxlength="20"><br/>
	Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
				<input type="radio" name="sex" value="Female">Female<br/>
	Date of Birth:	<input type="text" name="dob"><br/>
	Date of Die:	<input type="text" name="dod"> (leave blank if alive now)<br/>
	<input type="submit" value="add it!!"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$identity = $_GET["identity"];
$first = $_GET["first"];
$last = $_GET["last"];
$sex = $_GET["sex"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];
if($dod==NULL){$dod="NULL";}

if($identity AND $first AND $last AND $sex AND $dob)
{
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }

	if($identity == "Actor"){
		$query = "INSERT INTO ".$identity." (last, first, sex, dob, dod) VALUES ( '".$last."', '".$first."', '".$sex."', ".$dob.", ".$dod.")";
	}
	if($identity == "Director"){
		$query = "INSERT INTO ".$identity." (last, first, dob, dod) VALUES ( '".$last."', '".$first."', ".$dob.", ".$dod.")";
	}
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($query, $db_connection);
	if (!$result) {	echo 'Could not run query.'; exit;}
	
	print "<font color='Red'><b>Add Success!!</b></font><br/>";
	print $identity." : ".$first." ".$last;
	
	mysql_close($db_connection);
}else{
	print "Please fill out all information.";
}
?>
</body>
</html>