<html>
<head>
	<title>add new movie</title>
</head>

<body>
Add new movie: <br/>
<form action="./addMovieInfo2.php" method="GET">
	Title : <input type="text" name="title" maxlength="20"><br/>
	Compnay: <input type="text" name="company" maxlength="50"><br/>
	Year : <input type="text" name="year" maxlength="4"><br/>
	
	Director : <select name="did">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }

	$queryDirector = "SELECT id, first, last, dob FROM Director ORDER BY first";
	
	mysql_select_db("CS143", $db_connection);
	$resultDirector = mysql_query($queryDirector, $db_connection);
	if (!$resultDirector){ echo 'Could not run Director query.'; exit; }
	
	while($row = mysql_fetch_row($resultDirector)) {
		if($_GET["did"] == $row[0])
		{
			print "<option value=\"".$row[0]."\" selected>".$row[1]." ".$row[2]."(".$row[3].")</option>";
		}else{
			print "<option value=\"".$row[0]."\">".$row[1]." ".$row[2]."(".$row[3].")</option>";
		}
	}
?>
	</select>
	<br/>
	
	MPAA Rating : <select name="mpaarating">
	<option value="G">G</option>
	<option value="NC-17">NC-17</option>
	<option value="PG">PG</option>
	<option value="PG-13">PG-13</option>
	<option value="R">R</option>
	<option value="surrendere">surrendere</option>
	</select>
	<br/>
	
	Genre : 
	<input type="checkbox" name="genre_Action" value="Action">Action</input>
	<input type="checkbox" name="genre_Adult" value="Adult">Adult</input>
	<input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input>
	<input type="checkbox" name="genre_Animation" value="Animation">Animation</input>
	<input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input>
	<input type="checkbox" name="genre_Crime" value="Crime">Crime</input>
	<input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input>
	<input type="checkbox" name="genre_Drama" value="Drama">Drama</input>
	<input type="checkbox" name="genre_Family" value="Family">Family</input>
	<input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input>
	<input type="checkbox" name="genre_Horror" value="Horror">Horror</input>
	<input type="checkbox" name="genre_Musical" value="Musical">Musical</input>
	<input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input>
	<input type="checkbox" name="genre_Romance" value="Romance">Romance</input>
	<input type="checkbox" name="genre_Sci-Fi" value="Sci-Fi">Sci-Fi</input>
	<input type="checkbox" name="genre_Short" value="Short">Short</input>
	<input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input>
	<input type="checkbox" name="genre_War" value="War">War</input>
	<input type="checkbox" name="genre_Western" value="Western">Western</input>
	<br/>

<input type="submit" value="Add it!!"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$title = $_GET["title"];
$company = $_GET["company"];
$year = $_GET["year"];
$did = $_GET["did"];
$mpaarating = $_GET["mpaarating"];

$genre = array( $_GET["genre_Action"], $_GET["genre_Adult"], $_GET["genre_Adventure"], $_GET["genre_Animation"], $_GET["genre_Comedy"], $_GET["genre_Crime"],
				$_GET["genre_Documentary"], $_GET["genre_Drama"], $_GET["genre_Family"], $_GET["genre_Fantasy"], $_GET["genre_Horror"], $_GET["genre_Musical"],
				$_GET["genre_Mystery"], $_GET["genre_Romance"], $_GET["genre_Sci-Fi"], $_GET["genre_Short"], $_GET["genre_Thriller"], $_GET["genre_War"],
				$_GET["genre_Western"] );

if($title AND $company AND $year)
{
	if(!preg_match("/^\d\d\d\d$/",$year))
	{
		echo "Please type a correct year : ".$year."<br />";
		exit;
	}

	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }
	
	$updateMax = "UPDATE MaxMovieID SET id=id+1";
	$resultMax = mysql_query($updateMax, $db_connection);
	if (!$resultMax) {	echo 'Could not run Update MaxMovieID query.'; exit;}
	
	$queryID = "SELECT id FROM MaxMovieID";
	$resultID = mysql_query($queryID, $db_connection);
	if (!$resultID) {	echo 'Could not run SELECT MaxMovieID query.'; exit;}
	$row =mysql_fetch_row($resultID);
//	echo "<br />".$row[0]."<br />";
	$MovieID = $row[0];
	
	///////////// Add Movie ////////////////
	$queryInsert = "INSERT INTO Movie VALUES ( ".$MovieID.", '".$title."', ".$year.", '".$mpaarating."', '".$company."')";
	$resultInsert = mysql_query($queryInsert, $db_connection);
	if (!$resultInsert) {	echo 'Could not run Insert Movie query.'; exit;}
	
/*
	///////////// Get New MovieID ////////////////
	$queryMovieID = "SELECT MAX(id) FROM Movie";
	$resultMovieID = mysql_query($queryMovieID, $db_connection);
	if (!$resultMovieID) {	echo 'Could not run query.'; exit;}
	$MovieID = mysql_fetch_row($resultMovieID);
*/
	///////////// Add MovieGenre ////////////////
	foreach( $genre as $sub_genre){
		if($sub_genre != NULL){
			$queryGenre = "INSERT INTO MovieGenre VALUES ( ".$MovieID.", '".$sub_genre."' )";
			$resultGenre = mysql_query($queryGenre, $db_connection);
			if (!$resultGenre) {	echo 'Could not run Genre query.'; exit;}
		
		}//end if
	}//end foreach

	///////////// Add MovieDirector ////////////////
	$queryMovieDirector = "INSERT INTO MovieDirector VALUES ( ".$MovieID.", ".$did." )";
	mysql_select_db("CS143", $db_connection);
	$resultMovieDirector = mysql_query($queryMovieDirector, $db_connection);
	if (!$resultMovieDirector) {	echo 'Could not run MovieDirector query.'; exit;}
	

	print "<font color='Red'><b>Add Success!!</b><br/>";
	print "New Movie Title : ".$title."<br/>";
	print "Company Name : ".$company."<br/>";
	print "MPAA Rating : ".$mpaarating."<br/>";
	print "Year : ".$year."</font><br/>";
//	print "INSERT INTO Movie VALUES( ".$MovieID.", '".$title."', ".$year.", '".$mpaarating."', '".$company."'); <br/>";
	print "<a href='./addMovieActor.php?mid=".$MovieID."'>Add Actor/Role Relation</a><br />";
	print "<a href='./showMovieInfo.php?mid=".$MovieID."'>See movie info</a><br />";
	
	mysql_close($db_connection);
}else{
	print "Please fill out the movie title, company, and year.";
}

?>

</body>
</html>