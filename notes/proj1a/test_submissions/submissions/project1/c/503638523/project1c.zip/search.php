<html>
<head>
	<title>Search Actor / Movie</title>
	
	<style type="text/css">
	<!--
	font-family{arial, "lucida console", sans-serif};
	-->
	</style>
</head>
<body>
<form action="./search.php" method="GET">Search: 
<input type="text" name="keyword"></input>
<br/>
<input type="submit" value="Search" />
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$string = $_GET["keyword"];
if($string == "0" | $string =="\\0"){ $string = "\\\\0";}

if($string)
{
	if($string == "\\\\0"){
		echo "You are searching [0] results...<br/><br/>";
	}else{
		echo "You are searching [".$string."] results...<br/><br/>";
	}
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
////////////// Regular expression /////////////////////
$search = array ("'\?'","'\*'","'\+'","'\^'","'\.'", "'\\$'","'\|'");
$replace = array("\\\\\?", "\\\\\*", "\\\\\+", "\\\\\^", "\\\\\.", "\\\\\\\\$");
$string = preg_replace($search, $replace, $string);

//$string = preg_replace("/\\\$/", "\\\\\\\\\$", $string); //check the "$" input 

/////////////// from Actor table ///////////////////////
	$queryActor = "SELECT id, first, last, dob FROM Actor WHERE last REGEXP '".$string."' OR first REGEXP '".$string."'";
	
	echo "Searching match records in Actor database ...<br/>";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($queryActor, $db_connection);
	if (!$result) {
	    echo 'Could not run query.';
	    exit;
	}

	while($row = mysql_fetch_row($result)) {
		print "Actor: <a href = \"./showActorInfo.php?aid=".$row[0]."\">".$row[1]." ".$row[2]."(".$row[3].")</a><br/>";
	}

/////////////// from Movie table ///////////////////////
	$queryMovie = "SELECT id, title, year FROM Movie WHERE title REGEXP '".$string."'";
	
	echo "<br/>Searching match records in Movie database ...<br/>";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($queryMovie, $db_connection);
	if (!$result) {
	    echo 'Could not run query.';
	    exit;
	}

	while($row = mysql_fetch_row($result)) {
		print "Movie: <a href = \"./showMovieInfo.php?mid=".$row[0]."\">".$row[1]."(".$row[2].")</a><br/>";
	}
	mysql_close($db_connection);
}//end if($string)
?>
</body>
</html>