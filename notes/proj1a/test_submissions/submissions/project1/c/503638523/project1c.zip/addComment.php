<html>
<head>
	<title>add Comment</title>
</head>

<body>
Add new comment: <br/>
<form action="./addComment.php" method="GET">
	Movie:	<select name="mid">

<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection);	print "Connection failed: $errmsg <br />";	exit(1); }
	
	$query = "SELECT id, title, year FROM Movie ORDER BY title";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($query, $db_connection);
	if (!$result) { echo 'Could not run Movie query.'; exit; }

	while($row = mysql_fetch_row($result)) {
		if($_GET["mid"] == $row[0])
		{
			print "<option value=\"".$row[0]."\" selected>".$row[1]."(".$row[2].")</option>";
		}else{
			print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")</option>";
		}
	}
?>
	</select>
	<br/>
	
	Your Name:	<input type="text" name="yourname" value="Mr. Anonymous" maxlength="20"><br/>
	Rating:	<select name="rating">
	<option value="5"> 5 - Excellent </option>
	<option value="4"> 4 - Good </option>
	<option value="3"> 3 - It's ok~ </option>
	<option value="2"> 2 - Not worth </option>
	<option value="1"> 1 - I hate it </option>
	</select>
	<br/>
	
	Comments: <br/>
	<textarea name="comment" cols="80" rows="10"></textarea>
	<br/>
<input type="submit" value="Rate it!!"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$movieID = $_GET["mid"];
$yourname = $_GET["yourname"];
$rating = $_GET["rating"];
$comment = $_GET["comment"];

if($movieID AND $yourname AND $rating){

	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }

	$queryReview = "INSERT INTO Review VALUES ( '".$yourname."', NOW(), ".$movieID.", ".$rating.", '".$comment."')";

	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($queryReview, $db_connection);
	if (!$result) {	echo 'Could not run Review query.'; exit;}
	
	print "<font color='Red'><b>Thanks your comment!! We appreciate it!!</b></font><br/>";
	print "<a href = './showMovieInfo.php?mid=".$movieID."'>See Movie Info (including others' reviews)</a>";
	print "<hr style=\"background-color:#B6D6F9; border:none;\" />";
	
}//end if($movieID)

mysql_close($db_connection);
?>

</body>
</html>