<html>
<head>
	<title>add Actor / Director</title>
</head>

<body>
Add new actor/director: <br/>
<form action="./addActorDirectorBoth.php" method="GET">
	Identity:<input type="radio" name="identity" value="Actor" checked="true">Actor
			 <input type="radio" name="identity" value="Director">Director
			 <input type="radio" name="identity" value="Both">or Both<br/>
<hr style="background-color:#B6D6F9; border:none;" />
	First Name:	<input type="text" name="first" maxlength="20"><br/>
	Last Name:	<input type="text" name="last" maxlength="20"><br/>
	Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
				<input type="radio" name="sex" value="Female">Female<br/>
	Date of Birth:	<input type="text" name="dob"> (yyyymmdd)<br/>
	Date of Die:	<input type="text" name="dod"> (leave blank if alive now)<br/>
	<input type="submit" value="add it!!"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$identity = $_GET["identity"];
$first = $_GET["first"];
$last = $_GET["last"];
$sex = $_GET["sex"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];
if($dod==NULL){$dod="NULL";}

if($identity AND $first AND $last AND $sex AND $dob)
{

	if(!preg_match("/^\d\d\d\d\d\d\d\d$/",$dob))
	{
		echo "Please type a correct date of birth : ".$dob."<br />";
		exit;
	}
	$counter = 0;
	$yeardob = substr($dob, 0, 4); if($yeardob > 2008){ echo "The year of birth is not correct.<br />"; $counter++; }
	$monthdob = substr($dob, 4, 2); if($monthdob > 12){ echo "The month of birth is not correct.<br />"; $counter++; }
	$daydob = substr($dob, 6, 2); if($daydob > 31){ echo "The day of birth is not correct.<br />"; $counter++; }
	if($counter > 0){ exit; }

	if($dod != "NULL")
	{
		if(!preg_match("/^\d\d\d\d\d\d\d\d$/",$dod)){	echo "Please type a correct date of death : ".$dod."<br />"; exit;}
		$counter = 0;
		$yeardod = substr($dod, 0, 4); if($yeardod > 2008){ echo "The year of death is not correct.<br />"; $counter++; }
		$monthdod = substr($dod, 4, 2); if($monthdod > 12){ echo "The month of death is not correct.<br />"; $counter++; }
		$daydod = substr($dod, 6, 2); if($daydod > 31){ echo "The day of death is not correct.<br />"; $counter++; }
		if($counter > 0){ exit; }
	}

	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){ $errmsg = mysql_error($db_connection); print "Connection failed: $errmsg <br />"; exit(1); }

	if($identity == "Actor"){
		$updateMax = "UPDATE MaxPersonID SET id=id+1";
		mysql_select_db("CS143", $db_connection);
		$resultMax = mysql_query($updateMax, $db_connection);
		if (!$resultMax) {	echo 'Could not run Update MaxPersonID query.'; exit;}
		
		$queryID = "SELECT id FROM MaxPersonID";
		$resultID = mysql_query($queryID, $db_connection);
		if (!$resultID) {	echo 'Could not run MaxPersonID query.'; exit;}
		$row =mysql_fetch_row($resultID);
//		echo "<br />".$row[0]."<br />";
		$newID = $row[0];
		
		$queryInsert = "INSERT INTO ".$identity." VALUES ( ".$newID.", '".$last."', '".$first."', '".$sex."', ".$dob.", ".$dod.")";
		$resultInsert = mysql_query($queryInsert, $db_connection);
		if (!$resultInsert) {	echo 'Could not run Insert Actor query.'; exit;}
	}else 
	if($identity == "Director"){
		$updateMax = "UPDATE MaxPersonID SET id=id+1";
		mysql_select_db("CS143", $db_connection);
		$resultMax = mysql_query($updateMax, $db_connection);
		if (!$resultMax) {	echo 'Could not run Update MaxPersonID query.'; exit;}
		
		$queryID = "SELECT id FROM MaxPersonID";
		$resultID = mysql_query($queryID, $db_connection);
		if (!$resultID) {	echo 'Could not run MaxPersonID query.'; exit;}
		$row =mysql_fetch_row($resultID);
//		echo "<br />".$row[0]."<br />";
		$newID = $row[0];
		
		$queryInsert = "INSERT INTO ".$identity." VALUES ( ".$newID.", '".$last."', '".$first."', ".$dob.", ".$dod.")";
		$resultInsert = mysql_query($queryInsert, $db_connection);
		if (!$resultInsert) {	echo 'Could not run Insert Director query.'; exit;}
	}else 
	if($identity == "Both"){
		$updateMax = "UPDATE MaxPersonID SET id=id+1";
		mysql_select_db("CS143", $db_connection);
		$resultMax = mysql_query($updateMax, $db_connection);
		if (!$resultMax) {	echo 'Could not run Update MaxPersonID query.'; exit;}
		
		$queryID = "SELECT id FROM MaxPersonID";
		$resultID = mysql_query($queryID, $db_connection);
		if (!$resultID) {	echo 'Could not run MaxPersonID query.'; exit;}
		$row =mysql_fetch_row($resultID);
//		echo "<br />".$row[0]."<br />";
		$newID = $row[0];
		
		$queryInsert = "INSERT INTO Actor VALUES ( ".$newID.", '".$last."', '".$first."', '".$sex."', ".$dob.", ".$dod.")";
		$resultInsert = mysql_query($queryInsert, $db_connection);
		if (!$resultInsert) {	echo 'Could not run Insert Actor query.'; exit;}
		
		$queryInsert = "INSERT INTO Director VALUES ( ".$newID.", '".$last."', '".$first."', ".$dob.", ".$dod.")";
		$resultInsert = mysql_query($queryInsert, $db_connection);
		if (!$resultInsert) {	echo 'Could not run Insert Director query.'; exit;}
	}
	
	print "<font color='Red'><b>Add Success!!</b><br/>";
	if($identity=="Both"){print "Actor & Director : ";}
	else{ print  $identity." : ";}
	print $first." ".$last." (".$yeardob."-".$monthdob."-".$daydob.")</font><br />";
	if($identity!="Actor"){
		print "<a href = './addMovieInfo2.php?did=".$newID."'>Add a new movie for this director</a><br />";
	}
	if($identity!="Director"){
		print "<a href = './addMovieActor.php?aid=".$newID."'>Add Actor/Role Relation</a><br />";
		print "<a href = './showActorInfo.php?aid=".$newID."'>See the actor info</a>";
	}
	mysql_close($db_connection);
}else{
	print "Please fill out all information.";
}
?>
</body>
</html>