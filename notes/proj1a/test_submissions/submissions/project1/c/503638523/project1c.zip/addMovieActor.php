<html>
<head>
	<title>Add Actor's Role in a Movie</title>
</head>

<body>
Add new actor in a movie: <br/>
<form action="./addMovieActor.php" method="GET">
	Movie : <select name="mid">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection){
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	$query = "SELECT id, title, year FROM Movie ORDER BY title";
	
	mysql_select_db("CS143", $db_connection);
	$result = mysql_query($query, $db_connection);
	if (!$result) {
	    echo 'Could not run query.';
	    exit;
	}

	while($row = mysql_fetch_row($result)) {
		if($_GET["mid"] == $row[0])
		{
			print "<option value=\"".$row[0]."\" selected>".$row[1]."(".$row[2].")</option>";
		}else{
			print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")</option>";
		}
	}
?>
	</select>
	<br/>
	
	Actor : <select name="aid">
<?php
	$queryActor = "SELECT id, first, last, dob FROM Actor ORDER BY first";
	
	$resultActor = mysql_query($queryActor, $db_connection);
	if (!$resultActor) {	echo 'Could not run SELECT Actor query.'; exit;}

	while($rowActor = mysql_fetch_row($resultActor)) {
		if($_GET["aid"] == $rowActor[0])
		{
			print "<option value=\"".$rowActor[0]."\" selected>".$rowActor[1]." ".$rowActor[2]."(".$rowActor[3].")</option>";
		}else{
			print "<option value=\"".$rowActor[0]."\">".$rowActor[1]." ".$rowActor[2]."(".$rowActor[3].")</option>";
		}
	}

?>
	</select>
	<br/>
	
	Role: <input type="text" name="role" maxlength="50">
	<br/>
<input type="submit" value="Add it!!"/>
</form>
<hr style="background-color:#B6D6F9; border:none;" />

<?php

$mid = $_GET["mid"];
$aid = $_GET["aid"];
$role = $_GET["role"];

if($mid AND $aid AND $role)
{
	///////////// Add MovieActor ////////////////
	$queryMovieActor = "INSERT INTO MovieActor VALUES ( ".$mid.", ".$aid.", '".$role."')";
	
//mysql_select_db("CS143", $db_connection);
	$resultMovieActor = mysql_query($queryMovieActor, $db_connection);
	if (!$resultMovieActor) {	echo 'Could not run MovieActor query.'; exit;}
	
	print "<font color='Red'><b>Add Success!!</b><br />";
//	print $actorName." : "." ".$role;
	print "Role : ".$role."</font><br />";
	print "<a href = './showMovieInfo.php?mid=".$mid."'>See the movie info</a><br />";
	print "<a href = './showActorInfo.php?aid=".$aid."'>See the actor info</a>";
	
	mysql_close($db_connection);
}else{
	print "Please fill out all information.";
}
?>
</body>
</html>