Name: Tetsuya Takahashi
SID: 503-638-523
Email: enashiro@gmail.com

I used a command "mysql CS143 -uroot -ppassword < load.sql" to load the data.
Also, I used an absolute path '/home/cs143/www/data/~.del' in load.sql.
When I use './data/~.del' to load, it causes "ERROR 13 (HY000) at line 1: Can't get stat of './data/actor1.del' (Errcode: 2)". I asked TA about it and he said that I can use an absolute path instead of a relative and it doesn't matter because TA's and professor's systems should put the data file in the same directory. That's why I am using an absolute path '/home/cs143/data/~.del' in load.sql.



Just in case:
I created two sets of files; one is using a trigger in a load file (the file name is load_trigger.sql), and the programs in the following files fit on the trigger.
index.html + movie_database.html + addActorDirector.php + addMovieInfo.php  + others

Another one is not using a trigger in load.sql, and  the programs in the following files fit on no trigger.
index2.html + movie_database2.html + addActorDirectorBoth.php + addMovieInfo2.php  + others

I will use a no-trigger file set which is "./index2.html" on the demo.

When I use a trigger, it occurs some errors. So, I used "DELIMITER //" for each TRIGGER since MySQL does not work TRIGGER without the declaration.