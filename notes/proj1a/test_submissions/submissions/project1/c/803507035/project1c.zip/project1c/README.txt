{\rtf1\ansi\ansicpg1252\deff0\deflang1033{\fonttbl{\f0\fnil\fcharset0 Courier New;}{\f1\fswiss\fcharset0 Arial;}}
{\*\generator Msftedit 5.41.15.1507;}\viewkind4\uc1\pard\f0\fs20 CS143 Project 1C\par
Name: Erick Romero\par
UID: 803-507-035\par
Email: erickrom@ucla.edu\par
\par
Notes: \par
\par
I implemented all of the features except the link to add a comment from the page that shows the movie information.  I can add comments to a movie but not from clicking that link.  The problem is that the get method from the add new comment page does not get the id of the movie but rather the title.  I am able to add comments by going directly to the add comments page and selecting the movie, but not by being redirected from the show movie info page.\par
\f1\par
}
 