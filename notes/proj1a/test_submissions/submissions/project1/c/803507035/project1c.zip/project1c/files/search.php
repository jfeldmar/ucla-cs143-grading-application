<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>moviestalker 1.0</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="bg1">
	<div id="header">
		<h1><a href="search.php">MovieStalker.com<sup>1.0</sup></a></h1>
		<h2>By Erick Romero</h2>
	</div>
	<!-- end #header -->
</div>
<!-- end #bg1 -->
<div id="bg2">
	<div id="header2">
		<div id="menu">
			<ul>
				<li><a href="showActorInfo.php">Actors and Actresses</a></li>
				<li><a href="showMovieInfo.php">Movies</a></li>
				<li><a href="addNew.html">Add New Movie/Actor/Director</a></li>
			</ul>
		</div>
		<!-- end #menu -->
		
		<div id="search">
			<form method="get" action="search.php">
				<fieldset>
				<input type="text" name="u_phrase" value="search keywords" id="q" class="text" />
				<input type="submit" value="Search" class="button" />
				</fieldset>
			</form>
		</div>
		<!-- end #search -->
	</div>
	<!-- end #header2 -->
</div>
<!-- end #bg2 -->
<div id="bg3">
	<div id="bg4">
		<div id="bg5">
			<div id="page">
				<div id="content">
					<div class="post">	
					
					
<!-- select * from Actor where concat_ws(' ', first, last) like 'julia'; -->
<?php
if($_GET["u_phrase"])
	{
		$phrase=$_GET["u_phrase"];
		//Establish Connection 
		$db_connection = mysql_connect("localhost", "cs143", "");
		if(!$db_connection)
		{
    		$errmsg = mysql_error($db_connection);
    		print "Connection failed: $errmsg <br />";
    		exit(1);
		}
		
		//Select Database
		mysql_select_db("CS143", $db_connection);
	
		// split the phrase by any number of commas or space characters,
		// which include " ", \r, \t, \n and \f
		$keywords = preg_split("/[\s,]+/", $phrase);
		
		// output message
		echo "<h2>Your search for \"";
		for($j=0; $j<sizeof($keywords); $j++)
		{
			echo "$keywords[$j] ";
		}
		echo "<b>\" gave the following results: </b></h2>";
		
		// Query to search on Actor Table
		$query = sprintf ("	SELECT first, last, id 
							FROM Actor 
							WHERE first LIKE '%s' OR
							last LIKE '%s' OR 
							CONCAT_WS(' ', first, last) LIKE '%s' OR 
							CONCAT_WS(\", \", last, first) LIKE '%s'", 
			mysql_real_escape_string($phrase), mysql_real_escape_string($phrase), 
			mysql_real_escape_string($phrase), mysql_real_escape_string($phrase));
		
		$result = mysql_query($query);
		echo "<b>Actor\\Actress: </b><br>";
		//Print results for Actor Database	
		while ($row = mysql_fetch_row($result)){
			$first = $row[0];
			$last = $row[1];
			$id = $row[2];
			echo "<a href=\"showActorInfo.php?menu=$id\">$first $last</a><br>";
		}
		// Search Director Table
		echo "<br><b>Directors: </b><br>";
		// query to search Director Table
		$query = sprintf ("	SELECT first, last, id 
							FROM Director 
							WHERE first LIKE '%s' OR
							last LIKE '%s' OR 
							CONCAT_WS(' ', first, last) LIKE '%s' OR 
							CONCAT_WS(\", \", last, first) LIKE '%s'", 
			mysql_real_escape_string($phrase), mysql_real_escape_string($phrase), 
			mysql_real_escape_string($phrase), mysql_real_escape_string($phrase));
			
		$result = mysql_query($query);
		//Print results for Actor Database	
		while ($row = mysql_fetch_row($result)) {
			$first = $row[0];
			$last = $row[1];
			$id = $row[2];
			echo "<a href=\"showActorInfo.php?menu=$id\">$first $last</a><br>";
		}
		
		// Search Movie Table
		echo "<br><b>Movies: </b><br>";
		$query = "	SELECT title, year, id 
							FROM Movie
							WHERE title LIKE '%$phrase%'"; 
		
		$result = mysql_query($query);
		//Print results for Movie Database	
		while ($row = mysql_fetch_row($result)) {
			$title = $row[0];
			$year = $row[1];
			$id = $row[2];
			echo "<a href=\"showMovieInfo.php?movieMenu=$id\">$title ($year)</a><br>";
		}
		// Close Connection
		mysql_close($db_connection);
		mysql_free_result($result);
	}

?>
	
</div>	
</div>
<div style="clear: both; height: 40px;">&nbsp;</div>
</div>
</div>
</div>
</div>

</BODY>
</HTML>