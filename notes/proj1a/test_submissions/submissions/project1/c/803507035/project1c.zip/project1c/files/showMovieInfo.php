<html>
<body>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>moviestalker 1.0</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<div id="bg1">
	<div id="header">
		<h1><a href="search.php">MovieStalker.com<sup>1.0</sup></a></h1>
		<h2>By Erick Romero</h2>
	</div>
	<!-- end #header -->
</div>
<!-- end #bg1 -->
<div id="bg2">
	<div id="header2">
		<div id="menu">
			<ul>
				<li><a href="showActorInfo.php">Actors and Actresses</a></li>
				<li><a href="showMovieInfo.php">Movies</a></li>
				<li><a href="addNew.html">Add New Movie/Actor/Director</a></li>
			</ul>
		</div>
		<!-- end #menu -->
		
		<div id="search">
			<form method="get" action="search.php">
				<fieldset>
				<input type="text" name="u_phrase" value="search keywords" id="q" class="text" />
				<input type="submit" value="Search" class="button" />
				</fieldset>
			</form>
		</div>
		<!-- end #search -->
	</div>
	<!-- end #header2 -->
</div>
<!-- end #bg2 -->
<div id="bg3">
	<div id="bg4">
		<div id="bg5">
			<div id="page">
				<div id="content">
					<div class="post">	



<!-- Populate Drop Down Menu with Movie Information -->
<?php
//Establish Connection 
	$db_connection = mysql_connect("localhost", "cs143", "");	
	if(!$db_connection)
	{
    	$errmsg = mysql_error($db_connection);
    	print "Connection failed: $errmsg <br />";
    	exit(1);
	}
	//Select Database
	mysql_select_db("CS143", $db_connection);
	//query to get all Movie titles
	$query="SELECT id, title FROM Movie GROUP BY title";
	$result = mysql_query ($query);
	
	$options="";
	while ($row=mysql_fetch_array($result)) {
		$id=$row["id"];
		$title=$row["title"];
		$options.="<OPTION VALUE=\"$id\">".$title;
	}
	mysql_free_result($result);
?>
<!-- Drop down menu gets built here -->
<FORM action="showMovieInfo.php" method="get">
<b><font size=5>Search Movie Titles:</b></font>
<SELECT NAME=movieMenu>
<OPTION VALUE=0>Choose a Movie
<?=$options?>
</SELECT>
<input type="submit" value="Go!" />
</FORM>
	
<!-- Get Movie Info part -->
<?php
if($_GET["movieMenu"])
	{
		$movieId=$_GET["movieMenu"];
		// Query to get Movie's title, year, company, rating 
		$query = sprintf("SELECT title, year, company, rating 
						FROM Movie M  
						WHERE M.id = '%s'", 
			mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		// get row
		$row = mysql_fetch_row($result);
		$title = $row[0];
		$year = $row[1];
		$company = $row[2];
		$rating = $row[3];
		echo "<h2>-- Movie Information -- </h2>";
		echo "<b>Title:</b> $title ";
		echo "($year)<br>";
		echo "<b>Company:</b> $company<br>";
		echo "<b>Rating:</b> $rating<br>";
		// Query to get Movie's Director info
		$query = sprintf("	SELECT first, last
							FROM MovieDirector MD, Director D
							WHERE MD.mid = '%s' AND D.id = MD.did",
				mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		// output label
		echo "<b>Director: </b>";
		while($row = mysql_fetch_row($result)) {
			$directorFirst = $row[0];
			$directorLast = $row[1];
			echo "$directorFirst $directorLast<br>";
		}
		// Query to get Movie's Genre
		$query = sprintf("	SELECT genre
							FROM MovieGenre
							WHERE mid = '%s'",
				mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		echo "<b>Genre: </b>";
		while($row = mysql_fetch_row($result)) {
			$genre = $row[0];
			echo "$genre ";
		}
		echo "<br>";
		// Query to get Actors in Movie
		$query = sprintf("	SELECT first, last, role, id
							FROM Actor A, MovieActor MA
							WHERE MA.mid = '%s' AND A.id = MA.aid",
				mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		echo "<br><h2>-- Cast --</h2>";
		while($row = mysql_fetch_row($result)){
			$first = $row[0];
			$last = $row[1];
			$role = $row[2];
			$actorId = $row[3];
			echo "<a href=\"showActorInfo.php?menu=$actorId\">$first $last</a>  as  \"$role\"<br>";
		}
		
		//Query to get User Review
		// get average of rating
		$query = sprintf("	SELECT AVG(rating)
							FROM Review
							WHERE mid = '%s'",
				mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		if (mysql_num_rows($result) == 0){
			$avg = '0';
		}
		else {
			$row = mysql_fetch_row($result);
			$avg = $row[0];
		}
		// get user name, time, rating of movie, user comment
		$query = sprintf("	SELECT name, time, rating, comment
							FROM Review
							WHERE mid = '%s'",
				mysql_real_escape_string($movieId));
		// issue query in mysql
		$result = mysql_query($query);
		echo "<br><b>-- Users reviews --</b><br>";
		echo "<a href=\"addNew.php?addType=comments&movieOption=$movieId\">Add a review!</a><br>";
		if ($avg == "")
			echo "No reviews have been made about this movie... "."<a href=\"addNew.php?addType=comments&movieOption=$movieId\">be the first to write a review!</a><br>";
		else
			echo "Average Score is $avg out of 5 (5 is best)<br><br>";
		while($row = mysql_fetch_row($result)){
			$name = $row[0];
			$time = $row[1];
			$rating = $row[2];
			$comment = $row[3];
			echo "<b>$name</b> in $time rated this movie $rating star(s) out of 5.<br>Comment:<br> $comment<br><br>";
		}
		mysql_free_result($result);
	}
	
?>
</div>	
</div>
<div style="clear: both; height: 40px;">&nbsp;</div>
</div>
</div>
</div>
</div>
	
	
	
	
</BODY>
</HTML>