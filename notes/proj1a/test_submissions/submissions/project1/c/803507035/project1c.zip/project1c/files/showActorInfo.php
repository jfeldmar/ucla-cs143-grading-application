<html>
<body>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>moviestalker 1.0</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<div id="bg1">
	<div id="header">
		<h1><a href="search.php">MovieStalker.com<sup>1.0</sup></a></h1>
		<h2>By Erick Romero</h2>
	</div>
	<!-- end #header -->
</div>
<!-- end #bg1 -->
<div id="bg2">
	<div id="header2">
		<div id="menu">
			<ul>
				<li><a href="showActorInfo.php">Actors and Actresses</a></li>
				<li><a href="showMovieInfo.php">Movies</a></li>
				<li><a href="addNew.html">Add New Movie/Actor/Director</a></li>
			</ul>
		</div>
		<!-- end #menu -->
		
		<div id="search">
			<form method="get" action="search.php">
				<fieldset>
				<input type="text" name="u_phrase" value="search keywords" id="q" class="text" />
				<input type="submit" value="Search" class="button" />
				</fieldset>
			</form>
		</div>
		<!-- end #search -->
	</div>
	<!-- end #header2 -->
</div>
<!-- end #bg2 -->
<div id="bg3">
	<div id="bg4">
		<div id="bg5">
			<div id="page">
				<div id="content">
					<div class="post">	


<!-- Populate Drop Down Menu with Actor Information -->
<?php
//Establish Connection 
	$db_connection = mysql_connect("localhost", "cs143", "");	
	if(!$db_connection)
	{
    	$errmsg = mysql_error($db_connection);
    	print "Connection failed: $errmsg <br />";
    	exit(1);
	}
	//Select Database
	mysql_select_db("CS143", $db_connection);
	//query to get all Actor's names
	$query="SELECT id, first, last FROM Actor GROUP BY first, last";
	$result = mysql_query ($query);
	
	$options="";

	while ($row=mysql_fetch_array($result)) {
		$id=$row["id"];
		$first=$row["first"];
		$first="$first ";
		$last=$row["last"];
		$options.="<OPTION VALUE=\"$id\">".$first.$last;
	} 
	mysql_free_result($result);
?>
<!-- Drop down menu gets built here -->
<FORM action="showActorInfo.php" method="get">
<b><font size=5>Stalk Actor or Actress:</font></b>
<SELECT NAME=menu>
<OPTION VALUE=0>Choose an Actor
<?=$options?>
</SELECT>
<input type="submit" value="Go!" />
</FORM>

<!-- Get Info part -->
<?php
if($_GET["menu"])
	{
		$actorId=$_GET["menu"];
		// Get Actor's Personal Info
		$query=sprintf("SELECT * FROM Actor WHERE id='%s'", 
			mysql_real_escape_string($actorId));
		
		$result = mysql_query($query);
		$row = mysql_fetch_row($result);
		$first = $row[2];
		$last = $row[1];
		$sex = $row[3];
		$dob = $row[4];
		$dod = $row[5];
		if($dod == "")
			$dod = "*Still Alive*";
		echo "<h2>-- Actor/Actress Information --</h2>";
		echo "<b>Name:</b> $first $last <br>";
		echo "<b>Sex:</b> $sex <br>";
		echo "<b>Date of Birth:</b> $dob <br>";
		echo "<b>Date of Death:</b> $dod <br>";

		//Query to get Actor/Movie Relation
		$query = sprintf("	SELECT role, title, MA.mid
							FROM MovieActor MA, Movie M, Actor A
							WHERE MA.mid = M.id AND A.id = '%s' AND MA.aid = '%s'",
				mysql_real_escape_string($actorId),
				mysql_real_escape_string($actorId));
		
		// Issue query
		$result = mysql_query($query);
		// Print results of query	
		echo "<br><h2>-- Filmography --</h2>";
		while ($row = mysql_fetch_row($result)) {
        	if (is_null($row[0]))
        		$row[0]="N\A";
        	if (is_null($row[1]))
        		$row[1]="N\A";
			$role = $row[0];
			$title = $row[1];
			$movie = $row[2];
			//Print values
			//echo "&nbsp &nbsp ";
			echo "\"$role\" in ";
			echo "<a href=\"showMovieInfo.php?movieMenu=$movie\">$title</a><br>";
			//echo "$title<br>";
		}
	}
?>
	
	</div>	
</div>
<div style="clear: both; height: 40px;">&nbsp;</div>
</div>
</div>
</div>
</div>

	
</BODY>
</HTML>