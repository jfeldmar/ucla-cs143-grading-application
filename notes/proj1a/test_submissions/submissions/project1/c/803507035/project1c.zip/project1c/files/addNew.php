<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>moviestalker 1.0</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="bg1">
	<div id="header">
		<h1><a href="search.php">MovieStalker.com<sup>1.0</sup></a></h1>
		<h2>By Erick Romero</h2>
	</div>
	<!-- end #header -->
</div>
<!-- end #bg1 -->
<div id="bg2">
	<div id="header2">
		<div id="menu">
			<ul>
				<li><a href="showActorInfo.php">Actors and Actresses</a></li>
				<li><a href="showMovieInfo.php">Movies</a></li>
				<li><a href="addNew.html">Add New Movie/Actor/Director</a></li>
			</ul>
		</div>
		<!-- end #menu -->
		
		<div id="search">
			<form method="get" action="search.php">
				<fieldset>
				<input type="text" name="u_phrase" value="search keywords" id="q" class="text" />
				<input type="submit" value="Search" class="button" />
				</fieldset>
			</form>
		</div>
		<!-- end #search -->
	</div>
	<!-- end #header2 -->
</div>
<!-- end #bg2 -->
<div id="bg3">
	<div id="bg4">
		<div id="bg5">
			<div id="page">
				<div id="content">
					<div class="post">	


<!-- Connect to mysql database -->
<?php
	//Establish Connection 
	$db_connection = mysql_connect("localhost", "cs143", "");	
	if(!$db_connection)
	{
    	$errmsg = mysql_error($db_connection);
    	print "Connection failed: $errmsg <br />";
    	exit(1);
	}
	//Select Database
	mysql_select_db("CS143", $db_connection);
?>

<!-- Get type of new entry (actor-director, movie, comments, movie-actor -->
<?php
if($_GET["addType"])
	{
	$type=$_GET["addType"];
	// Actor-Director type
	if($type == "actor-director"){
		echo "<h2>Add new Actor or Director</h2>";
		echo "	<form action=\"addNew.php\" method=\"get\">
				<input type=\"radio\" name=\"actOrDir\" value=\"actor\"/>Actor&nbsp&nbsp
				<input type=\"radio\" name=\"actOrDir\" value=\"director\"/>Director&nbsp&nbsp<br>
				First Name:&nbsp&nbsp<input type=\"text\" name=\"first\"/><br>
				Last Name:&nbsp&nbsp&nbsp<input type = \"text\" name=\"last\"/><br>
				Sex:&nbsp&nbsp<input type=\"radio\" name=\"sex\" value=\"Male\"/>Male&nbsp&nbsp
				<input type=\"radio\" name=\"sex\" value=\"Female\"/>Female<br>
				Date of Birth:&nbsp&nbsp<input type=\"text\" name=\"dob\"/><br>
				Date of Death:&nbsp&nbsp<input type=\"text\" name=\"dod\"/>(Leave blank if still alive)<br>
				<input type=\"submit\" value=\"Add new entry!\" class=\"button\"/></form>";
	}
	// Movie Type
	if($type == "movie"){
		//query to get all Director's names
		$query="SELECT id, first, last FROM Director GROUP BY first, last";
		$result = mysql_query ($query);
		$options="";
		while ($row=mysql_fetch_array($result)) {
			$id=$row["id"];
			$first=$row["first"];
			$first="$first ";
			$last=$row["last"];
			$options.="<OPTION VALUE=\"$id\">".$first.$last;
		}
		// Title of page
		echo "<h2>Add new Movie</h2>";
		echo "	<form action=\"addNew.php\" method=\"get\">
				<font size=3><b>Title:<b></font>&nbsp&nbsp<input type=\"text\" name=\"title\"/><br>
				<font size=3><b>Company:<b></font>&nbsp&nbsp&nbsp<input type = \"text\" name=\"company\"/><br>
				<font size=3><b>Year:<b></font>&nbsp&nbsp<input type=\"text\" name=\"year\"/><br>
				<font size=3><b>Director:<b></font>&nbsp&nbsp<SELECT NAME=\"directorMenu\"><?=$options?></SELECT><br>
				<font size=3><b>Rating:<b></font>&nbsp&nbsp<select name=\"ratingMenu\"><OPTION VALUE=\"PG\">PG<OPTION VALUE=\"PG-13\">PG-13<OPTION VALUE=\"R\">R<OPTION VALUE=\"NC-17\">NC-17<OPTION VALUE=\"surrendere\">surrendere</select><br>
				<font size=3><b>Genre:<b></font>&nbsp&nbsp<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Action\">&nbsp Action&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Adult\">&nbsp Adult&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Adventure\">&nbsp Adventure&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Animation\">&nbsp Animation&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Comedy\">&nbsp Comedy&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Crime\">&nbsp Crime&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Documentary\">&nbsp Documentary&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Drama\">&nbsp Drama&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Family\">&nbsp Family&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Fantasy\">&nbsp Fantasy&nbsp&nbsp&nbsp<br>
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Horror\">&nbsp Horror&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Musical\">&nbsp Musical&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Mistery\">&nbsp Mystery&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Romance\">&nbsp Romance&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Sci-Fi\">&nbsp Sci-Fi&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Short\">&nbsp Short&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Thriller\">&nbsp Thriller&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"War\">&nbsp War&nbsp&nbsp&nbsp
				<INPUT TYPE=\"checkbox\" NAME=\"genre[]\" VALUE=\"Western\">&nbsp Western&nbsp&nbsp&nbsp<br>
				<input type=\"submit\" value=\"Add new Movie!\" class=\"button\"/></form>";
	}
	// Movie/Actor Relation type
	if($type == "movie-actor"){
		echo "<h2>Add New Actor-Movie Relation</h2>";
		
		//query to get all Actor's names
		$query="SELECT id, first, last FROM Actor GROUP BY first, last";
		$result = mysql_query ($query);
	
		$actorOptions="";
		while ($row=mysql_fetch_array($result)) {
			$id=$row["id"];
			$first=$row["first"];
			$first="$first ";
			$last=$row["last"];
			$actorOptions.="<OPTION VALUE=\"$id\">".$first.$last;
		}
		
		//query to get all Movie titles
		$query="SELECT id, title FROM Movie GROUP BY title";
		$result = mysql_query ($query);
	
		$movieOptions="";
		while ($row=mysql_fetch_array($result)) {
			$id=$row["id"];
			$title=$row["title"];
			$movieOptions.="<OPTION VALUE=\"$id\">".$title;
		}
		// Echo all forms
		echo "<FORM action=\"addNew.php\" method=\"get\">
			<h3>Actor or Actress:</h3></b>
			<SELECT NAME=actorMenu MULTIPLE SIZE=5>
			<?=$actorOptions?></SELECT> 
			<h3><br>Movies</h3>
			<SELECT NAME=movieMenu MULTIPLE SIZE=5>
			<?=$movieOptions?></SELECT><br>
			<br><h3>Role: &nbsp&nbsp&nbsp</h3><input type=text name=role size=50\>
			<input type=\"submit\" value=\"Add new Actor into Movie!\" />
			</FORM>";
		mysql_free_result($result);
	}
	// Comments to movie type
	if($type == "comments"){
		echo "<h1>Add comments to a stalking movie</h1>";
		
		$movieOption=$_GET[movieOption];
		//query to get all Movie titles
		$query="SELECT id, title FROM Movie GROUP BY title";
		$result = mysql_query ($query);
	
		$movieOptions="";
		while ($row=mysql_fetch_array($result)) {
			$id=$row["id"];
			$title=$row["title"];
			if($id == $movieOption)
				$titleSelected = $title;
			$movieOptions.="<OPTION VALUE=\"$id\">".$title;
		}
		// output forms
		echo "<FORM ACTION=\"addNew.php\" METHOD=\"get\" style=\"padding: 0px 0px 0px 80px\">
		<font size=3><b>Movie: &nbsp&nbsp</font></b><SELECT NAME=movieMenu>
		<?=$movieOptions?><OPTION SELECTED>$titleSelected</SELECT><br>
		<font size=3><b>Your Name: &nbsp&nbsp</font></b><input type=text name=urName size=20 value=\"Mr. Stalker\"\><br>
		<font size=3><b>Score this Movie: &nbsp&nbsp </font></b><select name=\"likeMenu\"><OPTION VALUE=\"5\">5-Very Stalkable<OPTION VALUE=\"4\">4-Stalkable<OPTION VALUE=\"3\">3-Somewhat Stalkable<OPTION VALUE=\"2\">2-Eh, Don't Stalk<OPTION VALUE=\"1\">1-Haaated it!</select>
		<br><font size=3><b>Would you Stalk this movie and why?</font></b><br><textarea name=\"comment\" rows=10 cols=70></textarea>
		<input type=\"submit\" value=\"Add Your Comment!\" />
		</FORM>";
	}
}
?>
<!-- Add new Actor -->
<?php
if($_GET["actOrDir"]){
	
	$person=$_GET["actOrDir"];
	if($_GET[dod]=="")
		$dod = NULL;
	else
		$dod=$_GET[dod];
	if($person=="actor"){
		// get the maximum ID for Actors
		$query="SELECT MAX(id) FROM Actor";
		$result = mysql_query($query);
		$row = mysql_fetch_row($result);
		$maxId = $row[0];
		$maxId++;
		//echo "Max id is $maxId<br>";
		// Insert statement
		$query="INSERT INTO Actor VALUES('$maxId', '$_GET[last]', '$_GET[first]', '$_GET[sex]', 
		'$_GET[dob]', '$dod')";
		
		$result = mysql_query($query);
		if($result){
			echo "<h2>Actor added successfully!   One more actor you can Stalk!</h2>";
		}
		else
			echo "Error, could not add entry";
	}
	if($person=="director"){
		// get the maximum ID for directors
		$query="SELECT MAX(id) FROM Director";
		$result = mysql_query($query);
		$row = mysql_fetch_row($result);
		$maxId = $row[0];
		$maxId++;
		//echo "Max id is $maxId<br>";
		// Insert statement
		$query="INSERT INTO Director VALUES('$maxId', '$_GET[last]', '$_GET[first]', 
		'$_GET[dob]', '$dod')";
		
		$result = mysql_query($query);
		if($result){
			echo "<h2>Director added successfully!</h2>";
		}
		else
			echo "Error, could not add entry to Director table";
		mysql_free_result($result);
	}
}
?>
	
<!-- Add new Movie -->
<?php
if($_GET["title"]){
	// get all values from $_GET method
	$title = $_GET[title];
	$company = $_GET[company];
	$year = $_GET[year];
	$directorId = $_GET[directorMenu];
	$rating = $_GET[ratingMenu]; // this is the actual rating (i.e. PG, PG-13, etc)
	$genres = $_GET[genre]; // this is an array
	
	$error = 0;  // error counter
	// get the maximum ID for Movies
	$query="SELECT MAX(id) FROM Movie";
	$result = mysql_query($query);
	$row = mysql_fetch_row($result);
	$maxMovieId = $row[0];
	$maxMovieId++;
	
	// Insert query on Movie table
	$query = sprintf("INSERT INTO Movie VALUES('$maxMovieId', '%s', '$year', '$rating', '%s')",
		mysql_real_escape_string($title), mysql_real_escape_string($company));
	$result = mysql_query($query);
	if(!$result){
		echo "Error, could not add movie information to Movie table"."  ".mysql_error()."<br>";
		$error++;
	}
	
	// Insert query into MovieDirector table
	$query = "INSERT INTO MovieDirector VALUES('$maxMovieId', '$directorId')";
	$result = mysql_query($query);
	if(!$result){
		echo "Error, could not add movie information to MovieDirector table"."  ".mysql_error()."<br>";
		$error++;
	}
	
	for ($i = 0; $i<sizeof($genres); $i++){
		$currGenre = $genres[$i];
		// Insert query into MovieGenre table
		$query = "INSERT INTO MovieGenre VALUES('$maxMovieId', '$currGenre')";
		$result = mysql_query($query);
		if(!$result){
			echo "Error, could not add Movie id $maxMovieId and genre $currGenre"."  ".mysql_error()."<br>";
			$error++;
		}
	}
	//mysql_free_result($result);
	if($error ==0)
		echo "<h2>Movie added successfully!</h2>";
}

?>
	
<!-- Add new Movie-Actor Relation -->
<?php
if($_GET[role]){
	//echo "Role is $_GET[role]<br>";
	//echo "Actor id is: $_GET[actorMenu]<br>";
	//echo "Movie id is: $_GET[movieMenu]<br>";
	// Query to insert into MovieActor table
	$query = "INSERT INTO MovieActor VALUES('$_GET[movieMenu]', '$_GET[actorMenu]', '$_GET[role]')";
	$result = mysql_query($query);
	if(!$result)
		echo "Error, could not add Movie-Actor relation to table MovieActor ".mysql_error();
	else
		echo "<h2>Movie-Actor relationship added successfully!</h2>";
}
?>	
<!-- Add new Comment -->
<?php
if($_GET[comment]){
	// Query to get id of movie
	// Query to add to Review table
	$query = "INSERT INTO Review VALUES('$_GET[urName]', NOW(), '$_GET[movieMenu]', '$_GET[likeMenu]', '$_GET[comment]')";
	$result = mysql_query($query);
	if(!$result)
		echo "Error, could not add comment into Review table ".mysql_error();
	else
		echo "<h2>Your comment has been added successfully!  Now, go stalk some more!</h2>";

}



?>
	</div>	
</div>
<div style="clear: both; height: 40px;">&nbsp;</div>
</div>
</div>
</div>
</div>

	
	
</body>
</html>
