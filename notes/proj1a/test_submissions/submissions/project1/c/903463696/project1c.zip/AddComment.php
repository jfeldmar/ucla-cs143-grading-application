<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Add Comment to Movie</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<?php
echo "Add new comment:</n></n>";

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$query = "SELECT id, title, year FROM Movie";
$rs = mysql_query($query, $db_connection);
$options = "";

//Populates dropdown menu with db data.
while ($row = mysql_fetch_array($rs)){
  $id = $row["id"];
  $title = $row["title"];
  $year = $row["year"];
  $options .= "<OPTION VALUE=\"$id\">".$title." (".$year.")";
}
?>

<form action="" method="get">
Movie: <select name="title">
<OPTION VALUE=0>--Select One--
<?=$options?>
</select><br />
Your name: <input type="text" name="name" value="Mr. Anonymous" maxlength="20" /><br />
Rating: <select name="rating">
  <option value="5"> 5 - Excellent </option>
  <option value="4"> 4 - Good </option>
  <option value="3"> 3 - Neutral </option>
  <option value="2"> 2 - Bad </option>
  <option value="1"> 1 - Rotten Tomato </option>
  </select><br />
Comments:<br />
<textarea name="comments" rows="10" cols="80">
</textarea><br /><br />
<input type="submit" value="Rate Movie"><br /><br /><hr />
</form>

<?php

//Declaration of variables.
$mid = $_GET["title"];
$name = $_GET["name"];
$rating = $_GET["rating"];
$comments = $_GET["comments"];

//Timestamp retrieval.
$timequery = "SELECT CURRENT_TIMESTAMP";
$rs = mysql_query($timequery, $db_connection); 
$row = mysql_fetch_row($rs);
$timestamp = $row[0];

//Insert tuple into Review table.
$insert = "INSERT INTO Review VALUES ('$name', '$timestamp', '$mid', '$rating', '$comments')";
$rs = mysql_query($insert, $db_connection);

if(sizeof($_GET) > 0){
  if($rs)
    print "Add Successful!!<br />";
  else
    print "Add failed. Please enter valid information.<br />"; 
}

mysql_close($db_connection);
?>

</html>
