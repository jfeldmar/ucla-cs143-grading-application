<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>CMDB: CS 143 Movie Database</title>
<style type="text/css">
body {font-size: 12pt;
        background-color: #ffffe0;
        margin-left:0;
	margin-right: 0px;
	margin-top: 19px}

div#buttonA {margin-left: 19px;
	width: 200px}

div#buttonA ul {margin: 0px;
	padding: 0px;
	list-style: square;
	font-family: Trebuchet, sans-serif;
	font-size: 15px;
	line-height: 23px;
	indent: no}

div#buttonA li {list-style-type: none;
	height: 23px;
	width: 200px;
	text-align: center;
	border-style: solid;
	border-color: #DCDCDC;
	border-width: 1px}

div#buttonA li a {
	height: 100%;
	width: 100%;
	display: block;
	text-decoration: none;
	border-width: 1px}

div#buttonA li a:link {
	color: black;
	font-weight: bold;
        background-color: #FFFFFF;
	opacity: .85;
	filter: alpha(opacity=85);
	-moz-opacity: 0.85}

div#buttonA li a:visited {
	color: black;
	font-weight: bold;
	background-color: #FFFFFF;
	opacity: .85;
	filter: alpha(opacity=85);
	-moz-opacity: 0.85}

div#buttonA li a:hover {
	color: black;
	font-weight: bold;
	background-color: #FFFFFF;
	opacity: 1;
	filter: alpha(opacity=100);
	-moz-opacity: 1}

div#buttonA li a:active {
	color: black;
	font-weight: bold;
	background-color: #FFFFFF;
	opacity: 1;
	filter: alpha(opacity=100);
	-moz-opacity: 1}

</style>
</head>
<body>
<div id="buttonA">
<ul>
<li><a href="index.php" target="main"><font color="navy" size="+1">Add New Content:</font></A>
</li><li><a href="AddPerson.php" target="main">Add Actor/Director</A>
</li><li><a href="AddComment.php" target="main">Add Comments To Movie</A>
</li><li><a href="AddMovie.php" target="main">Add Movie Information</A>
</li><li><a href="AddRole.php" target="main">Add Movie/Actor Relation</A>
</li><li><a href="index.php" target="main"></A>
</li><li><a href="index.php" target="main"><font color="navy" size="+1">Browsing Content:</font></A>
</li><li><a href="ShowActor.php" target="main">Show Actor Information</A>
</li><li><a href="ShowMovie.php" target="main">Show Movie Information</A>
</li><li><a href="index.php" target="main"></A>
</li><li><a href="index.php" target="main"><font color="navy" size="+1">Search Interface:</font></A>
</li><li><a href="index.php" target="main">Search Actor/Movie</A>
</ul>
</div>


</form>
</body>
</html>
