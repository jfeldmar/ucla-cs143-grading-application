<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Show Movie Information</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

//Movie dropdown menu.
$query = "SELECT id, title, year FROM Movie";
$rs = mysql_query($query, $db_connection);
$options = "";

//Populates dropdown menu with db data.
while ($row = mysql_fetch_array($rs)){
  $id = $row["id"];
  $title = $row["title"];
  $year = $row["year"];
  $options .= "<OPTION VALUE=\"$id\">".$title." (".$year.")";
}

//Declaration of variables.
$id = $_GET["title"];

//Check whether parameter passed.
if(sizeof($_GET) > 0){

//Select info in Movie table on tuple.
$select = "SELECT * FROM Movie WHERE id=$id";
$rs = mysql_query($select, $db_connection);

$row = mysql_fetch_row($rs);
$title = $row[1];
$year = $row[2];
$rating = $row[3];
$company = $row[4];

//Select info from MovieDirector table.
$select4 = "SELECT * FROM MovieDirector WHERE mid=$id";
$rs4 = mysql_query($select4, $db_connection);

if($rs4 != NULL){
  $row4 = mysql_fetch_row($rs4);
  $did = $row4[1];

  //Getting director name.
  $select5 = "SELECT * FROM Director WHERE id=$did";
  $rs5 = mysql_query($select5, $db_connection);
  
  if($rs5 == NULL){
    $dfirst = "Unlisted.";
    $dlast = "";
  }else{
    $row5 = mysql_fetch_row($rs5);
    $dlast = $row5[1];
    $dfirst = $row5[2];
  }
}else{
  $dfirst = "Unlisted.";
  $dlast = "";
}

//Retrieve from MovieGenre table.
$select6 = "SELECT * FROM MovieGenre WHERE mid=$id";
$rs6 = mysql_query($select6, $db_connection);


//Printing to the screen.
print "--Show Movie Info--<br/>Title: $title ($year)<br />
Producer: $company <br />
MPAA Rating: $rating <br />
Director: $dfirst $dlast<br />
Genre: "; 

$counter = "true";

//Printing genre.
while($row6 = mysql_fetch_row($rs6))
{ 
  $genre = $row6[1];
  if ($counter == "true")
    print "$genre";
  else
    print ", $genre";
  $counter = "false";
}

if($counter == "true")
  print "Unlisted. ";

//Listing actors in this movie. 
print "<br /><br />--Actors in this movie--<br />";

$select2 = "SELECT * FROM MovieActor WHERE mid=$id";
$rs2 = mysql_query($select2, $db_connection);

$counter = "true";

while($row2 = mysql_fetch_row($rs2))
{
  $aid = $row2[1];
  $role = $row2[2];

  $select7 = "SELECT * FROM Actor WHERE id=$aid";
  $rs7 = mysql_query($select7, $db_connection);
  $row7 = mysql_fetch_row($rs7);
  
  $alast = $row7[1];
  $afirst = $row7[2];

echo "<a href=\"./ShowActor.php?actor=" . $aid ."\">" . $afirst . " " .  $alast . "</a>";
print " acting as \"$role\".<br />";
  
  $counter = "false";
}

if($counter == "true")
  print "No actors have been listed yet. Please add them here.<br />";

print "<br />--User Reviews--<br />Average Score: ";

//Calculate average score received on movie.
$select8 = "SELECT * FROM Review WHERE mid=$id";
$rs8 = mysql_query($select8, $db_connection);

$counter = "true";
$totalrating = 0;
$numratings = 0;

while($row8 = mysql_fetch_row($rs8))
{
  $reviewrating = $row8[3];
  
  $totalrating = $totalrating + $reviewrating;
  $numratings = $numratings + 1;
  $counter = "false";
}

if ($numratings == 0)
  print "0.<br />";
else{
  $avgscore = $totalrating/$numratings;
  print "$avgscore. <br/>";
}

print "<br />Comments:<br /><br />";

if($counter == "true"){
  $text = "Add your review now!";
  print "Sorry, no one has reviewed this movie yet. "; 
  echo "<a href=\"./AddComment.php\">" . $text . "</a>";
  print "<br /><br /><hr />";
  exit(1);
}

$rs8 = mysql_query($select8, $db_connection);
while($row8 = mysql_fetch_row($rs8))
{
  $name = $row8[0];
  $time = $row8[1];
  $comment = $row8[4];

  print "$time<br />Rating: $reviewrating stars<br />$name wrote:<br />$comment<br /><br />";  
}

print "<hr />";

}
?>

<form action="" method="get">
Choose Movie: <select name="title">
<OPTION VALUE=0>--Select Movie--
<?=$options?>
</select><br /><br />
<input type="submit" value="Search"><br /><br /><hr /><br />
</form>

<?php
mysql_close($db_connection);
?>

</html>
