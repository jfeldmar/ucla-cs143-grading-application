<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Show Actor Information</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

//Actor dropdown menu.
$query = "SELECT id, last, first, dob FROM Actor";
$rs = mysql_query($query, $db_connection);
$options = "";

//Populates dropdown menu with db data.
while ($row = mysql_fetch_array($rs)){
  $id = $row["id"];
  $last = $row["last"];
  $first = $row["first"];
  $dob = $row["dob"];
  $options .= "<OPTION VALUE=\"$id\">".$first." ".$last." (".$dob.")";
}

//Declaration of variables.
$id = $_GET["actor"];

if(sizeof($_GET) > 0){

//Select info in Actor table on tuple.
$select = "SELECT * FROM Actor WHERE id=$id";
$rs = mysql_query($select, $db_connection);

$row = mysql_fetch_row($rs);
$last = $row[1];
$first = $row[2];
$sex = $row[3];
$dob = $row[4];
$dod = $row[5];

//Select info from MovieActor table.
$select2 = "SELECT * FROM MovieActor WHERE aid=$id";
$rs2 = mysql_query($select2, $db_connection);


//Printing to the screen.
print "--Show Actor Info--<br/>Name: $first $last <br />
Sex: $sex <br />
Date of Birth: $dob <br />
Date of Death: ";

if($dod == NULL)
  print "--Still Alive--";
else
  print "$dod";

$counter = "true";

print "<br /><br />--Roles--<br />";
  
while($row2 = mysql_fetch_row($rs2))
{
  $mid = $row2[0];
  $role = $row2[2];

  //If no movie attached to actor.
  if($mid==NULL)
  {
    print "This movie does not exist. Please add relation.<br />";
    exit(1);
  }

  //Select movie name from given MID.
  $select3 = "SELECT * FROM Movie WHERE id=$mid";
  $rs3 = mysql_query($select3, $db_connection);

  $row3 = mysql_fetch_row($rs3);
  $title = $row3[1];
  
  //If no role.
  if($role==NULL)
    print "Acted in $title. Please add role.<br />";
  else
    print "Played role \"$role\" in ";
    echo "<a href=\"./ShowMovie.php?title=" . $mid . "\">" . $title . "</a>";  
    print ".<br />";
  $counter = "false";
}

if($counter == "true"){
  $text = "Add one now!";
  print "No roles have been recorded yet for $first $last. ";
  echo "<a href=\"./AddRole.php\">" . $text . "</a>";
  print "<br />";
} 


print "<br /><hr />";
}
?>

<form action="" method="get">
Choose Actor: <select name="actor">
<OPTION VALUE=0>--Select Actor--
<?=$options?>
</select><br /><br />
<input type="submit" value="Search"><br /><br /><hr /><br /><br />
</form>

<?php
mysql_close($db_connection);
?>

</html>
