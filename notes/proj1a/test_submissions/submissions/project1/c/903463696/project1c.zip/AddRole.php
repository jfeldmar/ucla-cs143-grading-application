<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Add Movie/Actor Relation</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

//Movie dropdown menu.
$query = "SELECT id, title, year FROM Movie";
$rs = mysql_query($query, $db_connection);
$options = "";

//Populates dropdown menu with db data.
while ($row = mysql_fetch_array($rs)){
  $mid = $row["id"];
  $title = $row["title"];
  $year = $row["year"];
  $options .= "<OPTION VALUE=\"$mid\">".$title." (".$year.")";
}

//Actor dropdown menu.
$query = "SELECT id, last, first, dob FROM Actor";
$rs = mysql_query($query, $db_connection);
$options2 = "";

//Populates dropdown menu with db data.
while ($row = mysql_fetch_array($rs)){
  $aid = $row["id"];
  $last = $row["last"];
  $first = $row["first"];
  $dob = $row["dob"];
  $options2 .= "<OPTION VALUE=\"$aid\">".$first." ".$last." (".$dob.")";
}
?>

<form action="" method="get">
Add a new actor in a movie:<br /><br />
Movie: <select name="title">
<OPTION VALUE=0>--Select Movie--
<?=$options?>
</select><br />
Actor: <select name="actor">
<OPTION VALUE=0>--Select Actor--
<?=$options2?>
</select><br /> 
Role: <input type="text" name="role" maxlength="20" /><br /><br />
<input type="submit" value="Add Role"><br /><br /><hr />
</form>

<?php

//Declaration of variables.
$mid = $_GET["title"];
$aid = $_GET["actor"];
$role = $_GET["role"];

//Check whether parameter has been passed.
if(sizeof($_GET) > 0){

//Insert tuple into MovieActor table.
$insert = "INSERT INTO MovieActor VALUES ('$mid', '$aid', '$role')";
$rs = mysql_query($insert, $db_connection);

if($rs)
  print "Add Successful!!<br />";
else
  print "Add failed. Please enter valid information.";
}

mysql_close($db_connection);
?>

</html>
