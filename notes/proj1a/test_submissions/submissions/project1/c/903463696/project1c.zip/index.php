<!-- Tanya Gillis CS 143 Project 1C -->

<html>

<head><title>CMDb: CS 143 Movie Database</title></head>

<frameset cols="10%,20%,60%,10%">
  <frame name="grey" SRC="Grey.php" frameborder="0" scrolling="no" />
  <frame name="sidebar" SRC="sidebar.php" frameborder="0" scrolling="no" />
  <frame name="main" SRC="Search.php" frameborder="0" />
  <frame name="main" SRC="Grey.php" frameborder="0" scrolling="no" />
</frameset>

</html>
