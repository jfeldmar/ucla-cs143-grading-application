<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Add Actor/Director</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<form action="AddPerson.php" method="get">
Add new actor or director:<br /><br />
Identity: <input type="radio" name="identity" value="Actor" checked="true" />Actor 
<input type="radio" name="identity" value="Director" />Director
<hr>
First Name: <input type="text" name="first" maxlength="20" /><br />
Last Name: <input type="text" name="last" maxlength="20" /><br />
Sex: <input type="radio" name="sex" value="Male" checked="true" />Male 
<input type="radio" name="sex" value="Female"/>Female<br />
Date of Birth: <input type="text" name="dob" /> MUST be in format MM/DD/YYYY.<br />
Date of Death: <input type="text" name="dod" /> MUST be in format MM/DD/YYYY (leave blank if still alive).<br /><br /> 
<input type="submit" value="Add Entry" />
<br /><br /><hr>
</form>

<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

//Declaration of variables.
$identity = $_GET["identity"];
$first = $_GET["first"];
$last = $_GET["last"];
$sex = $_GET["sex"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];

//Check if parameter was passed.
if(sizeof($_GET) > 0){

//Largest ID at this time.
$rs = mysql_query("select * from MaxPersonID", $db_connection);
$i = mysql_fetch_row($rs);
$MaxPersonID = $i[0];

//Converting DOB to MySQL format.
$query = "select str_to_date('$dob', '%m/%d/%Y')";
$rs = mysql_query($query, $db_connection);
$j = mysql_fetch_row($rs);
$new_dob = $j[0];

//Convert DOD to MySQL format.
if ($dod == "")
  $new_dod == NULL;
else{
  $query = "select str_to_date('$dod', '%m/%d/%Y')";
  $rs = mysql_query($query, $db_connection);
  $k = mysql_fetch_row($rs);
  $new_dod = $k[0];
}

//Actor query.
if ($identity == "Actor")
{
  $MaxPersonID = $MaxPersonID + 1;
  $insert = "INSERT INTO Actor VALUES ('$MaxPersonID', '$last', '$first', '$sex', '$new_dob', '$new_dod')";
  $rs = mysql_query($insert, $db_connection);

  if($rs){
    $update = "UPDATE MaxPersonID SET id='$MaxPersonID'";
    mysql_query($update, $db_connection);
    print "Add Successful!!<br />";
  }else
    print "Add Failed. Please enter valid data.<br />";
}elseif ($identity == "Director")
{
  $MaxPersonID = $MaxPersonID + 1;
  $insert = "INSERT INTO Director VALUES ('$MaxPersonID', '$last', '$first', '$new_dob', '$new_dod')";
  $rs = mysql_query($insert, $db_connection);

  if($rs){
    $update = "UPDATE MaxPersonID SET id='$MaxPersonID'";
    mysql_query($update, $db_connection);
    print "Add Successful!!<br />";
  }else
    print "Add Failed. Please enter valid data.<br />";
}
}

mysql_close($db_connection);
?>



</html>
