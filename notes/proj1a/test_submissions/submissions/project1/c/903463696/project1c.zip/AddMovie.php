<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Add Movie Information</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$query = "SELECT id, last, first, dob FROM Director";
$rs = mysql_query($query, $db_connection);
$options = "";

//Populates dropdown menu with Director info.
while($row = mysql_fetch_array($rs)){
  $did = $row["id"];
  $last = $row["last"];
  $first = $row["first"];
  $dob = $row["dob"];
  $options .= "<OPTION VALUE=\"$did\">".$first." ".$last." ("."Birth: ".$dob.")";
}
?>
<form action="" method="get">

Add New Movie Information:<br /><br />
Title: <input type="text" name="title" maxlength="20" /><br />
Company: <input type="text" name="company" maxlength="50" /><br />
Year: <input type="text" name="year" maxlength="4" /> MUST be in format YYYY.<br />
Director: <select name="id">
<OPTION VALUE=0>--Select One--
<?=$options?></select><br /> 

MPAA Rating: <select name = "rating">
  <option value="G"> G </option>
  <option value="PG"> PG </option>
  <option value="PG-13"> PG-13 </option>
  <option value="R"> R </option>
  <option value="NC-17"> NC-17 </option>
</select><br />
 
Genre: <input type="checkbox" name="genre" value="Action" />Action </input> 
<input type="checkbox" name="genre" value="Adult" />Adult </input>
<input type="checkbox" name="genre" value="Adventure" />Adventure </input>
<input type="checkbox" name="genre" value="Animation" />Animation </input>
<input type="checkbox" name="genre" value="Comedy" />Comedy </input>
<input type="checkbox" name="genre" value="Crime" />Crime </input>
<input type="checkbox" name="genre" value="Documentary" />Documentary </input>
<input type="checkbox" name="genre" value="Drama" />Drama </input>
<input type="checkbox" name="genre" value="Family" />Family </input>
<input type="checkbox" name="genre" value="Fantasy" />Fantasy </input>
<input type="checkbox" name="genre" value="Horror" />Horror </input>
<input type="checkbox" name="genre" value="Musical" />Musical </input>
<input type="checkbox" name="genre" value="Mystery" />Mystery </input>
<input type="checkbox" name="genre" value="Romance" />Romance </input>
<input type="checkbox" name="genre" value="Sci-Fi" />Sci-Fi </input>
<input type="checkbox" name="genre" value="Short" />Short </input>
<input type="checkbox" name="genre" value="Thriller" />Thriller </input>
<input type="checkbox" name="genre" value="War" />War </input>
<input type="checkbox" name="genre" value="Western" />Western </input>
<br /><br /> 
<input type="submit" value="Add Movie" />
<br /><br /><hr>
</form>

<?php

//Declaration of variables.
$title = $_GET["title"];
$company = $_GET["company"];
$year = $_GET["year"];
$did = $_GET["id"];
$rating = $_GET["rating"];
$genre = $_GET["genre"];

//Check if passed.
if(sizeof($_GET) > 0){

//Largest ID at this time.
$rs = mysql_query("select * from MaxMovieID", $db_connection);
$i = mysql_fetch_row($rs);
$MaxMovieID = $i[0];

//Movie insertion.
  $MaxMovieID = $MaxMovieID + 1;
  $insert = "INSERT INTO Movie VALUES ('$MaxMovieID', '$title', '$year', '$rating', '$company')";
  $rs = mysql_query($insert, $db_connection);

  if(!$rs){
    print "Add Failed. Please enter valid data.<br />";
    exit(1);
  }else{
    $update = "UPDATE MaxMovieID SET id='$MaxMovieID'";
    mysql_query($update, $db_connection);
    $true = "true";
  }

//MovieGenre insertion.
  $insert = "INSERT INTO MovieGenre VALUES ('$MaxMovieID', '$genre')";
  $rs = mysql_query($insert, $db_connection);

  if(!$rs){
    print "Add Failed. Please enter valid data.<br />";
    exit(1);
  }else{
    $true = "true";
  }

//MovieDirector insertion.
  $insert = "INSERT INTO MovieDirector VALUES ('$MaxMovieID', '$did')";
  $rs = mysql_query($insert, $db_connection);

  if(!$rs){
    print "Add Failed. Please enter valid data.<br />";
    exit(1);
  }elseif($true == "true"){
    print "Add Successful!!<br />";
  }
}

mysql_close($db_connection);
?>



</html>
