<!-- Tanya Gillis CS 143 Project 1C -->

<html>
<head>
<title>Search</title>

<style type="text/css">
body
{background-image: url("./cmdb.jpg");
 background-repeat: no-repeat;
}
</style>
</head>

<br /><br /><br /><br /><br />
<form action="" method="get">
Search: <input type="text" name="keyword" /><br /><br /> 
<input type="submit" value="Search CMDb" />
<br /><br /><hr>
</form>

<?php
$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

//Declaration of variables.
$keyword = $_GET["keyword"];
$keyword = mysql_real_escape_string($keyword);

//Check whether parameter is passed.
if(sizeof($_GET) > 0){

//Trim whitespace from variable, stores individual pieces into array.
$keyword = trim($keyword);
$oldkey = $keyword;
$keyarr = explode(" ", $keyword);
$count = count($keyarr);

if ($keyword == ""){
  echo "Search Error: <br />Please enter a search term.";
  exit(1);
}

print "You are searching CMDb for [$keyword]...<br /><br />
Searching for matches in the Actor database...<br />";

if($count == 1){

//Query for each word.
foreach($keyarr as $keyword){

  $query = "SELECT * FROM Actor WHERE first LIKE '%$keyword%'";
  $query2 = "SELECT * FROM Actor WHERE last LIKE '%$keyword%'";
  $rs = mysql_query($query, $db_connection);
  $rs2 = mysql_query($query2, $db_connection);
  $test = "true";

  if(($rs != NULL) && ($rs2 != NULL))
  {  
    while($row = mysql_fetch_row($rs))
    {
      $id = $row[0];
      $last = $row[1];
      $first = $row[2];
      $dob = $row[4];

      echo "Actor: <a href=\"./ShowActor.php?actor=" . $id . "\">" . $first . " " . $last . " (" . $dob . ")" . "</a><br />";  
      $test = "false";
    }
  
    while($row = mysql_fetch_row($rs2))
    {
      $id2 = $row[0];
      $last2 = $row[1];
      $first2 = $row[2];
      $dob2 = $row[4];

      echo "Actor: <a href=\"./ShowActor.php?actor=" . $id2 . "\">" . $first2 . " " . $last2 . " (" . $dob2 . ")" . "</a><br />";  
      $test = "false";
    }
  }
  if ($test == "true")
    print "There are no Actor matches.<br />";
}
}elseif($count == 2)
{
  $query = "SELECT * FROM Actor";
  $rs = mysql_query($query, $db_connection);
  $test = "true";
  
  while($row = mysql_fetch_row($rs)){
    $id = $row[0];
    $last = $row[1];
    $first = $row[2];
    $dob = $row[4];
    
    $fullname = $first . " " . $last;

    if(stripos($fullname, $oldkey) !== false){
      echo "Actor: <a href=\"./ShowActor.php?actor=" . $id . "\">" . $first . " " . $last . " (" . $dob . ")" . "</a><br />";  
      $test = "false";
    }
       
  }

if($test == "true")
  print "There are no Actor matches.<br />";

}else
  print "There are no Actor matches.<br />";

print "<br />Searching for matches in the Movie database...<br />";

//Query for each word.


  $query = "SELECT * FROM Movie WHERE title LIKE '%$oldkey%'";
  $rs = mysql_query($query, $db_connection);
  $test = "true";

  if($rs != NULL)
  {  
    while($row = mysql_fetch_row($rs))
    {
      $id = $row[0];
      $title = $row[1];
      $year = $row[2];

      echo "Movie: <a href=\"./ShowMovie.php?actor=" . $id . "\">" . $title . " (" . $year . ")" . "</a><br />";  
      $test = "false";
    }
  }
  
  if ($test == "true")
    print "There are no Movie matches.<br />";

print "<br /><hr />";
}
mysql_close($db_connection);
?>

</html>
