<html>
<head><title>Actors</title></head>
<body>
<h1>Actors</h1>
<br/><a href="home.html">Home</a><br/>
<br />
Choose a letter:
<br />

<?php
$letter = $_GET['letter'];
$aid = $_GET['aid'];
for($i=65; $i<65+26; $i++)
{
	echo "<a href=\"actors.php?letter=".chr($i)."\">".chr($i)." </a>";
}
	echo "<br /><br/>";
if (isset($letter))
{
	$db_connection = mysql_connect("localhost", "cs143", "");
	if (!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if (!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query = 'SELECT id, first, last FROM Actor WHERE last LIKE \''.$letter.'%\' ORDER BY last;';
	$rs = mysql_query($query, $db_connection);
	if (!$rs)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	$numfields = mysql_num_fields($rs);
	while($row = mysql_fetch_row($rs))
	{
		echo "<a href=\"actors.php?aid=".$row[0]."\">".$row[1]." ".$row[2]."</a>";
		echo "<br />";
	}

	mysql_close($db_connection);
}
if (isset($aid))
{
	$db_connection = mysql_connect("localhost", "cs143", "");
	if (!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if (!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query1 = 'SELECT first, last, sex, dob, dod FROM Actor WHERE id='.$aid.';';
	$query2 = 'SELECT MovieActor.role, Movie.id, Movie.title FROM Movie, MovieActor WHERE MovieActor.aid='.$aid.' AND mid=Movie.id;';
	$rs1 = mysql_query($query1, $db_connection);
	if (!$rs1)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	while($row = mysql_fetch_row($rs1))
	{
		echo "Name: ".$row[0]." ".$row[1];
		echo "<br />";
		echo "Sex: ".$row[2];
		echo "<br />";
		echo "Date of Birth: ".$row[3];
		echo "<br />";
		if($row[4]==NULL)
			echo "Date of Death: Still Alive";
		else
		echo "Date of Death: ".$row[4];
		echo "<br />";
	}
	$rs2 = mysql_query($query2, $db_connection);
	if (!$rs2)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	echo "<br/>Played:<br/><br/>";
	while($row = mysql_fetch_row($rs2))
	{
		echo $row[0]." in "."<a href=\"movies.php?mid=".$row[1]."\">".$row[2]."</a>";
		echo "<br/>";
	}
	mysql_close($db_connection);
}
?>

</body>
</html>
