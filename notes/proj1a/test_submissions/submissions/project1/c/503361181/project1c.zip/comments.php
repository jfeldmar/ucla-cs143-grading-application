<html>
<head><title>Comments</title></head>
<body>
<a href="home.html">Home</a><br/>
<a href="movies.php">Choose a movie</a><br/><br/>
<br/>

<?php
$mid = $_GET["mid"];
$name = $_GET["name"];
$rating = $_GET["rating"];
$comment = $_GET["comment"];
if (isset($mid))
{
	$db_connection = mysql_connect("localhost", "cs143", "");
	if (!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if (!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query1 = 'SELECT title FROM Movie WHERE id='.$mid.';';
	$rs1 = mysql_query($query1, $db_connection);
	if (!$rs1)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	while($row = mysql_fetch_row($rs1))
	{
		echo "Movie: ".$row[0].'<br/>';
	}
if(!isset($name) or !isset($rating) or !isset($comment))
{
	echo '<form action="comments.php" method="GET">
	<br/>
	Name: 
	<input type="hidden" name="mid" value="'.$mid.'">
	<input type="text" name="name">
	<br/>
		Rating: 
	1<input type="radio" name="rating" value="1">
	2<input type="radio" name="rating" value="2">
	3<input type="radio" name="rating" value="3">
	4<input type="radio" name="rating" value="4">
	5<input type="radio" name="rating" value="5">
	<br/>
	<textarea name="comment" cols="50" rows="10"></textarea>
	<input type="submit" value="Submit" />
	</form>';
}
else
{

	$query = 'INSERT INTO Review(name, mid, rating, comment) VALUES (\''.$name.'\', '.$mid.', '.$rating.', \''.$comment.'\');';
	$rs = mysql_query($query, $db_connection);
	if (!$rs)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	else
		echo "<br/><br/>Successfully uploaded review.<br/><br/>";
}
	mysql_close($db_connection);
}
?>

</body>
</html>
