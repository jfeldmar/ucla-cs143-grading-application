<html>
<head><title>Search</title></head>
<body>
<h1>Search</h1>
<a href="home.html">Home</a>
<br><br>
<form action="search.php" method="GET">
Search for a movie or actor:
<input type="text" name="search">
<input type="submit" value="Submit">
<br><br>
<?php
$search = $_GET["search"];
if (isset($search))
{
	$search = strtolower($search);
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if(!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query1 = 'SELECT first, last, id FROM Actor';
	$query2 = 'SELECT title, id FROM Movie';
	$rs1 = mysql_query($query1, $db_connection);
	if(!rs1)
	{
		echo 'Could not run query: '.mysql_error();
		exit;
	}
	$rs2 = mysql_query($query2, $db_connection);
	if(!rs2)
	{
		echo 'Could not run query: '.mysql_error();
		exit;
	}
	while($row = mysql_fetch_row($rs1))
	{
		if (strtolower($row[0]) == $search
		or  strtolower($row[1]) == $search
		or  strtolower($row[0].' '.$row[1]) == $search)
		{
			echo '<a href="actors.php?aid='.$row[2].'">'.$row[0].' '.$row[1].'</a>';
			echo '<br>';
		}
	}
	while($row = mysql_fetch_row($rs2))
	{
		if(substr_count(strtolower($row[0]), $search))
		{
			echo '<a href="movies.php?mid='.$row[1].'">'.$row[0].'</a>';
			echo '<br>';
		} 
	}
}

?>
</body>
</html>
