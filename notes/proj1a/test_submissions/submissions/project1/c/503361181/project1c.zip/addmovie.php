<html>
<head><title>Add a Movie</title></head>
<body>
<h1>Add a Movie</h1>
<a href="home.html">Home</a>
<br><br>

<?php
$title = $_GET["title"];
$year = $_GET["year"];
$rating = $_GET["rating"];
$company = $_GET["company"];
if (!isset($title))
{
	echo '<form action="addmovie.php" method="GET">
	Title: 
	<input type="text" name="title">
	<br>
	Year: 
	<input type="text" name="year">
	<br>
	MPAA Rating: 
	<input type="text" name="rating">
	<br>
	Production Company: 
	<input type="text" name="company">
	<br>
	Genre: 
	<input type="checkbox" name="Action">Action</input>
	<input type="checkbox" name="Adult">Adult</input>
	<input type="checkbox" name="Adventure">Adventure</input>
	<input type="checkbox" name="Animation">Animation</input>
	<input type="checkbox" name="Comedy">Comedy</input>
	<input type="checkbox" name="Crime">Crime</input>
	<input type="checkbox" name="Documentary">Documentary</input>
	<input type="checkbox" name="Drama">Drama</input>
	<input type="checkbox" name="Family">Family</input>
	<input type="checkbox" name="Fantasy">Fantasy</input>
	<input type="checkbox" name="Horror">Horror</input>
	<input type="checkbox" name="Musical">Musical</input>
	<input type="checkbox" name="Mystery">Mystery</input>
	<input type="checkbox" name="Romance">Romance</input>
	<input type="checkbox" name="SciFi">SciFi</input>
	<input type="checkbox" name="Short">Short</input>
	<input type="checkbox" name="Thriller">Thriller</input>
	<input type="checkbox" name="War">War</input>
	<input type="checkbox" name="Western">Western</input>
	<br>
	<input type="submit" value="Submit" />
	</form>';
}
	$db_connection = mysql_connect("localhost", "cs143", "");
	if (!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if (!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query1 = "SELECT id FROM MaxMovieID;";
	$rs1 = mysql_query($query1, $db_connection);
	if (!$rs1)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	$row = mysql_fetch_row($rs1);
	$maxid = $row[0];
	$maxid++;
if(isset($title) and isset($year) and isset($rating) and isset($company))
{
	$query2 = 'INSERT INTO Movie(id, title, year, rating, company) VALUES ('.$maxid.', \''.$title.'\', '.$year.', \''.$rating.'\', \''.$company.'\');';
	$query3 = 'UPDATE MaxMovieID SET id='.$maxid.';';
	$rs2 = mysql_query($query2, $db_connection);
	if(!$rs2)
	{
		echo 'Could not run query: '. mysql_error();
		exit;
	}
	$rs3 = mysql_query($query3, $db_connection);
	if(!$rs3)
	{
		echo 'Could not run query: '. mysql_error();
		exit;
	}
if(isset($_GET["Action"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Action\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Adult"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Adult\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Adventure"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Adventure\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Animation"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Animation\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Comedy"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Comedy\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Crime"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Crime\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Documentary"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Documentary\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Drama"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Drama\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Family"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Family\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Fantasy"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Fantasy\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Horror"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Horror\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Musical"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Musical\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Mystery"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Mystery\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Romance"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Romance\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["SciFi"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'SciFi\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Thriller"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Thriller\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["War"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'War\');';
	$rs = mysql_query($query, $db_connection);
}
if(isset($_GET["Western"]))
{
	$query = 'INSERT INTO MovieGenre (mid, genre) VALUES ('.$maxid.', \'Western\');';
	$rs = mysql_query($query, $db_connection);
}
	echo "Successfully added Movie";
}

	mysql_close($db_connection);
?>

</body>
</html>
