<html>
<head><title>Add an Actor/Director</title></head>
<body>
<h1>Add an Actor or Director</h1>
<a href="home.html">Home</a>
<br><br>

<?php
$first = $_GET["first"];
$last = $_GET["last"];
$sex = $_GET["sex"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];
$actor = $_GET["actor"];
$director = $_GET["director"];
if (!isset($last))
{
	echo '<form action="addactor.php" method="GET">
	<input type="checkbox" name="actor" value="Actor">Actor</input>
	<input type="checkbox" name="director" value="Director">Director</input>
	<br>
	First Name: 
	<input type="text" name="first">
	<br>
	Last Name: 
	<input type="text" name="last">
	<br>
	Sex: 
	<input type="radio" name="sex" value="Male">Male</input>
	<input type="radio" name="sex" value="Female">Female</input>
	<br>
	Date of Birth (YYYYMMDD):
	<input type="text" name="dob">
	<br>
	Date of Death (YYYYMMDD):
	<input type="text" name="dod">
	<br>
	<input type="submit" value="Submit" />
	</form>';
}
	$db_connection = mysql_connect("localhost", "cs143", "");
	if (!db_connection)
	{
		echo 'Could not connect to database.';
		exit;
	}
	if (!mysql_select_db("CS143", $db_connection))
	{
		echo 'Could not select database.';
		exit;
	}
	$query1 = "SELECT id FROM MaxPersonID;";
	$rs1 = mysql_query($query1, $db_connection);
	if (!$rs1)
	{
		echo 'Could not run query: ' . mysql_error();
		exit;
	}
	$row = mysql_fetch_row($rs1);
	$maxid = $row[0];
	$maxid++;
if(isset($first) and isset($last) and isset($sex) and isset($dob))
{
	$query2 = "INSERT INTO Actor(id, first, last, sex, dob, dod) VALUES (".$maxid.", '".$first."', '".$last."', '".$sex."', '".$dob."', '".$dod."');";
	$query3 = "INSERT INTO Director(id, first, last, dob, dod) VALUES (".$maxid.", '".$first."', '".$last."', '".$dob."', '".$dod."');";
	$query4 = 'UPDATE MaxPersonID SET id='.$maxid.';';
if(isset($actor))
{
	$rs2 = mysql_query($query2, $db_connection);
	if(!$rs2)
	{
		echo 'Could not run query2: '. mysql_error();
		exit;
	}
	$rs4 = mysql_query($query4, $db_connection);
	if(!$rs4)
	{
		echo 'Could not run query4: '. mysql_error();
		exit;
	}
}
if(isset($director))
{
	$rs3 = mysql_query($query3, $db_connection);
	if(!$rs3)
	{
		echo 'Could not run query3: '. mysql_error();
		exit;
	}
	$rs4 = mysql_query($query4, $db_connection);
	if(!$rs4)
	{
		echo 'Could not run query4: '. mysql_error();
		exit;
	}
}
	echo "Successfully added Actor or Director";
}

	mysql_close($db_connection);
?>

</body>
</html>
