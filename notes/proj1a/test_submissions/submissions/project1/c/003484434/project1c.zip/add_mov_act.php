<?php include './header.php'; ?>

<h3>Add a Movie role for an actor</h3>
<form action="./add_mov_act.php" method="GET">
<table width="500">
<tr>
	<td class="form_label">Movie</td>
	<td>
		<select name="movie_id" style="width: 300;">
			<?php
				$link = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143", $link);
				$query="select id, title, year from Movie";
				$rs = mysql_query($query, $link);
				while($row = mysql_fetch_row($rs))
				{
					echo "<option value=\"" . $row[0] . "\">";
					echo $row[1] . " (Year: " . $row[2] . ")</option>\n";
				}
			?>
		</select>
	</td>
</tr>

<tr>
	<td class="form_label">Actor</td>
	<td>
	<select name="actor_id" style="width: 300;">
	<?php
		$link = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $link);
		$query="select first, last, id, dob from Actor group by first";
	
		$rs = mysql_query($query, $link);
		
		while($row = mysql_fetch_row($rs))
		{
			echo "<option value=\"" . $row[2] . "\">";
			echo $row[0] . " " . $row[1] . " (Birth: "
				. $row[3] . ")</option>\n";
		}
		echo "</select>"
	?>
	</td>
</tr>

<tr>
	<td class="form_label">Role</td>
	<td>
		<input type="text" name="role" maxlength="50">
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<?php
eval("\$movie_id = \$_GET[\"movie_id\"];");
eval("\$actor_id = \$_GET[\"actor_id\"];");
eval("\$role = \$_GET[\"role\"];");

if($movie_id != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);

	$query = "insert into MovieActor values('" . $movie_id . "','" 
		. $actor_id . "','" . $role . "')";
	$rs = mysql_query($query, $link);
	if($rs)
	{
		$query="select first, last from Actor where id=" . $actor_id;
		$rs = mysql_query($query, $link);
		$row = mysql_fetch_row($rs);
		$movie_title = "select title from Movie where id=" . $movie_id;
		$movie_title = mysql_query($movie_title, $link);
		$movie_title = mysql_fetch_row($movie_title);
		
		echo $row[0] . " " . $row[1] . " successfully added as " . $role . " in the movie \""
			. $movie_title[0] . "\".";
		echo "<br/>To see the info page for this movie, click <a href=\"./show_mov_info.php?movie_id="
			. $movie_id . "\">here</a>.<br/>";
	}
	else
		echo "fail.";
	mysql_close($link);
}
?>

</body>
</html>

