<?php include './header.php'; ?>

<body>
<h3>Add an Actor or Director to the database</h3>
<form action="./add_act_dir.php" method="GET">
<table width="400">
<tr>
	<td class="form_label">Title</td>
	<td>
		<input type="radio" name="identity" value="Actor" checked="true">Actor
		<input type="radio" name="identity" value="Director">Director
	</td>
</tr>

<tr>
	<td class="form_label">First name</td>
	<td>
		<input type="text" name="first" maxlength="20">
	</td>
</tr>

<tr>
	<td class="form_label">Last name</td>
	<td>
		<input type="text" name="last" maxlength="20">
	</td>
</tr>
<tr><td><br/></td></tr>

<tr>
	<td class="form_label">Sex</td>
	<td>
		<input type="radio" name="sex" value="Male" checked="true" />Male
		<input type="radio" name="sex" value="Female" />Female
	</td>
</tr>

<tr>
	<td class="form_label">DOB</td>
	<td>
		<input type="text" name="dob">
		<br/><small>Format: yyyymmdd</small>
	</td>
</tr>

<tr>
	<td class="form_label" valign="top">DOD</td>
	<td>
		<input type="text" name="dod">&nbsp;<small>(where applicable)</small>
		<br/><small>Format: yyyymmdd</small>
	</td>
</tr>
<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<?php
eval("\$identity = \$_GET[\"identity\"];");
eval("\$first = \$_GET[\"first\"];");
eval("\$last = \$_GET[\"last\"];");
eval("\$sex = \$_GET[\"sex\"];");
eval("\$dob = \$_GET[\"dob\"];");
eval("\$dod = \$_GET[\"dod\"];");

if($identity != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);

	if($identity == "Actor")
	{
		$id = "select id from MaxPersonID";
		$id = mysql_query($id, $link);
		$id = mysql_fetch_row($id);
		$query = "insert into Actor values('" . $id[0] . "','" 
			. $last . "','" . $first . "','" . $sex . "','"
			. $dob . "','" . $dob . "')";
		$rs = mysql_query($query, $link);
		
		if($rs)
		{
			echo $first . " " . $last . " successfully added to the database!";
			echo "<br/>To visit the page of this " . $identity 
				. ", please click <a href=\"./show_act_info.php?actor=" . $id[0] . "\">here</a>.";
			$ins_new_max = "update MaxPersonID set id=id+1";
			$ins_new_max = mysql_query($ins_new_max, $link);
		}
	}
	
	else	// Director
	{
		$id = "select id from MaxPersonID";
		$id = mysql_query($id, $link);
		$id = mysql_fetch_row($id);
		$query = "insert into Director values('" . $id[0] . "','" 
			. $last . "','" . $first . "','"
			. $dob . "','" . $dod . "')";
		$rs = mysql_query($query, $link);

		if($rs)
		{
			echo $first . " " . $last . " successfully added to the database!";
			echo "<br/>To visit the page of this " . $identity 
				. ", please click <a href=\"./show_act_info.php?actor=" . $id[0] . "\">here</a>.";
			$ins_new_max = "update MaxPersonID set id=id+1";
			$ins_new_max = mysql_query($ins_new_max, $link);
		}
	}
	mysql_close($link);
}
?>
</body>
</html>