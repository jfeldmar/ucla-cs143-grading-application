<?php include './header.php'; ?>

<h3>Show Actor information</h3>
<form action="./show_act_info.php" method="GET">
<table width="400">
<tr>
	<td class="form_label">Actor</td>
	<td>
		<select name="actor">
		<?php
			$link = mysql_connect("localhost", "cs143", "");
			mysql_select_db("CS143", $link);
			$query="select first, last, id, dob from Actor group by first";
			$rs = mysql_query($query, $link);
			
			while($row = mysql_fetch_row($rs))
			{
				echo "<option value=\"" . $row[2] . "\"";
				if($row[2] == $actor)
					echo " selected=\"selected\"";
				echo ">";
				echo $row[0] . " " . $row[1] . " (Birth: "
					. $row[3] . ")</option>\n";
			}
		?>
		</select>
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<div style="margin-left: 100px;">
<?php
eval("\$actor = \$_GET[\"actor\"];");

if($actor != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);

	$info = "select * from Actor where id='" . $actor . "'";
	$info = mysql_query($info, $link);
	$info = mysql_fetch_row($info);

	if($info)
	{
		echo "Name: " . $info[2] . " " . $info[1] . "<br/>";
		echo "Sex: " . $info[3] . "<br/>";
		echo "Date of birth: " . $info[4] . "<br/>";
		if($info[5] != null)
			echo "Date of death: " . $info[5] . "<br/>";

		echo "<br/>";

		$role = "select title, role, id from MovieActor, Movie where aid='"
			. $actor . "' and MovieActor.mid = Movie.id";
		$role = mysql_query($role, $link);
		
		while($row = mysql_fetch_row($role))
		{
			echo "Acted as \"" . $row[1] . "\" in <a href=\"./show_mov_info.php?movie_id="
				. $row[2] . "\">" . $row[0] . "</a><br/>";
		}

	}
	else
		echo "fail.";
		
	mysql_close($link);
}
?>
</div>
</body>
</html>

