<?php include './header.php'; ?>

<h3>Show Movie information</h3>
<form action="./show_mov_info.php" method="GET">
<table width="400">
<tr>
	<td class="form_label">Movie</td>
	<td>
		<?php
			eval("\$movie_id = \$_GET[\"movie_id\"];");
			echo "<select name=\"movie_id\" style=\"width: 300;\">";
		
			$link = mysql_connect("localhost", "cs143", "");
			mysql_select_db("CS143", $link);
			$query="select id, title, year from Movie group by title";
			$rs = mysql_query($query, $link);
			
			while($row = mysql_fetch_row($rs))
			{
				echo "<option value=\"" . $row[0] . "\"";
				if($row[0] == $movie_id)
					echo " selected=\"selected\"";
				echo ">";
				echo $row[1] . " (Year: " . $row[2] . ")</option>\n";
			}
			echo "</select>"
		?>
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<div style="margin-left: 100px;">
<?php
eval("\$movie_id = \$_GET[\"movie_id\"];");

if($movie_id != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);

	$info = "select title, year, rating, company from Movie where Movie.id=" 
		. $movie_id;
	$info = mysql_query($info, $link);
	$info = mysql_fetch_row($info);
	
	if($info)
	{
		echo "Title: " . $info[0] . "<br/>";
		echo "Year: " . $info[1] . "<br/>";
		echo "Rating: " . $info[2] . "<br/>";
		echo "Company: " . $info[3] . "<br/>";

		$dir_name = "select first, last from Director, MovieDirector where Director.id = MovieDirector.did and MovieDirector.mid = "
			. $movie_id;
		$dir_name = mysql_query($dir_name, $link);
		$dir_name = mysql_fetch_row($dir_name);
		if($dir_name != null)
		{
			echo "Director: " . $dir_name[0] . " "
				. $dir_name[1] . "<br/>";
		}
		$genre = "select genre from MovieGenre where mid = '"
			. $movie_id . "'";
		$genre = mysql_query($genre, $link);
		
		echo "Genre: ";
		$num_rows = mysql_num_rows($genre);
		$count_rows = 0;

		while($row = mysql_fetch_row($genre))
		{
			$count_rows = $count_rows + 1;
			echo $row[0];
			if($count_rows < $num_rows)
				echo ", ";
		}

		echo "<br/><br/>";

		$role =
		"select first, last, role, aid from MovieActor, Movie, Actor where mid='"
			. $movie_id . "' and MovieActor.mid = Movie.id and MovieActor.aid = Actor.id";
		$role = mysql_query($role, $link);
		
		while($row = mysql_fetch_row($role))
		{
			echo "<a href=\"./show_act_info.php?actor=" 
			. $row[3] . "\">" . $row[0] . " " . $row[1] . "</a>"
			. " as \"" . $row[2] . "\"<br/>";
		}
	
		echo "<br/>";

		$review = "select * from Review where mid=" . $movie_id;
		$review = mysql_query($review, $link);
		$avg = "select avg(rating), count(rating) from Review where mid="
			. $movie_id;
		$avg = mysql_query($avg, $link);
		$avg = mysql_fetch_row($avg);
		
		if($avg[1] == 0)
		{
			echo "<a href=\"./add_comment.php?def_id="
				. $movie_id . "\">Be the first 
				to review this movie!</a>";
		}

		else
		{
			echo "<strong>Average rating: " . $avg[0] . "/5.0 by " 
				. $avg[1] . " reviewers</strong><br/>";
		}
		echo "<br/>";

		echo "<div style=\"margin-left: 15px;\">";
		while($row = mysql_fetch_row($review))
		{
			echo "On " . $row[1] . ", " . $row[0] .
				" gave the movie a " . $row[3] . ":<br/>";
			echo $row[4] . "<br/><br/>";
		}
		echo "</div>";
	}
	else
		echo "fail.";

	mysql_close($link);
}
?>
</div>
</body>
</html>

