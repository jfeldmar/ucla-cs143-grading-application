<?php include './header.php'; ?>

<h3>Search for information</h3>
<form action="./search.php" method="GET">
<table width="400">
<tr>
	<td>Search</td>
	<td>
		<input type="text" name="saachi" style="width: 200px;">
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<div style="margin-left: 100px;">
<?php
eval("\$saachi = \$_GET[\"saachi\"];");

if($saachi != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);
	$query = "select first, last, dob from Actor where first like '%"
		. $saachi . "%' or last like '%" . $saachi . "%'";
	$rs = mysql_query($query, $link);
	if($rs)
	{
		while($row = mysql_fetch_row($rs))
		{
			echo "Actor: " . $row[0] . " " . $row[1]
				. " (Birth: " . $row[2] . ")<br/>";
		}
	}
	else
		echo "fail.";
	
	$query = "select first, last, dob from Director where first like '%"
		. $saachi . "%' or last like '%" . $saachi . "%'";
	$rs = mysql_query($query, $link);
	if($rs)
	{
		while($row = mysql_fetch_row($rs))
		{
			echo "Director: " . $row[0] . " " . $row[1]
				. " (Birth: " . $row[2] . ")<br/>";
		}
	}
	else
		echo "fail.";
		
	$query = "select title from Movie where title like '%"
		. $saachi . "%'";
	$rs = mysql_query($query, $link);
	if($rs)
	{
		while($row = mysql_fetch_row($rs))
		{
			echo "Movie: " . $row[0] . "<br/>";
		}
	}
	else
		echo "fail.";
	mysql_close($link);
}
?>
</div>
</body>
</html>

