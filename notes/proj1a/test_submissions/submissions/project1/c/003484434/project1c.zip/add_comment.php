<?php include './header.php'; ?>

<h3>Add new comment</h3>

<form action="./add_comment.php" method="GET">
<table width="500">
<tr>
	<td class="form_label">Movie</td>
	<td>
		<select name="movie_id" style="width: 300;">
		<?php
			$link = mysql_connect("localhost", "cs143", "");
			mysql_select_db("CS143", $link);
			$query="select id, title, year from Movie";
			$rs = mysql_query($query, $link);
			eval("\$def_id = \$_GET[\"def_id\"];");
			while($row = mysql_fetch_row($rs))
			{
				echo "<option value=\"" . $row[0] . "\"";
				if($row[0] == $def_id)
				{
					echo " selected=\"selected\" ";
				}
				echo ">";
				echo $row[1] . " (Year: " . $row[2] . ")</option>\n";
			}
			echo "</select>"
		?>
	</td>
</tr>

<tr>
	<td class="form_label">Name</td>
	<td>
		<input type="text" name="name" maxlength="20" value="Anonymous">
	</td>
</tr>

<tr>
	<td class="form_label">Rating</td>
	<td>
		<select name="rating">
			<option value="5"> 5 - Excellent </option>
			<option value="4"> 4 - Good </option>
			<option value="3"> 3 - Okay </option>
			<option value="2"> 2 - Not worth it </option>
			<option value="1"> 1 - Hate it </option>
		</select>
	</td>
</tr>

<tr>
	<td valign="top" class="form_label">Comments</td>
	<td>
		<textarea name="comment" cols="40" rows="10"></textarea>
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<?php
eval("\$movie_id = \$_GET[\"movie_id\"];");
eval("\$name = \$_GET[\"name\"];");
eval("\$rating = \$_GET[\"rating\"];");
eval("\$comment = \$_GET[\"comment\"];");

if($comment != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);
	$timestamp = date("F j, Y, g:i a");
	$query = "insert into Review(name, mid, rating, comment) values('"
		. $name . "','" . $movie_id . "','"
		. $rating . "','" . $comment . "')";
	$rs = mysql_query($query, $link);
	if($rs)
	{
		echo "Thanks for your input!<br/>";
		echo "To see the info page for this movie, click <a href=\"./show_mov_info.php?movie_id="
			. $movie_id . "\">here</a>.<br/>";
	}
	else
		echo "fail.";
		
	mysql_close($link);
}
?>

</body>
</html>

