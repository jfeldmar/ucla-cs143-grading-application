<?php include 'header.php' ?>

<p>Designed by Seung-Hyo Choi for CS143, Database Systems at UCLA</p>