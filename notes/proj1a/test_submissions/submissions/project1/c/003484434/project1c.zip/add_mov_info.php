<?php include './header.php'; ?>

<h3>Add Movie information</h3>
<form action="./add_mov_info.php" method="GET">
<table width="500">
<tr>
	<td class="form_label">Title</td>
	<td>
		<input type="text" name="title" maxlength="20">
	</td>
</tr>

<tr>
	<td class="form_label">Company</td>
	<td>
		<input type="text" name="company" maxlength="50">
	</td>
</tr>

<tr>
	<td class="form_label">Year</td>
	<td>
		<input type="text" name="year" maxlength="4">
	</td>
</tr>

<tr>
	<td class="form_label">Director</td>
	<td>
		<select name="did">
			<?php
				$link = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143", $link);
				$query="select first, last, id, dob from Director group by first";
				$rs = mysql_query($query, $link);
				
				while($row = mysql_fetch_row($rs))
				{
					echo "<option value=\"" . $row[2] . "\">";
					echo $row[0] . " " . $row[1] . " (Birth: "
						. $row[3] . ")</option>\n";
				}
				echo "</select>"
			?>
		</select>
	</td>
</tr>

<tr>
	<td class="form_label">MPAA Rating</td>
	<td>
		<select name="mpaarating">
			<option value="G">G</option>
			<option value="PG">PG</option>
			<option value="PG-13">PG-13</option>
			<option value="R">R</option>
			<option value="NC-17">NC-17</option>
		</select>
	</td>
</tr>

<tr>
	<td class="form_label" valign="top">Genre</td>
	<td>
		<table width="300">
			<?php
				$link = mysql_connect("localhost", "cs143", "");
				mysql_select_db("CS143", $link);
				$query="select distinct genre from MovieGenre";
				$rs = mysql_query($query, $link);
				$row_size = mysql_num_rows($rs);
				
				for($i = 0; $i < $row_size && $row = mysql_fetch_row($rs); $i++)
				{
					if($i % 3 == 0)
						echo "<tr>";
						
					echo "<td width=\"50\"><input type=\"checkbox\" name=\"genre[]" 
						. "\" value=\"" . $row[0] . "\">"
						. $row[0] . "</input></td>\n";
						
					if(($i+1) % 3 == 0)
						echo "</tr>";
				}
			?>
		</table>
	</td>
</tr>

<tr>
	<td class="form_label"></td>
	<td>
		<br/>
		<input type="submit" value="Submit Query"/>
	</td>
</tr>
</table>
</form>

<?php
eval("\$title = \$_GET[\"title\"];");
eval("\$company = \$_GET[\"company\"];");
eval("\$year = \$_GET[\"year\"];");
eval("\$did = \$_GET[\"did\"];");
eval("\$mpaarating = \$_GET[\"mpaarating\"];");

if($title != "")
{
	$link = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $link);

	$inp_genre = $_GET['genre'];
	$movie_id = "select id from MaxMovieID";
	$movie_id = mysql_query($movie_id, $link);
	$movie_id = mysql_fetch_row($movie_id);
	
	$inp_mov = "insert into Movie values('" . $movie_id[0]. "','" 
		. $title . 	"','" . $year . "','" . $mpaarating . "','"
		. $company . "')";
	$rs = mysql_query($inp_mov, $link);
	
	for($i = 0; $i < count($inp_genre); $i++)
	{
		$genre = "insert into MovieGenre values(" 
			. $movie_id[0] . ", '" . $inp_genre[$i] . "')";
		$rs = mysql_query($genre, $link);
	}
	
	if($rs)
	{
		$ins_mov_id = "update MaxMovieID set id=id+1";
		$ins_mov_id = mysql_query($ins_mov_id, $link);
		echo "\"" . $title . "\" successfully added as a Movie!<br/>";
		echo "To see the info page for this movie, click <a href=\"./show_mov_info.php?movie_id="
			. $movie_id[0] . "\">here</a>.<br/>";
	}

	$inp_did = "insert into MovieDirector values("
		. $movie_id[0] . ", " . $did . ")";
	$inp_did = mysql_query($inp_did, $link);
	mysql_close($link);
}
?>

</body>
</html>

