<html>
	<html>
	<head>
		<title>add actor / director</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
	<body>
	Add new comment: <br/>
	<form action="./addComment.php" method="GET">			
	<?php

	 print('Movie:	<select name="mid">');
 		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
  	
  	$query = 'SELECT title, year , id FROM Movie ORDER BY title';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"" .$row[2] . "\">" . $row[0] . "(" . $row[1] . ")</option>\n");
 		}	
	?>					
	</select>
	<br/>
	Your Name:	<input type="text" name="name" value="" maxlength="20"><br/>

	Rating:	<select name="rating">
		<option value="5"> 5 </option>
		<option value="4"> 4 </option>
		<option value="3"> 3 </option>
		<option value="2"> 2 </option>
		<option value="1"> 1 </option>
	</select>
	<br/>
	Comments: <br/>
	<textarea name="comment" cols="50" rows="10"></textarea>
	<br/>
	<input type="submit" value="Rate it!!"/>
	</form>
	<hr/>		
	
<?php
		if(!$_GET["mid"] or !$_GET["name"] or !$_GET["rating"] or !$_GET["comment"])
  	{
  		mysql_close($db_connection);
  		if($_GET["rating"])
  	 		die("Please add a name, rating and comment.");
  	 	else
  	 		die("");
  	}	
  	$name = $_GET["name"];
  	$mid = $_GET["mid"];
  	$rating = $_GET["rating"];
  	$comment = $_GET["comment"];
  	
  	if(strlen($comment) > 500)
  	{
   		mysql_close($db_connection);
   		die("Error: Comments need to be less than 500 characters!<br>"); 		 		
  	}  	
  	$comment = mysql_real_escape_string($comment);
  	$name = mysql_real_escape_string($name); 
  	 			
  	$query = "INSERT INTO Review(name, time, mid, rating, comment) VALUES ('$name',NOW(),'$mid','$rating','$comment')";
	  	 	
	 	$rs = mysql_query($query, $db_connection);
	 	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}	
		else
			print("Comment successfully addded to the database.");  			
  	mysql_close($db_connection );
  	?>

	</body>
</html>