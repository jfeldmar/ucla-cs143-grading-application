<html>
	<html>
	<head>
		<title>add new movie</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
	<body>
				Add new movie: <br/>

		<form action="./addMovieInfo.php" method="GET">			
			Title : <input type="text" name="title" maxlength="20"><br/>
			Company: <input type="text" name="company" maxlength="50"><br/>
			Year (yyyy): <input type="text" name="year" maxlength="4"><br/>	<!-- Todo: validation-->	
			Director : <select name="did">
		
		<?php
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
	  	  	
  	$query = 'SELECT first, last, id, dob FROM Director ORDER BY last';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"$row[2]\">$row[0] $row[1] ($row[3])</option>\n");
 		}	
  	mysql_close($db_connection );
		?>	
		</select>
		<br/>		
		MPAA Rating : <select name="mpaarating">
			<option value="G">G</option>
			<option value="NC-17">NC-17</option>
			<option value="PG">PG</option>
			<option value="PG-13">PG-13</option>
			<option value="R">R</option>
			<option value="none">none</option>
		</select>
		<br/>
		Genre : 
		<input type="checkbox" name="genre_Action" value="Action">Action</input>
		<input type="checkbox" name="genre_Adult" value="Adult">Adult</input>
		<input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input>

		<input type="checkbox" name="genre_Animation" value="Animation">Animation</input>	
		<input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input>
		<input type="checkbox" name="genre_Crime" value="Crime">Crime</input>
		<input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input>
		<input type="checkbox" name="genre_Drama" value="Drama">Drama</input>
		<input type="checkbox" name="genre_Family" value="Family">Family</input>
		<input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input>
		<input type="checkbox" name="genre_Horror" value="Horror">Horror</input>
		<input type="checkbox" name="genre_Musical" value="Musical">Musical</input>

		<input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input>
		<input type="checkbox" name="genre_Romance" value="Romance">Romance</input>
		<input type="checkbox" name="genre_Sci-Fi" value="Sci-Fi">Sci-Fi</input>
		<input type="checkbox" name="genre_Short" value="Short">Short</input>
		<input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input>
		<input type="checkbox" name="genre_War" value="War">War</input>
		<input type="checkbox" name="genre_Western" value="Western">Western</input><br/>
		<input type="submit" value="Add it!!"/>
	</form>
	<hr/>	
	
	<?php
	if($_GET["title"] and $_GET["did"])
	{
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
	 	
	 	$title = $_GET["title"];
	 	$company = $_GET["company"];
		$director = $_GET["did"];
		$year = $_GET["year"];
		$rating = $_GET["mpaarating"];
		
		$title = mysql_real_escape_string($title);
		$company = mysql_real_escape_string($company);
		
		if($year and !preg_match("`\d\d\d\d`",$year))
		{
				mysql_close($db_connection);
   			die('Invalid Year!<br>');
		}
		
		$query = "SELECT id FROM MaxMovieID";
		$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		
		$id = mysql_fetch_array($rs);
		$id = $id[0]+1;
		
		$query = "INSERT INTO Movie (id, title, year, rating, company) VALUES ('$id','$title','$year','$rating','$company')";
	  	 	
	 	$rs = mysql_query($query, $db_connection);
	 	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}	
		
		if($_GET["genre_Action"])
		{
			$genre = $_GET["genre_Action"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Adult"])
		{
			$genre = $_GET["genre_Adult"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Adventure"])
		{
			$genre = $_GET["genre_Adventure"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Animation"])
		{
			$genre = $_GET["genre_Animation"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Comedy"])
		{
			$genre = $_GET["genre_Comedy"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Crime"])
		{
			$genre = $_GET["genre_Crime"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Documentary"])
		{
			$genre = $_GET["genre_Documentary"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Drama"])
		{
			$genre = $_GET["genre_Drama"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Family"])
		{
			$genre = $_GET["genre_Family"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Fantasy"])
		{
			$genre = $_GET["genre_Fantasy"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Horror"])
		{
			$genre = $_GET["genre_Horror"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Musical"])
		{
			$genre = $_GET["genre_Musical"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Mystery"])
		{
			$genre = $_GET["genre_Mystery"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		if($_GET["genre_Romance"])
		{
			$genre = $_GET["genre_Romance"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Sci-Fi"])
		{
			$genre = $_GET["genre_Sci-Fi"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Short"])
		{
			$genre = $_GET["genre_Short"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Thriller"])
		{
			$genre = $_GET["genre_Thriller"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_War"])
		{
			$genre = $_GET["genre_War"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		} 
		if($_GET["genre_Western"])
		{
			$genre = $_GET["genre_Western"];
			$query = "INSERT INTO MovieGenre(mid, genre) VALUES ('$id','$genre')";	  	 	
	 		$rs = mysql_query($query, $db_connection);
	 		if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
		}
		
		$query = "UPDATE MaxMovieID SET id = '$id'";
		$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}		
		
		print("$title added to the database<p>");
		
		mysql_close($db_connection );
	}
	else
		Print("add Title or Director!<br>");
	
	?>					
		
	</body>
</html>
