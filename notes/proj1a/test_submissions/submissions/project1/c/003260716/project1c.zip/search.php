<html>
	<html>
	<head>
		<title>Search Actor / Movie</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
<table>
<tr>
	<?php
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
  	if($_GET["keyword"])
		{	
			$get = $_GET["keyword"];
			$get =  mysql_real_escape_string($get);
			
			$query = 'SELECT first, last, dob, id FROM Actor WHERE last LIKE \'%'. $get . '%\' OR first LIKE \'%'. $get . '%\'';
			$query2 = 'SELECT title, id FROM Movie WHERE title LIKE \'%'. $get . '%\'';
						
			echo "<td VALIGN=TOP><h3>Actors:</h3>\n";
				
			$rs = mysql_query($query, $db_connection);
			if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}
	
			$numfields = mysql_num_fields($rs);
			$numrows = mysql_num_rows($rs);
			echo "Actors found: " . $numrows ."<p/>";
			if ( $numrows > 0)
			{
				while($row = mysql_fetch_row($rs)) 
				{ 
					print("<a href=showActorInfo.php?aid=$row[3]>$row[0] $row[1] ($row[2])</a><br>\n");		
				}
				print "</td><br/>";
			}
			echo "<td VALIGN=TOP>&nbsp;</td>";
			$rs2 = mysql_query($query2, $db_connection);
			if (!$rs2)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}
	
			print "<td VALIGN=TOP><h3>Movies:</h3>\n";
			$numfields = mysql_num_fields($rs2);
			$numrows = mysql_num_rows($rs2);
			echo "Movies found: " . $numrows ."<p/>";
			if ( $numrows > 0)
			{
				while($row = mysql_fetch_row($rs2)) 
				{
						print("<a href=showMovieInfo.php?mid=$row[1]>$row[0]</a><br>\n");	
				}
				print("<p></td><br/>");
			}	
		}
  		
  		mysql_close($db_connection );
		?>
			</table>
			</body>
</html>
