<html>
	<html>
	<head>
		<title>Movie Information</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
	<body>
				
	<?php
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
	  	
  	if($_GET["mid"])
		{
			$mid = $_GET["mid"];
			$mid = mysql_real_escape_string($mid);
  	  $query = 'SELECT * FROM Movie WHERE Movie.id='. $mid;   
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			
			if($row = mysql_fetch_row($rs))
			{
				print("Movie: ". $row[1] . "<br/>");
				print("Year: ". $row[2] . "<br/>");
				print("Rating: ". $row[3] . "<br/>");	
				print("Company: ". $row[4] . "<br/>");				
 			}			
 			else 
 				print("The Movie you entered is unavailable.<br>\n");		
 				
 			#directors
   	  $query = 'SELECT first, last FROM Director,Movie,MovieDirector WHERE Director.id = MovieDirector.did AND Movie.id ='. $mid .' AND MovieDirector.mid ='.$mid;   
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			print("Director: ");			
			while($row = mysql_fetch_row($rs))
			{
				print($row[0] . " " . $row[1] . " " );	
 			}	 
 			print("<br/>");
  	
  	  #genre
   	  $query = 'SELECT genre FROM MovieGenre WHERE MovieGenre.mid='. $mid;   
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			print("Genre: ");			
			while($row = mysql_fetch_row($rs))
			{
				print($row[0] . " ");	
 			}	 	
 			
 			#Actors
 		  $query = 'SELECT first, last, role, Actor.id FROM Actor,Movie,MovieActor WHERE Actor.id = MovieActor.aid AND Movie.id = '. $mid . ' AND MovieActor.mid ='. $mid; 
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			print("<p/>Actors:<br/>");			
			while($row = mysql_fetch_row($rs))
			{
				print("<a href=showActorInfo.php?aid=". $row[3] . ">" . $row[0] . " " . $row[1] . "</a>" ." as \"". $row[2] ."\"<br>");			
 			}	
 			
			#Comments
 		  $query = "SELECT name,time,rating, comment FROM Review WHERE mid='$mid'"; 
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			print("<p/>Comments:<br/>");			
			while($row = mysql_fetch_row($rs))
			{
				print("$row[0] said at $row[1]:<br><b>Rating:</b> $row[2] STARS<br><b>Comments:</b> $row[3]<p>");			
 			}	
 
 			print("Add your own review <a href=./addComment.php?mid=$mid>here.</a>");
 			print("<hr>\n");
  	}
	
		print("<form action=\"./showMovieInfo.php\" method=\"GET\">Select Movie: <select name=\"mid\">");
	  	
  	$query = 'SELECT title, year , id FROM Movie ORDER BY title';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"" .$row[2] . "\">" . $row[0] . "(" . $row[1] . ")</option>\n");
 		}
 		
  		mysql_close($db_connection );
		?>	
				</select>
			<br/>
			<input type="submit" value="Go!"/>
		</form>
			</body>
</html>		
