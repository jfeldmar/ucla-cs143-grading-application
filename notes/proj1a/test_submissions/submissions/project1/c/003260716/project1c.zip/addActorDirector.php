<html>
	<html>
	<head>
		<title>add actor / director</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>
	<body>
		Add new actor/director: <br/>

		<form action="./addActorDirector.php" method="GET">
			Identity:	<input type="radio" name="identity" value="Actor" checked="true">Actor
						<input type="radio" name="identity" value="Director">Director<br/>
			<hr/>
			First Name:	<input type="text" name="first" maxlength="20"><br/>
			Last Name:	<input type="text" name="last" maxlength="20"><br/>
			Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
						<input type="radio" name="sex" value="Female">Female<br/>

						
			Date of Birth: (yyyy-mm-dd)	<input type="text" name="dob"><br/>
			Date of Death: (yyyy-mm-dd) <input type="text" name="dod"> (leave blank if alive now)<br/>
			<input type="submit" value="add it!!"/>
		</form>
		<hr/>
	<?php
	
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
	 	
	 	$identity = $_GET["identity"];
	 	$first = $_GET["first"];
		$last = $_GET["last"];
		$sex = $_GET["sex"];
		$dob = $_GET["dob"];
		$dod = $_GET["dod"];
		
		if(!$identity)
		{
			mysql_close($db_connection);
			die();
		}
		
		$first = mysql_real_escape_string($first);
		$last = mysql_real_escape_string($last);
		
		$query = "SELECT id FROM MaxPersonID";
		$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		
		if(!preg_match("`\d\d\d\d\-\d\d\-\d\d`",$dob))
		{
				mysql_close($db_connection);
   			die('Invalid Date of Birth<br>');
		}
		if($dod and !preg_match("`\d\d\d\d\-\d\d\-\d\d`",$dob))
		{
				mysql_close($db_connection);
   			die('Invalid Date of Death<br>');
		}
		
		$id = mysql_fetch_array($rs);
		$id = $id[0]+1;
	
		if ($identity == 'Actor')
		{
			if($dod)
				$query = "INSERT INTO Actor (id, last, first, sex, dob, dod) VALUES ('$id','$last','$first','$sex','$dob','$dod')";
			else
				$query = "INSERT INTO Actor (id, last, first, sex, dob) VALUES ('$id','$last','$first','$sex','$dob')";  
	 	}
	 	else
	 	{
	 		if($dod)
	 			$query = "INSERT INTO Director (id, last, first, dob, dod) VALUES ('$id','$last','$first','$dob','$dod')";
	 		else
	 			$query = "INSERT INTO Director (id, last, first, dob) VALUES ('$id','$last','$first','$dob')";
	 	}
	 	
	 	$rs = mysql_query($query, $db_connection);
	 	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
	 	 	
	 	$query = "UPDATE MaxPersonID SET id = '$id'";
		$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		} 			
		 	print("$identity $first $last added to the database.<p>");
		
		mysql_close($db_connection );
	
	?>				
	</body>
</html>