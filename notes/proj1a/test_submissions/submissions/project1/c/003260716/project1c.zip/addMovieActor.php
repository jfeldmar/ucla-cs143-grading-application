<html>
	<html>
	<head>
		<title>add actor's role in a movie</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
	<body>
				Add new actor in a movie: <br/>

		<form action="./addMovieActor.php" method="GET">
			Movie : <select name="mid">
	<?php
 		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
  	
  	$query = 'SELECT title, year , id FROM Movie ORDER BY title';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"" .$row[2] . "\">" . $row[0] . "(" . $row[1] . ")</option>\n");
 		}	
	?>					
	</select>
	<br/>		
	Actor : <select name="aid">
	<?php
	
	  $query = 'SELECT id, first, last ,dob FROM Actor ORDER BY first,last';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"" .$row[0] . "\">" . $row[1] . " " . $row[2] ." (" . $row[3] . ")</option>\n");
 		}	
  
	?>	
	</select>
	<br/>	
	Role: <input type="text" name="role" maxlength="50">
	<br/>
			<input type="submit" value="Add it!!"/>
		</form>
		<hr/>
	<?php		
		if(!$_GET["role"] or  !$_GET["mid"] or !$_GET["aid"])
  	{
  		mysql_close($db_connection);
   		die("Please add a role.");
  	}	
  	$aid = $_GET["aid"];
  	$mid = $_GET["mid"];

  	$role = $_GET["role"];
  	$role = mysql_real_escape_string($role);
  	 			
  	$query = "INSERT INTO MovieActor(mid, aid, role) VALUES ('$mid','$aid','$role')";
	  	 	
	 	$rs = mysql_query($query, $db_connection);
	 	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}	
		else
			print("$role successfully addded to the database.");  			
  	mysql_close($db_connection );
  	?>
	</body>
</html>
