<html>
	<html>
	<head>
		<title>Movie Information</title>
		<style type="text/css">
		@import url(cs143style.css);
		</style>
	</head>	
	<body>
				
	<?php
		$db_connection = mysql_connect("localhost","cs143","");
		if (!$db_connection)
		{
  		die('Could not connect: ' . mysql_error());
  	}
  	if (!mysql_select_db("CS143", $db_connection))
  	{
  		$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die('Could not select DB: ' . $errmsg);
  	}
	  	
  	if($_GET["aid"])
		{
			$aid = $_GET["aid"];
			$aid = mysql_real_escape_string($aid);
  	  $query = 'SELECT * FROM Actor WHERE id='. $aid;   
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			
			if($row = mysql_fetch_row($rs))
			{
				print("Name: ". $row[2] ." ". $row[1] . "<br/>");
				print("Sex: ". $row[3] . "<br/>");
				print("Date of Birth: ". $row[4] . "<br/>");	
				print("Date of Death: ". $row[5] . "<br/>");				
 			}			
 			else 
 				print("The Actor you entered is unavailable.\n");		
 				 			
 			#Movies
 		  $query = 'SELECT title, role,Movie.id FROM Actor,Movie,MovieActor WHERE Movie.id = MovieActor.mid AND Actor.id = '. $aid . ' AND MovieActor.aid ='. $aid; 
  		$rs = mysql_query($query, $db_connection);
  	 	if (!$rs)
			{
				$errmsg = mysql_error($db_connection);
				mysql_close($db_connection);
   			die($errmsg);
			}	
			print("<p/>Roles:<br/>");			
			while($row = mysql_fetch_row($rs))
			{
				print("\"" . $row[1] . "\" in <a href=showMovieInfo.php?mid=". $row[2] . ">". $row[0] ."</a><br>");				
 			}	   	
  	
  			print("<hr>\n");
  	}
	
		print("<form action=\"./showActorInfo.php\" method=\"GET\">\nSelect Actor : <select name=\"aid\">");
	  	
  	$query = 'SELECT id, first, last ,dob FROM Actor ORDER BY first,last';
  	$rs = mysql_query($query, $db_connection);
  	if (!$rs)
		{
			$errmsg = mysql_error($db_connection);
			mysql_close($db_connection);
   		die($errmsg);
		}
		while($row = mysql_fetch_row($rs)) 
		{		
			print("<option value=\"" .$row[0] . "\">" . $row[1] . " " . $row[2] ." (" . $row[3] . ")</option>\n");
 		}	
  		mysql_close($db_connection );
		?>	
				</select>
			<br/>
			<input type="submit" value="Go!"/>
		</form>
			</body>
</html>		