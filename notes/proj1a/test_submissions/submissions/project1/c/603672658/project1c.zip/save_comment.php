<?php

	$id = $_GET["id"];

        if (strlen($_GET["review"]) > 500) {
        	header("Location: movie_info.php?id=$id&error=4");
                exit(4);
        }


	///////////////////// Connecting to Database ////////////////////////////
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection) {
		header("Location: movie_info.php?id=$id&error=1");
                exit(1);
	}

	$db_select = mysql_select_db("CS143", $db_connection);
	if(!$db_select) {
		$errmsg = mysql_error($db_connection);
        	mysql_close($db_connection);
		header("Location: movie_info.php?id=$id&error=2&errmsg=$errmsg");
                exit(2);
	}
	/////////////////////////////////////////////////////////////////////////


	///// Inserting Reviews, Sequence: name, time, mid, rating, comment /////
	$sz_name = mysql_real_escape_string($_GET["name"], $db_connection);
	$sz_review = mysql_real_escape_string($_GET["review"], $db_connection);

	$query = sprintf("INSERT INTO Review VALUE('%s',NOW(),%d,%d,'%s')",
		  	  $sz_name, $id, $_GET["rating"], $sz_review);

	$rs = mysql_query($query, $db_connection);
	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		mysql_close($db_connection);
		header("Location: movie_info.php?id=$id&error=3&errmsg=$errmsg");
                exit(3);
	}
	/////////////////////////////////////////////////////////////////////////


	mysql_close($db_connection);	// Closing DB Connection

	header("Location: movie_info.php?id=$id");

?>
