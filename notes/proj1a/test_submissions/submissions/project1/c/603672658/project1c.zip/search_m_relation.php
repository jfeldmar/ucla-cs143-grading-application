<html>

<head>
  <title>My Movie Database</title>
</head>

<body>

        <?php
		$name = urlencode($_GET["name"]);
                $ad = $_GET["ad"];
                $key = $_GET["title"];

	        if (!$key)
	        	exit(0);

	        print "<b>Search Results for [$key]...</b><br><br>";


	        /////////////// Composing Regex for Search //////////////////////
	        $key = str_replace("*", "[[:alnum:]]*", $key);
	        $key_seg = explode(" ", $key);
	        $numOR = count($key_seg);

	        for ($i = 0; $i < $numOR; $i++) {
	        	$key_seg[$i] = explode("+", $key_seg[$i]);
	        }
	        /////////////////////////////////////////////////////////////////


	        //////////////// Connecting to Database /////////////////////////
	        $db_connection = mysql_connect("localhost", "cs143", "");
	        if(!$db_connection) {
	    		print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                print "<table border=0>";
                print "<TR>";


                //////// Forming Queries for Movie Titles with "keyword" ////////
                for ($i = 0; $i < $numOR; $i++) {

                	if ($i)
                        	$query = $query."UNION";

                        $sz_key = mysql_real_escape_string($key_seg[$i][0], $db_connection);
                        $query = sprintf($query.'(SELECT id, title, year, company
                        		 	  FROM Movie
                                          	  WHERE title REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                          	  $sz_key);

                        $numAND = count($key_seg[$i]);

                        for ($j = 1; $j < $numAND; $j++) {
                        	$sz_key = mysql_real_escape_string($key_seg[$i][$j], $db_connection);
                        	$query = sprintf($query.' AND title REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                		 $sz_key);
                        }

                        $query = $query.')';
                }
                /////////////////////////////////////////////////////////////////


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    		  	print "Query failed: $errmsg<br />";
   		  	exit(3);
               	}
                /////////////////////////////////////////////////////////////////


                ////////// Constructing List of Results with Hyperlinks /////////
                print "<TD valign=top>";
                print "<b>Results in Movie Database...</b><br>";

                while($row = mysql_fetch_row($rs)) {
                	$title = urlencode($row[1]);
                        $links = "$row[1] ($row[2])";

                        print "<a href = \"input_relation.php?name=$name&title=$title&ad=$ad\" target=\"input\">$links</a>";
                        print "<i> by \"$row[3]\"</i><br>";
                }

                print "<br>";
                /////////////////////////////////////////////////////////////////


                print "</table>";

                mysql_close($db_connection);	// Closing DB Connection
	?>

</body>

</html>
