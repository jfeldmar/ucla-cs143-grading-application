<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>

        <?php
        	$id = $_GET["id"];
		$error = $_GET["error"];
                $errmsg = $_GET["errmsg"];

                switch ($error) {
                	case 1:
                        	print "<i><span style=\"background-color:yellow\">";
                                print "DB connection failed while saving review</span></i><br><br>";
                                break;
                        case 2:
                                print "<i><span style=\"background-color:yellow\">";
                                print "DB selection failed while saving review: $errmsg</span></i><br><br>";
                                break;
                        case 3:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Query failed while saving review: $errmsg</span></i><br><br>";
                                break;
                        case 4:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Exceed length limitation: Max 500 characters</span></i><br><br>";
                                break;
                }


        	//////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                // Querying "Movie" and "MovieGenre" for Movie Info with id
                // Sequence: title, year, rating, company, genre
		$query = sprintf("SELECT title, year, rating, company, genre
                         	  FROM Movie M, MovieGenre MG
                                  WHERE M.id = MG.mid AND id = %s",
                                  $id);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }

                $row = mysql_fetch_row($rs);
                /////////////////////////////////////////////////////////////////


                /////////////////// Print Movie Info ////////////////////////////
                $title = urlencode("$row[0]");
                print "<br><a href = \"add_relation.php?title=$title\">[Add Relation]</a>";
                print "  <a href = \"#comment\">[Give Comment]</a><br><br>";

                print "<b>--- Movie Info ---</b><br>";
                print "Title: $row[0] ($row[1])<br>";
                print "Producer: $row[3]<br>";
                print "MPAA Rating: $row[2]<br>";
                print "Genre: $row[4]<br>";
                /////////////////////////////////////////////////////////////////


                // Querying "MovieDirector" and "Director" for Director Info of the Movie
                // Sequence: did, last, first, YEAR(dob), YEAR(dod)
		$query = sprintf("SELECT did, last, first, YEAR(dob), YEAR(dod)
                         	  FROM MovieDirector MD, Director D
                                  WHERE MD.did = D.id AND mid = %s",
                                  $id);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


                ////////////// Print Director Info of the Movie /////////////////
                print "Director: ";

                if ($row = mysql_fetch_row($rs)) {
                	print "<a href = \"director_info.php?id=$row[0]\">$row[2] $row[1] ($row[3]-$row[4])</a>";

                	while ($row = mysql_fetch_row($rs))
                		print ", <a href = \"director_info.php?id=$row[0]\">$row[2] $row[1] ($row[3]-$row[4])</a>";
                }

                print "<br><br>";
                /////////////////////////////////////////////////////////////////


                // Querying "MovieActor", "Actor" for Actor Roles with mid
                // Sequence: aid, role, last, first
		$query = sprintf("SELECT aid, role, last, first
                	          FROM MovieActor MA, Actor A
                                  WHERE MA.aid = A.id AND mid = %s",
                                  $id);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


                ///////////// Print Actor's Movie Role Info /////////////////////
                print "<b>--- Actor/Actress In This Movie ---</b><br>";

                while($row = mysql_fetch_row($rs)) {
                        print "<a href = \"actor_info.php?id=$row[0]\">$row[3] $row[2]</a>";
                        print " act as \"$row[1]\"<br>";
                }

                print "<br>";
                /////////////////////////////////////////////////////////////////


        	$query = sprintf("SELECT COUNT(*), AVG(rating)
                		  FROM Review
                                  WHERE mid = %s",
                                  $id);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }

                $row = mysql_fetch_row($rs);
                /////////////////////////////////////////////////////////////////


                ///////////////// Print General Statistics //////////////////////
                print "<b>--- User Reviews ---</b><br>";

                if ($row[0]) {
                	print "<b>Average Rating: <i>$row[1]</i>, by <i>$row[0]</i> review(s).</b><br><br>";
                }
                else {
                	print "Sorry, no reviews for this movie...";
                        print " <i><span style=\"color:red\">Add Your Reviews Now!!</span></i><br><br>";
                }
                /////////////////////////////////////////////////////////////////


                $query = sprintf("SELECT name, time, rating, comment
                		  FROM Review
                                  WHERE mid = %s",
                                  $id);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


                ///////////////////// Print User Reviews ////////////////////////
                while ($row = mysql_fetch_row($rs)) {
                	print "<i><span style=\"color:blue\">At $row[1], <span style=\"color:red\">$row[0]</span> rated";
                        print " <span style=\"color:red\">$row[2]</span> point(s) for this movie.</span></i><br>";
                        print "$row[3]<br><br>";
                }
                /////////////////////////////////////////////////////////////////


        	mysql_close($db_connection);	// Closing DB Connection
        ?>

        <a name="comment"><hr size=2 align="left" width=600 color="00a000"></a>

        <form action="save_comment.php" method="GET">
        	<?php print "<input type=\"hidden\" name=\"id\" value=$id />"; ?>

        	Your Name: <input type="text" name="name" value="Anonymous" size=15 maxlength=20 id="CS143" /><br>

                Your Rating: <SELECT NAME="rating">
			     <OPTION value=5 SELECTED>5 - Excellent
			     <OPTION value=4>4 - Good
			     <OPTION value=3>3 - OK~
			     <OPTION value=2>2 - Not Worth
			     <OPTION value=1>1 - Poor
			     </SELECT><br>

        	<textarea name="review" rows=7 cols=50></textarea><br>
                <i>(Max 500 characters)</i><br>

        	<input type="submit" style="WIDTH: 100;" value="Submit" />
                <input type="reset" style="WIDTH: 100;" value="Reset" />
        </form>

</body>
</html>
