<html>
<head>
  <title>My Movie Database</title>
</head>	
<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
        	<a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>
		
	<?php
	    function dateForm() {
			// Year Only
		  	print "<select name = \"year\">";
		  	$date = getdate();
		  	$year = $date['year'];
		  	
		  	$title = "yyyy";
	  		print "<option value =$title >$title</option>";
		  	for ($i = $year; $i > 1799; $i--)
		  		print "<option value =$i >$i</option>";
		  	print "</select>";
	    }  // end of dateForm function 
		
		function isValidName($n) {
			$regexp = "/^[a-zA-Z\s]*$/";
			return preg_match($regexp,$n);
		} // end of isValidName function
	    
	    $ft = $_GET["ft"];
	    $printTable = true; 
	    $e =  "00";   	    	    
	    $m[$e] = "";


            $db_connection = mysql_connect("localhost", "cs143", "");
	    if(!$db_connection) {
	    	$errmsg = mysql_error($db_connection);
	    	print "Connection failed: $errmsg<br />";
		exit(1);
	    }

	    $db_select = mysql_select_db("CS143", $db_connection);
	    if(!$db_select) {
	    	$errmsg = mysql_error($db_connection);
 		print "DB selection failed: $errmsg<br />";
		exit(2);
	    }


	    if ($ft == "false") {
	    	// check if inputs are valid	    	
			$m["00"] = $_POST["title"]." was successfully added. Thank you!!";
			$m["01"] = "The title of the movie is invalid";
			$m["02"] = "Choose the year of this movie";
			$m["04"] = "The company's name is invalid";

			if (!($_POST["title"]))						$e = "01"; else
			if ($_POST["year"] == "yyyy")				    	$e = "02"; else
			if (!($_POST["company"]))					$e = "04";

			if ($e == "00") { 
				$printTable = false; 
				////////////// Valid Information //////////////////////

		
                ////// Forming Queries for Actor Names Starting with <char> /////
				$query = sprintf("SELECT id FROM MaxMovieID");
	
                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if (!$rs) {
                	$errmsg = mysql_error($db_connection);
	    			print "Query failed: $errmsg<br />";
		   			exit(3);
	            }
	            
	            $row = mysql_fetch_row($rs);
	            
	            $newID = $row[0]+1;
	            
	            $query = sprintf("UPDATE MaxMovieID SET id = $newID");
                $rs = mysql_query($query, $db_connection);
                if (!$rs) {
                	$errmsg = mysql_error($db_connection);
	    			print "Query failed: $errmsg<br />";
		   			exit(3);
	            }

                    $sz_title = mysql_real_escape_string($_POST["title"], $db_connection);
                    $sz_company = mysql_real_escape_string($_POST["company"], $db_connection);

 	            $query = sprintf("INSERT INTO Movie VALUES($newID, '%s', %d, '%s', '%s')", 
	            				$sz_title, $_POST["year"], $_POST["rating"], $sz_company);
	            				
                $rs = mysql_query($query, $db_connection);
                
                if (!$rs) {
                 	$errmsg = mysql_error($db_connection);
	    		 	print "Query failed: $errmsg<br />";
		   		 	exit(3);
	            }
	            
 	            $query = sprintf("INSERT INTO MovieGenre VALUES($newID, '%s')", $_POST["genre"]);

                $rs = mysql_query($query, $db_connection);

                if (!$rs) {
                 	$errmsg = mysql_error($db_connection);
	    		 	print "Query failed: $errmsg<br />";
		   		 	exit(3);
	            }

                    if ($_POST["dir"]) {
                    	$query = sprintf("INSERT INTO MovieDirector VALUES($newID, '%s')", $_POST["dir"]);

                    	$rs = mysql_query($query, $db_connection);
                    	if (!$rs) {
                    		$errmsg = mysql_error($db_connection);
	    			print "Query failed: $errmsg<br />";
		   		exit(3);
	            	}
                    }

			}
	    }
	    
	    if ($printTable) {

                $query = "SELECT id, first, last, YEAR(dob), YEAR(dod) FROM Director";
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }

	    	// print a table 
	    	$firstTime = "false";
			print "<h2>Add New Movie <br></h2>";
			print "<form action=\"add_movie.php?ft=$firstTime\" method=\"POST\">";
			print "<table>";
		
			print "<tr>";
			print "<td align= \"right\">Title:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><input type=\"text\" name =\"title\" size = \"30\" maxlength = \"100\"/></td></tr>";
		
			print "<tr>";
			print "<td align= \"right\">Year:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\">";dateForm();print "</td></tr>";
		
			print "<tr>";
			print "<td align= \"right\">Rating:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><select name=\"rating\">";
                        print "<option>G";
                        print "<option>PG";
                        print "<option>PG-13";
                        print "<option>R";
                        print "<option>NC-17";
                        print "</select></td></tr>";


			print "<tr>";
			print "<td align= \"right\">Company:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><input type=\"text\" name =\"company\" size = \"30\" maxlength = \"50\"/></td></tr>";


			print "<tr>";
			print "<td align= \"right\">Genre:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><select name=\"genre\">";
                        print "<option>Action";
                        print "<option>Adult";
                        print "<option>Adventure";
                        print "<option>Animation";
                        print "<option>Comedy";
                        print "<option>Crime";
                        print "<option>Documentary";
                        print "<option>Drama";
                        print "<option>Family";
                        print "<option>Fantasy";
                        print "<option>Horror";
                        print "<option>Musical";
                        print "<option>Mystery";
                        print "<option>Romance";
                        print "<option>Sci-Fi";
                        print "<option>Short";
                        print "<option>Thriller";
                        print "<option>War";
                        print "<option>Western";
                        print "</select></td></tr>";


			print "<tr>";
			print "<td align= \"right\">Director:&nbsp;&nbsp;&nbsp</td>";
            		print "<td align= \"left\"><select name=\"dir\">";
                        print "<option value=0 selected>-----";

                        while ($row = mysql_fetch_row($rs)) {
                        	print "<option value=$row[0]>$row[1] $row[2] ($row[3]-$row[4])";
                        }

			print "</select>&nbsp;&nbsp;(Optional)</td></tr>";
			print "</table>";
				
			print "<table>";	
			print "<tr><td>";	
			print "<input type=\"submit\" name = \"add\" value = \"Add\"/></form></td>";
		
			print "<td>";
			print "<form action=\"browse_movie.php\" method=\"POST\">";
			print "<input type=\"submit\" name = \"cancel\" value = \"Cancel\"/></form></td></tr>";
			print "</table>";
	    }
	    
	    if ($ft == "false") {
	    	// print a message
	    	print "<br>";
	    	$message = $m[$e];
	    	if ($e != "00") 
	    		print "<font color=\"red\"> $message </font>";
	    	else 
		    	print $message;
	    }


            ////////////////// Closing DB Connection ///////////////////////
	    mysql_close($db_connection);
    ?>
	
</body>
</html>
