<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
        	<a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>

	<?php

        ////////// Aphabetical Browse List for Actor or Director ////////////////
        ////////// Depending on "ad", $ad = Actor/Director //////////////////////
        $ad = $_GET["ad"];
        $ft = "true";

	print "<h4>Add <a href = \"add_actor.php?ad=$ad&ft=$ft\">New $ad</a><br>";
	print "<dd><i>or</i></dd><br>";
	print "Browse ".$ad."s by<br><br>";

	print "<dd>First Name:
			<a href = \"browse_actor.php?ad=$ad&first=A&last=\"> A</a>
			<a href = \"browse_actor.php?ad=$ad&first=B&last=\"> B</a>
			<a href = \"browse_actor.php?ad=$ad&first=C&last=\"> C</a>
			<a href = \"browse_actor.php?ad=$ad&first=D&last=\"> D</a>
			<a href = \"browse_actor.php?ad=$ad&first=E&last=\"> E</a>
			<a href = \"browse_actor.php?ad=$ad&first=F&last=\"> F</a>
			<a href = \"browse_actor.php?ad=$ad&first=G&last=\"> G</a>
			<a href = \"browse_actor.php?ad=$ad&first=H&last=\"> H</a>
			<a href = \"browse_actor.php?ad=$ad&first=I&last=\"> I</a>
			<a href = \"browse_actor.php?ad=$ad&first=J&last=\"> J</a>
			<a href = \"browse_actor.php?ad=$ad&first=K&last=\"> K</a>
			<a href = \"browse_actor.php?ad=$ad&first=L&last=\"> L</a>
			<a href = \"browse_actor.php?ad=$ad&first=M&last=\"> M</a>
			<a href = \"browse_actor.php?ad=$ad&first=N&last=\"> N</a>
			<a href = \"browse_actor.php?ad=$ad&first=O&last=\"> O</a>
			<a href = \"browse_actor.php?ad=$ad&first=P&last=\"> P</a>
			<a href = \"browse_actor.php?ad=$ad&first=Q&last=\"> Q</a>
			<a href = \"browse_actor.php?ad=$ad&first=R&last=\"> R</a>
			<a href = \"browse_actor.php?ad=$ad&first=S&last=\"> S</a>
			<a href = \"browse_actor.php?ad=$ad&first=T&last=\"> T</a>
			<a href = \"browse_actor.php?ad=$ad&first=U&last=\"> U</a>
			<a href = \"browse_actor.php?ad=$ad&first=V&last=\"> V</a>
			<a href = \"browse_actor.php?ad=$ad&first=W&last=\"> W</a>
			<a href = \"browse_actor.php?ad=$ad&first=X&last=\"> X</a>
			<a href = \"browse_actor.php?ad=$ad&first=Y&last=\"> Y</a>
			<a href = \"browse_actor.php?ad=$ad&first=Z&last=\"> Z</a></dd><br><br>

		<dd>Last Name:
			<a href = \"browse_actor.php?ad=$ad&first=&last=A\"> A</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=B\"> B</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=C\"> C</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=D\"> D</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=E\"> E</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=F\"> F</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=G\"> G</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=H\"> H</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=I\"> I</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=J\"> J</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=K\"> K</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=L\"> L</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=M\"> M</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=N\"> N</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=O\"> O</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=P\"> P</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=Q\"> Q</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=R\"> R</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=S\"> S</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=T\"> T</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=U\"> U</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=V\"> V</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=W\"> W</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=X\"> X</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=Y\"> Y</a>
			<a href = \"browse_actor.php?ad=$ad&first=&last=Z\"> Z</a><br>
		</dd></h4>";
        /////////////////////////////////////////////////////////////////////////

        ?>



        <?php
        	//////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed: $errmsg<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                	mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                ////// Forming Queries for Actor Names Starting with <char> /////
        	if ($_GET["first"]) {
			$query = sprintf("SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		  FROM $ad
                                          WHERE first LIKE '%s%%'
                                          ORDER BY first",
                                          $_GET["first"]);
                }
                else if ($_GET["last"]) {
                	$query = sprintf("SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		  FROM $ad
                                          WHERE last LIKE '%s%%'
                                          ORDER BY last",
                                          $_GET["last"]);
                }
                else {
                	mysql_close($db_connection);
                	exit(0);
                }
                /////////////////////////////////////////////////////////////////


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


                ////////////// Constructing Table for Results ///////////////////
                /*
        	print "<table border=1>";
        	print "<TR>";

	        for($i = 0; $i < $numCol; ++$i) {
        		print "<TH align=center>".mysql_field_name($rs, $i);
	        }

        	while($row = mysql_fetch_row($rs)) {
                	print "<TR>";
        		for($i = 0; $i < $numCol; ++$i) {
                        	print "<TD align=center>".$row[$i];
                       	}
        	}

		print "</table>";
                */
                /////////////////////////////////////////////////////////////////


		////////// Constructing List of Results with Hyperlinks /////////
                while($row = mysql_fetch_row($rs)) {
                	$links = "$row[1] $row[2] ($row[3]-$row[4])";

                        if (!strcmp($ad, "Actor"))
                        	print "<a href = \"actor_info.php?id=$row[0]\">$links</a><br>";
                        else if (!strcmp($ad, "Director"))
                        	print "<a href = \"director_info.php?id=$row[0]\">$links</a><br>";
                }
                /////////////////////////////////////////////////////////////////


                mysql_close($db_connection);	// Closing DB Connection
        ?>

</body>
</html>
