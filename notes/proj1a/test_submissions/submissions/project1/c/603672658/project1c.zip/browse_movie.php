<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
        	<a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>
	
	<?php 
        $ft = "true";	
		print "<h4>Add <a href = \"add_movie.php?ft=$ft\">New Movie</a><br>";
	?>
	<dd><i>or</i></dd><br>
	Browse Movies by<br><br>
	<dd>
		Title:
			<a href = "browse_movie.php?title=A"> A</a>
			<a href = "browse_movie.php?title=B"> B</a>
			<a href = "browse_movie.php?title=C"> C</a>
			<a href = "browse_movie.php?title=D"> D</a>
			<a href = "browse_movie.php?title=E"> E</a>
			<a href = "browse_movie.php?title=F"> F</a>
			<a href = "browse_movie.php?title=G"> G</a>
			<a href = "browse_movie.php?title=H"> H</a>
			<a href = "browse_movie.php?title=I"> I</a>
			<a href = "browse_movie.php?title=J"> J</a>
			<a href = "browse_movie.php?title=K"> K</a>
			<a href = "browse_movie.php?title=L"> L</a>
			<a href = "browse_movie.php?title=M"> M</a>
			<a href = "browse_movie.php?title=N"> N</a>
			<a href = "browse_movie.php?title=O"> O</a>
			<a href = "browse_movie.php?title=P"> P</a>
			<a href = "browse_movie.php?title=Q"> Q</a>
			<a href = "browse_movie.php?title=R"> R</a>
			<a href = "browse_movie.php?title=S"> S</a>
			<a href = "browse_movie.php?title=T"> T</a>
			<a href = "browse_movie.php?title=U"> U</a>
			<a href = "browse_movie.php?title=V"> V</a>
			<a href = "browse_movie.php?title=W"> W</a>
			<a href = "browse_movie.php?title=X"> X</a>
			<a href = "browse_movie.php?title=Y"> Y</a>
			<a href = "browse_movie.php?title=Z"> Z</a><br><br>
	</dd></h4>

        <?php
        	//////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed: $errmsg<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                ///// Forming Queries for Movie Titles Starting with <char> /////
        	if ($_GET["title"]) {
			$query = sprintf("SELECT id, title, year, company
                        		  FROM Movie
                                          WHERE title LIKE '%s%%'
                                          ORDER BY title",
                                          $_GET["title"]);
                }
                else {
                	exit(0);
                }
                /////////////////////////////////////////////////////////////////


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


		////////// Constructing List of Results with Hyperlinks /////////
                while($row = mysql_fetch_row($rs)) {
                	$links = "$row[1] ($row[2])";

                        print "<a href = \"movie_info.php?id=$row[0]\">$links</a>";
                        print "<i> by $row[3]</i><br>";
                }
                /////////////////////////////////////////////////////////////////


                mysql_close($db_connection);	// Closing DB Connection
        ?>

</body>
</html>
