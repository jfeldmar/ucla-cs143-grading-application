<?php
	$sa = $_GET["sa"];
        $sm = $_GET["sm"];
        $ad = $_GET["people"];
        $name = $_GET["name"];
        $title = $_GET["title"];

        if ($sa) {
        	$name = urlencode($name);
                $title = urlencode($title);
		header("Location: search_a_relation.php?name=$name&title=$title&ad=$ad");
        }
        else if ($sm) {
        	$name = urlencode($name);
                $title = urlencode($title);
                header("Location: search_m_relation.php?name=$name&title=$title&$ad=$ad");
        }
        else {
        	$role = $_GET["role"];

                if (strlen($role) > 50) {
        		header("Location: relation_result.php?error=4");
                	exit(4);
        	}


		///////////////////// Connecting to Database ////////////////////////////
		$db_connection = mysql_connect("localhost", "cs143", "");
		if(!$db_connection) {
			header("Location: relation_result.php?error=1");
                	exit(1);
		}

		$db_select = mysql_select_db("CS143", $db_connection);
		if(!$db_select) {
			$errmsg = mysql_error($db_connection);
        		mysql_close($db_connection);
			header("Location: relation_result.php?error=2&errmsg=$errmsg");
                	exit(2);
		}
		/////////////////////////////////////////////////////////////////////////


                ///////////////// Query for Actor/Director //////////////////////////////
                $sz_name = mysql_real_escape_string($name, $db_connection);
                $query = "SELECT id FROM $ad WHERE CONCAT(first, \" \", last) = '$sz_name'";

                $rs = mysql_query($query, $db_connection);
		if(!$rs) {
			 $errmsg = mysql_error($db_connection);
			 mysql_close($db_connection);
			 header("Location: relation_result.php?error=3&errmsg=$errmsg");
                	 exit(3);
		}

                $row = mysql_fetch_row($rs);
                if (!$row) {
                        header("Location: relation_result.php?error=5");
                	exit(5);
                }

                $id = $row[0];
                /////////////////////////////////////////////////////////////////////////


                ///////////////// Query for Movie ///////////////////////////////////////
                $sz_title = mysql_real_escape_string($title, $db_connection);
                $query = "SELECT id FROM Movie WHERE title = '$sz_title'";

                $rs = mysql_query($query, $db_connection);
		if(!$rs) {
			 $errmsg = mysql_error($db_connection);
			 mysql_close($db_connection);
			 header("Location: relation_result.php?error=3&errmsg=$errmsg");
                	 exit(3);
		}

                $row = mysql_fetch_row($rs);
                if (!$row) {
                        header("Location: relation_result.php?error=6");
                	exit(6);
                }

                $mid = $row[0];
                /////////////////////////////////////////////////////////////////////////


                //// Inserting Relation, MovieActor Sequence: mid, aid, role ////////////
                ////                     MovieDirector Sequence: mid, did    ////////////
                $sz_role = mysql_real_escape_string($role, $db_connection);

                if (!strcmp($ad, "Actor"))
                	$query = sprintf("INSERT INTO MovieActor VALUE(%d, %d, '%s')",
                        		  $mid, $id, $sz_role);
                else
                	$query = sprintf("INSERT INTO MovieDirector VALUE(%d, %d)",
                        		  $mid, $id);

                $rs = mysql_query($query, $db_connection);
		if(!$rs) {
			 $errmsg = mysql_error($db_connection);
			 mysql_close($db_connection);
			 header("Location: relation_result.php?error=3&errmsg=$errmsg");
                	 exit(3);
		}
                /////////////////////////////////////////////////////////////////////////


                header("Location: relation_result.php?error=0");
        }
?>
