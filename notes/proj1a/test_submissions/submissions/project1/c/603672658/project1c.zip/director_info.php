<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
                <a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>

        <?php

        	//////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                // Querying "Actor" for Director Info with id
                // Sequence: id, last, first, dob, dod
		$query = sprintf("SELECT * FROM Director WHERE id = %s", $_GET["id"]);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }

                $row = mysql_fetch_row($rs);
                /////////////////////////////////////////////////////////////////


                /////////////////// Print Director Info /////////////////////////
                $name = urlencode("$row[2] $row[1]");
                print "<br><a href = \"add_relation.php?name=$name&ad=Director\">[Add Relation]</a><br><br>";

                print "<b>--- Director Info ---</b><br>";
                print "Name: $row[2] $row[1]<br>";
                print "Date of Birth: $row[3]<br>";

                if ($row[4])
                	print "Date of Death: $row[4]<br><br>";
              	else
                	print "Date of Death: Still Alive<br><br>";
                /////////////////////////////////////////////////////////////////


                // Querying "MovieDirector", "Movie" for Directed Movies with did
                // Sequence: mid, title, company
		$query = sprintf("SELECT mid, title, company
                	          FROM MovieDirector MD, Movie M
                                  WHERE MD.mid = M.id AND did = %s",
                                  $_GET["id"]);


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////


                ///////////// Print Info of Directed Movies /////////////////////
                print "<b>--- Directed ---</b><br>";
                while($row = mysql_fetch_row($rs)) {
                        print "<a href = \"movie_info.php?id=$row[0]\">$row[1]</a>";
                        print "<i> by \"$row[2]\"</i><br>";
                }
                /////////////////////////////////////////////////////////////////


                mysql_close($db_connection);	// Closing DB Connection
        ?>
</body>
</html>
