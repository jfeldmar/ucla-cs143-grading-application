<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
                <a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>

        <?php
        	/////////////// Checking Genuine Search "keyword" ///////////////
                $key = $_GET["keyword"];
		if (!$key)
                	exit(0);

                print "<b>Search Results for [$key]...</b><br><br>";
                /////////////////////////////////////////////////////////////////


                /////////////// Composing Regex for Search //////////////////////
                $key = str_replace("*", "[[:alnum:]]*", $key);
                $key_seg = explode(" ", $key);
                $numOR = count($key_seg);

                for ($i = 0; $i < $numOR; $i++) {
                	$key_seg[$i] = explode("+", $key_seg[$i]);
                }

                /*
                $regex = "[[:<:]]$key_seg[0][[:>:]]";

                for ($i = 1; $i < $numWords; $i++) {
                	$regex = "$regex|[[:<:]]$key_seg[$i][[:>:]]";
                }
                */

                //print "$regex<br>";
                /////////////////////////////////////////////////////////////////


        	//////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                print "<table border=0>";
                print "<TR>";


		// Actor
                if ($_GET["menu"] == 1 || $_GET["menu"] == 0) {

                	///////// Forming Queries for Actor Names with "keyword" ////////
                        for ($i = 0; $i < $numOR; $i++) {

                        	if ($i)
                                	$query = $query.'UNION';

                                $sz_key = mysql_real_escape_string($key_seg[$i][0], $db_connection);
                        	$query = sprintf($query.'(SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		 		  FROM Actor
                                          		  WHERE CONCAT(first, " ", last) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                          		  $sz_key);

                                $numAND = count($key_seg[$i]);

                                for ($j = 1; $j < $numAND; $j++) {
                                        $sz_key = mysql_real_escape_string($key_seg[$i][$j], $db_connection);
                                	$query = sprintf($query.' AND CONCAT(first, " ", last) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                                 	 $sz_key);
                                }

                                $query = $query.')';
                        }

                        /*
			$query = sprintf('SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		  FROM Actor
                                          WHERE first REGEXP \'%1$s\' OR
                                          	last REGEXP \'%1$s\'',
                                          $regex);
                        */
                	/////////////////////////////////////////////////////////////////


                	//////////////// Querying Database //////////////////////////////
                	$rs = mysql_query($query, $db_connection);
                	if(!$rs) {
                  		$errmsg = mysql_error($db_connection);
                                mysql_close($db_connection);
    		  		print "Query failed: $errmsg<br />";
   		  		exit(3);
               		}
                	/////////////////////////////////////////////////////////////////


                        ////////// Constructing List of Results with Hyperlinks /////////
                        print "<TD valign=top width=300>";
                        print "<b>Results in Actor Database...</b><br>";

                	while($row = mysql_fetch_row($rs)) {
                		$actor_links = "$row[1] $row[2] ($row[3]-$row[4])";

                        	print "<a href = \"actor_info.php?id=$row[0]\">$actor_links</a><br>";
                	}

                        print "<br>";
                	/////////////////////////////////////////////////////////////////

                        $query = '';	// Clearing $query
                }


                // Director
                if ($_GET["menu"] == 2 || $_GET["menu"] == 0) {

                	/////// Forming Queries for Director Names with "keyword" ///////
                        for ($i = 0; $i < $numOR; $i++) {

                        	if ($i)
                                	$query = $query.'UNION';

                                $sz_key = mysql_real_escape_string($key_seg[$i][0], $db_connection);
                        	$query = sprintf($query.'(SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		 		  FROM Director
                                          		  WHERE CONCAT(first, " ", last) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                          		  $sz_key);

                                $numAND = count($key_seg[$i]);

                                for ($j = 1; $j < $numAND; $j++) {
                                	$sz_key = mysql_real_escape_string($key_seg[$i][$j], $db_connection);
                                	$query = sprintf($query.' AND CONCAT(first, " ", last) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                                 	 $sz_key);
                                }

                                $query = $query.')';
                        }
                	/////////////////////////////////////////////////////////////////


                	//////////////// Querying Database //////////////////////////////
                	$rs = mysql_query($query, $db_connection);
                	if(!$rs) {
                  		$errmsg = mysql_error($db_connection);
                                mysql_close($db_connection);
    		  		print "Query failed: $errmsg<br />";
   		  		exit(3);
               		}
                	/////////////////////////////////////////////////////////////////


                        ////////// Constructing List of Results with Hyperlinks /////////
                        print "<TD valign=top width=300>";
                        print "<b>Results in Director Database...</b><br>";

                	while($row = mysql_fetch_row($rs)) {
                		$dir_links = "$row[1] $row[2] ($row[3]-$row[4])";

                        	print "<a href = \"director_info.php?id=$row[0]\">$dir_links</a><br>";
                	}

                        print "<br>";
                	/////////////////////////////////////////////////////////////////

                	$query = '';	// Clearing $query
                }


                // Movie
                if ($_GET["menu"] == 3 || $_GET["menu"] == 0) {

                	// Forming Queries for Movie "title" and "company" with "keyword"
                        for ($i = 0; $i < $numOR; $i++) {

                        	if ($i)
                                	$query = $query.'UNION';

                                $sz_key = mysql_real_escape_string($key_seg[$i][0], $db_connection);
                        	$query = sprintf($query.'(SELECT id, title, year, company
                        		 		  FROM Movie
                                          		  WHERE CONCAT(title, " ", company) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                          		  $sz_key);

                                $numAND = count($key_seg[$i]);

                                for ($j = 1; $j < $numAND; $j++) {
                                	$sz_key = mysql_real_escape_string($key_seg[$i][$j], $db_connection);
                                	$query = sprintf($query.' AND CONCAT(title, " ", company) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                                 	 $sz_key);
                                }

                                $query = $query.')';
                        }
                	/////////////////////////////////////////////////////////////////


                	//////////////// Querying Database //////////////////////////////
                	$rs = mysql_query($query, $db_connection);
                	if(!$rs) {
                  		$errmsg = mysql_error($db_connection);
                                mysql_close($db_connection);
    		  		print "Query failed: $errmsg<br />";
   		  		exit(3);
               		}
                	/////////////////////////////////////////////////////////////////


                        ////////// Constructing List of Results with Hyperlinks /////////
                        print "<TD valign=top>";
                        print "<b>Results in Movie Database...</b><br>";

                	while($row = mysql_fetch_row($rs)) {
                		$movie_links = "$row[1] ($row[2])";

                        	print "<a href = \"movie_info.php?id=$row[0]\">$movie_links</a>";
                                print "<i> by \"$row[3]\"</i><br>";
                	}

                        print "<br>";
                	/////////////////////////////////////////////////////////////////

                	$query = '';	// Clearing $query
                }


                print "</table>";

                mysql_close($db_connection);	// Closing DB Connection
        ?>

</body>
</html>
