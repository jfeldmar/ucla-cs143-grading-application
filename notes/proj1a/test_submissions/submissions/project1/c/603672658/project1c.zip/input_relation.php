<html>

<head>
  <title>My Movie Database</title>
</head>

<body>

	<?php
        	$ad = $_GET["ad"];
        	$name = $_GET["name"];
                $title = $_GET["title"];
        ?>

        <b><i><font size="4">Add Actor/Director/Movie Relation</font></b></i><br>

	<form action="save_relation.php" method="GET" target="search">

        	<table border=0><tr>

        	<?php	if (!strcmp($ad, "Director")) { ?>
			<td colspan=3><input type="radio" name="people" value="Actor">Actor
                	<input type="radio" name="people" value="Director" checked>Director<br>
                <?php	}
                	else {	?>
                        <td  colspan=3><input type="radio" name="people" value="Actor" checked>Actor
                	<input type="radio" name="people" value="Director">Director<br>
                <?php	}	?>

                <tr>
        	<?php
                	print "<td>Name:";
                	print "<td><input type=\"text\" name=\"name\" size=25 value=\"$name\" />";
                ?>
                <td><input type="submit" style="WIDTH: 45;" name="sa" value="Search" />

                <tr>
                <?php
                	print "<td>Movie:";
                        print "<td><input type=\"text\" name=\"title\" size=25 value=\"$title\" />";
                ?>
                <td><input type="submit" style="WIDTH: 45;" name="sm" value="Search" />

                <tr>
                <td>Role:
                <td><input type="text" name="role" size=25 maxlength=50 />
                <td><i>(actor only)</i>

                </table><br>

                <input type="submit" style="WIDTH: 60;" value="Submit" />
                <input type="reset" style="WIDTH: 60;" value="Reset" /><br>
        </form>

</body>

</html>
