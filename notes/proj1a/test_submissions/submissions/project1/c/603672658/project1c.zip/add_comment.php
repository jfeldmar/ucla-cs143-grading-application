<html>
<head>
  <title>My Movie Database</title>
</head>

<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>

        <br><br>

	<?php

                //////////////// Connecting to Database /////////////////////////
        	$db_connection = mysql_connect("localhost", "cs143", "");
        	if(!$db_connection) {
    			print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                $query = "SELECT id, title, year FROM Movie";


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    			print "Query failed: $errmsg<br />";
   			exit(3);
                }
                /////////////////////////////////////////////////////////////////

        ?>

        <b><i><font size="5">Add Your Comments Now!!</font></b></i><br>

	<form action="save_comment.php" method="GET">

        	<?php
                	print "Movie: ";
                        print "<SELECT NAME=\"id\">";

                        while($row = mysql_fetch_row($rs)) {
                        	print "<OPTION value=$row[0]>$row[1] ($row[2])";
                        }

                        print "</SELECT><br>";
                ?>

		Your Name: <input type="text" name="name" value="Anonymous" size=15 maxlength=20 id="CS143" /><br>

		Your Rating: <SELECT NAME="rating">
			     <OPTION value=5 SELECTED>5 - Excellent
		   	     <OPTION value=4>4 - Good
		     	     <OPTION value=3>3 - OK~
			     <OPTION value=2>2 - Not Worth
			     <OPTION value=1>1 - Poor
			     </SELECT><br>

		<textarea name="review" rows=10 cols=60></textarea><br>
                <i>(Max 500 characters)</i><br>

		<input type="submit" style="WIDTH: 100;" value="Submit" />
                <input type="reset" style="WIDTH: 100;" value="Reset" />
	</form>

        <?php
        	mysql_close($db_connection);	// Closing DB Connection
        ?>

</body>
</html>
