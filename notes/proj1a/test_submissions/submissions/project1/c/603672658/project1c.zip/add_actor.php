<html>
<head>
  <title>My Movie Database</title>
</head>	
<body>
	<br><br><br><br>
	<p align="center"><b><i>
		<font color="red"  size="40">My      </font>
		<font color="blue" size="40">Movie   </font>
		<font color="red"  size="40">Database</font>
	</b></i></p>

        <p align="center">
	<form action="search.php" method="GET" align="center">
		<input type="text" name="keyword" size="50"/>
                <select name="menu">
                <option value=0 selected>All
                <option value=1>Actor
                <option value=2>Director
                <option value=3>Movie
                </select>
		<br>
		<input type="submit" style="WIDTH: 125;" value="Search"/>
		<input type="submit" style="WIDTH: 125;" value="I'm Feeling Lucky"/>
	</form>
        </p>

	<p align="center">
		<a href = "search.php">Home</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Actor">Actors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_actor.php?ad=Director">Directors</a>&nbsp;&nbsp;&nbsp;
		<a href = "browse_movie.php">Movies</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_comment.php">Comment</a>&nbsp;&nbsp;&nbsp;
                <a href = "add_relation.php">Relation</a>
	</p>
		
	<?php
	    function dateForm($date) {
		  	// Month
		  	$d = $date."_mm";
		  	print "<select name = \"$d\">";
		  	
		  	$title = "mm";
	  		print "<option value =$title >$title</option>";
		  	for ($i = 1; $i <= 12; $i++) {
		  		if ($i < 10) $j = "0".strval($i);
		  		else         $j = strval($i); 
		  		print "<option value =$j >$j</option>";
		  	}
		  	print "</select>";
			
			// Day
			$d = $date."_dd";
		  	print "&nbsp;/&nbsp;&nbsp;";
		  	print "<select name = \"$d\">";
		  	
		  	$title = "dd";
	  		print "<option value =$title >$title</option>";
		  	for ($i = 1; $i <= 31; $i++) {
		  		if ($i < 10) $j = "0".strval($i);
		  		else         $j = strval($i); 
		  		print "<option value =$j >$j</option>";
		  	}
		  	print "</select>";
			
			// Year
			$d = $date."_yyyy";
		  	print "&nbsp;/&nbsp;&nbsp;";
		  	print "<select name = \"$d\">";
		  	$date = getdate();
		  	$year = $date['year'];
		  	
		  	$title = "yyyy";
	  		print "<option value =$title >$title</option>";
		  	for ($i = $year; $i > 1799; $i--)
		  		print "<option value =$i >$i</option>";
		  	print "</select>";
	    }  // end of dateForm function 

		function isLeap($y) {
			if ($y % 4 == 0) {
				if ($y % 100 == 0) {
					if ($y % 400 == 0)
						return true;
					else 
						return false;
				}
				else return true;
			}
			else return false;
		} // end of isLeap function
		
		function isValidDate($y, $m, $d) {
			if ($y == "yyyy" || $m == "mm" || $d == "dd")
				return false;
			else 
			
			if (($m == "04" || $m == "06" || $m == "09" || $m == "11") && ($d == 31))
				return false;
			else 
			
			if (($m == "02") && ($d > "29"))
				return false;
			else
			
			if (($m == "02") && ($d == "29") && (! isLeap($y)))
				return false;
			else 
				return true;
		} // end of isValidDate function 
		
		function isValidName($n) {
			$regexp = "/^[a-zA-Z\s]*$/";
			return preg_match($regexp,$n);
		} // end of isValidName function
	    
	    $ad = $_GET["ad"];	
	    $ft = $_GET["ft"];
	    $printTable = true; 
	    $e =  "00";   	    	    
	    $m[$e] = "";
	    
	    if ($ft == "false") {
	    	// check if inputs are valid	    	
			$m["00"] = $_POST["fname"]." ".$_POST["lname"]." was successfully added. Thank you!!";
			$m["01"] = "First name is invalid";
			$m["02"] = "Last name is invalid";
			$m["03"] = "Choose the sex of this person";
			$m["04"] = "Your choice of date of birth is invalid";
			$m["05"] = "Your choice of date of death is invalid";
			$m["06"] = "Date of birth can't be greater than or equal to date of death";

			$dob    = $_POST["dob_yyyy"].$_POST["dob_mm"].$_POST["dob_dd"];
			$dod    = $_POST["dod_yyyy"].$_POST["dod_mm"].$_POST["dod_dd"];
			
			if (!($_POST["fname"] && isValidName($_POST["fname"]))) 											   $e = "01"; else 
			if (!($_POST["lname"] && isValidName($_POST["lname"]))) 											   $e = "02"; else 
			if (! $_POST["sex"  ] && $ad == "Actor"               ) 											   $e = "03"; else			
			if (! isValidDate($_POST["dob_yyyy"], $_POST["dob_mm"], $_POST["dob_dd"])) 							   $e = "04"; else 
			if (! (($dod == "yyyymmdd") || (isValidDate($_POST["dod_yyyy"], $_POST["dod_mm"], $_POST["dod_dd"])))) $e = "05"; else 
			if (($dod != "yyyymmdd") && ($dob >= $dod)) 														   $e = "06"; 
			
			if ($e == "00") { 
				$printTable = false; 
				////////////// Valid Information //////////////////////
	        	$db_connection = mysql_connect("localhost", "cs143", "");
	        	if(!$db_connection) {
	        		$errmsg = mysql_error($db_connection);
	    			print "Connection failed: $errmsg<br />";
		   			exit(1);
	        	}
	
				$db_select = mysql_select_db("CS143", $db_connection);
	        	
	        	if(!$db_select) {
	        		$errmsg = mysql_error($db_connection);
	    	 		print "DB selection failed: $errmsg<br />";
	   	 			exit(2);
	        	}
		
                ////// Forming Queries for Actor Names Starting with <char> /////
				$query = sprintf("SELECT id FROM MaxPersonID");
	
                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if (!$rs) {
                	$errmsg = mysql_error($db_connection);
	    			print "Query failed: $errmsg<br />";
		   			exit(3);
	            }
	            
	            $row = mysql_fetch_row($rs);
	            
	            $newID = $row[0]+1;
	            
	            $query = sprintf("UPDATE MaxPersonID SET id = $newID");
                $rs = mysql_query($query, $db_connection);
                if (!$rs) {
                	$errmsg = mysql_error($db_connection);
	    			print "Query failed: $errmsg<br />";
		   			exit(3);
	            }
	            
	            if ($dod == "yyyymmdd") 
	            	$dod = "NULL"; 
	            else {
	            	$dod = $_POST["dod_yyyy"]."-".$_POST["dod_mm"]."-".$_POST["dod_dd"];
	            	$dod = "'$dod'";
	            }
	            	
	            if ($ad == "Actor") {
	 	            $query = sprintf("INSERT INTO Actor VALUES($newID, '%s', '%s', '%s', '%s-%s-%s', %s)", 
		            				$_POST["lname"], $_POST["fname"], $_POST["sex"],
		            				$_POST["dob_yyyy"], $_POST["dob_mm"], $_POST["dob_dd"], $dod);
	            }
	            else {
	 	            $query = sprintf("INSERT INTO Director VALUES($newID, '%s', '%s', '%s-%s-%s', %s)", 
		            				$_POST["lname"], $_POST["fname"], 
		            				$_POST["dob_yyyy"], $_POST["dob_mm"], $_POST["dob_dd"], $dod);
	            }
	            				
                $rs = mysql_query($query, $db_connection);
                
                if (!$rs) {
                 	$errmsg = mysql_error($db_connection);
	    		 	print "Query failed: $errmsg<br />";
		   		 	exit(3);
	            }
	            
	            ////////////////// Closing DB Connection ///////////////////////
                mysql_close($db_connection);	
			}
	    }
	    
	    if ($printTable) {
	    	// print a table 
	    	$firstTime = "false";
			print "<h2>Add New $ad <br></h2>";
			print "<form action=\"add_actor.php?ad=$ad&ft=$firstTime\" method=\"POST\">";
			print "<table>";
		
			print "<tr>";
			print "<td align= \"right\">First Name:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><input type=\"text\" name =\"fname\" size = \"20\" maxlength = \"20\"/></td></tr>";
		
			print "<tr>";
			print "<td align= \"right\">Last Name:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\"><input type=\"text\" name =\"lname\" size = \"20\" maxlength = \"20\"/></td></tr>";
		
			if ($ad == "Actor") {
				print "<tr>";
				print "<td align= \"right\">Sex:&nbsp;&nbsp;&nbsp</td>";
				print "<td align= \"left\">";
				print "<input type=\"radio\" name=\"sex\" value=\"Male\"> Male &nbsp;&nbsp;&nbsp";
				print "<input type=\"radio\" name=\"sex\" value=\"Female\"> Female </td></tr>";
			}
			
			print "<tr>";
			print "<td align= \"right\">Date of Birth:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\">";dateForm("dob");print "</td></tr>";
			
			print "<tr>";
			print "<td align= \"right\">Date of Death:&nbsp;&nbsp;&nbsp</td>";
			print "<td align= \"left\">";dateForm("dod");print "</td></tr>";
			print "</table>";
				
			print "<table>";	
			print "<tr><td>";	
			print "<input type=\"submit\" name = \"add\" value = \"Add\"/></form></td>";
		
			print "<td>";	
			print "<form action=\"browse_actor.php?ad=$ad\" method=\"POST\">";
			print "<input type=\"submit\" name = \"cancel\" value = \"Cancel\"/></form></td></tr>";
			print "</table>";
			
			print "<p>* Leave Date of Death blank if this person is still alive	</p>";
	    }
	    
	    if ($ft == "false") {
	    	// print a message
	    	print "<br>";
	    	$message = $m[$e];
	    	if ($e != "00") 
	    		print "<font color=\"red\"> $message </font>";
	    	else 
		    	print $message;
	    }	    
    ?>
	
</body>
</html>
