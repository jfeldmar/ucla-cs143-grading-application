<html>

<head>
  <title>My Movie Database</title>
</head>

<body>

	<?php
		$key = $_GET["name"];
	        $ad = $_GET["ad"];
                $title = urlencode($_GET["title"]);

	        if (!$key)
	        	exit(0);

	        print "<b>Search Results for [$key]...</b><br><br>";


	        /////////////// Composing Regex for Search //////////////////////
	        $key = str_replace("*", "[[:alnum:]]*", $key);
	        $key_seg = explode(" ", $key);
	        $numOR = count($key_seg);

	        for ($i = 0; $i < $numOR; $i++) {
	        	$key_seg[$i] = explode("+", $key_seg[$i]);
	        }
	        /////////////////////////////////////////////////////////////////


	        //////////////// Connecting to Database /////////////////////////
	        $db_connection = mysql_connect("localhost", "cs143", "");
	        if(!$db_connection) {
	    		print "Connection failed<br />";
   			exit(1);
        	}

		$db_select = mysql_select_db("CS143", $db_connection);
        	if(!$db_select) {
         		$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    	 		print "DB selection failed: $errmsg<br />";
   	 		exit(2);
        	}
                /////////////////////////////////////////////////////////////////


                print "<table border=0>";
                print "<TR>";


                //// Forming Queries for Actor/Director Names with "keyword" ////
                for ($i = 0; $i < $numOR; $i++) {

                	if ($i)
                        	$query = $query."UNION";

                        $sz_key = mysql_real_escape_string($key_seg[$i][0], $db_connection);
                        $query = sprintf($query.'(SELECT id, first, last, YEAR(dob), YEAR(dod)
                        		 	  FROM %1$s
                                          	  WHERE CONCAT(first, " ", last) REGEXP \'[[:<:]]%2$s[[:>:]]\'',
                                          	  $ad, $sz_key);

                        $numAND = count($key_seg[$i]);

                        for ($j = 1; $j < $numAND; $j++) {
                        	$sz_key = mysql_real_escape_string($key_seg[$i][$j], $db_connection);
                        	$query = sprintf($query.' AND CONCAT(first, " ", last) REGEXP \'[[:<:]]%1$s[[:>:]]\'',
                                		 $sz_key);
                        }

                        $query = $query.')';
                }
                /////////////////////////////////////////////////////////////////


                //////////////// Querying Database //////////////////////////////
                $rs = mysql_query($query, $db_connection);
                if(!$rs) {
                	$errmsg = mysql_error($db_connection);
                        mysql_close($db_connection);
    		  	print "Query failed: $errmsg<br />";
   		  	exit(3);
               	}
                /////////////////////////////////////////////////////////////////


                ////////// Constructing List of Results with Hyperlinks /////////
                print "<TD valign=top>";
                print "<b>Results in $ad Database...</b><br>";

                while($row = mysql_fetch_row($rs)) {
                	$name = urlencode("$row[1] $row[2]");
                	$links = "$row[1] $row[2] ($row[3]-$row[4])";

                        print "<a href = \"input_relation.php?name=$name&title=$title&ad=$ad\" target=\"input\">$links</a><br>";
                }

                print "<br>";
                /////////////////////////////////////////////////////////////////


                print "</table>";

                mysql_close($db_connection);	// Closing DB Connection
	?>

</body>

</html>
