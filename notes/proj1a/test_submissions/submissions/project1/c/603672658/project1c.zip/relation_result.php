<html>

<head>
  <title></title>
</head>

<body>

	<?php

		$error = $_GET["error"];
                $errmsg = $_GET["errmsg"];

                switch ($error) {
                	case 0:
                        	print "<i><font size=4>Thank You for Your Information ^^</font></i><br>";
                                break;
                	case 1:
                        	print "<i><span style=\"background-color:yellow\">";
                                print "DB connection failed</span></i><br>";
                                break;
                        case 2:
                                print "<i><span style=\"background-color:yellow\">";
                                print "DB selection failed: $errmsg</span></i><br>";
                                break;
                        case 3:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Query failed: $errmsg</span></i><br>";
                                break;
                        case 4:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Role exceed length limitation: Max 500 characters</span></i><br>";
                                break;
                        case 5:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Person name not found: Please check your information</span></i><br>";
                                break;
                        case 6:
                                print "<i><span style=\"background-color:yellow\">";
                                print "Movie title not found: Please check your information</span></i><br>";
                                break;
                }

	?>

</body>

</html>
