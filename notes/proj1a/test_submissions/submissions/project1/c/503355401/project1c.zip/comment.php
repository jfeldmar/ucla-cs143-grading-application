<?php
	function check_error_mysql($check, $db) {
		if (!$check) {
			echo "<P>" . mysql_error($db) . "</P>";
			exit(1);
		}
	}

	$comment = $_POST['comment'];
	$score = $_POST['score'];
	$mid = $_POST['mid'];
	$name = $_POST['name'];

	$db = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143");
	$result = mysql_query("
INSERT INTO Review VALUES('$name', CURRENT_TIMESTAMP, $mid, $score, '$comment');
	", $db);
	check_error_mysql($result, $db);
	mysql_close($db);
	echo "<html><head><meta http-equiv=refresh content=\"0; URL=movie.php?id=$mid\" /></head></html>";
?>
