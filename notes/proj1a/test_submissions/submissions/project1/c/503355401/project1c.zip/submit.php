<?php
	function check_error_mysql($check, $db) {
		if (!$check) {
			echo "<P>" . mysql_error($db) . "</P>";
			exit(1);
		}
	}
	$db = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143");

	$type = $_POST['type'];

	if ($type == "actor") {
		$first = $_POST['first'];
		$last = $_POST['last'];
		$sex = $_POST['sex'];
		$dob = $_POST['dob-year'] . '-' . $_POST['dob-month'] . '-' . $_POST['dob-day'];
		$dod = $_POST['dod-year'] . '-' . $_POST['dod-month'] . '-' . $_POST['dod-day'];
		$result = mysql_query("
SELECT * FROM MaxPersonID;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$result = mysql_query("
UPDATE MaxPersonID SET id = id + 1;
		", $db);
		check_error_mysql($result, $db);
		$id = $row[0];
		if ($_POST['alive'] == "") {
		$result = mysql_query("
INSERT INTO Actor VALUES ($id, '$last', '$first', '$sex', '$dob', '$dod');
		", $db);
		check_error_mysql($result, $db);
		}
		else {
		$result = mysql_query("
INSERT INTO Actor VALUES ($id, '$last', '$first', '$sex', '$dob', NULL);
		", $db);
		check_error_mysql($result, $db);
		}
	}
	if ($type == "director") {
		$first = $_POST['first'];
		$last = $_POST['last'];
		$dob = $_POST['dob-year'] . '-' . $_POST['dob-month'] . '-' . $_POST['dob-day'];
		$dod = $_POST['dod-year'] . '-' . $_POST['dod-month'] . '-' . $_POST['dod-day'];
		$result = mysql_query("
SELECT * FROM MaxPersonID;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$result = mysql_query("
UPDATE MaxPersonID SET id = id + 1;
		", $db);
		check_error_mysql($result, $db);
		$id = $row[0];
		if ($_POST['alive'] == "") {
		$result = mysql_query("
INSERT INTO Director VALUES ($id, '$last', '$first', '$dob', '$dod');
		", $db);
		check_error_mysql($result, $db);
		}
		else {
		$result = mysql_query("
INSERT INTO Director VALUES ($id, '$last', '$first', '$sex', '$dob', NULL);
		", $db);
		check_error_mysql($result, $db);
		}
	}
	if ($type == "movie") {
		$title = $_POST['title'];
		$year = $_POST['year'];
		$rating = $_POST['rating'];
		$company = $_POST['company'];
		$result = mysql_query("
SELECT * FROM MaxMovieID;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$result = mysql_query("
UPDATE MaxMovieID SET id = id + 1;
		", $db);
		check_error_mysql($result, $db);
		$id = $row[0];
		$result = mysql_query("
INSERT INTO Movie VALUES ($id, '$title', '$year', '$rating', '$company');
		", $db);
		check_error_mysql($result, $db);
	}

	mysql_close($db);
	echo "<html><head><meta http-equiv=refresh content=\"0; URL=add_thanks.php\" /></head></html>";
?>
