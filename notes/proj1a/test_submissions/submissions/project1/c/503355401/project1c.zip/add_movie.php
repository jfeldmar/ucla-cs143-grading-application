<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; Add Movie</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
		<!--
			<div class="sidebar-top"> News </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"></div>
			</div>
		-->
		</div>
	</div>
	<div class="content">
		<div class="entry">
		<div class="heading">Contribute</div>
		<p>Help us make MovieBuff even better by contributing information to our site! Fill out one of the forms below and click "Submit" to add your information to our site.</p>
		</div>
		<div class="entry">
		<div class="heading">Add Director</div>
		<form method="post" action="submit.php">
		<input type="hidden" name="type" value="movie" />
		Title <input class="text" type="text" name="title" /><br />
		Year <input class="text" type="text" name="year" /><br />
		Rating <input class="text" type="text" name="rating" /><br />
		Company <input class="text" type="text" name="company" /><br />
<br /><input type="submit" value="Submit" />
		</form>
		</div>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
