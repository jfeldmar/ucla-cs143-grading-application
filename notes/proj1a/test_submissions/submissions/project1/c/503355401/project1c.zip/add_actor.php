<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; Add Actor</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
		<!--
			<div class="sidebar-top"> News </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"></div>
			</div>
		-->
		</div>
	</div>
	<div class="content">
		<div class="entry">
		<div class="heading">Contribute</div>
		<p>Help us make MovieBuff even better by contributing information to our site! Fill out one of the forms below and click "Submit" to add your information to our site.</p>
		</div>
		<div class="entry">
		<div class="heading">Add Actor</div>
		<form method="post" action="submit.php">
		<input type="hidden" name="type" value="actor" />
		First Name <input class="text" type="text" name="first" /><br />
		Last Name <input class="text" type="text" name="last" /><br />
		Sex <select class="text" name="sex"><option value="Male">Male</option><option value="Female">Female</option></select><br />
		Date of Birth <select class="text" name="dob-month"><option value="1">January</option><option value="2">February</option><option value="3">March</option><option value="4">April</option><option value="5">May</option><option value="6">June</option><option value="7">July</option><option value="8">August</option><option value="9">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><select class="text" name="dob-day">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<input type="text" class="text-year" name="dob-year" />
<br />
		Date of Death <select class="text" name="dod-month"><option value="1">January</option><option value="2">February</option><option value="3">March</option><option value="4">April</option><option value="5">May</option><option value="6">June</option><option value="7">July</option><option value="8">August</option><option value="9">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><select class="text" name="dod-day">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<input type="text" class="text-year" name="dod-year" />
<br />Still Alive <input type="checkbox" name="alive" value="alive" />
<br /><input type="submit" value="Submit" />
		</form>
		</div>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
