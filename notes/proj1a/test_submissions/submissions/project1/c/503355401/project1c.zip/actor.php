<?php
	function check_error_mysql($check, $db) {
		if (!$check) {
			echo "<P>" . mysql_error($db) . "</P>";
			exit(1);
		}
	}

	if ($_GET["id"]) {
		$db = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143");
		$id = $_GET['id'];

		$result = mysql_query("
SELECT first, last, sex, dob, dod
  FROM Actor
 WHERE id = $id;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$first = $row[0];
		$last = $row[1];
		$sex = $row[2];
		$dob = $row[3];
		$dod = $row[4];
		if ($dod == "") $dod = "Present";
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; <?php echo "$first $last"; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
		<!--
			<div class="sidebar-top"> News </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"></div>
			</div>
		-->
		</div>
	</div>
	<div class="content">
<?php
	if ($_GET["id"]) {
		echo "<div class=\"entry\">\n";
		echo "<div class=\"heading\">$first $last</div>\n";
		echo "<p>$sex, $dob&ndash;$dod</p>";

		echo "</div>";
		$result = mysql_query("
SELECT AVG(Review.rating)
  FROM MovieActor, Review
 WHERE MovieActor.aid = $id
   AND Review.mid = MovieActor.mid;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$rating = $row[0];
		if ($rating == "") $rating = "?";

		echo "<div class=\"entry\">\n";
		echo "<div class=\"sub-heading\">Filmography</div>\n";

		$result = mysql_query("
SELECT title, role, mid, year
  FROM MovieActor, Movie
 WHERE MovieActor.aid = $id
   AND Movie.id = MovieActor.mid
ORDER BY year DESC;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$num = 1;
		while ($row = mysql_fetch_row($result)) {
			check_error_mysql($row, $db);
			$title = $row[0];
			$role = $row[1];
			$mid = $row[2];
			$year = $row[3];
			echo "<div>$num. <a href=\"./movie.php?id=$mid\">$title</a> ($year) $role</div>\n";
			$num++;
		}
		if ($num == 1) echo "<p>This actor has not acted in any movies.</p>";

		echo "</div>\n";
		mysql_close($db);
	}
?>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
