<?php
	function check_error_mysql($check, $db) {
		if (!$check) {
			echo "<P>" . mysql_error($db) . "</P>";
			exit(1);
		}
	}

	if ($_GET["id"]) {
		$db = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143");
		$id = $_GET['id'];

		$result = mysql_query("
SELECT title, rating, year, company
  FROM Movie
 WHERE id = $id;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$title = $row[0];
		$rating = $row[1];
		$year = $row[2];
		$company = $row[3];
		$result = mysql_query("
SELECT AVG(Review.rating)
  FROM Review
 WHERE mid = $id;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$score = $row[0];
		if ($score == "") $score = "?";
		if ($_GET['score'] != "") $score = $_GET['score'];
		if ($score > 4) $score = 4;
		if ($score < 1) $score = 0;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; <?php echo "$title"; ?></title>
<link href="css/style.css" rel="stylesheet" type="text/css" />

        <style type="text/css">
            div.rating
            {
                background-image: url(images/<?php
                    if ($score != 0)
                    {
                        echo('starRating' . round($score));
                    } else {
                        echo('star0');
                    }
                ?>.gif);
                background-repeat: no-repeat;
            }
			
            a img
            {
                border-style: none;
            }
			
            a.star1 img
            {
                background-image: url(images/starTransparent1.gif);
            }
			
            a.star1:hover img
            {
                background-image: url(images/star1.gif);
            }
			
            a.star1
            {
                margin-left: -32px;
            }
			
            a.star2 img
            {
                background-image: url(images/starTransparent2.gif);
            }
			
            a.star2:hover img
            {
                background-image: url(images/star2.gif);
            }
			
            a.star2
            {
                margin-left: -48px;
            }
			
            a.star3 img
            {
                background-image: url(images/starTransparent3.gif);
            }
			
            a.star3:hover img
            {
                background-image: url(images/star3.gif);
            }
			
            a.star3
            {
                margin-left: -64px;
            }
			
            a.star4 img
            {
                background-image: url(images/starTransparent4.gif);
            }
			
            a.star4:hover img
            {
                background-image: url(images/star4.gif);
            }
        </style>

</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
		<!--
			<div class="sidebar-top"> News </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"></div>
			</div>
		-->
		</div>
	</div>
	<div class="content">
<?php
	if ($_GET["id"]) {
		echo "<div class=\"entry\">\n";
		echo "<div class=\"heading\">$title ($year) <span class=\"rating\">&nbsp;$rating&nbsp;</span></div>\n";
		echo "<p>$company</p>";
		echo "
        <div class=\"rating\">
            <a class=\"star4\" href=\"./movie.php?id=$id&score=4\"><img src=\"images/starTransparent4.gif\" alt=\"\" /></a><a class=\"star3\" href=\"./movie.php?id=$id&score=3\"><img src=\"images/starTransparent3.gif\" alt=\"\" /></a><a class=\"star2\" href=\"./movie.php?id=$id&score=2\"><img src=\"images/starTransparent2.gif\" alt=\"\" /></a><a class=\"star1\" href=\"./movie.php?id=$id&score=1\"><img src=\"images/starTransparent1.gif\" alt=\"\" /></a>
        </div>
		";
		if ($_GET['score'] != "") echo "<p>We want to know what you thought of this movie! Please submit a comment below to upload your score.</p>";
		echo "</div>";

		echo "<div class=\"entry\">\n";
		echo "<div class=\"sub-heading\">Director</div>\n";
		$result = mysql_query("
SELECT first, last, id
  FROM MovieDirector, Director
 WHERE MovieDirector.mid = $id
   AND Director.id = MovieDirector.did;
		", $db);
		check_error_mysql($result, $db);
		$row = mysql_fetch_row($result);
		check_error_mysql($result, $db);
		$first = $row[0];
		$last = $row[1];
		$did = $row[2];
		echo "<div><a href=\"./director.php?id=$did\">$first $last</a></div>\n";
		echo "</div>";

		echo "<div class=\"entry\">\n";
		echo "<div class=\"sub-heading\">Cast</div>\n";

		$result = mysql_query("
SELECT first, last, role, aid
  FROM MovieActor, Actor
 WHERE MovieActor.mid = $id
   AND Actor.id = MovieActor.aid;
		", $db);
		check_error_mysql($result, $db);
		$num = 1;
		while ($row = mysql_fetch_row($result)) {
			check_error_mysql($row, $db);
			$first = $row[0];
			$last = $row[1];
			$role = $row[2];
			$aid = $row[3];
			echo "<div>$num. <a href=\"./actor.php?id=$aid\">$first $last</a> $role</div>\n";
			$num++;
		}

		echo "</div>\n";

		$result = mysql_query("
SELECT name, comment, rating, YEAR(time), MONTH(time), DAY(time)
  FROM Review
 WHERE mid = $id
ORDER BY time DESC;
		", $db);
		check_error_mysql($result, $db);
		$num= mysql_num_rows($result);
		check_error_mysql($result, $db);
		echo "<div class=\"entry\"><div class=\"heading\">Comments ($num)</div>";
		if ($num == 0) echo "There are currently no comments for this movie.";
		while ($row = mysql_fetch_row($result)) {
			check_error_mysql($row, $db);
			$name = $row[0];
			$comment = $row[1];
			$rating = $row[2];
			$year = $row[3];
			$month = $row[4];
			$day = $row[5];
			echo "<div class=\"sub-heading\">$name ($month/$day/$year)<br /><img src=\"images/starRating$rating.gif\" /></div><div class=\"comment-middle\">$comment</div>\n";
		}
		echo "</div>";

		echo "<div class=\"entry\"><div class=\"heading\">Post a Comment</div>";
		echo "<form action=\"comment.php\" method=\"post\">Name <input type=\"input\" class=\"text\" name=\"name\" /><br /><textarea class=\"text\" name=\"comment\"></textarea><br /><input type=\"hidden\" value=\"$score\" name=\"score\" /><input type=\"hidden\" name=\"mid\" value=\"$id\" /><input type=\"submit\" value=\"Post\"/></form></div>";
		echo "</div>\n";
		mysql_close($db);
	}
?>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
