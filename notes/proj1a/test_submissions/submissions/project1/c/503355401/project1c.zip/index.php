<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; The Ultimate Movie Database</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main-active.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
			<div class="sidebar-top"> News </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <b>10/28/2008 &mdash; Site launch</b> Welcome to the launch of MovieBuff, the ultimate online movie database!</div>
			</div>
		</div>
		<div class="sidebar-content">
			<div class="sidebar-top"> Contribute </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_actor.php"><b>Add Actor</b></a> </div>
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_director.php"><b>Add Director</b></a> </div>
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_movie.php"><b>Add Movie</b></a> </div>
			</div>
		</div>
	</div>
	<div class="content">
		<div class="heading">Welcome to MovieBuff!</div>
		<div class="entry">
			<p>MovieBuff is the best place to search for information about your favorite movies, actors, and directors! We have one of the largest databases of user-contributed movie information on the internet. We provide a place for users to shout out about the movies they like&hellip; and hate! Read some of our user comments or rate the movie and write one of your own.</p>
			<p>MovieBuff is based on a thriving community of movie enthusiasts just like yourself. We are a community-driven project and require your input in order to be the best! See something missing? Feel free to add it! Help us build our site and make it even better.</p>
			<p>Get started by typing in some search terms above!</p>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
