<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; Search Results</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
		</div>
	</div>
	<div class="content">
		<div class="heading">Search Results</div>
		<div class="entry">
<?PHP
	function check_error_mysql($check, $db) {
		if (!$check) {
			echo "<P>" . mysql_error($db) . "</P>";
			exit(1);
		}
	}

	if ($_GET["value"]) {
		$db = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143");
		$query = mysql_real_escape_string($_GET["value"]);
		$terms = "'" . implode("', '", explode(' ', $query)) . "'";

		$result_exact = mysql_query("
SELECT id, first, last, 'actor'
  FROM Actor
 WHERE LOWER(first) IN ($terms)
   AND LOWER(last) IN ($terms)
 UNION
SELECT id, title, year, 'movie'
  FROM Movie
 WHERE LOWER(title) = LOWER('$query')
 UNION
SELECT id, first, last, 'director'
  FROM Director
 WHERE LOWER(first) IN ($terms)
   AND LOWER(last) IN ($terms);
		", $db);
		check_error_mysql($result_exact, $db);
		$num_exact = mysql_num_rows($result_exact);
		check_error_mysql($result_exact, $db);

		$result_related = mysql_query("
SELECT id, first, last, 'actor'
  FROM Actor
 WHERE LOWER(first) IN ($terms)
    OR LOWER(last) IN ($terms)
 UNION
SELECT id, title, year, 'movie'
  FROM Movie
 WHERE LOWER(title) LIKE LOWER('$query')
   AND LOWER(title) != LOWER('$query')
 UNION
SELECT id, first, last, 'director'
  FROM Director
 WHERE LOWER(first) IN ($terms)
   OR LOWER(last) IN ($terms);
                ", $db);
		check_error_mysql($result_related, $db);
		$num_related = mysql_num_rows($result_related);
		check_error_mysql($result_related, $db);

		$value = $_GET['value'];
		echo "<p>Found ";
		if ($num_exact) echo "$num_exact exact match ";
		if ($num_exact && $num_related) echo "and ";
		if ($num_related) echo "$num_related related matches ";
		if (!$num_exact && !$num_related) echo "no matches ";
		echo "for <b>$value</b>.</p></div>";

		$num = 1;
		if ($num_exact) {
		echo "<div class=\"entry\">\n";
		echo "<div class=\"heading\">Exact Matches</div>\n";
		while ($row = mysql_fetch_row($result_exact)) {
			check_error_mysql($row, $db);
			$id = $row[0];
			$first = $row[1];
			$last = $row[2];
			$type = $row[3];
			if ($type == 'actor') {
			echo "<div>$num. <a href=\"./actor.php?id=$id\">$first $last</a></div>\n";
			}
			else if ($type == 'movie') {
			echo "<div>$num. <a href=\"./movie.php?id=$id\">$first ($last)</a></div>\n";
			}
			else if ($type == 'director') {
			echo "<div>$num. <a href=\"./director.php?id=$id\">$first $last</a> (Director)</div>\n";
			}
			$num++;
		}
		echo "</div>\n";
		}

		if ($num_related) {
		echo "<div class=\"entry\">\n";
		echo "<div class=\"heading\">Related Matches</div>\n";
		while ($row = mysql_fetch_row($result_related)) {
			check_error_mysql($row, $db);
			$id = $row[0];
			$first = $row[1];
			$last = $row[2];
			$type = $row[3];
			if ($type == 'actor') {
			echo "<div>$num. <a href=\"./actor.php?id=$id\">$first $last</a></div>\n";
			}
			else if ($type == 'movie') {
			echo "<div>$num. <a href=\"./movie.php?id=$id\">$first ($last)</a></div>\n";
			}
			else if ($type == 'director') {
			echo "<div>$num. <a href=\"./director.php?id=$id\">$first $last</a> (Director)</div>\n";
			}
			$num++;
		}
		echo "</div>\n";
		}
		mysql_close($db);
	}
?>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
