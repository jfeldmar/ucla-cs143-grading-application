<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MovieBuff &mdash; Submission Successful</title>
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="header">
		<div class="header-holder">
			<div class="header-left"> <a class="header" href="./index.php"><img src="images/navigation-main.gif" /></a><a class="header" href="about.php"><img src="images/navigation-about.gif" /></a></div>
			<div class="header-right"><form action="search.php" method="get"><img class="search" src="images/search.gif" alt="search" /><input class="header-text" type="text" name="value" value="<?php echo $_GET['value']; ?>" /><!--<input class="button" type="submit" />--></form></div>
		</div>
	</div>
	<div class="title">
		<div class="title-holder">
			<img src="images/title.gif" />
		</div>
	</div>
	<div class="header-bottom">
		<div class="header-bottom-holder">  </div>
	</div>
	<div class="site">
	<div class="sidebar">
		<div class="sidebar-content">
			<div class="sidebar-top"> Contribute </div>
			<div class="sidebar-middle">
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_actor.php"><b>Add Actor</b></a> </div>
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_director.php"><b>Add Director</b></a> </div>
				<div class="sidebar-text"> <img src="images/bullet.gif" /> <a href="./add_movie.php"><b>Add Movie</b></a> </div>
			</div>
		</div>
	</div>
	<div class="content">
		<div class="heading">Thank You!</div>
		<div class="entry">
			<p>Your submission was processed successfully. Thank you for making MovieBuff even better with your contribution! Feel free to continue to contribute to our site.</p>
			<p><a href="./index.php">&laquo; Return to main page</a></p>
		</div>
		<!--
		<div class="date">
			<div class="month">Version</div>
			<div class="day">0.1</div>
		</div>
		-->
	</div>
	</div>
	<div class="footer-top">
		<div class="footer-top-holder">  </div>
	</div>
	<div class="footer">
		<div class="footer-holder">

			This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/3.0/us/">Creative Commons Attribution 3.0 United States License</a>.
			<br />
			Comments? Suggestions? Contact the site <a href="mailto:justin.meza@gmail.com">administrator</a>.
		</div>
	</div>
</body>
</html>
