<!-- 
    Document   : query.php
    Created on : Oct 18, 2008, 2:15:53 PM
    Author        : cody prestwood   303596543
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
      <title>Movie Database Project 1C</title>
    		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<LINK href="./pagebasics.css" type="text/css" rel="STYLESHEET">
	</head>
	<body>
		<!--Banner logo table -->
		<!--div style="LEFT: .5in; POSITION: absolute; TOP: 0in; scroll: auto" id="Div1"-->
			<table id="Table3" align="center" border="0" cellspacing="0">
				<tbody>
					<tr>
						<td align="center" bgcolor="#000000">
							<h2>Add Movie<br>
								To Database</h2>
						</td>
						<td><IMG height="150" alt="logo banner" src="./girlfish1.jpg" width="230" border="0" name="logo"></td>
						<td valign="bottom" bgcolor="#a3b116">
							<table id="t5" border="0">
								<tbody>
									<tr>
									
									<td align="center">
										<a href="./actorpage.php">
											<h5>Add Actor/Director</h5>
										</a>
									</td>
									<td align="center">
										<a href="./reviewpage.php">
											<h5>Submit Review</h5>
										</a>
									</td>
									<td align="center">
										<a href="./moviepage.php">
											<h5>Add Movie</h5>
										</a>
									</td>
									<td align="center">
										<a href="./querypage.php">
											<h5>Search by Keyword</h5></a>
										</td>
									<td align="center">
											<a href="./browseactor.php">
												<h5>Browse Actors</h5>
										</a>
									</td>
									<td align="center">
											<a href="./browsemovie.php">
												<h5>Browse Movies</h5>
										</a>
									</td>
									<td align="center">
											<a href="./movieactor.php">
												<h5>Add Rolls To Movies</h5>
										</a>
									</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody></table>
		<!--/div>
		<Banner logo table (end)-->

   <form  method="GET">
    <P><h4>
	<!--input type="text" name="calcstr" size="20"/>
          <Age: <input type="text" name="age" /-->
	<!--TEXTAREA id="Textarea1" name="calcstr" rows="5" cols="43"></TEXTAREA-->
	Title : <input type="text" name="title" size="50" maxlength="100"/><br>
	Company: <input type="text" name="company" size=50 maxlength="50"/><br>
	Year : <input type="text" name="year" size=6 maxlength="4"/><br>
	Select MPAA Rating : <select id="select1" name="mpaarating">
			<option value="G" selected>G</option>
			<option value="PG">PG</option>
			<option value="PG-13">PG-13</option>
			<option value="NC-17">NC-17</option>
			<option value="R">R</option>
			<option value="X">X</option>
			</select>
			<br>
			Select Genre : <select id="select2" name="genre">
			<option  value="Action" selected>Action</option>
			<option  value="Adult">Adult</option>
			<option value="Adventure">Adventure</option>
			<option  value="Animation">Animation</option>
			<option value="Comedy">Comedy</option>
			<option  value="Crime">Crime</option>
			<option  value="Documentary">Documentary</option>
			<option value="Drama">Drama</option>
			<option  value="Family">Family</option>
			<option  value="Fantasy">Fantasy</option>
			<option  value="Horror">Horror</option>
			<option value="Musical">Musical</option>
			<option value="Mystery">Mystery</option>
			<option value="Romance">Romance</option>
			<option  value="Sci-Fi">Sci-Fi</option>
			<option value="Short">Short</option>
			<option  value="Thriller">Thriller</option>
			<option value="War">War</option>
			<option value="Western">Western</option>
			</select><br>
			<u>If Director or Actor is not listed, then you will need to add them first.</u><br>
			Select Director : <select id="select3" name="director">
		<!---------------------------------------------------------------------------------------------->
		<?php
		if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link))
		{
		    echo 'Could not select database';
			echo "MySQL Error: " . mysql_error($link);
			print "<br>";
		    exit;
		}
		$result = mysql_query("Select id,first,last from Director where last > 'A' order by last", $link);
		// loop through each record and present them
		$fields=mysql_num_fields($result);
		while ($row = mysql_fetch_row($result))
		{ 
			// option value
			print '<option value="'.$row[0].'">'.$row[1].' '.$row[2].'</option>';
		}
		print "</select><br>";
		print 'Select Actor : <select id="select4" name="actor">';
		print '<option value="null"> None </option>';

		$result = mysql_query("Select id,first,last from Actor where last > 'A' order by last", $link);
		// loop through each record and present them
		$fields=mysql_num_fields($result);
		while ($row = mysql_fetch_row($result))
		{ 
			// option value
			print '<option value="'.$row[0].'">'.$row[1].' '.$row[2].'</option>';
		}
		mysql_close($link);
		?>
		<!---------------------------------------------------------------------------------------------->
			</select><br>
			Name of Character or Role in Movie : <input type="text" name="role" size=40 maxlength="50"/>
			</p></h4>
		<input type="submit" value="Add Movie" />
   </form>
   <br>
    <?php

    if($_GET["title"] && $_GET["year"])
    {
	    $title = $_GET["title"];
		$rate=$_GET["mpaarating"];
		$comp = $_GET["company"];
		$year = $_GET["year"];
		$genre = $_GET["genre"];
		$dirt = $_GET["director"];
		$actor = $_GET["actor"];
		$role = $_GET["role"];
		//print "calcin=".$calcin."<br>";
	    if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link)) {
			echo "Select DB CS143 Error: " . mysql_error($link)."<br>";
		    exit;
		}

		$pattern='/[\012\013\014\015]/';
		$slashchk="\0..\37!@\@\177..\377";
		//$pattern[1]='/[\073]{1}$/';
		//print "pattern=".$pattern[0]." ".$pattern[1]."<br>";
		$title = preg_replace($pattern, ' ', $title);
		$title = addcslashes($title, $slashchk);
		$comp = preg_replace($pattern, ' ', $comp);
		$comp = addcslashes($comp, $slashchk);

		// get movie id
		$result = mysql_query("update MaxMovieID set id=id+1", $link);
		if (!$result) {
		    print "Update Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request
		$result = mysql_query("select * from MaxMovieID", $link);
		if (!$result) {
		    print "Update Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_num_rows($result); // if select  type of query
		$row = mysql_fetch_row($result);
		$fields=mysql_num_fields($result);
		//print $nrows.' '.$fields.' '.$row."<br>";
		// Movie(id, title, year, rating, company)
		$sql = "insert into Movie values(".$row[0].", '{$title}',{$year},'{$rate}', '{$comp}')";
		//print $sql."<br>";
		$id=$row[0];
		// Now submit the query to sql
		$result = mysql_query($sql, $link);
		if (!$result) {
		    echo "Insert Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request
		
		$sql="insert into MovieDirector values({$id},{$dirt})";
		//print $sql."<br>";
		$result = mysql_query($sql, $link);
		if (!$result) {
		    echo "Insert Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request

		$sql="insert into MovieGenre values({$id},'{$genre}')";
		//print $sql."<br>";
		$result = mysql_query($sql, $link);
		if (!$result) {
		    echo "Insert Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request
		if ($actor != "null" && !empty($role))
		{
			$sql="insert into MovieActor values({$id},{$actor},'{$role}')";
			//print $sql."<br>";
			$result = mysql_query($sql, $link);
			if (!$result) {
			    echo "Insert Error: " . mysql_error($link)."<br>";
			    exit;
			}
			$nrows = mysql_affected_rows($link); // if non-select type request
		}
		mysql_close($link);
		print "<h4>Created {$nrows} Movie Record: {$id} </h4>";
	}
    ?>    
  </body>
</html>