Cody Prestwood 303596543
Project 1C
The website can be activated on any php file in the zip package.