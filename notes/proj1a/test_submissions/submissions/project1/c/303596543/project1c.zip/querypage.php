<!-- 
    Document   : query.php
    Created on : Oct 28, 2008,
    Author        : cody prestwood   303596543
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
      <title>Movie Database Project 1C</title>
    		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<LINK href="./pagebasics.css" type="text/css" rel="STYLESHEET">
	</head>
	<body>
		<!--Banner logo table -->
		<!--div style="LEFT: .5in; POSITION: absolute; TOP: 0in; scroll: auto" id="Div1"-->
			<table id="Table3" align="center" border="0" cellspacing="0">
				<tbody>
					<tr>
						<td align="center" bgcolor="#000000">
							<h2>Searching<br>
								by Keyword</h2>
						</td>
						<td><IMG height="150" alt="logo banner" src="./girlfish1.jpg" width="230" border="0" name="logo"></td>
						<td valign="bottom" bgcolor="#a3b116">
							<table id="t5" border="0">
								<tbody>
									<tr>
									
									<td align="center">
										<a href="./actorpage.php">
											<h5>Add Actor/Director</h5>
										</a>
									</td>
									<td align="center">
										<a href="./reviewpage.php">
											<h5>Submit Review</h5>
										</a>
									</td>
									<td align="center">
										<a href="./moviepage.php">
											<h5>Add Movie</h5>
										</a>
									</td>
									<td align="center">
										<a href="./querypage.php">
											<h5>Search by Keyword</h5></a>
										</td>
									<td align="center">
											<a href="./browseactor.php">
												<h5>Browse Actors</h5>
										</a>
									</td>
									<td align="center">
											<a href="./browsemovie.php">
												<h5>Browse Movies</h5>
										</a>
									</td>
									<td align="center">
											<a href="./movieactor.php">
												<h5>Add Rolls To Movies</h5>
										</a>
									</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody></table>
		<!--/div>
		<Banner logo table (end)-->

	<br>
   <form  method="GET">
    <h4>Enter Your Search Criteria<br>Separate multiple people, movies, etc. with comma ,</h4>
    <P>
		<SELECT id="Select1" name="selectlist">
			<OPTION value="0" selected>Movie Titles</OPTION>
			<OPTION value="1">Actors</OPTION>
			<OPTION value="2">Directors</OPTION>
			<OPTION value="3">Movie Genres</OPTION>
			<OPTION value="4">Reviews</OPTION>
		</SELECT>
	<input type="text" name="calcstr" size="30"/>
    <input type="submit" value="Search" />
    </P>
   </form>

    <?php

    if($_GET["calcstr"]) // only process if there is  actual data.
    {
	    $calcin = $_GET["calcstr"];
		$selectid = $_GET["selectlist"];
		$checkreview = $_GET["checkreview"];
		//print "calcin=".$calcin."<br>";
	    if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link)) {
		    echo 'Could not select database';
			echo "MySQL Error: " . mysql_error($link);
			print "<br>";
		    exit;
		}
		/* eliminate the lf,cr,etc and escape \133..\140 is [\]^_` */
		$pattern='/[\012\013\014\015]/';
		$calcin = preg_replace($pattern, ' ', $calcin);
		$pieces = explode(",", $calcin);
		/* print "calcin=".$calcin."<br>"; */
		//print_r ($pieces);
		$sql = addcslashes($calcin, "\0..\37!@\@\177..\377");
		$decoded = stripcslashes($sql);
		if (strstr($sql,"\134\116") !== false) $sql = $decoded; //correct for \N
		//print "sql=".$sql."<br>";
		//print "decoded=".$decoded."<br>";

		if ($selectid == 0)
		{	$sql="Select * From Movie where ";
			foreach($pieces as $piece)
			{
			$sql = $sql." title like '%".$piece."%' or ";
			}
			$sql = substr($sql,0,strlen($sql)-3);
		}
		else if ($selectid == 1)
		{ $sql="Select distinct title,year,rating from Movie,(select mid from MovieActor M,Actor A where A.id=M.aid and (";
			foreach($pieces as $piece)
			{
			$sql = $sql." last like '".$piece."' or ";
			}
			$sql = substr($sql,0,strlen($sql)-3);
			$sql=$sql.")) S where S.mid=Movie.id";
		}
		else if ($selectid == 2)
		{ $sql="Select distinct title,year,rating from Movie,(select mid from MovieDirector M,Director A where A.id=M.did and (";
			foreach($pieces as $piece)
			{
			$sql = $sql." last like '".$piece."' or ";
			}
			$sql = substr($sql,0,strlen($sql)-3);
			$sql=$sql.")) S where S.mid=Movie.id";
		}
		else if ($selectid == 3)
		{ $sql="Select title,year,rating from MovieGenre,Movie where MovieGenre.mid=Movie.id and ";
			foreach($pieces as $piece)
			{
			$sql = $sql." genre like '".$piece."' or ";
			}
			$sql = substr($sql,0,strlen($sql)-3);
		}
		else if ($selectid == 4)
		{ $sql="Select title,Review.rating,time,comment from Review,Movie where Review.mid=Movie.id and ";
			foreach($pieces as $piece)
			{
			$sql = $sql." Movie.title like '%".$piece."%' or ";
			}
			$sql = substr($sql,0,strlen($sql)-3);
		}
		// Now submit the query to sql
		//print $sql."<br>";
		$result = mysql_query($sql, $link);
		if (!$result)
		{
		    echo "DB Error, could not query the database\n";
		    echo "MySQL Error: " . mysql_error($link);
			print "<br>";
		    exit;
		}

		// returns false if query failed or the number of records for SELECT operation
		$nrows = mysql_num_rows($result); // if select  type of query
		
		print "<P>Total records: {$nrows} </P>";
		
		if ($nrows > 0)
	    {	
			// setup html table stuff
			print '<table id="Table3" align="left" border="1" cellspacing="2"> <tbody>';
			// loop through the column headers and present them
			$fields=mysql_num_fields($result);
			echo "<tr>"; 
			for ($i=0; $i < $fields; $i++) {
				//Table Header
				print "<th>".mysql_field_name($result, $i)."</th>"; 
			}
			echo "</tr>\n";
			// loop through each record and present them
			while ($row = mysql_fetch_row($result)) { 
				//Table body
				echo "<tr>";
			    for ($f=0; $f < $fields; $f++) {
				//print "row{$f}=".$row[$f]."<br>";
				if (empty($row[$f])) $row[$f]="Null";
			    echo "<td>".$row[$f]."</td>";
				}
				echo "</tr>\n";
			}
			print "</tbody></table>";
	    } // endif nrows is not zero
		mysql_close($link);
	} // endif calcstr is not empty
    ?>    
  </body>
</html>