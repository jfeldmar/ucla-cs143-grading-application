<!-- 
    Document   : query.php
    Created on : Oct 18, 2008, 2:15:53 PM
    Author        : cody prestwood   303596543
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
      <title>Movie Database Project 1C</title>
    		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<LINK href="./pagebasics.css" type="text/css" rel="STYLESHEET">
	</head>
	<body>
		<!--Banner logo table -->
		<!--div style="LEFT: .5in; POSITION: absolute; TOP: 0in; scroll: auto" id="Div1"-->
			<table id="Table3" align="center" border="0" cellspacing="0">
				<tbody>
					<tr>
						<td align="center" bgcolor="#000000">
							<h2>Browse<br>
								Movies</h2>
						</td>
						<td><IMG height="150" alt="logo banner" src="./girlfish1.jpg" width="230" border="0" name="logo"></td>
						<td valign="bottom" bgcolor="#a3b116">
							<table id="t5" border="0">
								<tbody>
									<tr>
									
									<td align="center">
										<a href="./actorpage.php">
											<h5>Add Actor/Director</h5>
										</a>
									</td>
									<td align="center">
										<a href="./reviewpage.php">
											<h5>Submit Review</h5>
										</a>
									</td>
									<td align="center">
										<a href="./moviepage.php">
											<h5>Add Movie</h5>
										</a>
									</td>
									<td align="center">
										<a href="./querypage.php">
											<h5>Search by Keyword</h5></a>
										</td>
									<td align="center">
											<a href="./browseactor.php">
												<h5>Browse Actors</h5>
										</a>
									</td>
									<td align="center">
											<a href="./browsemovie.php">
												<h5>Browse Movies</h5>
										</a>
									</td>
									<td align="center">
											<a href="./movieactor.php">
												<h5>Add Rolls To Movies</h5>
										</a>
									</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody></table>
		<!--/div>
		<Banner logo table (end)-->

   <form  method="GET">
    <P><h4>

	Select Movie : <select id="select3" name="movie">
		<!---------------------------------------------------------------------------------------------->
		<?php
		if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link))
		{
		    echo 'Could not select database';
			echo "MySQL Error: " . mysql_error($link);
			print "<br>";
		    exit;
		}
		$result = mysql_query("Select id,title,year from Movie where title > '0' order by title", $link);
		// loop through each record and present them
		$fields=mysql_num_fields($result);
		while ($row = mysql_fetch_row($result))
		{ 
			// option value
			print '<option value="'.$row[0].'">'.$row[1].' ('.$row[2].')</option>';
		}

		mysql_close($link);
		?>
		<!---------------------------------------------------------------------------------------------->
			</select><br>
			</p></h4>
		<input type="submit" value="Find Movie" />
   </form>
   <br>
    <?php

    if($_GET["movie"])
    {
	    $title = $_GET["movie"];

	    if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link)) {
			echo "Select DB CS143 Error: " . mysql_error($link)."<br>";
		    exit;
		}

		print '<table id="Table3" align="left" border="1" cellspacing="2"> <tbody>';

		$result = mysql_query("Select title,year,rating,genre from Movie,MovieGenre where id={$title} and mid={$title}", $link);
		if (!$result)
		{
		    echo "Select Error: " . mysql_error($link) ."<br>";
		    exit;
		}
		// loop through the column headers and present them
		$fields=mysql_num_fields($result);
		echo "<tr>"; 
		for ($i=0; $i < $fields; $i++) {
			//Table Header
			print "<th>".mysql_field_name($result, $i)."</th>"; 
		}
		echo "</tr>\n";
		// loop through each record and present them
		while ($row = mysql_fetch_row($result)) { 
			//Table body
			echo "<tr>";
			for ($f=0; $f < $fields; $f++) 
			{
			//print "row{$f}=".$row[$f]."<br>";
			if (empty($row[$f])) $row[$f]="Null";
			echo "<td>".$row[$f]."</td>";
			}
			echo "</tr>\n";
		}
		print "</tbody></table>";
		print '<table id="Table3" align="left" border="1" cellspacing="2">';
		$result = mysql_query("Select first,last,role,id from Actor,MovieActor where id=aid and mid={$title}", $link);
		if (!$result)
		{
		    echo "Select Error: " . mysql_error($link) ."<br>";
		    exit;
		}
		// loop through the column headers and present them
		$fields=mysql_num_fields($result);
		echo "<tr>"; 
		print "<th>Actor</th>";
		print "<th>Character/Role</th>";
		echo "</tr><tbody>";
		// loop through each record and present them
		while ($row = mysql_fetch_row($result)) { 
			//Table body
			echo "<tr>";
			print '<td><a href="./movieactor.php?aid='.$row[3].'">'.$row[0].' '.$row[1].'</a></td>';
			print '<td>'.$row[2].'</td>';
			echo "</tr>";
		}
		echo "</tbody></table>";

		mysql_close($link);
	}
    ?>    
  </body>
</html>