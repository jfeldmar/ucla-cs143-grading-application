<!-- 
    Document   : actorpage.php
    Created on : Oct 28, 2008, 
    Author        : cody prestwood   303596543
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
      <title>Movie Database Project 1C</title>
    		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<LINK href="./pagebasics.css" type="text/css" rel="STYLESHEET">
	</head>
	<body>
		<!--Banner logo table -->
		<!--div style="LEFT: .5in; POSITION: absolute; TOP: 0in; scroll: auto" id="Div1"-->
			<table id="Table3" align="center" border="0" cellspacing="0">
				<tbody>
					<tr>
						<td align="center" bgcolor="#000000">
							<h2>Add New Actor/Director<br>
								To Database</h2>
						</td>
						<td><IMG height="150" alt="logo banner" src="./girlfish1.jpg" width="230" border="0" name="logo"></td>
						<td valign="bottom" bgcolor="#a3b116">
							<table id="t5" border="0">
								<tbody>
									<tr>
									
									<td align="center">
										<a href="./actorpage.php">
											<h5>Add New Actor/Director</h5>
										</a>
									</td>
									<td align="center">
										<a href="./reviewpage.php">
											<h5>Submit Review</h5>
										</a>
									</td>
									<td align="center">
										<a href="./moviepage.php">
											<h5>Add Movie</h5>
										</a>
									</td>
									<td align="center">
										<a href="./querypage.php">
											<h5>Search by Keyword</h5></a>
										</td>
									<td align="center">
											<a href="./browseactor.php">
												<h5>Browse Actors</h5>
										</a>
									</td>
									<td align="center">
											<a href="./browsemovie.php">
												<h5>Browse Movies</h5>
										</a>
									</td>
									<td align="center">
											<a href="./movieactor.php">
												<h5>Add Rolls To Movies</h5>
										</a>
									</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody></table>
		<!--/div>
		<Banner logo table (end)-->

   <form  method="GET">
    <P><h4>
	Firstname: <input type="text" name="first"  maxlength="50"/><br>
	Lastname: <input type="text" name="last"  maxlength="50"/><br>
	Date of Birth-Month : <select id="select3" name="dobm">
			<option  value="1">January</option>
			<option value="2">February</option>
			<option  value="3">March</option>
			<option value="4">April</option>
			<option  value="5">May</option>
			<option  value="6">June</option>
			<option value="7">July</option>
			<option  value="8">August</option>
			<option  value="9">September</option>
			<option  value="10">October</option>
			<option value="11">November</option>
			<option value="12">December</option>
			</select>
		Day(dd): <input type="text" name="dobd" size=3 maxlength="2"/>
		Year (yyyy): <input type="text" name="doby" size=5 maxlength="4"/><br>
	Date of Death-Month : <select id="select2" name="dodm">
			<option  value="0" selected>None</option>
			<option  value="1">January</option>
			<option value="2">February</option>
			<option  value="3">March</option>
			<option value="4">April</option>
			<option  value="5">May</option>
			<option  value="6">June</option>
			<option value="7">July</option>
			<option  value="8">August</option>
			<option  value="9">September</option>
			<option  value="10">October</option>
			<option value="11">November</option>
			<option value="12">December</option>
			</select>
		Day(dd): <input type="text" name="dodd" size=3 maxlength="2"/>
		Year (yyyy): <input type="text" name="dody" size=5 maxlength="4"/><br>
	Select Gender : <select id="select1" name="sex">
			<option value="Female" selected>Female</option>
			<option value="Male">Male</option>
			<option value="Transgender">Transgender</option>
			</select>
			<br>
	<input type="radio" value="1" name="actor" checked="checked"> Actor Record<br>
	<input type="radio" value="0" name="actor"> Director Record<br>
	</p></h4>
		<input type="submit" value="Add Record" />
   </form>
   <br>
    <?php

    if($_GET["last"] && $_GET["first"] && $_GET["doby"])
    {
	    $first = $_GET["first"];
		$last=$_GET["last"];
		$sex = $_GET["sex"];
		$dob = $_GET["doby"].$_GET["dobm"].$_GET["dobd"];
		$dod = $_GET["dody"].$_GET["dodm"].$_GET["dodd"];
		$actor = $_GET["actor"];
		if ($_GET["dobd"] > 31 || $_GET["dobd"] < 1) {
			print 'Invalid date of birth: '.$_GET["dobd"].'<br>';
			exit;
		}
	    if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link)) {
			echo "Select DB CS143 Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$pattern='/[\012\013\014\015]/';
		$slashchk="\0..\37!@\@\177..\377";
		//$pattern[1]='/[\073]{1}$/';
		//print "pattern=".$pattern[0]." ".$pattern[1]."<br>";
		$last = preg_replace($pattern, ' ', $last);
		$last = addcslashes($last, $slashchk);
		$first = preg_replace($pattern, ' ', $first);
		$first = addcslashes($first, $slashchk);

		// get person id
		$result = mysql_query("update MaxPersonID set id=id+1", $link);
		if (!$result) {
		    print "Update Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request
		$result = mysql_query("select * from MaxPersonID", $link);
		if (!$result) {
		    print "Update Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_num_rows($result); // if select  type of query
		$row = mysql_fetch_row($result);
		$fields=mysql_num_fields($result);
		//print $nrows.' '.$fields.' '.$row."<br>";
		// Actor(id int, last varchar(20) NOT NULL, first varchar(20) NOT NULL, sex varchar(6), dob date NOT NULL, dod date)
		if ($_GET['dodm'] == 0) $dod='\\N';
		if ($actor) {
			$sql = "insert into Actor values(".$row[0].", '{$last}','{$first}','{$sex}', {$dob},{$dod})";
			$aid='Actor';
		}
		else {
			$sql = "insert into Director values(".$row[0].", '{$last}','{$first}', {$dob},{$dod})";
			$aid='Director';
		}
		//print $sql."<br>";
		$id=$row[0];
		// Now submit the query to sql
		$result = mysql_query($sql, $link);
		if (!$result) {
		    echo "Insert Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request

		mysql_close($link);
		print "<h4>Created {$nrows} {$aid} Record: {$id} </h4>";
	}
    ?>    
  </body>
</html>