<!-- 
    Document   : reviewpage.php
    Created on : Oct 28, 2008
    Author        : cody prestwood   303596543
-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
      <title>Movie Database Project 1C</title>
    		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<LINK href="./pagebasics.css" type="text/css" rel="STYLESHEET">
	</head>
	<body>
		<!--Banner logo table -->
		<!--div style="LEFT: .5in; POSITION: absolute; TOP: 0in; scroll: auto" id="Div1"-->
			<table id="Table3" align="center" border="0" cellspacing="0">
				<tbody>
					<tr>
						<td align="center" bgcolor="#000000">
							<h2>Add New<br>
								Movie Review</h2>
						</td>
						<td><IMG height="150" alt="logo banner" src="./girlfish1.jpg" width="230" border="0" name="logo"></td>
						<td valign="bottom" bgcolor="#a3b116">
							<table id="t5" border="0">
								<tbody>
									<tr>
									
									<td align="center">
										<a href="./actorpage.php">
											<h5>Add New Actor/Director</h5>
										</a>
									</td>
									<td align="center">
										<a href="./reviewpage.php">
											<h5>Submit Review</h5>
										</a>
									</td>
									<td align="center">
										<a href="./moviepage.php">
											<h5>Add Movie</h5>
										</a>
									</td>
									<td align="center">
										<a href="./querypage.php">
											<h5>Search by Keyword</h5></a>
										</td>
									<td align="center">
											<a href="./browseactor.php">
												<h5>Browse Actors</h5>
										</a>
									</td>
									<td align="center">
											<a href="./browsemovie.php">
												<h5>Browse Movies</h5>
										</a>
									</td>
									<td align="center">
											<a href="./movieactor.php">
												<h5>Add Rolls To Movies</h5>
										</a>
									</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody></table>
		<!--/div>
		<Banner logo table (end)-->

   <form  method="GET">
    <P><h4>
	<!--iReview(name varchar(20), time timestamp, mid int references Movie(mid), rating int, comment varchar(500))-->

	Select Movie To Review: <select id="select3" name="movie">
		<!---------------------------------------------------------------------------------------------->
		<?php
		if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link))
		{
		    echo 'Could not select database';
			echo "MySQL Error: " . mysql_error($link);
			print "<br>";
		    exit;
		}
		$result = mysql_query("Select id,title,year from Movie where title > '0' order by title", $link);
		// loop through each record and present them
		$fields=mysql_num_fields($result);
		while ($row = mysql_fetch_row($result))
		{ 
			// option value
			print '<option value="'.$row[0].'">'.$row[1].' ('.$row[2].')</option>';
		}
		mysql_close($link);
		?>
		<!---------------------------------------------------------------------------------------------->
		</select><br>
			Your name or email : <input type="text" name="title" size="20" maxlength="20"/><br>
	Select Star Rating : <select id="select1" name="rating">
			<option value="1" selected>1 Star-Terrible</option>
			<option value="2">2 Stars-Mediocre</option>
			<option value="3">3 Stars-Average</option>
			<option value="4">4 Stars-Good</option>
			<option value="5">5 Stars-Fantastic</option>
			</select>
			<br>
	<u>Your Comments:</u><br> <TEXTAREA id="Textarea1" name="calcstr" rows="5" cols="50" maxlength="500"></TEXTAREA><br>
		</p></h4>
		<input type="submit" value="Submit Review" />
   </form>
   <br>
    <?php

    if($_GET["title"])
    {
	    $title = $_GET["title"];
		$rate=$_GET["rating"];
		$comp = $_GET["calcstr"];
		$mid = $_GET["movie"];

	    if (!$link = mysql_connect("localhost", "cs143", "")) 
		{
		    echo 'Could not connect to mysql';
		    exit;
		}
		if (!mysql_select_db("CS143", $link)) {
			echo "Select DB CS143 Error: " . mysql_error($link)."<br>";
		    exit;
		}

		$pattern='/[\012\013\014\015]/';
		$slashchk="\0..\37!@\@\177..\377";
		//$pattern[1]='/[\073]{1}$/';
		//print "pattern=".$pattern[0]." ".$pattern[1]."<br>";
		$title = preg_replace($pattern, ' ', $title);
		$title = addcslashes($title, $slashchk);
		$comp = preg_replace($pattern, ' ', $comp);
		$comp = addcslashes($comp, $slashchk);

		// Movie(id, title, year, rating, company)
		// add the review to the database
		$sql = "insert into Review values( '{$title}',now(),{$mid},{$rate}, '{$comp}')";
		print $sql."<br>";
		// Now submit the query to sql
		$result = mysql_query($sql, $link);
		if (!$result) {
		    echo "Insert Error: " . mysql_error($link)."<br>";
		    exit;
		}
		$nrows = mysql_affected_rows($link); // if non-select type request

		mysql_close($link);
		print "<h4>Submitted {$nrows} Review Record</h4>";
	}
    ?>    
  </body>
</html>