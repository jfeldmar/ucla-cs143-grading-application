<?php

	function CreateDirectorMovieRelation($mid, $pid)
	{
		$queryString = "INSERT INTO MovieDirector
						VALUES ('$mid', '$pid')";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
	
	}
	
	function CreateActorMovieRelation($mid, $pid, $role)
	{
		$queryString = "INSERT INTO MovieActor
						VALUES ('$mid', '$pid', '$role')";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
	
	}
	
	$pid = $_POST["pid"];
	$mid = $_GET["MID"];
	$role = $_POST["role"];
	$job = $_GET["JOB"];
	
	
	$noPid = 0;
	
	if (!$pid)
		$noPid = 1;


	if ($noPid)
	{
		header("location: addpersontomovie.php?&noPid=$noPid&JOB=$job&MID=$mid");
	}
	
	

	
		
?>

<html>
	<head>
		
		<link rel="stylesheet" type="text/css" href="1C.css" />
		

	<title>Person Info Submitted</title>


	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\"><select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<?PHP

	if ($job == "Director")
		CreateDirectorMovieRelation($mid, $pid);
	else if ($job == "Actor")
		CreateActorMovieRelation($mid, $pid, $role);
	
	print "Thanks for submitting information! <a href=\"movieinfo.php?MID=$mid\">Click here</a> to return to the movie page.</br>"
	?>
</div>


</div>

	</body>
	


</html>
	
	
	
