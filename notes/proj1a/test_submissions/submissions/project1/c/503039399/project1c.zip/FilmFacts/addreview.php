<html>
	<head>
		
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<?php
		
		$noName = $_GET["noName"];
		$noStar = $_GET["noStar"];
		$noReview = $_GET["noReview"];



	function GetMovieInfo($id)
	{
		$queryString = "SELECT *
						FROM Movie
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
		
	// Returns an array of strings.
		$mid = $_GET["MID"];
	$movieInfo = array();
	$movieInfo = GetMovieInfo($mid);
	print"<title>Review Movie - $movieInfo[1]</title>";

	
?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
		<h1>Review Movie</h1>
<?php
	if ($noName + $noStar + $noReview)
		print "<h3 style=\"color: red\">Please complete all required fields.</h3>";
print"<form action=\"submitreview.php?MID=$mid\" method=\"post\">";

if ($noName)
	print "<span style=\"color: red\">Reviewer Name: </span>";
else
	print "Reviewer Name: ";


print " <input type=\"text\" name=\"reviewerName\">
<br>
<br>";

if ($noStar)
	print "<span style=\"color: red\">Movie Rating: </span>";
else
	print "Movie Rating: ";

print "<br>
<input type=\"radio\" name=\"starRating\" value=\"1\"> 1 Stars<br>
<input type=\"radio\" name=\"starRating\" value=\"2\"> 2 Stars<br>
<input type=\"radio\" name=\"starRating\" value=\"3\"> 3 Stars<br>
<input type=\"radio\" name=\"starRating\" value=\"4\"> 4 Stars<br>
<input type=\"radio\" name=\"starRating\" value=\"5\"> 5 Stars<br>
<br>";

if ($noReview)
	print "<span style=\"color: red\">Movie Review: </span>";
else
	print "Movie Review: ";
	
print "<textarea name=\"reviewText\" cols=\"80\" rows=\"7\"></textarea>
<input type=\"submit\" value=\"Submit\">
</form>";




?>
</div>




</div>

	</body>
	


</html>
	