<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Browse Movies</title>
<?php




	function GenerateMovieList()
	{
		
		
		$queryString = "SELECT id, title, year
						FROM Movie
						ORDER BY title";
						
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		$row = array();
		print "<select size=\"20\" name=\"MID\">";
		while($row =mysql_fetch_row($rs))
		{
			$mid = $row[0];
			$title = $row[1];
			$year = $row[2];
			print "<option value =\"$mid\">$title ($year)</option>";
		
		
		}
		
		
		print "</select>";
	
	
	}
		
?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<?PHP

print "<h1>Choose a Movie</h1>";



print "<form action=\"movieinfo.php\" method=\"get\">";

GenerateMovieList();
print "<br><br>";


?>
<br>
<input type="submit" value="Submit">
</form>
</div>



</body>
</html>
