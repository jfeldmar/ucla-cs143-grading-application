<?php



	function PostReview($rd)
	{
	
		$queryString = "INSERT INTO Review
						VALUES ('$rd[0]', '$rd[1]', '$rd[2]', '$rd[3]', '$rd[4]')";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		mysql_query($queryString, $db_connection);
		
		mysql_close($db_connection);
	
	
	
	}
	
	function GetMovieInfo($id)
	{
		$queryString = "SELECT *
						FROM Movie
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
	// Returns a database object
	function GetMovieReviews($id)
	{
		$queryString = "SELECT *
						FROM MovieReview
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
	// Returns an array of strings.
	function GetMovieGenres($id)
	{
		$queryString = "SELECT genre
						FROM MovieGenre
						WHERE mid=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		
		$movieGenre = array();
		$temp = array();
		while($temp = mysql_fetch_row($rs))
		{
			$movieGenre[] = $temp[0];
		}
			
		return $movieGenre;
	
	}
	
	function PrintMovieGenres($movieGenres)
	{
		while(count($movieGenres) > 1)
			print array_pop($movieGenres) . ", ";
		print array_pop($movieGenres);
		
	}
	
	
	function PrintDirectorList($id)
	{
		$queryString = "SELECT id, last, first
						FROM Director
						WHERE id in (
							SELECT did
							FROM MovieDirector
							WHERE mid=$id )";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		
		
		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$DID = $row[0];
			$last = $row[1];
			$first = $row[2];
			$printString = $printString . "<li><a href=\"personinfo.php?id=$DID\">$first $last</a></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	}
	
	function PrintActorList($id)
	{
		$queryString = "SELECT id, last, first, role
						FROM Actor A, MovieActor MA
						WHERE MA.mid = $id AND A.id = MA.aid";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		
		
		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$AID = $row[0];
			$last = $row[1];
			$first = $row[2];
			$role = $row[3];
			$printString = $printString . "<li><a href=\"personinfo.php?id=$AID\">$first $last</a><span class=\"moviedetails\"> - $role</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
		
	}
	
	
	
	$reviewerName = $_POST["reviewerName"];
	$starRating = $_POST["starRating"];
	$reviewTime = date ("Y-m-d H:i:s", time());
	$mid = $_GET["MID"];
	$movieReview = $_POST["reviewText"];
	$reviewData = array($reviewerName, $reviewTime, $mid, $starRating, $movieReview);
	
	
	$noName = 0;
	$noStar = 0;
	$noText = 0;
	$noMID = 0;
	
	if (!$starRating)
	{
		//print "NO STAR!";
		$noStar = 1;
	}
	if (!$reviewerName)
	{
		//print "NO NAME!";
		$noName = 1;
	}
	if (!$movieReview)
	{
		//print "NO REVIEW!";
		$noReview = 1;
	}
	if (!$mid)
	{
		//print "NO MID!";
		$noMid = 1;
	}
	
	if ($noStar + $noName + $noText + $noMid)
	{
		header("location: addreview.php?MID=$mid&noStar=$noStar&noName=$noName&noReview=$noReview&noMid=$noMid");
	}


	
	$mid = $_GET["MID"];
	$movieInfo = array();
	$movieInfo = GetMovieInfo($mid);
	
?>

<html>
	<head>
		
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Movie Review Submitted</title>
		
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<?PHP
	if (!($noStar + $noName + $noText + $noMid))
		PostReview($reviewData);
	
	print "Thanks for submitting a review! <a href=\"movieinfo.php?MID=$mid\">Click here</a> to return to the movie page.</br>"
	?>
</div>



</div>

	</body>
	


</html>
	
	
	
