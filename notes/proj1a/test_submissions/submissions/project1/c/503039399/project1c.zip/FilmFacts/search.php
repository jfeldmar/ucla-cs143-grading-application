<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Search Results</title>
<?php

// Function Definitions
	function generateTableFromQuery($queryString)
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);

		//$sanitized_name = mysql_real_escape_string($name, $db_connection);
		//$query_to_issue = sprintf($queryString, $sanitized_name);

		$rs = mysql_query($queryString, $db_connection);
		print "<table border=\"1\"><tr>";
		$numCols = 0;
		$colNames = array ();// Store the column names in $colNames
							 // and save the number of columns in the table in $numCols
		while ($tableInfo = mysql_fetch_field($rs))
		{
			$colNames[$numCols] = $tableInfo->name;
			$numCols++;
		}
		
		
		// Create the table headers
		for($i=0; $i<$numCols; $i++)
			print "<td class=\"hed\">" . $colNames[$i] . "</td>";

		print "</tr>";


		while($row = mysql_fetch_row($rs)) {
			print "<tr>";
			for($i=0; $i<$numCols; $i++)
			{
				if ($row[$i] == NULL)
					print "<td>N/A</td>";
				else
					print "<td>" . $row[$i] . "</td>";
			}
			print "</tr>";
		}
		print "</table>";
		print $printString;		
		mysql_close($db_connection);


	}
	
	
	function PrintActorTable($queryString, $sortBy)
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else
		{
		$printString = "<ul class=\"person\">";

		while($row = mysql_fetch_row($rs)) {
			$AID = $row[0];
			if ($sortBy == "last")
				$actorName = "$row[1], " . "$row[2]";
			else
				$actorName = "$row[2] " . "$row[1]";

			$printString = $printString . "<li><a href=\"personinfo.php?id=$AID\">$actorName</a></li>";

			}

		$printString = $printString . "</ul>";

		}

		print $printString;
		mysql_close($db_connection);
	
	}
	
	function PrintDirectorTable($queryString, $sortBy)
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		// $printString = $printString . 
		else {
		$printString = "<ul class=\"person\">";
		while($row = mysql_fetch_row($rs)) {
			$DID = $row[0];
			if ($sortBy == "last")
				$directorName = "$row[1], " . "$row[2]";
			else
				$directorName = "$row[2] " . "$row[1]";
			$printString = $printString . "<li><a href=\"personinfo.php?id=$DID\">$directorName</a></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	
	}

	function PrintMovieTable($queryString)
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$MID = $row[0];
			$movieTitle = $row[1];
			$movieYear = $row[2];
			$movieMPAARating = $row[3];
			$movieCompany = $row[4];
			$printString = $printString . "<li><a href=\"MovieInfo.php?MID=$MID\">$movieTitle</a>  [$movieMPAARating] <span class=\"moviedetails\">($movieYear, $movieCompany)</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	
	}
	
// SearchActorsByName($searchString) takes a whitespace-delimited string and returns a
// string containing a SQL SELECT query.  The query searches the Actor for tuples
// where the begining of 'first' OR 'last' match the entries in $searchString

	function SearchActorsByName($searchString,$sortBy)
	{
		
		$keywords = array();
		$keywords = explode(" ", $searchString);
		$numKeywords = sizeof($keywords);
		$sqlQuery = "
		SELECT *
		FROM Actor
		WHERE ";
		for($i = 0; $i < $numKeywords; $i++)
		{
			$sqlQuery = $sqlQuery . "(first LIKE \"$keywords[$i]%\" OR last LIKE \"$keywords[$i]%\")";
			
			if ($i != $numKeywords-1)
			{
				 $sqlQuery = $sqlQuery . " AND ";
			}
			
				

		}
		$sqlQuery = $sqlQuery . "ORDER BY " . $sortBy;
		return $sqlQuery;
	}


	function SearchDirectorsByName($searchString, $sortBy)
	{
		$keywords = array();
		$keywords = explode(" ", $searchString);
		$numKeywords = sizeof($keywords);
		$sqlQuery = "
		SELECT *
		FROM Director
		WHERE ";
		for($i = 0; $i < $numKeywords; $i++)
		{
			$sqlQuery = $sqlQuery . "(first LIKE \"$keywords[$i]%\" OR last LIKE \"$keywords[$i]%\")";
			
			if ($i != $numKeywords-1)
			{
				 $sqlQuery = $sqlQuery . " AND ";
			}

				

		}
		$sqlQuery = $sqlQuery . "ORDER BY " . $sortBy;
		return $sqlQuery;
	}
	
	
	function SearchMoviesByName($searchString)
	{
		$keywords = array();
		$keywords = explode(" ", $searchString);
		$numKeywords = sizeof($keywords);
		$sqlQuery = "
		SELECT *
		FROM Movie
		WHERE ";
		for($i = 0; $i < $numKeywords; $i++)
		{
			$sqlQuery = $sqlQuery . "(title LIKE \"%$keywords[$i]%\")";
			
			if ($i != $numKeywords-1)
			{
				 $sqlQuery = $sqlQuery . " AND ";
			}

				

		}
		
		return $sqlQuery;
	
	
	}

?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\"><select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<div id="searchresults">
<h1>Search Results<br></h1>

	<?php

	$searchQuery = $_GET["searchQuery"];
	$category = $_GET["category"];
	$actorSort = $_GET["actorSort"];
	$directorSort = $_GET["directorSort"];
	$searchStringActor = "category=$category&searchQuery=$searchQuery&directorSort=$directorSort";
	$searchStringDirector = "category=$category&searchQuery=$searchQuery&actorSort=$actorSort";

	if ($actorSort != "first" && $actorSort != "last")
		$actorSort = "first";
	if ($directorSort != "first" && $directorSort != "last")
		$directorSort = "first";
		
	if ($searchQuery == "")
		print "Please enter a search query.";
	else
	{
	
	if ($category == "actors" || $category == "all")
	{
		$actorQuery = SearchActorsByName($searchQuery, $actorSort);
		print "<h2>Actors</h2>";
		print "<i>Sort By: <a href=\"search.php?$searchStringActor&actorSort=first\">First Last</a> or <a href=\"search.php?$searchStringActor&actorSort=last\">Last, First</a></i><br>";
		PrintActorTable($actorQuery, $actorSort);
		print "<br>";


	}
	if ($category == "movies" || $category == "all") 
	{
		$movieQuery = SearchMoviesByName($searchQuery);
		print "<h2>Movies</h2>";
		PrintMovieTable($movieQuery);
		print "<br>";

	}
	if ($category == "directors" || $category == "all") 
	{
		$directorQuery = SearchDirectorsByName($searchQuery, $directorSort);
		print "<h2>Directors</h2>";
		print "<i>Sort By: <a href=\"search.php?$searchStringDirector&directorSort=first\">First Last</a> or <a href=\"search.php?$searchStringDirector&directorSort=last\">Last, First</a></i><br>";
		PrintDirectorTable($directorQuery, $directorSort);
		print "<br>";

	}

	

	
	}
	?>
	
</div>
	
	
	
</div>






</div>

	</body>
	


</html>