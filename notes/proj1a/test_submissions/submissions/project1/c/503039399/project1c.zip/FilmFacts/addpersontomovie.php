<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Add a Person</title>
<?php


		$mid = $_GET["MID"];
		$job = $_GET["JOB"];
	
	
	function GetMovieTitle($id)
	{
		$queryString = "SELECT title
						FROM Movie
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		$name = array();
		$name = mysql_fetch_row($rs);
		return $name[0];
	
	}
	function GeneratePersonList($job, $name)
	{
		
		
		$queryString = "SELECT *
						FROM $job
						ORDER BY first";
						
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		$row = array();
		print "<select size=\"20\" name=\"$name\">";
		while($row =mysql_fetch_row($rs))
		{
			$aid = $row[0];
			$last = $row[1];
			$first = $row[2];
			print "<option value =\"$aid\">$first $last</option>";
		
		
		}
		
		
		print "</select>";
	
	
	}
		
	function GenerateDateOption($monthTarget, $dayTarget, $yearTarget, $death, $ti1, $ti2, $ti3)
	{
		$monthNames = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
		print "<select name=\"$monthTarget\" tabindex=\"$ti1\">";
		if ($death)
			print "<option value=\"0\"></option>";
		for ($m=1; $m<=12; $m++)
			print "<option value=\"$m\">" . $monthNames[$m-1] . "</option>";
		print "</select>";
		

		print "<select name=\"$dayTarget\" tabindex=\"$ti2\">";
		if ($death)
			print "<option value=\"0\"></option>";
		for ($d=1; $d<=31; $d++)
			print "<option value=\"$d\">$d</option>";
		print "</select>";


		print "<select name=\"$yearTarget\" tabindex=\"$ti3\">";		
		if ($death)
			print "<option value=\"0\"></option>";
		for ($y=2008; $y>=1890; $y--)
			print "<option value=\"$y\">$y</option>";
		print "</select>";
	
	
	}
	
	$movieTitle = GetMovieTitle($mid);

?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<?PHP
if($job == "Director")
	print "<h1>Add a Director to <i>$movieTitle</i></h1>";
if($job == "Actor")
	print "<h1>Add an Actor to $movieTitle</h1>";



print "<form action=\"submitpersontomovie.php?JOB=$job&MID=$mid\" method=\"post\">";

GeneratePersonList($job, "pid");
print "<br><br>";
if ($job == "Actor")
	print "Role: <input type=\"text\" name=\"role\" size=\"50\">";
	
print "<br><br>";

?>
<br>
<input type="submit" value="Submit">
</form>
</div>



</body>
</html>
