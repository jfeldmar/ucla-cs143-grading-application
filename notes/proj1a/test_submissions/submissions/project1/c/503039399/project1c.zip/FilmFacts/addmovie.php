
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Add a Movie</title>
<?php


		$noTitle = $_GET["noTitle"];
		$noCompany = $_GET["noCompany"];

	function GenerateYearOption($target, $ti)
	{

		print "<select name=\"$target\" tabindex=\"$ti\">";		
		for ($y=2008; $y>=1890; $y--)
			print "<option value=\"$y\">$y</option>";
		print "</select>";
	
	
	}
	


?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<h1>Add Movie</h1>
<?php
	if ($noTitle + $noCompany)
		print "<h3 style=\"color: red\">Please complete all required fields.</h3>";
		?>
<form action="submitmovie.php" method="post">
<?php

if ($noTitle)
	print "<span style=\"color: red\">Title: </span>";
else
	print "Title: ";

print "<input type=\"text\" name=\"title\" tabindex=\"4\"><br>";

if ($noCompany)
	print "<span style=\"color: red\">Company: </span>";
else
	print "Company: ";

print "<input type=\"text\" name=\"company\" tabindex=\"4\"><br>";

	
?>
Rating: <select name="rating" tabindex="6">
<option value="G">G</option>
<option value="PG">PG</option>
<option value="PG-13">PG-13</option>
<option value="R">R</option>
<option value="NC-17">NC-17</option>
<option value="NR">NR</option>
</select>
<br>
Year: 
<?php GenerateYearOption("year", 7); ?>
<br>
Genre(s):
<input type="text" name="genres" tabindex="8"><br>(enter multiple genres seperated by commas, i.e. "Action, Adventure")<br>
<input type="submit" value="Submit" tabindex="13">

</div>



</body>
</html>
