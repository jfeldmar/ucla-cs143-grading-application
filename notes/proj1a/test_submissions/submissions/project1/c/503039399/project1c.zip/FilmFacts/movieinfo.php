<html>
	<head>
		
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<?php


	function GetMovieInfo($id)
	{
		$queryString = "SELECT *
						FROM Movie
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
	function GetAverageScore($mid)
	{
	$queryString = "SELECT AVG(rating)
					FROM Review
					WHERE mid=$mid
					GROUP BY mid;";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		if (mysql_num_rows($rs) == 0)
			return "No Reviews";
		else
		{
			$answer = array();
			$answer = mysql_fetch_row($rs);
			return round($answer[0], 1);
		}
	
	
	
	
	
	}
	// Returns a database object
	function GetMovieReviews($id)
	{
		$queryString = "SELECT *
						FROM Review
						WHERE mid=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return $rs;

	
	}
	
	// Returns an array of strings.
	function GetMovieGenres($id)
	{
		$queryString = "SELECT genre
						FROM MovieGenre
						WHERE mid=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		
		$movieGenre = array();
		$temp = array();
		while($temp = mysql_fetch_row($rs))
		{
			$movieGenre[] = $temp[0];
		}
			
		return $movieGenre;
	
	}
	
	function PrintMovieGenres($movieGenres)
	{
		while(count($movieGenres) > 1)
			print array_pop($movieGenres) . ", ";
		print array_pop($movieGenres);
		
	}
	
	
	function PrintDirectorList($id)
	{
		$queryString = "SELECT id, last, first
						FROM Director
						WHERE id in (
							SELECT did
							FROM MovieDirector
							WHERE mid=$id )";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		
		
		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$DID = $row[0];
			$last = $row[1];
			$first = $row[2];
			$printString = $printString . "<li><a href=\"personinfo.php?id=$DID\">$first $last</a></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	}
	
	function PrintActorList($id)
	{
		$queryString = "SELECT id, last, first, role
						FROM Actor A, MovieActor MA
						WHERE MA.mid = $id AND A.id = MA.aid";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		
		
		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$AID = $row[0];
			$last = $row[1];
			$first = $row[2];
			$role = $row[3];
			$printString = $printString . "<li><a href=\"personinfo.php?id=$AID\">$first $last</a><span class=\"moviedetails\"> - $role</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
		
	}
	$mid = $_GET["MID"];
	$movieInfo = array();
	$movieInfo = GetMovieInfo($mid);
	print"<title>Movie Details - $movieInfo[1]</title>";

	
?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
	
	<?php
		$mid = $_GET["MID"];
		$movieInfo = array(); // MID, Title, Year, Rating, Company
		$movieGenres = array();
		$movieInfo = GetMovieInfo($mid);
		$movieGenres = GetMovieGenres($mid);
		$aveReview = GetAverageScore($mid);
		
		print "<h1>$movieInfo[1] ($movieInfo[2]) [$movieInfo[3]]</h1>";
		
		print "Studio: $movieInfo[4]<br>";
		print "Genre(s): ";
		PrintMovieGenres($movieGenres);
		print "<br>Average Review Score: $aveReview stars<br>";
		
		
		print "<h2>Director(s) (<a href=\"addpersontomovie.php?JOB=Director&MID=$mid\">Add a director</a>)</h2>";
		PrintDirectorList($mid);
		print "<h2>Actors (<a href=\"addpersontomovie.php?JOB=Actor&MID=$mid\">Add an actor</a>)</h2>";
		PrintActorList($mid);
		
		$rs = GetMovieReviews($mid);
	

		print "<div id=\"moviereviewsection\">";
		print "<h3>User Reviews (<a href=\"addreview.php?MID=$mid\">Review this movie</a>)</h3>";
		
		if (mysql_num_rows($rs) == 0)
		{
			print "No one has reviewed this movie! <a href=\"addreview.php?MID=$mid\">Click Here</a> to add your review.";
		
		}
		while ($row = mysql_fetch_row($rs))
		{
			$reviewDate = date("m/d/Y",strtotime($row[1]));
			print "<div id=\"moviereview\">";
			print "Reviewd By: $row[0] on $reviewDate<br>";
			print "$row[3] stars<br><br>";
			print "$row[4]";
			print "</div>";

		}
		print "<div id=\"moviereviewsection\">";
		
		
		print "</div>";
		
		
		
		
		
		print "</div>";
	?>
	
</div>
	
	
	




</div>

	</body>
	


</html>