CS 143 Project 1C
Rob Green
503039399

FilmFacts is a movie database website, similar to IMDb.  It stores data about movies, actors, directors, and the relations between them.  It stores which actors are in which movies, and who directed the movies.  Each movie also can have multiple user-submitted movie reviews, each with a rating of 1-5 stars.  

Users are able to add new movies to the database, specifiying their title, studio, year made, and genres.  They are also able to later add actors, directors, and genres to the movie.

The can add new actors and directors to the database as well and then later associate them with movies.

The site can be navigated in two ways.  First, a search box is available on every page of the site, allowing users to search for actors, directors, and movies.  The search results for actors and directors can be sorted by either first or last name.  Users are also able to browse all of the actors, directors, and movies in the database using browse links in the left sidebar of every page.  

Each person in the database has its own page.  The actor and director pages list information about the person such as their date of birth and gender.  Also listed on the page is his or her filmography which is a list of links to movies they have directed or acted in.  

Movies also have their own page on the site.  There listed is its year, company, and average user rating.  Users can add actors, directors, and reviews to the movie.  

