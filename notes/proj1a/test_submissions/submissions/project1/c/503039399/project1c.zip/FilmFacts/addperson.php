<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
		<title>Add a Person</title>
<?php


		$noFirst = $_GET["noFirst"];
		$noLast = $_GET["noLast"];

	function GenerateDateOption($monthTarget, $dayTarget, $yearTarget, $death, $ti1, $ti2, $ti3)
	{
		$monthNames = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
		print "<select name=\"$monthTarget\" tabindex=\"$ti1\">";
		if ($death)
			print "<option value=\"0\"></option>";
		for ($m=1; $m<=12; $m++)
			print "<option value=\"$m\">" . $monthNames[$m-1] . "</option>";
		print "</select>";
		

		print "<select name=\"$dayTarget\" tabindex=\"$ti2\">";
		if ($death)
			print "<option value=\"0\"></option>";
		for ($d=1; $d<=31; $d++)
			print "<option value=\"$d\">$d</option>";
		print "</select>";


		print "<select name=\"$yearTarget\" tabindex=\"$ti3\">";		
		if ($death)
			print "<option value=\"0\"></option>";
		for ($y=2008; $y>=1890; $y--)
			print "<option value=\"$y\">$y</option>";
		print "</select>";
	
	
	}
	

?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\">
			search
			<select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
<h1>Add an Actor or a Director</h1>
<?php
	if ($noFirst + $noLast)
		print "<h3 style=\"color: red\">Please complete all required fields.</h3>";
		?>
<form action="submitperson.php" method="post">
<input type="radio" name="Job" value="actor" tabindex="1" checked>Actor<br>
<input type="radio" name="Job"value="director" tabindex="2">Director<br>
<input type="radio" name="Job" value="both" tabindex="3">Both<br>
<?php

if ($noFirst)
	print "<span style=\"color: red\">First Name: </span>";
else
	print "First Name: ";

print "<input type=\"text\" name=\"first\" tabindex=\"4\"><br>";

if ($noLast)
	print "<span style=\"color: red\">Last Name: </span>";
else
	print "Last Name: ";

print "<input type=\"text\" name=\"last\" tabindex=\"4\"><br>";

	
?>
Sex: <select name="sex" tabindex="6">
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
<br>
Date of Birth: 
<?php GenerateDateOption("DOBM", "DOBD", "DOBY", 0, 7, 8, 9); ?>
<br>
Date of Death:
<?php GenerateDateOption("DODM", "DODD", "DODY", 1, 10, 11, 12); ?>
<br>
<input type="submit" value="Submit" tabindex="13">

</div>



</body>
</html>
