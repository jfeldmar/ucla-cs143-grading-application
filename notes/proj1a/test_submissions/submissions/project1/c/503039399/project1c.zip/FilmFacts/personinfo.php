<html>
	<head>
		<link rel="stylesheet" type="text/css" href="1C.css" />
<?php



	function IsActor($id)
	{
		$queryString = "SELECT *
						FROM Actor
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);
		return mysql_num_rows($rs);
		
	}
	
	function IsDirector($id)
	{
		$queryString = "SELECT *
						FROM Director
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_num_rows($rs);
	}
	
	function GetActorInfo($id)
	{
		$queryString = "SELECT *
						FROM Actor
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
	
	function GetDirectorInfo($id)
	{
		$queryString = "SELECT *
						FROM Director
						WHERE id=$id";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		mysql_close($db_connection);

		return mysql_fetch_row($rs);
	
	}
	
	
	function PrintActedMoviesList($id)
	{
		$queryString = "SELECT id, title, year, role
						FROM (SELECT * FROM Movie M, MovieActor MA where M.id=MA.mid) MwR
						WHERE aid=$id AND id IN (
							SELECT mid
							FROM MovieActor
							WHERE aid=$id)
						ORDER BY year DESC";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$MID = $row[0];
			$movieTitle = $row[1];
			$movieYear = $row[2];
			$movieRole = $row[3];
			$printString = $printString . "<li><a href=\"MovieInfo.php?MID=$MID\">$movieTitle</a><span class=\"moviedetails\"> ($movieYear) - $movieRole</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	
	}
	
function PrintDirectedMoviesList($id)
	{
		$queryString = "SELECT id, title, year
						From Movie 
						WHERE id IN 
							(SELECT mid FROM MovieDirector WHERE did=$id)
						ORDER BY year DESC";
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$MID = $row[0];
			$movieTitle = $row[1];
			$movieYear = $row[2];
			$printString = $printString . "<li><a href=\"MovieInfo.php?MID=$MID\">$movieTitle</a><span class=\"moviedetails\"> ($movieYear)</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	

	
	
	
	}
	
// Function Definitions
	function PrintMovieTable($queryString)
	{
		$db_connection = mysql_connect("localhost", "cs143", "");
		mysql_select_db("CS143", $db_connection);
		$rs = mysql_query($queryString, $db_connection);
		

		if (mysql_num_rows($rs) == 0)
		{
			$printString = $printString . "<ul class=\"noresults\"><li>No Results.</li></ul>";
		}
		else {
		$printString = "<ul class=\"movie\">";

		while($row = mysql_fetch_row($rs)) {
			$MID = $row[0];
			$movieTitle = $row[1];
			$movieYear = $row[2];
			$movieMPAARating = $row[3];
			$movieCompany = $row[4];
			$printString = $printString . "<li><a href=\"MovieInfo.php?MID=$MID\">$movieTitle</a>  [$movieMPAARating] <span class=\"moviedetails\">($movieYear, $movieCompany)</span></li>";
						

			}
		$printString = $printString . "</ul>";

		}
		
		print $printString;		
		mysql_close($db_connection);
	
	}
		print "<title>Person Details</title>";



?>
	</head>
	
	<body>
<div id="header">
	
		<div id="headerleft">
			<a href="index.html"><img src="images/logo.png"></a>
		</div>
		
		<div id="headerright">
			
			<?php
			$searchQuery = $_GET["searchQuery"];
			$category = $_GET["category"];
			print "
			<form method=\"get\" action=\"search.php\" id=\"headersearch\"><select name=\"category\">";
			if ($category == "all")
				print "<option value=\"all\" selected=\"selected\">all</option>";
			else print "<option value=\"all\">all</option>";
			
			if ($category == "actors")
				print "<option value=\"actors\" selected=\"selected\">actors</option>";
			else print "<option value=\"actors\">actors</option>";
			
			if ($category == "movies")
				print "<option value=\"movies\" selected=\"selected\">movies</option>";
			else print "<option value=\"movies\">movies</option>";
			
			if ($category == "directors")
				print "<option value=\"directors\" selected=\"selected\">directors</option>";
			else print "<option value=\"directors\">directors</option>";

			
			
			print "
			</select>
			<input type=\"text\" name=\"searchQuery\" size=\"20\" value=\"$searchQuery\">
			<input type=\"submit\" value=\"Search\">
			</form>"
			?>
			
		</div>
		
</div>
<div id="frame">
<div id="leftcol">
<a href="addmovie.php">Add Movie</a><br>
<a href="addperson.php">Add an Actor or a Director</a><br>
<a href="browsemovies.php">Browse Movies</a><br>
<a href="browseactors.php">Browse Actors</a><br>
<a href="browsedirectors.php">Browse Directors</a><br>
</div>

<div id="content">
	
	<?php
		$id = $_GET["id"];
		$isActor = IsActor($id);
		$isDirector = IsDirector($id);
		if ($isActor + $isDirector == 0)
			print "Sorry, that person does not exist in the database.";
		else
		{
			$personInfo = array();
			if ($isActor)
				$personInfo = GetActorInfo($id);
			else if ($isDirector)
			{
				$tempInfo = array();
				$tempInfo = GetDirectorInfo($id);	
				$personInfo[0]=$tempInfo[0]; // ID
				$personInfo[1]=$tempInfo[1]; // last name
				$personInfo[2]=$tempInfo[2]; // first name
				$personInfo[3]="";	 // sex
				$personInfo[4]=$tempInfo[3]; // DOB
				$personInfo[5]=$tempInfo[4]; // DOD
			}
			
			$PHPDOB = strtotime($personInfo[4]);
			$DOB = date("m/d/y", $PHPDOB);
			$PHPDOD = strtotime($personInfo[5]);
			if ($PHPDOD)
				$DOD = date("m/d/y", $PHPDOD);

			print "<h2>$personInfo[2] $personInfo[1] - <i>[$personInfo[3]] ($DOB - $DOD)</i></h2> ";
		
			print "<h3>Filmography</h3>";
			if ($isActor)
			{
				print "Actor";	
				print PrintActedMoviesList($id);
			}
			if ($isDirector)
			{
				print "Director";	
				print PrintDirectedMoviesList($id);
			
			}
		}
		
		?>
	
</div>
	
	
	



</div>

	</body>
	


</html>