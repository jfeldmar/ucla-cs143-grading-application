<?php
	include('./header.php');
?>
        <div class="pageName"><p>Add Actor/Director</p></div>
        <div class="bodyText">
        	<?php
        		if ( isset($_GET['submit']) && !empty($_GET['submit']) ) {
        			$identity = $_GET['identity'];
        			$first = trim(strip_tags($_GET['first']));
        			$last = trim(strip_tags($_GET['last']));
        			$gender = $_GET['sex'];
        			$dob = trim(strip_tags($_GET['dob']));
        			$dod = trim(strip_tags($_GET['dod']));
        			
        			// Check for errors
        			$errors = array();
        			if ( empty($first) ) {
        				$errors[] = 'You must provide a first name.';
        			}
        			if ( empty($last) ) {
        				$errors[] = 'You must provide a last name.';
        			}
        			// Check dates
        			if ( !empty($dob) && (($dobTimestamp = strtotime($dob)) === false) ) {
        				$errors[] = 'You must provide a date of birth in a readable format.';
        			}
        			if ( !empty($dod) && (($dodTimestamp = strtotime($dod)) === false) ) {
        				$errors[] = 'You must provide a date of death in a readable format.';
        			}
        			
        			// Convert Dates to SQL format
	        			if ( !empty($dob) )
		        			$dob = date('Y-m-d', $dobTimestamp);
	        			else
	        				$dob = null;
	        			if ( !empty($dod) )
		        			$dod = date('Y-m-d', $dodTimestamp);
	        			else
	        				$dod = null;
        			
        			// TODO: Check for duplicates if necessary?
        			
        			// Display Formatting
        			echo '<div class="subHeader">Results</div>';
					echo '<div class="formField">';
        			
        			if ( count($errors) == 0 ) {
	        			// Get the PID
	        			$sql = 'SELECT id+1 AS newId FROM MaxPersonID ORDER BY id DESC LIMIT 1';
        				$rs  = mysql_query($sql, $db_connection);
        				$row = mysql_fetch_array($rs);
        				$pid = $row['newId'];
        				$sql = sprintf("INSERT INTO MaxPersonID VALUES ('%d')",
        						$pid
        						);
        				$rs  = mysql_query($sql, $db_connection);
	        			
	        			// Construct the SQL according to the identity
	        			if ( $identity == 'Actor' ) {
	        				$sql = sprintf("INSERT INTO Actor VALUES ('%d', '%s', '%s', '%s', '%s', '%s')",
	        						$pid,
	        						mysql_real_escape_string($last),
	        						mysql_real_escape_string($first),
	        						$gender,
	        						$dob, 
	        						$dod
	        						);
	        			} else {
	        				$sql = sprintf("INSERT INTO Director VALUES ('%d', '%s', '%s', '%s', '%s')",
	        						$pid,
	        						mysql_real_escape_string($last),
	        						mysql_real_escape_string($first),
	        						$dob,
	        						$dod
	        						);
	        			}
	        			$rs  = mysql_query($sql, $db_connection);
	        			
	        			if ( $rs ) {
	        				echo '<div>Actor/Director successfully added.</div>';
	        			} else {
	        				echo '<div style="color:red;">Error inserting Actor/Director.</div>';
	        			}
        			} else {
        				// Handle Errors
    					foreach ($errors as $error) {
        					echo '<div style="color:red;">' . $error . '</div>';
        				}
        			}
        			
        			// Close the div
        			echo '</div>';
        			
	        		// Display a divider
	        			echo '<div class="divider"></div>';
        		}
        	?>
			<form action="./page_i1.php" method="GET">
            	<div>Identity</div>
                <div class="formField">
                    <input type="radio" name="identity" value="Actor" checked="true" onclick="document.getElementById('radioGender').style.display = 'block';">Actor
                    <input type="radio" name="identity" value="Director" onclick="document.getElementById('radioGender').style.display = 'none';">Director
                </div>
                <div class="divider">
                </div>
                <div>First Name</div>
                <div class="formField">
					<input type="text" name="first" style="width:300px;" maxlength="20">
                </div>
                <div>Last Name</div>
                <div class="formField">
					<input type="text" name="last" style="width:300px;" maxlength="20">
				</div>
                <div id="radioGender">
                    <div>Sex</div>
                    <div class="formField">
                        <input type="radio" name="sex" value="Male" checked="true">Male
                        <input type="radio" name="sex" value="Female">Female
                    </div>
                </div>
                <div>Date of Birth</div>
                <div class="formField">
                	<input type="text" name="dob">
                </div>
                <div>Date of Death (leave blank if alive now)</div>
                <div class="formField">
                	<input type="text" name="dod">
                </div>
                <input type="submit" name="submit" value="Add it!!"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>