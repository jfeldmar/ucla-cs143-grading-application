<?php
	include('./header.php');
?>
        <div class="pageName"><p>Add Movie Information</p></div>
        <div class="bodyText">
        	<?php
        		if ( isset($_GET['submit']) && !empty($_GET['submit']) ) {
        			// Assign fields
        			$title = trim(strip_tags($_GET['title']));
        			$company = trim(strip_tags($_GET['company']));
        			$year = trim(strip_tags($_GET['year']));
        			$did = $_GET['did'];
        			$mpaarating = $_GET['mpaarating'];
        			$genreArray = $_GET['genre'];
        			
        			// Check for complete values
        			$errors = array();
        			if ( empty($title) ) {
        				$errors[] = 'Error: The movie must have a title.';
        			}
        			if ( !empty($year) && ( $year > date('Y') || $year < 1895 || !is_numeric($year) ) ) { // 1895 = invention of the motion picture camera
        				$errors[] = 'Error: The year is not valid.';
        			}
        			// TODO: Check for duplicate movie, if necessary
        			
        			// Display Formatting
        			echo '<div class="subHeader">Results</div>';
					echo '<div class="formField">';
        			
        			if ( count($errors) == 0 ) {
        				// Create a new movie id
        				$sql = 'SELECT id+1 AS newId FROM MaxMovieID ORDER BY id DESC LIMIT 1';
        				$rs  = mysql_query($sql, $db_connection);
        				$row = mysql_fetch_array($rs);
        				$mid = $row['newId'];
        				$sql = sprintf("INSERT INTO MaxMovieID VALUES ('%d')",
        						$mid
        						);
        				$rs  = mysql_query($sql, $db_connection);
        				
        				// Insert the new movie
        				$sql = sprintf("INSERT INTO Movie VALUES ('%d', '%s', '%d', '%s', '%s')",
        						$mid,
        						mysql_real_escape_string($title),
        						$year,
        						$mpaarating,
        						mysql_real_escape_string($company)
        						);
						$rs  = mysql_query($sql, $db_connection);
						
						// Insert the Director
						if ( !empty($did) ) {
							$sql = sprintf("INSERT INTO MovieDirector VALUES ('%d', '%d')",
									$mid,
									$did
									);
							$rs  = mysql_query($sql, $db_connection) or die(mysql_error());
						}
						
						// Insert the Movie Generes
						if ( count($genreArray) > 0 ) {
							$sql = sprintf("INSERT INTO MovieGenre VALUES ('%d', '%s')",
									$mid,
									$genreArray[0]
									);
							
							for ($i = 1; $i < count($genreArray); $i++) {
								$sql .= sprintf(", ('%d', '%s')",
										$mid,
										$genreArray[$i]
										);
							}
							
							$rs  = mysql_query($sql, $db_connection);
						}
						
						echo 'Movie successfully added.';
        			} else {
        				// There are errors present
        				foreach ($errors as $error) {
        					echo '<div style="color:red;">' . $error . '</div>';
        				}
        			}
        			
        			// close the div
        			echo '</div>';
        			
        			// Display a divider
        			echo '<div class="divider"></div>';
        		}
        	?>
			<form action="./page_i3.php" method="GET">
            	<div>Title</div>
                <div class="formField">
                    <input type="text" name="title" style="width:300px;" maxlength="20">
                </div>                <div>Company</div>
                <div class="formField">
					<input type="text" name="company" style="width:300px;" maxlength="50">
                </div>
                <div>Year</div>
                <div class="formField">
					<input type="text" name="year" maxlength="4">
				</div>
                <div>Director</div>
                <div class="formField">
                	<select name="did">
						<option value="">Select a Director</option>
                		<?php
							$sql = 'SELECT id,last,first,dob FROM Director ORDER BY first ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								if ( empty($row['dob']) )
									$dob = '';
								else
									$dob = ' (Birth: ' . $row['dob'] . ')';
								
								echo '<option value="' . $row['id'] . '">' . $row['first'] . ' ' 
									. $row['last'] . $dob . '</option>';
							}
						?>
                    </select>
                </div>
                <div>MPAA Rating</div>
                <div class="formField">
                	<select name="mpaarating">
						<option value="">Select a MPAA Rating</option>
                        <option value="G">G</option>
                        <option value="NC-17">NC-17</option>
                        <option value="PG">PG</option>
                        <option value="PG-13">PG-13</option>
                        <option value="R">R</option>
						<option value="surrendere">surrendere</option>
					</select>
                </div>
                <div>Genre</div>
                <div class="formField">
                	<?php
                		// Display all the genres
                		$sql = 'SELECT genre FROM MovieGenre GROUP BY genre ORDER BY genre ASC';
                		$rs  = mysql_query($sql, $db_connection);
                		
                		while ( $row = mysql_fetch_array($rs) ) {
                			$genre = $row['genre'];
                			
                			echo '<div class="formCheckbox">';
                			//echo '<input type="checkbox" name="genre_' . $genre . '" value="' . $genre . '">' . $genre . '</input>';
                			echo '<input type="checkbox" name="genre[]" value="' . $genre . '">' . $genre . '</input>';
                			echo '</div>';
                		}
                	?>
                    <div style="clear:both;"></div>
                </div>
                <input type="submit" name="submit" value="Add it!!"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>