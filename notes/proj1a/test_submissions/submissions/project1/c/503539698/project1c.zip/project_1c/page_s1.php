<?php
	include('./header.php');
?>
        <div class="pageName"><p>Search Actor/Movie</p></div>
        <div class="bodyText">
			<form action="./page_s1.php" method="GET">	
            	<div>Search by Keyword</div>
                <div class="formField">	
                	<input type="text" name="keyword" style="width:300px;"></input>
                </div>
                <input type="submit" value="Search"/>
            </form>
            <?php
            	if ( isset($_GET['keyword']) && !empty($_GET['keyword']) ) {
            		$originalKeyword = strtolower($_GET['keyword']);
            		$keyword = explode(' ', $originalKeyword);
            		
            		// Display a divider
        			echo '<div class="divider"></div>';
        			
        			// Searching for Actor
        			$sql = sprintf("SELECT id,last,first,dob FROM Actor WHERE LCASE(first + ' ' + last) LIKE '%%%s%%'",
        					mysql_real_escape_string($originalKeyword)
        					);
            		for( $i = 0; $i < count($keyword); $i++ ) {
            			$sql .= sprintf(" OR LCASE(first) LIKE '%%%s%%'",
            					mysql_real_escape_string($keyword[$i])
            					);
            		}
            		for( $i = 0; $i < count($keyword); $i++ ) {
            			$sql .= sprintf(" OR LCASE(last) LIKE '%%%s%%'",
            					mysql_real_escape_string($keyword[$i])
            					);
            		}
            		$rs  = mysql_query($sql, $db_connection);
            		$num = @mysql_num_rows($rs);
            		
            		// Show Actor Results
					echo '<div class="subHeader">Searching match records in Actor database:</div>';
					echo '<div class="formField">';
	            		while ( $row = mysql_fetch_array($rs) ) {
	            			$aid = $row['id'];
	            			$name = ucwords($row['first'] . ' ' . $row['last']);
	            			
	            			if ( empty($row['dob']) ) {
	            				$dob = '';
	            			} else {
	            				$dob = ' (' . $row['dob'] . ')';
	            			}
	            			
	            			echo '<div>Actor: <a href="./page_b1.php?aid=' . $aid . '">' . $name . $dob . '</a></div>';
	            		}
	            		// Check for the case of 0 results
	            		if ( $num == 0 ) {
	            			echo '<div>There are no matching Actor results.</div>';
	            		}
        			echo '</div>';
        			
        			// Display a divider
        			echo '<div class="blueDivider"></div>';
            		
            		// Searching for Movie
            		$sql = sprintf("SELECT id,title,year FROM Movie WHERE LCASE(title) LIKE '%%%s%%'",
            				mysql_real_escape_string($keyword[0])
            				);
            		for( $i = 1; $i < count($keyword); $i++ ) {
            			$sql .= sprintf(" OR LCASE(title) LIKE '%%%s%%'",
            					mysql_real_escape_string($keyword[$i])
            					);
            		}
            		$rs  = mysql_query($sql, $db_connection);
            		$num = @mysql_num_rows($rs);
            		
            		// Show Movie Results
					echo '<div class="subHeader">Searching match records in Movie database:</div>';
					echo '<div class="formField">';
	            		while ( $row = mysql_fetch_array($rs) ) {
	            			$mid = $row['id'];
	            			$title = ucwords($row['title']);
	            			
	            			if ( empty($row['year']) ) {
	            				$year = '';
	            			} else {
	            				$year = ' (' . $row['year'] . ')';
	            			}
	            			
	            			echo '<div>Movie: <a href="./page_b2.php?mid=' . $mid . '">' . $title . $year . '</a></div>';
	            		}
	            		// Check for the case of 0 results
	            		if ( $num == 0 ) {
	            			echo '<div>There are no matching Movie results.</div>';
	            		}
        			echo '</div>';
            	}
            ?>
        </div>
<?php
	include('./footer.php');
?>