<?php
	include('./header.php');
?>
        <div class="pageName"><p>Show Actor Information</p></div>
        <div class="bodyText">
    		<?php
    			if ( isset($_GET['aid']) && !empty($_GET['aid']) ) {
    				$aid = trim($_GET['aid']);
    				
    				// SQL to fetch the actor information
    				$sql = sprintf("SELECT * FROM Actor WHERE id='%d'",
    						$aid
    						);
    				$rs  = mysql_query($sql, $db_connection);
    				$row = mysql_fetch_array($rs);
    				
    				// Set up Variables
    				$first = ucwords($row['first']);
    				$last = ucwords($row['last']);
    				$name = $first . ' ' . $last;
    				
    				if ( empty($row['sex']) )
    					$sex = 'N/A';
    				else
						$sex = ucwords($row['sex']);
						
					if ( empty($row['dob']) || $row['dob'] == '0000-00-00' )
						$dob = 'N/A';
					else
						$dob = $row['dob'];
						
					if ( empty($row['dod']) || $row['dod'] == '0000-00-00' )
						$dod = 'N/A';
					else
						$dod = $row['dod'];
						
					// Show Actor Info
					echo '<div class="subHeader">Show Actor Info</div>';
					echo '<div class="formField">';
	        			echo '<div>Name: ' . $name . '</div>';
	        			echo '<div>Sex: ' . $sex . '</div>';
	        			echo '<div>Date of Birth: ' . $dob . '</div>';
	        			echo '<div>Date of Death: ' . $dod . '</div>';
        			echo '</div>';
        			
        			// SQL to fetch the movie information
    				$sql = sprintf("SELECT mid,role,title FROM MovieActor MA, Movie M WHERE MA.mid = M.id AND aid='%d'",
    						$aid
    						);
    				$rs  = mysql_query($sql, $db_connection);

        			// Show Acted In
        			echo '<div class="subHeader">Acted In</div>';
					echo '<div class="formField">';
						// Display the movies the actor has been in
						while ( $row = mysql_fetch_array($rs) ) {
							$mid = $row['mid'];
		    				$title = ucwords($row['title']);
		    				
		    				if ( empty($row['role']) )
		    					$role = '';
							else
			    				$role = '&#8220;' . $row['role'] . '&#8221; ';
			    				
		    				echo '<div>Act ' . $role . ' in <a href="./page_b2.php?mid=' . $mid . '">' . $title . '</a></div>';
						}
        			echo '</div>';
        			
        			// Display a divider
        			echo '<div class="divider"></div>';
    			}
        	?>
			<form action="./page_b1.php" method="GET">
                <div>See Another Actor</div>
                <div class="formField">
                	<select name="aid">
                    	<?php
							$sql = 'SELECT id,last,first,dob FROM Actor ORDER BY first ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								if ( empty($row['dob']) )
									$dob = '';
								else
									$dob = ' (' . $row['dob'] . ')';
								
								echo '<option value="' . $row['id'] . '">' . $row['first'] . ' ' 
									. $row['last'] . $dob . '</option>';
							}
						?>
                    </select>
                </div>
                <input type="submit" value="Search"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>