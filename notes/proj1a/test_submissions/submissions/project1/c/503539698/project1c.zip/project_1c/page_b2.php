<?php
	include('./header.php');
?>
        <div class="pageName"><p>Show Movie Information</p></div>
        <div class="bodyText">
        	<?php
    			if ( isset($_GET['mid']) && !empty($_GET['mid']) ) {
    				$mid = trim($_GET['mid']);
    				
    				// SQL to fetch the Movie Information
    				$sql = sprintf("SELECT title, year, rating, company FROM Movie WHERE id='%d'",
    						$mid
    						);
    				$rs  = mysql_query($sql, $db_connection);
    				$row = mysql_fetch_array($rs);
    				
    				// Set up Variables
    				$title = ucwords($row['title']);
    				
    				if ( empty($row['year']) )
						$year = '';
					else
						$year = ' (' . $row['year'] . ')';
						
					if ( empty($row['rating']) )
						$rating = 'N/A';
					else
						$rating = ucwords($row['rating']);
						
					if ( empty($row['company']) )
						$company = 'N/A';
					else
						$company = ucwords($row['company']);
						
					// Fetch the director (can be multiple!)
					$sql = sprintf("SELECT last,first,dob FROM Director D, MovieDirector MD WHERE D.id=MD.did AND mid='%d' ORDER BY first ASC",
							$mid
							);
					$rs  = mysql_query($sql, $db_connection);
					$director = array();
					while ( $row = @mysql_fetch_array($rs) ) {
						$first = ucwords($row['first']);
						$last = ucwords($row['last']);
						if ( empty($row['dob']) )
							$dob = '';
						else
							$dob = ' (' . $row['dob'] . ')';
						$director[] = $first . ' ' . $last . $dob;
					}
					if ( count($director) == 0 )
						$director = 'N/A';
					else if ( count($director) == 1 )
						$director = $director[0];
					else
						$director = implode(', ', $director);
						
					// Fetch the genre (can be multiple!)
					$sql = sprintf("SELECT genre FROM MovieGenre WHERE mid='%d' ORDER BY genre ASC",
							$mid
							);
					$rs  = mysql_query($sql, $db_connection);
					$genre = array();
					while ( $row = mysql_fetch_array($rs) ) {
						$genre[] = ucwords($row['genre']);
					}
					if ( count($genre) == 0 )
						$genre = 'N/A';
					else if ( count($genre) == 1 )
						$genre = $genre[0];
					else
						$genre = implode(', ', $genre);
						
					// Show Movie Info
					echo '<div class="subHeader">Show Movie Info</div>';
					echo '<div class="formField">';
	        			echo '<div>Title: ' . $title . $year . '</div>';
	        			echo '<div>Producer: ' . $company . '</div>';
	        			echo '<div>MPAA Rating: ' . $rating . '</div>';
	        			echo '<div>Director: ' . $director . '</div>';
	        			echo '<div>Genre: ' . $genre . '</div>';
        			echo '</div>';
        			
        			// SQL to fetch the Actors Information
    				$sql = 'SELECT aid,role,last,first FROM MovieActor MA, Actor A WHERE MA.aid = A.id AND MA.mid = ' . "'" . $mid . "'";
    				$rs  = mysql_query($sql, $db_connection);
    				
    				// Show Actors Info
					echo '<div class="subHeader">Actors in this Movie</div>';
					echo '<div class="formField">';
	    				while ( $row = mysql_fetch_array($rs) ) {
	    					$name = ucwords($row['first'] . ' ' . $row['last']);
	    					$role = ucwords($row['role']);
	    					$aid = $row['aid'];
	    					
	    					echo '<div><a href="./page_b1.php?aid=' . $aid . '">' . $name .'</a> act as &#8220;' . $row['role'] . '&#8221;</div>';
	    				}
    				echo '</div>';
    				
    				// SQL to fetch the User Reviews Information
					$sql = 'SELECT name, time, rating, comment FROM Review WHERE mid = ' . "'" . $mid . "'";
    				$rs  = mysql_query($sql, $db_connection);
    				
    				$sql2 = 'SELECT AVG(rating) AS avgRating, COUNT(*) AS numReviews FROM Review WHERE mid = ' . "'" . $mid . "'";
    				$rs2  = mysql_query($sql2, $db_connection);
    				$row2 = mysql_fetch_array($rs2);
    				$avgRating = ( empty($row2['avgRating']) ) ? 0 : $row2['avgRating'];
    				$numReviews = $row2['numReviews'];
    				
    				// Show User reviews
					echo '<div class="subHeader">User Reviews</div>';
					echo '<div class="formField">';
						echo '<div>Average Score: ' . $avgRating . '/5 (5.0 is best) by ' . $numReviews . ' review(s). <a href="./page_i2.php?mid=' . $mid . '">Add your review now!!</a></div>';
	    				while ( $row = mysql_fetch_array($rs) ) {
							echo '<div class="blueDivider"></div>';
	    					$name = ucwords($row['name']);
	    					$rating = $row['rating'];
	    					$comment = $row['comment'];
	    					echo '<div>In ' . $row['time'] . ', <span style="color:red;">' . $name . '</span> said: I rate this movie <span style="color:red;">' . $rating . '</span> point(s), here is my comment:';
							echo '<div>' . $comment. '</div>';
	    				}
    				echo '</div>';
        			
        			// Display a divider
        			echo '<div class="divider"></div>';
    			}
        	?>
			<form action="./page_b2.php" method="GET">
                <div>See Another Movie</div>
                <div class="formField">
                	<select name="mid">
                		<?php
							$sql = 'SELECT id,title,year FROM Movie ORDER BY title ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								// Check for a NULL year value
								if ( empty($row['year']) )
									$year = '';
								else
									$year = ' (' . $row['year'] . ')';
								
								echo '<option value="' . $row['id'] . '">' . $row['title'] . $year . '</option>';
							}
						?>
                    </select>
                </div>
                <input type="submit" value="Search"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>