<?php
	/// Call the mysql connection at the top so it will be available 
	/// for the entire script

	// MySQL Connection
	$db_connection = mysql_connect('localhost', 'cs143', '');
	
	// Handle Connection Errors
	if ( !$db_connection ) {
		$error_message = mysql_error($db_connection);
		print 'Connection failed: ' . $error_message . '<br />';
		exit(1);
	}
	
	// Select the Database
	mysql_select_db('CS143', $db_connection);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CS 143 - Project 1C</title>
<style type="text/css">
	body {
		margin:0px;
		background-color:#64748B;
	}
		
	a {
		color: #FF6600;
		font-weight:bold;
		text-decoration:none;
	}
		
	a:hover {
		color: #FFBA00;
	}
	
	.padding {
		padding:14px;
	}
	
	.headerText {
		font:24px Times New Roman, Times, serif;
		color: #FFBA00;
		letter-spacing:.3em;
		line-height:26px;
	}
		
	.tagline {
		font: 11px Arial, Helvetica, sans-serif;
		color: #D3DCE6;
		line-height:16px;
	}
		
	.bodyText {
		font:11px Arial, Helvetica, sans-serif;
		line-height:22px;
		color:#26354A;
		letter-spacing:.1em;
	}
		
	.pageName {
		font:24px Arial, Helvetica, sans-serif;
		color: #FF6600;
		letter-spacing:.2em;
		line-height:32px;
	}
		
	.sidebarText {
		font:11px Arial, Helvetica, sans-serif;
		color: #FFBA00;
		letter-spacing:.1em;
		line-height:18px;
	}
	
	.formField {
		margin-bottom:10px;
	}
	
	.divider {
		font-size:0px;
		height:0px;
		border-bottom:1px dashed #FF6600;
		margin-bottom:10px;
		margin-top:8px;
	}
	
	.formCheckbox {
		float:left; width:110px;
	}
	
	.subHeader {
		font:bold 12px Arial, Helvetica, sans-serif;
		color: #2D374D;
		font-weight:bold;
		line-height:20px;
		letter-spacing:.1em;
	}
	
	.blueDivider {
		font-size:0px;
		height:0px;
		border-bottom:1px dashed #64748B;
		margin-bottom:10px;
		margin-top:8px;
	}
</style>
</head>

<body>
<div style="background-color:#26354A; height:70px;">
	<div class="headerText" style="padding-left:15px; padding-top:22px;">
		CS 143 - Project 1C <span class="tagline">| By Matt Snider &amp; Alan Zhao</span>
    </div>
</div>
<div style="background-color:#FF6600; height:4px; border-bottom:1px solid #D3DCE6;">
</div>
<div style="background-color:#D3DCE6; overflow:hidden;">
    <div style="width:230px; background-color:#26354A; float:left; padding-bottom: 1000em; margin-bottom: -999.5em;" class="sidebarText" id="padding">
    	<div style="padding-left:15px; padding-top:20px;">
            <div style="border-left:4px solid #FF6600; padding-left:10px;">
                ADD NEW CONTENT
            </div>
            <div class="sidebarText" style="padding:14px;">
                <a href="./page_i1.php">Add Actor/Director &gt;</a><br />
                <a href="./page_i2.php">Add Comments to Movie &gt;</a><br />
                <a href="./page_i3.php">Add Movie Information &gt;</a><br />
                <a href="./page_i4.php">Add Movie/Actor Relation &gt;</a><br />
            </div>
            <div style="border-left:4px solid #FF6600; padding-left:10px;">
                BROWSERING CONTENT
            </div>
            <div class="sidebarText" style="padding:14px;">
                <a href="./page_b1.php">Show Actor Information &gt;</a><br />
                <a href="./page_b2.php">Show Movie Information &gt;</a><br />
            </div>
            <div style="border-left:4px solid #FF6600; padding-left:10px;">
                SEARCH INTERFACE
            </div>
            <div class="sidebarText" style="padding:14px;">
                <a href="./page_s1.php">Search Actor/Movie &gt;</a><br />
            </div>
        </div>
    </div>
    <div style="width:440px; margin-left:300px; padding-top:20px; padding-bottom: 1000em; margin-bottom: -999.5em;">
