<?php
	include('./header.php');
?>
        <div class="pageName"><p>Add Movie/Actor Relation</p></div>
        <div class="bodyText">
        	<?php
        		if ( isset($_GET['role']) && !empty($_GET['role']) ) {
        			$mid = $_GET['mid'];
        			$aid = $_GET['aid'];
        			$role = trim(strip_tags($_GET['role']));
        			
        			// Check for a duplicate
					$sql = sprintf("SELECT COUNT(*) AS numRoles FROM MovieActor WHERE mid='%s' AND aid='%s' AND role='%s'", 
							$mid, 
							$aid, 
							mysql_real_escape_string($role)
							);
        			$rs  = mysql_query($sql, $db_connection);
        			$row = @mysql_fetch_array($rs);
        			$num = $row['numRoles'];
        			
        			// Display Formatting
        			echo '<div class="subHeader">Results</div>';
					echo '<div class="formField">';
						echo '<div>';
        			
        			// Check if there are duplicate inserts
        			if ( $num == 0 ) { // Then there are no duplicates
        			
	        			// SQL Insert
	        			$sql = sprintf("INSERT INTO MovieActor VALUES ('%d', '%d', '%s')",
	        					$mid,
	        					$aid,
	        					mysql_real_escape_string($role)
	        					);
	        			$rs  = mysql_query($sql, $db_connection);
	        			
	        			// Show Results
					
						
						if ( $rs ) {
	        				echo 'Movie/Actor Relation added successfully!';
	        			} else {
	        				echo '<span style="color:red;">Error inserting Movie/Actor Relation.</span>';
	        			}
	        			
        			} else { // This is a duplicate insert, let the user know
        				echo '<span style="color:red;">Error: duplicate Movie/Actor Relation.</span>';
        			}
						
						echo '</div>';
					echo '</div>';
    				
    				// Display a divider
        			echo '<div class="divider"></div>';
        		}
        	?>
			<form action="./page_i4.php" method="GET">
            	<div>Movie</div>
                <div class="formField">
                	<select name="mid">
                		<?php
							$sql = 'SELECT id,title,year FROM Movie ORDER BY title ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								// Check for a NULL year value
								if ( empty($row['year']) )
									$year = '';
								else
									$year = ' (' . $row['year'] . ')';
								
								echo '<option value="' . $row['id'] . '">' . $row['title'] . $year . '</option>';
							}
						?>
                    </select>
                </div>
                <div>Actor</div>
                <div class="formField">
                	<select name="aid">
                        <?php
							$sql = 'SELECT id,last,first,dob FROM Actor ORDER BY first ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								if ( empty($row['dob']) )
									$dob = '';
								else
									$dob = ' (' . $row['dob'] . ')';
								
								echo '<option value="' . $row['id'] . '">' . $row['first'] . ' ' 
									. $row['last'] . $dob . '</option>';
							}
						?>
                    </select>
                </div>
                <div>Role</div>
                <div class="formField">
                	<input type="text" name="role" style="width:300px;" maxlength="50">
				</div>
                <input type="submit" value="Add it!!"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>