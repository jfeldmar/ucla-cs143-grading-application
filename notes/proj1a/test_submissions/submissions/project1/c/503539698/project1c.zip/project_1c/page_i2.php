<?php
	include('./header.php');
?>
        <div class="pageName"><p>Add Comments to a Movie</p></div>
        <div class="bodyText">
        	<?php
        		if ( isset($_GET['submit']) && !empty($_GET['submit']) ) {
        			$mid = $_GET['mid'];
        			$name = trim(strip_tags($_GET['yourname']));
        			$rating = $_GET['rating'];
        			$comment = trim(strip_tags($_GET['comment']));
        			
        			$errors = array();
        			if ( empty($mid) ) {
        				$errors[] = 'You must select a movie.';
        			}
        			if ( empty($name) ) {
        				$errors[] = 'You must provide your name.';
        			}
        			
        			// Display Formatting
        			echo '<div class="subHeader">Results</div>';
					echo '<div class="formField">';
        			
        			if ( count($errors) == 0 ) { // If there were no errors in the input
	        			// Insert the review
	        			$sql = sprintf("INSERT INTO Review VALUES ('%s', NOW(), '%d', '%d', '%s')",
	        					$name,
	        					$mid,
	        					$rating,
	        					$comment
	        					);
						$rs  = mysql_query($sql, $db_connection);
						
						// Results
						echo '<div>The review was successfully added.</div>';
        			} else {
    					// Handle Errors
    					foreach ($errors as $error) {
        					echo '<div style="color:red;">' . $error . '</div>';
        				}
        			}
        			
        			// Close the div
        			echo '</div>';
        			
        			// Display a divider
        			echo '<div class="divider"></div>';
        		}
        	?>
			<form action="./page_i2.php" method="GET">
            	<div>Movie</div>
                <div class="formField">
                	<select name="mid">
                    	<?php
							$sql = 'SELECT id,title,year FROM Movie ORDER BY title ASC';
							$rs = mysql_query($sql, $db_connection);
							while ( $row = mysql_fetch_array($rs) ) {
								// Check for a NULL year value
								if ( empty($row['year']) )
									$year = '';
								else
									$year = ' (' . $row['year'] . ')';
								// Check for pre-Selected Value
								if ( isset($_GET['mid']) & !empty($_GET['mid']) && $_GET['mid'] == $row['id'] ) {
									echo '<option selected value="' . $row['id'] . '">' . $row['title'] . $year . '</option>';
								} else {
									echo '<option value="' . $row['id'] . '">' . $row['title'] . $year . '</option>';
								}
							}
						?>
                    </select>
                </div>
                <div>Your Name</div>
                <div class="formField">
                	<input type="text" name="yourname" value="Mr. Anonymous" style="width:400px;" maxlength="20">
                </div>
                <div>Rating</div>
                <div class="formField">
                	<select name="rating">
                		<option value="">Select a Rating</option>
						<option value="5"> 5 - Excellent </option>
						<option value="4"> 4 - Good </option>
						<option value="3"> 3 - It's ok </option>
						<option value="2"> 2 - Not worth </option>
						<option value="1"> 1 - I hate it </option>
					</select>
                </div>
                <div>Comments</div>
                <div class="formField">
                	<textarea name="comment" style="width:400px;" rows="10"></textarea>
                </div>
                <input type="submit" name="submit" value="Rate it!!"/>
            </form>
        </div>
<?php
	include('./footer.php');
?>