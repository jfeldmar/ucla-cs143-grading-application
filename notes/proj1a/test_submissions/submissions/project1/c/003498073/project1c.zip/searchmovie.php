<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>addmovie</title>
</head>

<body>
	<p>
		<img src="searchmovie.gif" width="200" height="150"
	</p>
	
	<form action="browsemovie.php?param1=title" method="get">
		<font size="+2"><b>Search for Movie</b></font><br>
		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="black" />
		</div>
		<b>Title:</b/><input type= "text" id="param1" name="param1" value="" size= "50"/><br>
		<br>
		<input type="submit" name="submit" value="Search!"/> 
	</form>

</body>
</html>
