<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>processmovie</title>
</head>

<body>
<?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	$id = $_GET["id"];
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "id:$id<br>";
	*/
	$query = "SELECT * FROM Movie WHERE id = $id";
	$result = mysql_query($query, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "query:  $query<br>";
	*/
	if ($result != false){
		// Store the information
		while($row = mysql_fetch_row($result)) {
			$id = $row[0];
			$title = $row[1];
			$year = $row[2];
			$rating = $row[3];
			$company = $row[4];	
		}
		
		// Print out Information
		print "<h2>$title</h2>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
		print "<b>Rated:</b> $rating<br>";
		
		// 		Figure out the Movie Genre's
			$query2 = "SELECT genre FROM MovieGenre WHERE mid = $id
					  ORDER by genre ASC";
			$result2 = mysql_query($query2, $db_connection);
		print "<b>Genre:</b>";
		if ($result2 != false)
			while($row = mysql_fetch_row($result2))    
				print " $row[0]";
		print "<br>";
		print "<b>Production Company:</b> $company<br>";
		print "<b>Release Year:</b> $year<br>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
	}
	// Figure out the Director(s)
	$query = "SELECT last,first,id FROM Director WHERE id IN (SELECT did FROM MovieDirector WHERE mid = $id
			  ORDER by last ASC)";
	$result = mysql_query($query, $db_connection);
	
	// Print the Directors
	if ($result != false)
			while($row = mysql_fetch_row($result))    
				print "<b>Director:</b> <a href=\"processperson.php?id=$row[2]\" target=\"mainFrame\">$row[0], $row[1]</a><br>";
	if (mysql_num_rows($result) == 0)
		print "<b>Director: Unknown<br>";
	
	print"<div>
		<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
	</div>";
	
	// Figure out the Cast
	$query = "SELECT last,first,id FROM Actor WHERE id IN (
					SELECT aid FROM MovieActor WHERE mid = $id)
			  ORDER by last ASC";
	$result = mysql_query($query, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "query:  $query<br>";
	*/
	
	if ($result != false){
		// Print out the Cast
		print"<br>";
		print "<h3>Cast:</h3>";
		
		while($row = mysql_fetch_row($result)) {	
			$query3 = "SELECT role FROM MovieActor WHERE aid = $row[2] AND mid = $id";
			$result3 = mysql_query($query3, $db_connection);
			$row2= mysql_fetch_row($result3);
			$role=$row2[0];
			print "<a href=\"processperson.php?id=$row[2]\" target=\"mainFrame\">$row[0], $row[1]</a> as $role<br>";
		}
		print"<br><div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
	}
	
	// Figure out the Reviews
	$query = "SELECT AVG(rating),COUNT(rating) FROM Review WHERE mid = $id";
	$result = mysql_query($query, $db_connection);
	$row = mysql_fetch_row($result);
	
	
	$query2 = "SELECT * FROM Review WHERE mid = $id 
				ORDER BY time";
	$result2 = mysql_query($query2, $db_connection);
		
	print "<br>
			<font color='chocolate' size = '+2'>
				<b>Reviews of \"$title\"</b>
			</font>
		   <br>";
	
	// Print the Average Rating
	if (mysql_num_rows($result2) == 0){
		print "<br><br> 
				No review/rating available, <a href=\"addreview.php?id=$id\" target=\"mainFrame\">write the first review of this movie.</a>
				<br><br>";
	}
	else {
		print "<br>
				<b>Average User Rating:</b>
				<br>";
		if($row[0] < 0.5)
			print'	<img src="0stars.png" width="180" height="50">';
		elseif($row[0] < 1.5)
			print'	<img src="1stars.png" width="180" height="50">';
		elseif($row[0] < 2.5)
			print'	<img src="2stars.png" width="180" height="50">';
		elseif($row[0] < 3.5)
			print'	<img src="3stars.png" width="180" height="50">';
		elseif($row[0] < 4.5)
			print'	<img src="4stars.png" width="180" height="50">';
		elseif($row[0] < 5.5)
			print'	<img src="5stars.png" width="180" height="50">';
		print "<br>
			<br>
			<a href=\"addreview.php?id=$id\" target=\"mainFrame\" >Write a review</a> 
			<b> and share your thoughts with other users.</b><br>
			<br>";
		
		while($row2 = mysql_fetch_row($result2)){
			// Print REview clip
			print'	<img src="reviewclip.gif" width="16" height="16">';
			// Print Review Given
			if($row2[3] < 0.5)
				print'	<img src="0stars.png" width="45" height="12">';
			elseif($row2[3] < 1.5)
				print'	<img src="1stars.png" width="45" height="12">';
			elseif($row2[3] < 2.5)
				print'	<img src="2stars.png" width="45" height="12">';
			elseif($row2[3] < 3.5)
				print'	<img src="3stars.png" width="45" height="12">';
			elseif($row2[3] < 4.5)
				print'	<img src="4stars.png" width="45" height="12">';
			elseif($row2[3] < 5.5)
				print'	<img src="5stars.png" width="45" height="12">';
			print "<br>";
			// Print Reviewer
			print"<b>Reviewer:</b> $row2[0]<br>";
			// Print time of review
			print"<b>Date Reviewed: </b>$row2[1]<br>";
			// Print Review;
			print"<b>Comments: </b>$row2[4]<br
					<br>";
		}
		print "<br>
			<a href=\"addreview.php?id=$id\" target=\"mainFrame\" >Write a review</a> 
			<b> and share your thoughts with other users.</b>
			<br>";
		
		
	}
	print"<br><div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
		
	mysql_close($db_connection);
?>

</body>
</html>
