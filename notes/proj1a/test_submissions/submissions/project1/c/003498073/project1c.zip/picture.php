<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>picure</title>
</head>

<body>

	<p>
		<img src="imdb.gif" width="398" height="365"
	</p>


</body>
</html>
