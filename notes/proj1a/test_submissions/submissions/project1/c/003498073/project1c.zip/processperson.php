<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>processperson</title>
</head>

<body>

<?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	$id = $_GET["id"];
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "id:$id<br>";
	*/
	
	// Actor Table
	$query = "SELECT * FROM Actor WHERE id = $id";
	$result = mysql_query($query, $db_connection);
	
	// Director Table
	$query2 = "SELECT * FROM Director WHERE id = $id";
	$result2 = mysql_query($query2, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "query:  $result<br>";
	echo "query2: $result2<br>";
	*/
	
	if ($result != false || $result2 != false){
		if (mysql_num_rows($result2) == 0) {//only use first query
			// Store the information
			while($row = mysql_fetch_row($result)) {
				$id = $row[0];
				$lastname = $row[1];
				$firstname = $row[2];
				$gender = $row[3];
				$dob = $row[4];		
				$dod = $row[5];
			}
		}
		else if (mysql_num_rows($result) == 0) {//only use second query
			// Store the information
			while($row = mysql_fetch_row($result2)) {
				$id = $row[0];
				$lastname = $row[1];
				$firstname = $row[2];
				$dob = $row[3];		
				$dod = $row[4];
			}
		}
		else{ // use first query since it has all the info
			// Store the information
			while($row = mysql_fetch_row($result)) {
				$id = $row[0];
				$lastname = $row[1];
				$firstname = $row[2];
				$gender = $row[3];
				$dob = $row[4];		
				$dod = $row[5];
			}
		}
		
		// Print out Information
		print "<h2>$lastname, $firstname</h2>";
		if (mysql_num_rows($result) == 0)
			print "(Director)";
		else if (mysql_num_rows($result2) == 0 && $gender == "Female")
			print "(Actress)";
		else if (mysql_num_rows($result2) == 0 && $gender == "Male")
			print "(Actor)";
		else if (mysql_num_rows($result2) != 0 && $gender == "Female")
			print "(Director/Actress)";
		else if (mysql_num_rows($result2) != 0 && $gender == "Male")
			print "(Director/Actor)";
		print "<br>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
		print "<b>Gender:</b> ";
			if (mysql_num_rows($result) == 0) print "Unknown<br>";
			else print "$gender<br>";
		print "<b>Date of Birth:</b> $dob<br>";
		if ($dod != NULL) print "<b>Date of Death:</b> $dod<br>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='gray' />
		</div>";
	}
	$query = "SELECT title,year,id FROM Movie WHERE id IN (
					SELECT mid FROM MovieActor WHERE aid = $id)
			  ORDER by year ASC";
	$result = mysql_query($query, $db_connection);
	
	$query2 = "SELECT title,year,id FROM Movie WHERE id IN (
					SELECT mid FROM MovieDirector WHERE did = $id)
			  ORDER by year ASC";
	$result2 = mysql_query($query2, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "query:  $query<br>";
	
	*/
	
	// Check to see if he is a Actor
	if (mysql_num_rows($result) != 0){	
		// Print out the Filmography
		print"<br>";
		print "<h3>Filmography:</h3>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='black' />
		</div>";
		
		while($row = mysql_fetch_row($result)) 
			print "<a href=\"processmovie.php?id=$row[2]\" target=\"mainFrame\">$row[0] ($row[1])<br></a>";
	}
	
	// Check to see if is a Director
	if (mysql_num_rows($result2) != 0){
		// Print out the Movies
		print"<br>";
		print "<h3>Directed:</h3>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='black' />
		</div>";
		
		while($row = mysql_fetch_row($result2)) 
			print "<a href=\"processmovie.php?id=$row[2]\" target=\"mainFrame\">$row[0] ($row[1])<br></a>";
	}

	mysql_close($db_connection);
?>

</body>
</html>
