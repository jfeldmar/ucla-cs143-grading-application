<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>browseactor</title>
</head>

<body>
<?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	$firstname = $_GET["param1"];
	$lastname = $_GET["param2"];
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "firstname:$firstname <br> lastname:$lastname <br> gender:$gender <br>";
	*/
	if ($lastname == "" && $firstname == ""){
		$userquery = "";
	}
	elseif ($lastname == "" && $firstname != ""){
		$userquery = 	"SELECT last,first,id 
						FROM Actor 
						WHERE first LIKE '%$firstname%'";
	}
	elseif ($lastname != "" && $firstname == ""){
		$userquery = 	"SELECT last,first,id 
						FROM Actor 
						WHERE last LIKE '%$lastname%'";
	}
	elseif ($lastname != "" && $firstname != ""){
		$userquery = 	"SELECT last,first,id 
						FROM Actor 
						WHERE last LIKE '%$lastname%' AND
								first LIKE '%$firstname%'";
	}
	$query = get_magic_quotes_gpc() ? stripslashes($userquery) : $userquery; 
	$result = mysql_query($query, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "userquery:  $userquery<br>";
	echo "query:  $query<br>";
	*/
	if ($result != false){
		print "<h3>Actors / Actresses Matching ";
		if ($lastname == "" && $firstname != "")
			print "\"$firstname\"";
		elseif ($lastname != "" && $firstname == "")
			print "\"$lastname\"";
		elseif ($lastname != "" && $firstname != "")
			print "\"$firstname $lastname\"";
		print"</h3>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='black' />
		</div>";
		
		// Print out the information
		while($row = mysql_fetch_row($result)) 
			print "<a href=\"processperson.php?id=$row[2]\" target=\"mainFrame\">$row[0], $row[1]<br></a>";
	}

	mysql_close($db_connection);
?>

</body>
</html>
