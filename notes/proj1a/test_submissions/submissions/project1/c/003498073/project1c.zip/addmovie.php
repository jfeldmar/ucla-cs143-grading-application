<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>addmovie</title>
</head>

<body>
	<p>
		<img src="addmovie.gif" width="200" height="150"
	</p>
	<?php
		$array = array(1,2,3,4);
		echo $array;
		?>
	
	
		<form action="connection.php?
		type=addmovie&
		param1=title&
		param2=year&
		param3=rating&
		param4=company&
		param5=genre
	
	
		"
		method="get">
		<input type='hidden' name='type' value='addmovie' />
		<font size="+2"><b>Insert a New Movie</b></font><br>
		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="black" />
		</div>
		<b>New Movie Title:</b/><input type= "text" id="param1" name="param1" value="" /><br>
		<br>
		<b>Year of Production:</b/><input type= "text" id="param2" name="param2" value="" /><br>
		<br>
		<b>Production Company:</b/><input type= "text" id="param4" name="param4" value="" /><br>
		<br>
		<b>Rating: </b/><br>
		     	<input type='radio' name='param3' value='G'/>G <br>
	  			<input type='radio' name='param3' value='PG'/>PG<br>
				<input type='radio' name='param3' value='PG-13'/>PG-13<br>
				<input type='radio' name='param3' value='R'/>R<br>
				<input type='radio' name='param3' value='NC-17'/>NC-17<br>
				<input type='radio' name='param3' value='surrendere'/>surrendere<br>
		<pre><b>Genre:		<input type="checkbox" name="param5[]" value="Action"> Action			<input type="checkbox" name="param5[]" value="Drama"> Drama
		<input type="checkbox" name="param5[]" value="Comedy"> Comedy			<input type="checkbox" name="param5[]" value="Adventure"> Adventure
		<input type="checkbox" name="param5[]" value="Family"> Family			<input type="checkbox" name="param5[]" value="Documentary"> Documentary
		<input type="checkbox" name="param5[]" value="Mystery"> Mystery		<input type="checkbox" name="param5[]" value="Horror"> Horror
		<input type="checkbox" name="param5[]" value="Crime"> Crime			<input type="checkbox" name="param5[]" value="Science Fiction"> Sci-Fi
		<input type="checkbox" name="param5[]" value="Fanasy"> Fantasy		<input type="checkbox" name="param5[]" value="Western"> Western
		<input type="checkbox" name="param5[]" value="Roman"> Romance		<input type="checkbox" name="param5[]" value="Drama"> Animation
		<input type="checkbox" name="param5[]" value="War"> War			<input type="checkbox" name="param5[]" value="Musical"> Musical
		<input type="checkbox" name="param5[]" value="Thriller"> Thriller		<input type="checkbox" name="param5[]" value="Adult"> Adult
		<input type="checkbox" name="param5[]" value="Short"> Short 
			</pre></b>
		<br>
		<br>
		<input type="reset" name="reset" value="Reset"/>
		<input type="submit" name="submit" value="Add"/> 
	</form>
		












</body>
</html>
