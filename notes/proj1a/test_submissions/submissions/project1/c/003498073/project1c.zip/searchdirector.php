<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>searchdirector</title>
</head>

<body>
	<p>
		<img src="searchdirector.jpg" width="200" height="150"
	</p>
	
	<form action="browsedirector.php?param1=firstname&param2=lastname&param3=gender" method="get">
		<font size="+2"><b>Search for Director</b></font><br>
		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="black" />
		</div>
		<b>First name:</b/><input type= "text" id="param1" name="param1" value="" /><br>
		<b>Last name:</b/><input type= "text" id="param2" name="param2" value="" /><br>
		<br>
		<input type="submit" name="submit" value="Search!"/> 
	</form>
</body>
</html>
