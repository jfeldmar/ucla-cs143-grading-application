<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>adddirector</title>
</head>

<body>
	<p>
		<img src="adddirector.gif" width="200" height="150"
	</p>
	<form action="connection.php?
		type=adddirector&
		param1=firstname&
		param2=lastname&
		param4=dobm&
		param5=dobd&
		param6=doby&
		param7=dobm&
		param8=dobd&
		param9=doby" 
		method="get">
		
		<input type='hidden' name='type' value='adddirector' />
		<font size="+2"><b>Insert a New Actor</b></font><br>
		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="black" />
		</div>
		<b>First name:</b/><input type= "text" id="param1" name="param1" value="" /><br>
		<b>Last name:</b/><input type= "text" id="param2" name="param2" value="" /><br>
			
		<b>DOB:<input type= "text" size ="2" id ="param4" name="param4" value="" />
			/<input type= "text" size ="2" id ="param5" name="param5" value="" />
			/<input type= "text" size ="4" id ="param6" name="param6" value="" /><br>
		
		<b>DOD:<input type= "text" size ="2" id ="param7" name="param7" value="" />
			/<input type= "text" size ="2" id ="param8" name="param8" value="" />
			/<input type= "text" size ="4" id ="param9" name="param9" value="" /><br>
		<br>
		<br>
		<input type="reset" name="reset" value="Reset"/>
		<input type="submit" name="submit" value="Add"/> 
	</form>
		












</body>
</html>
