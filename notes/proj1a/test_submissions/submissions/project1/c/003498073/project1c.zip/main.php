<HTML>
	<TITLE>main</TITLE>
	<frameset cols="200,*" border=0>
		<frame src="menu.php" name="menuFrame" scrolling="no" />
		<frame src="picture.php" name="mainFrame" scrolling="yes" noresize=true />
	</frameset>
	<noframes>
	</noframes>
</HTML>