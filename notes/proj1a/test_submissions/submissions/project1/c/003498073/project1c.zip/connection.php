<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head><?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	// Find out what kind of webpage it is
	$type= $_GET["type"];
	
	//print "type:$type<Br><br><br><br>";	
	
	// type=addreview
	if($type == "addreview"){
		$name= $_GET["param1"];
		$mid= $_GET["param3"];
		$rating= $_GET["param4"];
		$comment= $_GET["param5"];
			
		/*
		print "---------THIS IS FOR DEBUGGING!!----------<br>
		type=$type,  name=$name,  mid=$mid, rating=$rating,  comment=$comment";
		*/
		
		// If no name entered
		if($name == "")
			$name = "anonymous";
		
		// If not valid rating
		if($rating == ""){
			print "Sorry, an <b>error</b> has occured while processing your Review<br>
					Possible causes are use of an escape character or not giving a rating.<br>
					<br>";
			
			print "<a href=\"addreview.php?id=$mid\" target=\"mainFrame\" >Click here</a> to try again...";
		}
		
		else{
			// Otherwise we can add the movie review
			$query = "INSERT INTO Review VALUES(\"$name\",now(),$mid,$rating,\"$comment\")"; 
			$result = mysql_query($query, $db_connection);
			
			// Use this to debug queries
			if ($result != true){
				print "INSERTION ERROR in MYSQL <br><br>";
				$error = mysql_error();
				print "$error<br><br>";
			}
			// -- Use this to debug queries
			
			// Sucessful addition
			print "<b>Thank you for submitting your review of this item.</b><br>
					Your review has been published. Thank you for sharing your thoughts and opinions with us. <br>
					<br>
					<br>
					";
			
			print "<a href=\"processmovie.php?id=$mid\" target=\"mainFrame\"><b>Back to the movie page</b></a>";
		}
	}
	//type=addactor
	elseif($type==addactor){
		$first= $_GET["param1"];
		$last= $_GET["param2"];
		$gender= $_GET["param3"];
		$dobm= $_GET["param4"];
		$dobd= $_GET["param5"];
		$doby= $_GET["param6"];
		$dodm= $_GET["param7"];
		$dodd= $_GET["param8"];
		$dody= $_GET["param9"];
	// If no name entered, no gender specified, dob not specified
		if($last == "" || $first == "" || $gender == "" || $dobm == "" || $dobd == "" || $doby == ""
				|| ($dodm != "" && $dodd == "" && $dody =="")
				|| ($dodm == "" && $dodd != "" && $dody =="")
				|| ($dodm == "" && $dodd == "" && $dody !="")	){
			print "Sorry, an <b>error</b> has occured while processing your addition of a new actor/actress<br>
					Possible causes are not fully specifying a name, gender or birthday.<br>
					<br>
					Note that if the person if dead, you must fully specify their day of death.<br>
					<br>
					<br>";
			
			print "<a href='addactor.php' target=\"mainFrame\" >Click here</a> to try again...";
		}
		
		else{
			// Otherwise we can add the actor
			
			// Figure out if the person has died
			if ($dodm == "")
				$dod = "alive";
			else	
				$dod = "dead";
			
			// First look up MaxPersonID
			$query = "SELECT id FROM MaxPersonID"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			$newid = $row[0];
			$newid = $newid + 1;
		
				// -- Use this to debug queries
				if ($result != true){
					print "// First look up MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Update MaxPersonID
			$newid = $newid + 1;
			$query = "UPDATE MaxPersonID SET id = $newid"; 
			$result = mysql_query($query, $db_connection);
			
				// -- Use this to debug queries
				if ($result != true){
					print "// Update MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Add Actor with updated MaxPersonID
			//   This person hasn't died yet
			if ($dod == "alive") 
				$query = "INSERT INTO Actor VALUES($newid,\"$last\",\"$first\",\"$gender\",'$doby-$dobm-$dobd',NULL)"; 
			//   This person has died
			elseif($dod =="dead")
				$query = "INSERT INTO Actor VALUES($newid,\"$last\",\"$first\",\"$gender\",'$doby-$dobm-$dobd','$dody-$dodm-$dodd')";
			
			$result = mysql_query($query, $db_connection);
			
				// Use this to debug queries
				if ($result != true){
					print "// Add Actor with updated MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Sucessful addition
			print "<b>The Actor/Actress has been successfully added to the database.</b><br>
					<br>
					<br>
					";
			
			print "<a href=\"processperson.php?id=$newid\" target=\"mainFrame\"><b>Visit the new Actor's/Actress' page</b></a>";
		}
	}
	//type=adddirector
	elseif($type==adddirector){
		$first= $_GET["param1"];
		$last= $_GET["param2"];
		$dobm= $_GET["param4"];
		$dobd= $_GET["param5"];
		$doby= $_GET["param6"];
		$dodm= $_GET["param7"];
		$dodd= $_GET["param8"];
		$dody= $_GET["param9"];
	// If no name entered,  dob not specified
		if($last == "" || $first == "" ||  $dobm == "" || $dobd == "" || $doby == ""
				|| ($dodm != "" && $dodd == "" && $dody =="")
				|| ($dodm == "" && $dodd != "" && $dody =="")
				|| ($dodm == "" && $dodd == "" && $dody !="")	){
			print "Sorry, an <b>error</b> has occured while processing your addition of a new director<br>
					Possible causes are not fully specifying a name or birthday.<br>
					<br>
					Note that if the person if dead, you must fully specify their day of death.<br>
					<br>
					<br>";
			
			print "<a href='adddirector.php' target=\"mainFrame\" >Click here</a> to try again...";
		}
		
		else{
			// Otherwise we can add the director
			
			// Figure out if the person has died
			if ($dodm == "")
				$dod = "alive";
			else	
				$dod = "dead";
			
			// First look up MaxPersonID
			$query = "SELECT id FROM MaxPersonID"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			$newid = $row[0];
			$newid = $newid + 1;
		
				// -- Use this to debug queries
				if ($result != true){
					print "// First look up MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Update MaxPersonID
			$newid = $newid + 1;
			$query = "UPDATE MaxPersonID SET id = $newid"; 
			$result = mysql_query($query, $db_connection);
			
				// -- Use this to debug queries
				if ($result != true){
					print "// Update MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Add Actor with updated MaxPersonID
			//   This person hasn't died yet
			if ($dod == "alive") 
				$query = "INSERT INTO Director VALUES($newid,\"$last\",\"$first\",'$doby-$dobm-$dobd',NULL)"; 
			//   This person has died
			elseif($dod =="dead")
				$query = "INSERT INTO Director VALUES($newid,\"$last\",\"$first\",'$doby-$dobm-$dobd','$dody-$dodm-$dodd')";
			
			$result = mysql_query($query, $db_connection);
			
				// Use this to debug queries
				if ($result != true){
					print "// Add Actor with updated MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Sucessful addition
			print "<b>The Director has been successfully added to the database.</b><br>
					<br>
					<br>
					";
			
			print "<a href=\"processperson.php?id=$newid\" target=\"mainFrame\"><b>Visit the new Director's page</b></a>";
		}
	}
	elseif($type==addmovie){
		$title=  $_GET["param1"];
		$year=   $_GET["param2"];
		$rating= $_GET["param3"];
		$company=$_GET["param4"];
		$genre=  $_GET["param5"];
						
		// If no name entered, no year of production, no production company, or no rating
		if($title == "" || $year == "" ||  $rating == "" || $company == "" || $genre[0] == ""){
			print "Sorry, an <b>error</b> has occured while processing your addition of a new Movie<br>
					Possible causes are not fully specifying a movie title, the year of production, the rating, or at least one genre.<br>
					<br>
					<br>";
			
			print "<a href='movie.php' target=\"mainFrame\" >Click here</a> to try again...";
		}
		
		else{
			// Otherwise we can add the movie
			
			// First look up MaxMovieID
			$query = "SELECT id FROM MaxMovieID"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			$newid = $row[0];
			$newid = $newid + 1;
		
				// -- Use this to debug queries
				if ($result != true){
					print "// First look up MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Update MaxMovieID
			$newid = $newid + 1;
			$query = "UPDATE MaxMovieID SET id = $newid"; 
			$result = mysql_query($query, $db_connection);
			
				// -- Use this to debug queries
				if ($result != true){
					print "// Update MaxMovieID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
			
			// Add Movie with updated MovieID
			//   This person hasn't died yet
			
			$query = "INSERT INTO Movie VALUES($newid,\"$title\",$year,'$rating','$company')";
			
			$result = mysql_query($query, $db_connection);
			
				// Use this to debug queries
				if ($result != true){
					print "// Add Actor with updated MaxMovieID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
				
			// Add Genres of this movie to Movie Genre	
			$i=0;
			while ($genre[$i]){
				$query = "INSERT INTO MovieGenre VALUES($newid,\"$genre[$i]\")";
				$result = mysql_query($query, $db_connection);
			 	$i = $i + 1;
			}
			
			
			// Sucessful addition
			print "<b>The Movie has been successfully added to the database, now please specify the director(s).</b><br>
					<br>
					<br>
					";
			
			$query = "SELECT * FROM Director"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			// Add director
			print"
			<form action=\"connection.php?
				type=insertdirectorcast&
				param1=mid&
				param2=did\"
				method=\"get\">
				
				<input type='hidden' name='type' value='insertdirectorcast'/>			
				<input type='hidden' name='param1' value='$newid' />
				<select name=\"param2\">
			";
					// Create a Dropdown box of all directors
					while($row = mysql_fetch_row($result)){
						print"
						<option value=\"$row[0]\">$row[1], $row[2] </option>		
						";				
					}
			print"
				<br><br>
				<input type=\"submit\" name=\"submit\" value=\"Add\"/> 
			</form>
			";// End add director
		}
	}
	elseif($type==insertdirectorcast){
		$mid=  $_GET["param1"];
		$did=  $_GET["param2"];
		
		// We are adding the cast
		if($did=="")
		{	
			print "<b>Please specify at least one member of the cast.</b><br>
					<br>
					";
			
			$query = "SELECT * FROM Actor"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			// Add Actor
			print"
			<form action=\"connection.php?
				type=insertcast&
				param1=mid&
				param2=aid&
				param3=role\"
				method=\"get\">
				
				<input type='hidden' name='type' value='insertcast'/>			
				<input type='hidden' name='param1' value='$mid' />
				<select name=\"param2\">
			";
					// Create a Dropdown box of all Actors
					while($row = mysql_fetch_row($result)){
						print"
						<option value=\"$row[0]\">$row[1], $row[2] </option>		
						";				
					}
			print"
				</select>
				with a role as <input type='text' name='param3' size='20' \>
				<br>
				<br>
				<input type=\"submit\" name=\"submit\" value=\"Add\"/> 
			</form>
			";// End add Actor
			
			
		}
		else{ // We are adding a director
			
			$query = "SELECT * FROM Director where id=$did"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			$query2 = "SELECT * FROM Movie where id=$mid"; 
			$result2 = mysql_query($query2, $db_connection);
			$row2 = mysql_fetch_row($result2);
			
			// First we must add the director to the MovieDirector Table
			$query3 = "INSERT INTO MovieDirector VALUES($mid,$did)";
			$result = mysql_query($query3, $db_connection);
			
			// We can go onto add movies or add cast
			print "<b>$row[2] $row[1]</b> has been successfully added to <b>$row2[1]</b>, you can add another director or continue on
					to add the cast<br><br>";
			// Add director
			$query = "SELECT * FROM Director"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			print"
				<form action=\"connection.php?
					type=insertdirectorcast&
					param1=mid&
					param2=did\"
					method=\"get\">
					
					<input type='hidden' name='type' value='insertdirectorcast'/>
					<input type='hidden' name='param1' value='$mid' />
					<select name=\"param2\">
						<option value=\"\"><b>Continue on to add cast</b></option>
				";
						// Create a Dropdown box of all directors
						while($row = mysql_fetch_row($result)){
							print"
							<option value=\"$row[0]\">$row[1], $row[2] </option>		
							";				
						}
				print"
					<br><br>
					<input type=\"submit\" name=\"submit\" value=\"Submit\"/> 
				</form>
			";// End add director
		}
	}
	elseif($type==insertcast){
		$mid=  $_GET["param1"];
		$aid=  $_GET["param2"];
		$role= $_GET["param3"];
		if($aid == ""){// Finished adding people
			print "<b>The Movie and its cast/director(s) has been successfully added to the database.</b><br>
					<br>
					<br>
					";
			
			print "<a href=\"processmovie.php?id=$mid\" target=\"mainFrame\"><b>Visit the new Movie's page</b></a>";
		}
		else{// Add another person to cast
			$query = "SELECT * FROM Actor where id = $aid"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			$query2 = "SELECT * FROM Movie where id =$mid"; 
			$result2 = mysql_query($query2, $db_connection);
			$row2 = mysql_fetch_row($result2);
	
			// First we must add the Actor to the MovieActor Table
			$query3 = "INSERT INTO MovieActor VALUES($mid,$aid,'$role')";
			$result = mysql_query($query3, $db_connection);
			
				// -- Use this to debug queries
				if ($result != true){
					print "// First look up MaxPersonID INSERTION ERROR in MYSQL <br><br>";
					$error = mysql_error();
					print "$error<br><br>";
				}
				// -- Use this to debug queries
				
			// We can go onto add more actors or stop
			print "<b>$row[2] $row[1]</b> has been successfully added to <b>$row2[1]</b>, you can add another actor or to the cast or finish.
					<br><br>";
			
			$query = "SELECT * FROM Actor"; 
			$result = mysql_query($query, $db_connection);
			$row = mysql_fetch_row($result);
			// Add Actor
			print"
			<form action=\"connection.php?
				type=insertcast&
				param1=mid&
				param2=aid&
				param3=role\"
				method=\"get\">
				
				<input type='hidden' name='type' value='insertcast'/>			
				<input type='hidden' name='param1' value='$mid' />
				<select name=\"param2\">
			";
					// Create one option to finish
					print"
						<option value=\"\"><b>Finished adding cast</b></option>
						";
					// Create a Dropdown box of all Actors
					while($row = mysql_fetch_row($result)){
						print"
						<option value=\"$row[0]\">$row[1], $row[2] </option>		
						";				
					}
			print"
				</select>
				with a role as <input type='text' name='param3' size='30' \>
				<br>
				<br>
				<input type=\"submit\" name=\"submit\" value=\"Submit\"/> 
			</form>
			";// End add Actor
		}
	}
	else
		print "Mistake!<br><br>";

	mysql_close($db_connection);
	?>
</head>

</body>
</html>
