<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>addreview</title>
</head>

<body>
	<?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	$id = $_GET["id"];
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "id:$id<br>";
	*/
	$query = "SELECT * FROM Movie WHERE id = $id";
	$result = mysql_query($query, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "query:  $query<br>";
	*/
	$row = mysql_fetch_row($result);
	$title= $row[1];
		
	print"	
	<font color='chocolate' size = '+2'>
		<b>Write a review of \"$title\"</b><br>
	</font>
	<div>
		<hr align='center' noshade='noshade' size='1' width='100%' color='gray' />
	</div>
	<br>
	Richard's Movie Database invites all users to write reviews for any movie on our site. Let people know your opinion!<br>
	<br>";
	
	print"<form action='connection.php?
		type=addreview&
		param1=name&
		param3=id&
		param4=review&
		param5=comment' 
		method='get'>
	<input type='hidden' name='type' value='addreview' />
	<input type='hidden' name='param3' value='$id' />";
	print"<ol>
			<li><b>How do you review this movie?</b><br>
		     	<input type='radio' name='param4' value='0'/>0
	  			<input type='radio' name='param4' value='1'/>1
				<input type='radio' name='param4' value='2'/>2
				<input type='radio' name='param4' value='3'/>3
				<input type='radio' name='param4' value='4'/>4
				<input type='radio' name='param4' value='5'/>5<br>
			<br>
			<li><b>What is your name?</b><br>
				<input type='text' name='param1' value='' size='20'/><br>
			<br>
			<li><b>Enter your review below:</b> (Maximum of 700 words)<br>
				<textarea name='param5' rows='10' cols='70'/>
				</textarea><br>
			<br>
		  </ol>
			<div>
				<hr align='center' noshade='noshade' size='1' width='100%' color='gray' />
			</div>
			<br>";
			print "<input type='reset' name='reset' value='Reset!'/> ";
			print "<input type='submit' name='submit' value='Submit Review'/> ";
		print"</form>";

	mysql_close($db_connection);
	?>
</body>
</html>
