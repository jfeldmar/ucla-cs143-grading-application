<html>
	<head>
		<title>menu</title>
	</head>

	<body bgcolor="#ADC466">
		<font size="+2"><b>Movie Database</b></font>

		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="white" />
		</div>
		
		<p><b>Actor/Actress</b></p>
		<ul>
			<li><a href="addactor.php" target="mainFrame">Add Actor</a></li>
			<li><a href="searchactor.php" target="mainFrame">Search</a></li>
		</ul>
		<p><b>Director</b></p>
		<ul>
			<li><a href="adddirector.php" target="mainFrame">Add Director</a></li>
			<li><a href="searchdirector.php" target="mainFrame">Search</a></li>
		</ul>
		
		<p><b>Movie</b><p>
		<ul>
			<li><a href="addmovie.php" target="mainFrame">Add Movie</a></li>
			<li><a href="searchmovie.php" target="mainFrame">Search</a></li>
		</ul>
		
		<div>
			<hr align="center" noshade="noshade" size="2" width="100%" color="white" />
		</div>
	</body>

</html>
