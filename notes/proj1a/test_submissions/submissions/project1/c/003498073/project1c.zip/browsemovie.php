<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
	<title>browsemovie</title>
</head>

<body>

<?php
	
	// Establish Connection to MySQL
	$db_connection = mysql_connect("localhost", "cs143", "");

	// Establish Connection to the database
	mysql_select_db("CS143", $db_connection);

	$title = $_GET["param1"];
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "firstname:$firstname <br> lastname:$lastname <br> gender:$gender <br>";
	*/
	if ($title == ""){
		$userquery = "";
	}
	else{
		$userquery = 	"SELECT *
						FROM Movie 
						WHERE title LIKE '%$title%'";
	}
	
	$query = get_magic_quotes_gpc() ? stripslashes($userquery) : $userquery; 
	$result = mysql_query($query, $db_connection);
	
	/*
	echo "-----FOR DEBUGGING PURPOSES! -----<br>";
	echo "userquery:  $userquery<br>";
	echo "query:  $query<br>";
	*/
	if ($result != false){
		print "<h3>Movie Titles matching \"$title\"";
		print"</h3>";
		print"<div>
			<hr align='center' noshade='noshade' size='2' width='100%' color='black' />
		</div>";
		
		// Print out the information
		while($row = mysql_fetch_row($result)) 
			print "<a href=\"processmovie.php?id=$row[0]\" target=\"mainFrame\">$row[1] ($row[2])<br></a>";
	}

	mysql_close($db_connection);
?>

</body>
</html>
