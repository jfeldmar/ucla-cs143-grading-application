<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Comment!</title>
</head>

<body>
<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<?php
	if (strval($_GET["movie"]) == "") { // default behavior: show movie names and links to movie pages
		echo "ERROR: This page needs a movie id to work! <BR />";
		return;
	}
	
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);
	
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	$movieID = $_GET["movie"];
	
	$rs = mysql_query("SELECT M.title, M.year, M.company, M.rating, MG.genre, D.first, D.last ".
						"FROM Movie M, Director D, MovieGenre MG, MovieDirector MD ".
						"WHERE M.id=$movieID AND MG.mid=$movieID AND D.id=MD.did", $db_connection);
	
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	$row = mysql_fetch_row($rs); // there should only be one row
	echo "<DIV CLASS=\"info\"><H2>Commenting on <A HREF=\"movie.php?movie=$movieID\">$row[0]"."</A>($row[1])</H2>";
	echo "Directed by $row[5] $row[6] <BR />";
	echo "$row[2] </DIV><BR />";
	
	echo "<FORM METHOD=\"GET\">";
	echo "<INPUT ID=\"hidden\" NAME=\"movie\" VALUE=\"$movieID\"></INPUT>";

?>

Name:
<INPUT STYLE="width:13em;" TYPE="TEXT" NAME="reviewername"></INPUT><BR />
Rating:
<INPUT TYPE="RADIO" NAME="rating" VALUE="1">1</INPUT>
<INPUT TYPE="RADIO" NAME="rating" VALUE="2">2</INPUT>
<INPUT TYPE="RADIO" NAME="rating" VALUE="3" checked>3</INPUT>
<INPUT TYPE="RADIO" NAME="rating" VALUE="4">4</INPUT>
<INPUT TYPE="RADIO" NAME="rating" VALUE="5">5</INPUT>
<BR />
<TEXTAREA STYLE="width:100%;" NAME="comment" ROWS="8">Type in your review here!</TEXTAREA><BR />
<INPUT TYPE="SUBMIT" VALUE="Submit" />
</FORM>

<?php
	
	$movieID = $_GET["movie"];
	
	if (isset($_GET["reviewername"]))
		if (strval($_GET["reviewername"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a name.</DIV>";
		}
		else {
			$rname = $_GET["reviewername"];
			$rating = $_GET["rating"];
			$comment = $_GET["comment"];
			$query = "INSERT INTO Review ".
						"VALUES(\"$rname\",NOW(),$movieID,$rating,\"$comment\")";
			$rs = mysql_query($query, $db_connection);
			if (!$rs) {
				$errmsg = mysql_error($db_connection);
				print $errmsg;
				exit(1);
			}
			echo "Thank you! Your review has been submitted.";
			
		}
	
	echo "<H2>Reviews:</H2>";
	
	$rs = mysql_query("SELECT AVG(rating) FROM Review WHERE mid=$movieID", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	$row = mysql_fetch_row($rs);
	if ($row[0] != NULL) {
		echo "<CENTER><H3>Average Rating: $row[0]</H3></CENTER>";
		$rs = mysql_query("SELECT name, time, rating, comment FROM Review WHERE mid=$movieID ORDER BY time DESC", $db_connection);
		while($row = mysql_fetch_row($rs)) {
			$name = $row[0];
			$time = $row[1];
			$rating = $row[2];
			$comment = $row[3];
			echo "<DIV CLASS=\"comment\"><font size=\"2\"><B>$name</B> at $time"." ($rating out of 5):</font><BR />";
			echo "$comment <BR /></DIV>";
		}
	}
	else
		echo "No reviews have been posted for this movie yet. <BR />";
	
	mysql_close($db_connection);
?>
</DIV>
</body>
</html>