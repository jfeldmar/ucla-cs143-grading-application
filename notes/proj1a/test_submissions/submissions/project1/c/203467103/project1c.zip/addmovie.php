<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Add a Movie</title>
</head>

<body>

<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<DIV CLASS="INFO" STYLE="text-align:left; width: 35em;">
<H1>Add a Movie:</H1>
<FORM METHOD="GET">
Title:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="title"></INPUT><BR />
Year:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="year"></INPUT><BR />
Company:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="company"></INPUT><BR />
Director:
<SELECT STYLE="position:absolute;left:10em" NAME="director">
<OPTION SELECTED VALUE="">Select...</OPTION>
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);

	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	$rs = mysql_query("SELECT last, first, id from Director", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	while($row = mysql_fetch_row($rs)) {
			echo "<OPTION VALUE=\"$row[2]\">";
			echo "$row[0], $row[1]";
			echo "</OPTION>";
	}
?>
</SELECT>
<BR /><BR />
MPAA Rating:
<SELECT STYLE="position:absolute;left:10em" NAME="rating">
<OPTION SELECTED VALUE="">Select...</OPTION>
<OPTION>G</OPTION>
<OPTION>PG</OPTION>
<OPTION>PG-13</OPTION>
<OPTION>R</OPTION>
<OPTION>surrendere</OPTION>
</SELECT>
<BR />
Genre:
<SELECT STYLE="position:absolute;left:10em" NAME="genre">
<OPTION SELECTED VALUE="">Select...</OPTION>
<OPTION>Action</OPTION>
<OPTION>Adult</OPTION>
<OPTION>Adventure</OPTION>
<OPTION>Animation</OPTION>
<OPTION>Comedy</OPTION>
<OPTION>Crime</OPTION>
<OPTION>Documentary</OPTION>
<OPTION>Drama</OPTION>
<OPTION>Family</OPTION>
<OPTION>Fantasy</OPTION>
<OPTION>Horror</OPTION>
<OPTION>Musical</OPTION>
<OPTION>Mystery</OPTION>
<OPTION>Romance</OPTION>
<OPTION>Sci-Fi</OPTION>
<OPTION>Short</OPTION>
<OPTION>Thriller</OPTION>
<OPTION>War</OPTION>
<OPTION>Western</OPTION>
</SELECT>
<BR />
<INPUT TYPE="SUBMIT" VALUE="Submit" />
</FORM>

<?php
	
	$title = $_GET["title"];
	$year = $_GET["year"];
	$rating = $_GET["rating"];
	$company = $_GET["company"];
	$director = $_GET["director"];
	$genre = $_GET["genre"];
	if (isset($_GET["title"])) {
		if (strval($_GET["title"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a title.</DIV>";
			return;
		}
		if (strval($_GET["year"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a last name.</DIV>";
			return;
		}
		if (strval($_GET["rating"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a rating.</DIV>";
			return;
		}
		if (strval($_GET["director"]) == "") {
			echo "<DIV CLASS=\"error\">Please select a director.</DIV>";
			return;
		}
		if (strval($_GET["genre"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a genre.</DIV>";
			return;
		}
		if (strval($_GET["company"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a company name.</DIV>";
			return;
		}
	}
	else
		return;
	
	$rs = mysql_query("SELECT * from MaxMovieID", $db_connection);
	$row = mysql_fetch_row($rs);
	$id = $row[0] + 1; // id = maxID + 1
	
	// update maxID
	$rs = mysql_query("UPDATE MaxMovieID SET id=$id WHERE id=$id-1", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	// insert movie
	$query = "INSERT INTO Movie VALUES($id, \"$title\", $year, \"$rating\", \"$company\")";
	$rs = mysql_query($query, $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	// confirm insertion
	$rs = mysql_query("SELECT title, year, company from Movie WHERE id=$id", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	$row = mysql_fetch_row($rs);
	echo "Added $row[0] ($row[1]), ($row[2]) <BR />";
	
	// insert movie/director relation
	$rs = mysql_query("INSERT INTO MovieDirector VALUES($id, $director)", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	// insert movie/genre relation
	$rs = mysql_query("INSERT INTO MovieGenre VALUES($id, \"$genre\")", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	mysql_close($db_connection);
?>

</DIV>
</DIV>
</body>
</html>