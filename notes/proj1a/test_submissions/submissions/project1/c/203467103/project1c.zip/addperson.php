<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Add a Person</title>
</head>

<body>

<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<DIV CLASS="INFO" STYLE="text-align:left; width: 35em;">
<H1>Add a Person:</H1>
<FORM METHOD="GET">
First Name:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="firstname"></INPUT><BR />
Last Name:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="lastname"></INPUT><BR />
<BR />
Sex:
<INPUT TYPE="RADIO" NAME="sex" VALUE="Male">Male</INPUT>
<INPUT TYPE="RADIO" NAME="sex" VALUE="Female">Female</INPUT>
<BR />
Profession:
<INPUT TYPE="RADIO" NAME="job" VALUE="Actor">Actor</INPUT>
<INPUT TYPE="RADIO" NAME="job" VALUE="Director">Director</INPUT>
<BR />
<BR />
Born: <BR />
<INPUT STYLE="width:13em;" TYPE="TEXT" NAME="dob"></INPUT>
(YYYY-MM-DD)<BR /><BR />
Deceased: (leave blank if still alive) <BR />
<INPUT STYLE="width:13em;" TYPE="TEXT" NAME="dod"></INPUT>(YYYY-MM-DD) <BR />
<BR />

<INPUT TYPE="SUBMIT" VALUE="Submit" />
</FORM>

<?php
	// DATE FORMAT: YYYY-MM-DD
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);

	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	// TODO: finish error checking
	$firstname = $_GET["firstname"];
	$lastname = $_GET["lastname"];
	$sex = $_GET["sex"];
	$job = $_GET["job"];
	$dob = $_GET["dob"];
	$dod = $_GET["dod"];
	if (isset($_GET["firstname"])) {
		if (strval($_GET["firstname"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a first name.</DIV>";
			return;
		}
		if (strval($_GET["lastname"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a last name.</DIV>";
			return;
		}
		if (strval($_GET["sex"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a gender.</DIV>";
			return;
		}
		if (strval($_GET["job"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a profession.</DIV>";
			return;
		}
		if (strval($_GET["dob"]) == "") {
			echo "<DIV CLASS=\"error\">Please provide a date of birth.</DIV>";
			return;
			// check for malformed date
		}
		if (strval($_GET["dod"]) != "") {
			return; // check for malformed date
		}
		else
			$dod = "NULL";
	}
	else
		return;
	
	$rs = mysql_query("SELECT * from MaxPersonID", $db_connection);
	$row = mysql_fetch_row($rs);
	$id = $row[0] + 1; // id = maxID + 1
	
	if ($job=="Actor")
		$query = "INSERT INTO $job VALUES($id, \"$lastname\", \"$firstname\", \"$sex\", \"$dob\", \"$dod\")";
	else
		$query = "INSERT INTO $job VALUES($id, \"$lastname\", \"$firstname\", \"$dob\", \"$dod\")";
	$rs = mysql_query($query, $db_connection); // insert person
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	$rs = mysql_query("SELECT first, last, dob, dod from $job WHERE id=$id", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	$row = mysql_fetch_row($rs); // confirm insertion
	echo "Added $row[0] $row[1] ($row[2]-$row[3]) <BR />";
	
	// update maxID
	$rs = mysql_query("UPDATE MaxPersonID SET id=$id WHERE id=$id-1", $db_connection);
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	mysql_close($db_connection);
?>

</DIV>
</DIV>

</body>
</html>