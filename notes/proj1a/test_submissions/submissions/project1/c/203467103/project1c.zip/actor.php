<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Actor Information</title>
</head>

<body>

<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<?php

	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);

	
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	if (strval($_GET["actor"]) == "") { // default behavior: show actor names and links to actor pages
		
		echo "<DIV CLASS=\"info\"><H1>Actor Information</H1>";
		
		$letter = $_GET["letter"];
		if (strval($letter) == "") { // default behavior: show actors with last names starting with A
			$letter = "A";
		}
		
		echo "|";
		for ($i = 'A'; $i <= 'Z' && strlen($i) == 1; $i++) { // why doesn't <= 'Z' work? don't know
			if ($i == $letter)
				echo "<b> $i |</b>";
			else
				echo " <A HREF=\"actor.php?letter=$i\">$i</A> |";
		}
		echo "<BR />";
		echo "</DIV>";
	
		$rs = mysql_query("SELECT last, first, dob, id FROM Actor WHERE last LIKE \"$letter"."%\"ORDER BY last", $db_connection);	
		if (!$rs) {
			$errmsg = mysql_error($db_connection);
			print $errmsg;
			exit(1);
		}

		$count = 0;
		echo "<BR />";
		while($row = mysql_fetch_row($rs)) {
			echo "<DIV CLASS=\"row\">";
			$date = $row[2];
			echo "<A HREF=\"actor.php?actor=$row[3]\">$row[0], $row[1]</A> " . " ($date)"; // provides actorID as the link
			echo "</DIV>";
		}
		return;
	}
	
	$actorID = $_GET["actor"];

	$rs = mysql_query("SELECT last, first, sex, dob, dod ".
						"FROM Actor WHERE id=$actorID", $db_connection);
	
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	$row = mysql_fetch_row($rs); // there should only be one row
	echo "<DIV CLASS=\"info\">";
	echo "<H1>$row[1] $row[0]</H1>";
	$dob = strtotime($row[3]);
	echo "Born ".date("F d, Y", $dob)."<BR />";
	$dod = $row[4];
	if ($dod != NULL) {
		$dod = strtotime($row[4]);
		echo "Died ".date("F d, Y", $dod)." <BR />";
	}
	if ($row[2] == "Male")
		echo "He ";
	else
		echo "She ";
	if ($dod != NULL) {
		echo "was ".(date("Y", $dod) - date("Y", $dob))." years old.<BR />";
	}
	else {
		echo "is ".(date("Y", time()) - date("Y", $dob))." years old.<BR />";
	}
	
	$rs = mysql_query("SELECT title, year, role, id FROM Movie M, MovieActor MA ".
						"WHERE M.id=MA.mid AND MA.aid=$actorID ".
						"ORDER BY year DESC", $db_connection);
	
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	
	echo "<H2>Filmography:</H2>";
	
	echo "<OL>";
	if (!mysql_num_rows($rs))
		echo "No movies found!";
	while($row = mysql_fetch_row($rs)) {
		echo "<LI><A HREF=\"movie.php?movie=$row[3]\">$row[0]</A> ($row[1]) as $row[2]</LI>";
	}
	echo "</OL>";
	
	echo "</DIV>";
	mysql_close($db_connection);
?>

</DIV>

</body>
</html>