<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Add an Actor to a Movie</title>
</head>

<body>

<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<DIV CLASS="INFO" STYLE="text-align:left; width: 35em;">
<H1>Add an Actor to a Movie:</H1>

<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);

	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	$movieID = $_GET["movie"];
	$actorID = $_GET["actor"];
	$role = $_GET["role"];
	if (isset($_GET["movie"])) {
		if (strval($role) == "") {
			echo "<DIV CLASS=\"error\">Please provide a role.</DIV>";
			return;
		}
		$rs = mysql_query("INSERT INTO MovieActor VALUES($movieID, $actorID, '$role')", $db_connection);
		if (!$rs) {
			$errmsg = mysql_error($db_connection);
			print $errmsg;
			exit(1);
		}
		echo "Actor added! <BR />";
		return;
	}
	
?>

<FORM METHOD="GET">
Select Actor:
<SELECT STYLE="position:absolute;left:10em; width:auto" NAME="actor">
<?php
	
	$rs = mysql_query("SELECT last, first, dob, id FROM Actor "
						."ORDER BY last", $db_connection);	
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	if (mysql_num_rows($rs)) {
		while($row = mysql_fetch_row($rs)) {
			$date = $row[2];
			echo "<OPTION VALUE=\"$row[3]\">$row[0], $row[1]</A> " . " ($date)</OPTION>"; // provides actorID as the link
		}
	}
?>
</SELECT>
<BR />
Select Movie:
<SELECT STYLE="position:absolute;left:10em; width:30em" NAME="movie">
<?php	
	$rs = mysql_query("SELECT title, year, rating, id FROM Movie "
						."ORDER BY title", $db_connection);	
	if (!$rs) {
		$errmsg = mysql_error($db_connection);
		print $errmsg;
		exit(1);
	}
	if (mysql_num_rows($rs)) {
		while($row = mysql_fetch_row($rs)) {
			$date = $row[2];
			echo "<OPTION VALUE=\"$row[3]\">$row[0], $row[1]</A> " . " ($date)</OPTION>"; // provides actorID as the link
		}
	}
	mysql_close($db_connection);
?>
</SELECT>
<BR />
Role:
<INPUT STYLE="position:absolute;left:10em; width:13em;" TYPE="TEXT" NAME="role"></INPUT><BR />
<INPUT TYPE="SUBMIT" VALUE="Submit" />
</FORM>

</DIV>
</DIV>
</body>
</html>