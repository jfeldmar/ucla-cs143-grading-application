<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<title>Search</title>
</head>

<body>

<DIV CLASS="nav">
<A HREF="addperson.php">Add Person</A> |
<A HREF="addmovie.php">Add Movie</A> |
<A HREF="addactormovie.php">Add Actor/Movie Relation</A> |
<A HREF="actor.php">Browse Actors</A> |
<A HREF="movie.php">Browse Movies</A> |
<A HREF="search.php">SEARCH</A>
</DIV>

<DIV CLASS="main">

<DIV CLASS="INFO" STYLE="text-align:left; width: 35em;">
<H1>Find a person or movie:</H1>
<FORM METHOD="GET">
<INPUT STYLE="width:auto" TYPE="TEXT" NAME="search"></INPUT>
<INPUT TYPE="SUBMIT" VALUE="Search!" />
</FORM>

<?php

	$db_connection = mysql_connect("localhost", "cs143", "");
	mysql_select_db("CS143", $db_connection);

	
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	if (isset($_GET["search"]) && strval($_GET["search"]) != "") {
		$search = $_GET["search"];
		
		echo "Searching through actors:";
		echo "<BR />";
		// GET ACTORS
		$rs = mysql_query("SELECT last, first, dob, id FROM Actor WHERE last LIKE \"%$search%\" OR "
							."first LIKE \"%$search%\" OR "
							."CONCAT(first, ' ', last) LIKE \"%$search%\" "
							."ORDER BY last", $db_connection);	
		if (!$rs) {
			$errmsg = mysql_error($db_connection);
			print $errmsg;
			exit(1);
		}
		if (mysql_num_rows($rs)) {
			while($row = mysql_fetch_row($rs)) {
				echo "<DIV CLASS=\"row\">";
				$date = $row[2];
				echo "<A HREF=\"actor.php?actor=$row[3]\">$row[0], $row[1]</A> " . " ($date)"; // provides actorID as the link
				echo "</DIV>";
			}
		}
		else
			echo "No actors found!";
		
		echo "<BR />";
		echo "Searching through movies:";
		echo "<BR />";
		
		// GET MOVIES
		$rs = mysql_query("SELECT title, year, rating, id FROM Movie WHERE title LIKE \"%$search%\" "
							."ORDER BY title", $db_connection);	
		if (!$rs) {
			$errmsg = mysql_error($db_connection);
			print $errmsg;
			exit(1);
		}
		if (mysql_num_rows($rs)) {
			while($row = mysql_fetch_row($rs)) {
				echo "<DIV CLASS=\"row\">";
				echo "<A HREF=\"movie.php?movie=$row[3]\">$row[0] </A> ($row[1])"; // provides movieID as the link
				echo "</DIV>";
			}
		}
		else
			echo "No movies found!";
		return;
	}
	
	mysql_close($db_connection);
?>

</DIV>
</body>
</html>