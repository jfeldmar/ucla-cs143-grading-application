<html>
	<head>
		<title>JMDB: Where People Meet Movie!</title>
		<link rel="stylesheet" type="text/css" href="main.css" />
		<script type="text/javascript" src="main.js"></script>
	</head>
	<body>
		<table id="main-table">
			<tr id="top-row">
				<td colspan="2">
					<table id="inner-table">
						<tr id="page-logo">
							<td colspan='6'>
								<a href="jmdbmain.php" id="logo">JMDB: Where People Meet Movies!</a>
							</td>
						</tr>
						<tr id="search-box-table">
							<td colspan='6'>
								<form action="jmdbmain.php" method="GET">
									<input id="search-box" type="text" name="query" value="Enter a search term" onfocus="clearSearchBox(id);" onblur="resetSearchBox(id);"><input id="search-button" type="submit" value="Search">
								</form>
							</td>
						</tr>
						<tr id="link-option">
							<td id="option1" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="actorInfo.php">Actor Info</a>
							</td>
							<td id="option2" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="movieInfo.php">Movie Info</a>
							</td>
							<td id="option3" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="aadi.php">Add Act/Direc Info</a>
							</td>
							<td id="option4" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ac.php">Add Comments</a>
							</td>
							<td id="option5" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ami.php">Add Movie Info</a>
							</td>
							<td id="option6" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="amar.php">Add Mov/Act Rel</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr id="bottom-row">
				<td id="side-table">
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie order by year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Recently Posted Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[1] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]</a><br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select comment, mid, time from Review order by time desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Latest Comments:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11 && $row != null; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
							{
								printf("<a href='movieInfo.php?mid=$row[1]' id='side-link'>");
								printf("$i. - ");
								for ($j = 0; $j < 20 && $row[0][$j] != null; $j++)
								{
									$s = $row[0][$j];
									printf("$s");
								}
								if (sizeof($row[0] > 20))
								{
									printf("...");
								}
								printf("</a>");
							}
							if ($row != null)
								printf("<br />");
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie M, Review R where M.id = R.mid group by M.id order by M.year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Popular Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]<br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
				</td>
				<td id="display-table">
					<div id="display-div">
						<h3 id="page-title">Actor Information</h3>
						
						<?php
							$actor = $_REQUEST['aid'];
							
							if ($actor != null)
							{
								$db_connection = mysql_connect("localhost", "cs143", "");
						
								$query = "select * from Actor where id = $actor";
						
								mysql_select_db("CS143", $db_connection);
								
								$temp = mysql_query($query, $db_connection);
								
								$rs = mysql_fetch_row($temp);
								
								if ($rs != null)
								{
									printf("<b>Name:</b> <b style='color:green'>$rs[1] $rs[2]</b> <br /> <b>Sex:</b> <b style='color:green'>$rs[3]</b> <br /> <b>Date of Birth:</b> <b style='color:green'>$rs[4]</b> <br />");
									
									if ($rs[5] != null)
									{
										printf("<b>Date of Death:</b> <b style='color:green'>$rs[5]</b> <br />");
									}
									else
									{
										printf("<b>Date of Death:</b> <b style='color:green'>Still Alive</b><br /><br />");
									}
									
									$query = "select mid, title, role from MovieActor MA, Movie M where MA.mid = M.id and MA.aid = $actor";
										
									$temp = mysql_query($query, $db_connection);
									
									$rs = mysql_fetch_row($temp);
									
									if ($rs != null)
									{
										printf("<h3>Acted in</h3>");
										
										do 
										{
											if ($rs != null)
											{
												printf("Acted as \"$rs[2]\" in <a href='movieInfo.php?mid=$rs[0]' style='color:green;text-decoration:underline;'>$rs[1]</a><br />");
											}
											$rs = mysql_fetch_row($temp);
										} while($rs != null);
									}
									else
									{
										printf("<h1 style='color:red;'>No related movie!</h1>");
									}
								}
								else
								{
									printf("<h1 style='color:red;'>Does not exist!</h1>");
								}
							}
						?>
						
						<br />
						<hr>
						<form action="actorInfo.php" method="GET">
							<?php
								$db_connection = mysql_connect("localhost", "cs143", "");
								
								$query = "select id, first, last from Actor";
						
								mysql_select_db("CS143", $db_connection);
								
								$temp = mysql_query($query, $db_connection);
								
								$rs = mysql_fetch_row($temp);
								
								printf("<select name='aid'>");
								
								do 
								{
									$rs = mysql_fetch_row($temp);
									if ($rs != null)
									{
										printf("<option value='$rs[0]'>$rs[1] $rs[2]</option>");
									}
									
								} while ($rs != null);
								
								printf("</select>");
								
								mysql_close($db_connection);
							?>
							
							<input type="submit" value="Search!" />
						</form>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>