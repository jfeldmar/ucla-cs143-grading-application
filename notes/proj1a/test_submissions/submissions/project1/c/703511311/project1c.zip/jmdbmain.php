<html>
	<head>
		<title>JMDB: Where People Meet Movie!</title>
		<link rel="stylesheet" type="text/css" href="main.css" />
		<script type="text/javascript" src="main.js"></script>
	</head>
	<body>
		<table id="main-table">
			<tr id="top-row">
				<td colspan="2">
					<table id="inner-table">
						<tr id="page-logo">
							<td colspan='6'>
								<a href="jmdbmain.php" id="logo">JMDB: Where People Meet Movies!</a>
							</td>
						</tr>
						<tr id="search-box-table">
							<td colspan='6'>
								<form action="jmdbmain.php" method="GET">
									<input id="search-box" type="text" name="query" value="Enter a search term" onfocus="clearSearchBox(id);" onblur="resetSearchBox(id);"><input id="search-button" type="submit" value="Search">
								</form>
							</td>
						</tr>
						<tr id="link-option">
							<td id="option1" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="actorInfo.php">Actor Info</a>
							</td>
							<td id="option2" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="movieInfo.php">Movie Info</a>
							</td>
							<td id="option3" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="aadi.php">Add Act/Direc Info</a>
							</td>
							<td id="option4" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ac.php">Add Comments</a>
							</td>
							<td id="option5" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ami.php">Add Movie Info</a>
							</td>
							<td id="option6" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="amar.php">Add Mov/Act Rel</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr id="bottom-row">
				<td id="side-table">
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie order by year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Recently Posted Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[1] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]</a><br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select comment, mid, time from Review order by time desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Latest Comments:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11 && $row != null; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
							{
								printf("<a href='movieInfo.php?mid=$row[1]' id='side-link'>");
								printf("$i. - ");
								for ($j = 0; $j < 20 && $row[0][$j] != null; $j++)
								{
									$s = $row[0][$j];
									printf("$s");
								}
								if (sizeof($row[0] > 20))
								{
									printf("...");
								}
								printf("</a>");
							}
							if ($row != null)
								printf("<br />");
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie M, Review R where M.id = R.mid group by M.id order by M.year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Popular Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]<br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
				</td>
				<td id="display-table">
					<div id="display-div">
						<h3 id="page-title">Contents</h3>
						<form method="GET">
							<?php
								$search = $_REQUEST['query'];
								
								if ($search != null && $search != "Enter a search term")
								{
									$firstTerm = "";
									$secondTerm = "";
									
									for($i = 0; $i < strlen($search) && $search[$i] != " "; $i++)
									{
										$firstTerm[$i] = $search[$i];
									}
									
									$count = $i;
									$i++;
									
									$firstTerm = strtoupper(implode($firstTerm));
									
									for(; $i < strlen($search) && $search[$i] != " "; $i++)
									{
										$secondTerm[$i - (count + 2)] = $search[$i];
									}
									
									if ($secondTerm != null)
										$secondTerm = strtoupper(implode($secondTerm));
									
									if (strlen($search) > $i)
									{
										printf("<h1 style='color:red;'>Enter only upto two terms!</h1>");
										exit(1);
									}
									
									$db_connection = mysql_connect("localhost", "cs143", "");
									
									mysql_select_db("CS143", $db_connection);
						
									$query = "select id, first, last, dob from Actor";
									
									$rs = mysql_query($query, $db_connection);
									
									$row = mysql_fetch_row($rs);
									
									$start = false;
									
									if ($row != null)
									{
										printf("<h1 style='color:blue;'>Result: Stars</h1>");
										
										do
										{
											$temp = strtoupper($row[1]).strtoupper($row[2]);
											$start = false;
											for ($i = 0; $i < strlen($temp); $i++)
											{
												if ($firstTerm[0] == $temp[$i])
												{
													$start = true;
													for ($j = 0; $j < strlen($firstTerm) && $i < strlen($temp); $j++, $i++)
													{
														if ($start == true && $firstTerm[$j] != $temp[$i])
														{
															$start = false;
															break;
														}
														
														if (($j + 1) < strlen($firstTerm) && ($i + 1) == strlen($temp))
														{
															$start = false;
															break;
														}
													}
												}
												
												if ($start == true)
													break;
											}
											
											if ($start == true && $secondTerm != null)
											{
												$start = false;
												for ($i = 0; $i < strlen($temp); $i++)
												{
													if ($secondTerm[0] == $temp[$i])
													{
														$start = true;
														for ($j = 0; $j < strlen($secondTerm) && $i < strlen($temp); $j++, $i++)
														{
															if ($start == true && $secondTerm[$j] != $temp[$i])
															{
																$start = false;
																break;
															}
															
															if (($j + 1) < strlen($secondTerm) && ($i + 1) == strlen($temp))
															{
																$start = false;
																break;
															}
														}
													}
													
													if ($start == true)
														break;
												}
											}
											
											if ($start == true)
											{	
												echo "<a href='actorInfo.php?aid=$row[0]' style='color:green;text-decoration:underline;'>$row[1] $row[2] ($row[3])</a><br />";
											}	
											$row = mysql_fetch_row($rs);
										} while($row != null);
									}
									else
									{
										printf("<h1 style='color:red;'>No match found!</h1>");
									}
									
									$query = "select id, title, year from Movie";
									
									$rs = mysql_query($query, $db_connection);
									
									$row = mysql_fetch_row($rs);
									
									$start = false;
									
									if ($row != null)
									{
										printf("<h1 style='color:blue;'>Result: Movies</h1>");
										
										do
										{
											$temp = strtoupper($row[1]);
											$start = false;
											for ($i = 0; $i < strlen($temp); $i++)
											{
												if ($firstTerm[0] == $temp[$i])
												{
													$start = true;
													for ($j = 0; $j < strlen($firstTerm) && $i < strlen($temp); $j++, $i++)
													{
														if ($start == true && $firstTerm[$j] != $temp[$i])
														{
															$start = false;
															break;
														}
														
														if (($j + 1) < strlen($firstTerm) && ($i + 1) == strlen($temp))
														{
															$start = false;
															break;
														}
													}
												}
												
												if ($start == true)
													break;
											}
											
											if ($start == true && $secondTerm != null)
											{
												$start = false;
												for ($i = 0; $i < strlen($temp); $i++)
												{
													if ($secondTerm[0] == $temp[$i])
													{
														$start = true;
														for ($j = 0; $j < strlen($secondTerm) && $i < strlen($temp); $j++, $i++)
														{
															if ($start == true && $secondTerm[$j] != $temp[$i])
															{
																$start = false;
																break;
															}
															
															if (($j + 1) < strlen($secondTerm) && ($i + 1) == strlen($temp))
															{
																$start = false;
																break;
															}
														}
													}
													
													if ($start == true)
														break;
												}
											}
											
											if ($start == true)
											{	
												echo "<a href='movieInfo.php?mid=$row[0]' style='color:brown;text-decoration:underline;'>$row[1] ($row[2])</a><br />";
											}	
											$row = mysql_fetch_row($rs);
										} while($row != null);
									}
									else
									{
										printf("<h1 style='color:red;'>No match found!</h1>");
									}
									
									mysql_close($db_connection);
								}
							?>
						</form>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>