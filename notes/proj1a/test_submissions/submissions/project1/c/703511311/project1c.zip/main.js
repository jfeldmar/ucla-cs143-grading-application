/**
 * @author john
 */
function optionMouseOver(id)
{
	document.getElementById(id).style.backgroundColor = "#6cff6e";
}

function optionMouseOut(id)
{
	document.getElementById(id).style.backgroundColor = "#7aa938";
}

function clearSearchBox(id)
{
	if (document.getElementById(id).value == "Enter a search term")
	{
		document.getElementById(id).value = "";
	}
}

function resetSearchBox(id)
{
	if (document.getElementById(id).value == "")
	{
		document.getElementById(id).value = "Enter a search term";
	}
}
