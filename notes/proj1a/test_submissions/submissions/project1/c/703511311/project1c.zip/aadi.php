<html>
	<head>
		<title>JMDB: Where People Meet Movie!</title>
		<link rel="stylesheet" type="text/css" href="main.css" />
		<script type="text/javascript" src="main.js"></script>
	</head>
	<body>
		<table id="main-table">
			<tr id="top-row">
				<td colspan="2">
					<table id="inner-table">
						<tr id="page-logo">
							<td colspan='6'>
								<a href="jmdbmain.php" id="logo">JMDB: Where People Meet Movies!</a>
							</td>
						</tr>
						<tr id="search-box-table">
							<td colspan='6'>
								<form action="jmdbmain.php" method="GET">
									<input id="search-box" type="text" name="query" value="Enter a search term" onfocus="clearSearchBox(id);" onblur="resetSearchBox(id);"><input id="search-button" type="submit" value="Search">
								</form>
							</td>
						</tr>
						<tr id="link-option">
							<td id="option1" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="actorInfo.php">Actor Info</a>
							</td>
							<td id="option2" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="movieInfo.php">Movie Info</a>
							</td>
							<td id="option3" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="aadi.php">Add Act/Direc Info</a>
							</td>
							<td id="option4" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ac.php">Add Comments</a>
							</td>
							<td id="option5" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ami.php">Add Movie Info</a>
							</td>
							<td id="option6" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="amar.php">Add Mov/Act Rel</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr id="bottom-row">
				<td id="side-table">
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie order by year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Recently Posted Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[1] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]</a><br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select comment, mid, time from Review order by time desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Latest Comments:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11 && $row != null; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
							{
								printf("<a href='movieInfo.php?mid=$row[1]' id='side-link'>");
								printf("$i. - ");
								for ($j = 0; $j < 20 && $row[0][$j] != null; $j++)
								{
									$s = $row[0][$j];
									printf("$s");
								}
								if (sizeof($row[0] > 20))
								{
									printf("...");
								}
								printf("</a>");
							}
							if ($row != null)
								printf("<br />");
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie M, Review R where M.id = R.mid group by M.id order by M.year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Popular Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]<br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
				</td>
				<td id="display-table">
					<div id="display-div">
						<h3 id="page-title">Add Actor/Director</h3>
						<form action="aadi.php" method="GET">
							Identity:
							<input name="actorOrDirector" id="actorRadioButton" type="radio" value="actor" checked="">Actor
							<input name="actorOrDirector" id="directorRadioButton" type="radio" value="director">Director
							<br /><br />
							First Name:<input name="firstName" type="text"><br />
							Last Name:<input name="lastName" type="text"><br /><br />
							Gender:
							<input name="gender" id="male" type="radio" value="male" checked="">Male
							<input name="gender" id="female" type="radio" value="female">Female
							<br /><br />
							DOB:
							<select name="dob-year">
								<option>Year</option>
								<?php
									$i = 0;
									for ($i = 2009; $i > 1900; $i--)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>	
							<select name="dob-month">
								<option>Month</option>
								<?php
									$i = 0;
									for ($i = 1; $i < 13; $i++)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>
							<select name="dob-day">
								<option>Day</option>
								<?php
									$i = 0;
									for ($i = 1; $i < 32; $i++)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>
							<br />
							DOD:
							<select name="dod-year">
								<option>Year</option>
								<?php
									$i = 0;
									for ($i = 2009; $i > 1900; $i--)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>	
							<select name="dod-month">
								<option>Month</option>
								<?php
									$i = 0;
									for ($i = 1; $i < 13; $i++)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>
							<select name="dod-day">
								<option>Day</option>
								<?php
									$i = 0;
									for ($i = 1; $i < 32; $i++)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>
							<br />
							<br />
							<input id="submit" type="submit" value="ADD">
						</form>
						
						<?php
							function addPerson()
							{
								$actor = 0;
								$firstName = null;
								$lastName = null;
								$gender = null;
								$dob = null;
								$dod = null;
								
								if ($_REQUEST["actorOrDirector"] == "actor")
								{
									$actor = 1;
									if ($_REQUEST["gender"] == "male")
										$gender = "male";
									else
										$gender = "female";
								}
								
								$firstName = $_REQUEST["firstName"];
								$lastName = $_REQUEST["lastName"];
								if ($firstName == null)
								{
									printf("Please enter the First Name");
									exit(1);
								}
								if ($lastName == null)
								{
									printf("Please enter the Last Name");
									exit(1);
								}
								
								$year = $_REQUEST["dob-year"];
								$month = $_REQUEST["dob-month"];
								$day = $_REQUEST["dob-day"];
								
								if ($year != "Year" && $month != "Month" && $day != "Day")
								{
									if ($month < 10)
										$month = "0".$month;
									if ($day < 10)
										$day = "0".$day;
									
									$dob = $year."-".$month."-".$day;
								}
								else
								{
									print("<h1 style='color:red;'>Please choose DOB!</h1>");
									exit(0);
								}
								
								$year = $_REQUEST["dod-year"];
								$month = $_REQUEST["dod-month"];
								$day = $_REQUEST["dod-day"];
								
								if ($year != "Year" && $month != "Month" && $day != "Day")
								{
									if ($month < 10)
										$month = "0".$month;
									if ($day < 10)
										$day = "0".$day;
									
									$dod = $year."-".$month."-".$day;
								}
								else
								{
									$dod = null;
								}
								
								$db_connection = mysql_connect("localhost", "cs143", "");
								mysql_select_db("CS143", $db_connection);
								
								$query = "";
						
								if ($actor == 1)
								{
									$id = 0;
									$query = "select * from Actor where first = '$firstName' and last = '$lastName'";
									$temp = mysql_query($query, $db_connection);
									
									if (mysql_fetch_row($temp) == null)
									{
										$query = "select id from Director where first = '$firstName' and last = '$lastName'";
										$temp = mysql_query($query, $db_connection);
										
										$check = mysql_fetch_row($temp);
										
										if ($check == null)
										{
											$query = "select id from MaxPersonID";
											$rs = mysql_fetch_row(mysql_query($query, $db_connection));
											$id = $rs[0]+1;
										}
										else
										{
											$id = $check[0];
										}
										
										if ($dod != null)
											$query = "insert into Actor values ($id, '$lastName', '$firstName', '$gender', '$dob', '$dod')";
										else
											$query = "insert into Actor values ($id, '$lastName', '$firstName', '$gender', '$dob', null)";
											
										if (mysql_query($query, $db_connection))
										{
											printf("<h1 style='color:green;'>Successfully Added!</h1>");
											
											if ($check == null)
											{
												$query = "update MaxPersonID set id = $id";
												mysql_query($query, $db_connection);
											}
										}
										else
										{
											printf("<h1 style='color:red;'>Please, do it again!</h1>");
										}
									}
									else
									{
										printf("<h1 style='color:red;'>Please, do it again!</h1>");
									}
								}
								else
								{
									$id = 0;
									$query = "select * from Director where first = '$firstName' and last = '$lastName'";
									$temp = mysql_query($query, $db_connection);
									
									if (mysql_fetch_row($temp) == null)
									{
										$query = "select id from Actor where first = '$firstName' and last = '$lastName'";
										$temp = mysql_query($query, $db_connection);
										
										$check = mysql_fetch_row($temp);
										
										if ($check == null)
										{
											$query = "select id from MaxPersonID";
											$rs = mysql_fetch_row(mysql_query($query, $db_connection));
											$id = $rs[0]+1;
										}
										else
										{
											$id = $check[0];
										}
										
										if ($dod != null)
											$query = "insert into Director values ($id, '$lastName', '$firstName', '$dob', '$dod')";
										else
											$query = "insert into Director values ($id, '$lastName', '$firstName', '$dob', null)";
											
										if (mysql_query($query, $db_connection))
										{
											printf("<h1 style='color:green;'>Successfully Added!</h1>");
											
											if ($check == null)
											{
												$query = "update MaxPersonID set id = $id";
												mysql_query($query, $db_connection);
											}
										}
										else
										{
											printf("<h1 style='color:red;'>Please, do it again!</h1>");
										}
									}
									else
									{
										printf("<h1 style='color:red;'>Please, do it again!</h1>");
									}
								}
								mysql_close($db_connection);
							}
							
							if ($_REQUEST["firstName"] != null ||
								$_REQUEST["lastName"] != null)
								addPerson();
						?>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>