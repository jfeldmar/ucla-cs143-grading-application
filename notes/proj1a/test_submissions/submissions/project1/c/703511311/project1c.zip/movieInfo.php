<html>
	<head>
		<title>JMDB: Where People Meet Movie!</title>
		<link rel="stylesheet" type="text/css" href="main.css" />
		<script type="text/javascript" src="main.js"></script>
	</head>
	<body>
		<table id="main-table">
			<tr id="top-row">
				<td colspan="2">
					<table id="inner-table">
						<tr id="page-logo">
							<td colspan='6'>
								<a href="jmdbmain.php" id="logo">JMDB: Where People Meet Movies!</a>
							</td>
						</tr>
						<tr id="search-box-table">
							<td colspan='6'>
								<form action="jmdbmain.php" method="GET">
									<input id="search-box" type="text" name="query" value="Enter a search term" onfocus="clearSearchBox(id);" onblur="resetSearchBox(id);"><input id="search-button" type="submit" value="Search">
								</form>
							</td>
						</tr>
						<tr id="link-option">
							<td id="option1" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="actorInfo.php">Actor Info</a>
							</td>
							<td id="option2" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="movieInfo.php">Movie Info</a>
							</td>
							<td id="option3" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="aadi.php">Add Act/Direc Info</a>
							</td>
							<td id="option4" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ac.php">Add Comments</a>
							</td>
							<td id="option5" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ami.php">Add Movie Info</a>
							</td>
							<td id="option6" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="amar.php">Add Mov/Act Rel</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr id="bottom-row">
				<td id="side-table">
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie order by year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Recently Posted Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[1] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]<br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select comment, mid, time from Review order by time desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Latest Comments:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11 && $row != null; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
							{
								printf("<a href='movieInfo.php?mid=$row[1]' id='side-link'>");
								printf("$i. - ");
								for ($j = 0; $j < 20 && $row[0][$j] != null; $j++)
								{
									$s = $row[0][$j];
									printf("$s");
								}
								if (sizeof($row[0] > 20))
								{
									printf("...");
								}
								printf("</a>");
							}
							if ($row != null)
								printf("<br />");
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie M, Review R where M.id = R.mid group by M.id order by M.year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Popular Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]</a><br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
				</td>
				<td id="display-table">
					<div id="display-div">
						<h3 id="page-title">Movie Information</h3>
						<?php
							$movie = $_REQUEST['mid'];
							
							if ($movie != null)
							{
								$db_connection = mysql_connect("localhost", "cs143", "");
						
								$query = "select title, company, rating, year from Movie where id = $movie";
						
								mysql_select_db("CS143", $db_connection);
								
								$temp = mysql_query($query, $db_connection);
								
								$rs = mysql_fetch_row($temp);
								
								$query = "select first, last from Director D, MovieDirector MD where MD.mid = $movie and MD.did = D.id";
								
								$temp2 = mysql_query($query, $db_connection);
								
								$rsd = mysql_fetch_row($temp2);
								
								$query = "select genre from MovieGenre where mid = $movie";
								
								$temp3 = mysql_query($query, $db_connection);
								
								$rsg = mysql_fetch_row($temp3);
								
								if ($rs != null)
								{
									printf("<b>Title:</b> <b style='color:green'>$rs[0] ($rs[3])</b> <br /> <b>Producer:</b> <b style='color:green'>$rs[1]</b> <br /> <b>MPAA Rating:</b> <b style='color:green'>$rs[2]</b> <br /> <b>Director:</b> <b style='color:green'>$rsd[0] $rsd[1]</b> <br />");
									printf("<b>Genre: </b>");
									do 
									{
										if ($rsg != null)
										{
											printf("<b style='color:green'>$rsg[0]</b>");
										}
										$rsg = mysql_fetch_row($temp3);
										if ($rsg != null)
											printf(", ");
									} while($rsg != null);
									
									$query = "select id, first, last, role from MovieActor MA, Actor A where MA.mid = $movie and MA.aid = A.id";
										
									$temp = mysql_query($query, $db_connection);
									
									$rs = mysql_fetch_row($temp);
									
									if ($rs != null)
									{
										printf("<br /><br /><h3>Stars in this movie:</h3>");
										
										do 
										{
											if ($rs != null)
											{
												printf("<a href='actorInfo.php?aid=$rs[0]' style='color:green;text-decoration:underline;'>$rs[1] $rs[2]</a> acted as \"$rs[3]\"<br />");
											}
											$rs = mysql_fetch_row($temp);
										} while($rs != null);
									}
									else
									{
										printf("<h1 style='color:red;'>No related star!</h1>");
									}
									
									$query = "select * from Review where mid = $movie";
										
									$temp = mysql_query($query, $db_connection);
									
									$rs = mysql_fetch_row($temp);
									
									if ($rs != null)
									{
										printf("<br /><br /><h3>User Review:</h3>");
										
										$query = "select AVG(rating), COUNT(*) from Review where mid = $movie";
										
										$temp2 = mysql_query($query, $db_connection);
										
										$rs1 = mysql_fetch_row($temp2);
										
										printf("Average Score: $rs1[0]/5 by $rs1[1] review(s). <a href='ac.php?mid=$movie' style='color:green;text-decoration:underline;'>Add your review!</a><br />");
										printf("All Comments in Details:<br /><br />");
										
										do 
										{
											if ($rs != null)
											{
												printf("<p style='color:blue;'>Name: $rs[0], on $rs[1], rated $rs[3]</p>");
												printf("$rs[4]<br />");
											}
											$rs = mysql_fetch_row($temp);
										} while($rs != null);
										
										printf("<br />");
									}
									else
									{
										printf("<h2><a href='ac.php?mid=$movie' style='color:blue;text-decoration:underline;'>Add your review!</a></h2>");
									}
								}
								else
								{
									printf("<h1 style='color:red;'>Does not exist!</h1>");
								}
								mysql_close($db_connection);
							}
						?>
						
						<br />
						<hr>
						<form action="movieInfo.php" method="GET">
							<?php
								$db_connection = mysql_connect("localhost", "cs143", "");
								
								$query = "select id, title from Movie";
						
								mysql_select_db("CS143", $db_connection);
								
								$temp = mysql_query($query, $db_connection);
								
								$rs = mysql_fetch_row($temp);
								
								printf("<select name='mid'>");
								
								do 
								{
									$rs = mysql_fetch_row($temp);
									if ($rs != null)
									{
										printf("<option value='$rs[0]'>$rs[1]</option>");
									}
									
								} while ($rs != null);
								
								printf("</select>");
								
								mysql_close($db_connection);
							?>
							
							<input type="submit" value="Search!" />
						</form>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>