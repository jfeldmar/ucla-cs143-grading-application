<html>
	<head>
		<title>JMDB: Where People Meet Movie!</title>
		<link rel="stylesheet" type="text/css" href="main.css" />
		<script type="text/javascript" src="main.js"></script>
	</head>
	<body>
		<table id="main-table">
			<tr id="top-row">
				<td colspan="2">
					<table id="inner-table">
						<tr id="page-logo">
							<td colspan='6'>
								<a href="jmdbmain.php" id="logo">JMDB: Where People Meet Movies!</a>
							</td>
						</tr>
						<tr id="search-box-table">
							<td colspan='6'>
								<form action="jmdbmain.php" method="GET">
									<input id="search-box" type="text" name="query" value="Enter a search term" onfocus="clearSearchBox(id);" onblur="resetSearchBox(id);"><input id="search-button" type="submit" value="Search">
								</form>
							</td>
						</tr>
						<tr id="link-option">
							<td id="option1" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="actorInfo.php">Actor Info</a>
							</td>
							<td id="option2" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="movieInfo.php">Movie Info</a>
							</td>
							<td id="option3" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="aadi.php">Add Act/Direc Info</a>
							</td>
							<td id="option4" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ac.php">Add Comments</a>
							</td>
							<td id="option5" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="ami.php">Add Movie Info</a>
							</td>
							<td id="option6" onmouseover="optionMouseOver(id);" onmouseout="optionMouseOut(id);" onclick="optionMouseOver(id);">
								<a href="amar.php">Add Mov/Act Rel</a>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr id="bottom-row">
				<td id="side-table">
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie order by year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Recently Posted Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[1] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]</a><br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select comment, mid, time from Review order by time desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Latest Comments:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11 && $row != null; $i++)
						{
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
							{
								printf("<a href='movieInfo.php?mid=$row[1]' id='side-link'>");
								printf("$i. - ");
								for ($j = 0; $j < 20 && $row[0][$j] != null; $j++)
								{
									$s = $row[0][$j];
									printf("$s");
								}
								if (sizeof($row[0] > 20))
								{
									printf("...");
								}
								printf("</a>");
							}
							if ($row != null)
								printf("<br />");
						}
						mysql_close($db_connection);
					?>
					
					<hr>
					
					<?php
						$db_connection = mysql_connect("localhost", "cs143", "");
						
						$query = "select id, title from Movie M, Review R where M.id = R.mid group by M.id order by M.year desc";
				
						mysql_select_db("CS143", $db_connection);
						
						$rs = mysql_query($query, $db_connection);
						
						printf("<b>Most Popular Title:</b><br />");
						
						$i = 0;
						for ($i = 1; $i < 11; $i++)
						{
							
							$row = mysql_fetch_row($rs);
							if ($row[0] != null)
								echo "<a href='movieInfo.php?mid=$row[0]' id='side-link'>$i - $row[1]<br />";
						}
						mysql_close($db_connection);
					?>
					
					<hr>
				</td>
				<td id="display-table">
					<div id="display-div">
						<h3 id="page-title">Add Movie Information</h3>
						<form method="GET">
							Title:
							<input style="margin-left:33px;" type="text" name="movie-title" />
							<br />
							Company:
							<input type="text" name="movie-company" />
							<br />
							Year:
							<select name="year" style="margin-left:33px;">
								<?php
									for ($i = 2009; $i > 1900; $i--)
									{
										printf("<option value='$i'>$i</option>");
									}
								?>
							</select>
							<br /><br />
							Director:
							<select name="director">
								<?php
									$db_connection = mysql_connect("localhost", "cs143", "");
							
									$query = "select id, first, last from Director order by last asc";
							
									mysql_select_db("CS143", $db_connection);
									
									$rs = mysql_query($query, $db_connection);
									
									$temp = mysql_fetch_row($rs);
									
									do 
									{
										if ($temp != null)
											printf("<option value='$temp[0]'>$temp[1] $temp[2]</option>");
											
										$temp = mysql_fetch_row($rs);
									} while ($temp != null);
									
									mysql_close($db_connection);
								?>
							</select>
							<br /><br />
							MPAA rating:
							<select name="rating">
								<option value="G">G</option>
								<option value="NC-17">NC-17</option>
								<option value="PG">PG</option>
								<option value="PG-13">PG-13</option>
								<option value="R">R</option>
								<option value="surrendere">surrendere</option>
							</select>
							<br /><br />
							Genre:
							<br />
							<input type="checkbox" name="genre_Action" value="Action">Action</input>
							<input type="checkbox" name="genre_Adult" value="Adult">Adult</input>
							<input type="checkbox" name="genre_Adventure" value="Adventure">Adventure</input>
							<input type="checkbox" name="genre_Animation" value="Animation">Animation</input>
							<input type="checkbox" name="genre_Comedy" value="Comedy">Comedy</input>
							<br />
							<input type="checkbox" name="genre_Crime" value="Crime">Crime</input>
							<input type="checkbox" name="genre_Documentary" value="Documentary">Documentary</input>
							<input type="checkbox" name="genre_Drama" value="Drama">Drama</input>
							<input type="checkbox" name="genre_Family" value="Family">Family</input>
							<input type="checkbox" name="genre_Fantasy" value="Fantasy">Fantasy</input>
							<br />
							<input type="checkbox" name="genre_Horror" value="Horror">Horror</input>
							<input type="checkbox" name="genre_Musical" value="Musical">Musical</input>
							<input type="checkbox" name="genre_Mystery" value="Mystery">Mystery</input>
							<input type="checkbox" name="genre_Romance" value="Romance">Romance</input>
							<input type="checkbox" name="genre_Sci-Fi" value="Sci-Fi">Sci-Fi</input>
							<br />
							<input type="checkbox" name="genre_Short" value="Short">Short</input>
							<input type="checkbox" name="genre_Thriller" value="Thriller">Thriller</input>
							<input type="checkbox" name="genre_War" value="War">War</input>
							<input type="checkbox" name="genre_Western" value="Western">Western</input>
							<br /><br />
							
							<input type="submit" value="Done!" />
						</form>
						
						<?php
							$title = $_REQUEST['movie-title'];
							$company = $_REQUEST['movie-company'];
							$year = $_REQUEST['year'];
							$director = $_REQUEST['director'];
							$rating = $_REQUEST['rating'];
							
							if ($title != null && $company != null)
							{
								$db_connection = mysql_connect("localhost", "cs143", "");
						
								mysql_select_db("CS143", $db_connection);
								
								$query = "select * from MaxMovieID";
								
								$rs = mysql_fetch_row(mysql_query($query, $db_connection));
								
								$newMid = $rs[0] + 1;
								
								$query = "insert into Movie values ($newMid, '$title', $year, '$rating', '$company')";
								$query2 = "update MaxMovieID set id = $newMid";
								$query3 = "insert into MovieDirector values($newMid, $director)";
								if (mysql_query($query, $db_connection) && mysql_query($query2, $db_connection) && mysql_query($query3, $db_connection))
								{
									$genre[0] = $_REQUEST['genre_Action'];
									$genre[1] = $_REQUEST['genre_Adult'];
									$genre[2] = $_REQUEST['genre_Adventure'];
									$genre[3] = $_REQUEST['genre_Animation'];
									$genre[4] = $_REQUEST['genre_Comedy'];
									$genre[5] = $_REQUEST['genre_Crime'];
									$genre[6] = $_REQUEST['genre_Documentary'];
									$genre[7] = $_REQUEST['genre_Drama'];
									$genre[8] = $_REQUEST['genre_Family'];
									$genre[9] = $_REQUEST['genre_Fantasy'];
									$genre[10] = $_REQUEST['genre_Horror'];
									$genre[11] = $_REQUEST['genre_Musical'];
									$genre[12] = $_REQUEST['genre_Mystery'];
									$genre[13] = $_REQUEST['genre_Romance'];
									$genre[14] = $_REQUEST['genre_Sci-fi'];
									$genre[15] = $_REQUEST['genre_Short'];
									$genre[16] = $_REQUEST['genre_Thriller'];
									$genre[17] = $_REQUEST['genre_War'];
									$genre[18] = $_REQUEST['genre_Western'];
									
									for ($i = 0; $i < sizeof($genre); $i++)
									{
										if ($genre[$i] != null)
										{
											$query = "insert into MovieGenre values($newMid, '$genre[$i]')";
											if (!mysql_query($query, $db_connection))
											{
												printf("<h1 style='color:red;'>Please, do it again!</h1>");
												exit(1);
											}
										}
									}
									printf("<h1 style='color:green;'>Successfully Added!</h1>");
								}
								else
								{
									$query = "delete from Movie where id = $newMid";
									$newMid = $newMid - 1;
									$query2 = "update MaxMovieID set id = $newMid";
									
									mysql_query($query, $db_connection);
									mysql_query($query2, $db_connection);
									
									printf("<h1 style='color:red;'>Please, do it again!</h1>");
								}
								
								mysql_close($db_connection);
							}
						?>
					</div>
				</td>
			</tr>
		</table>
	</body>
</html>