<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>To search for a movie or actor, type your search and submit.</b>
<br><br>
<form action="search.php" method="GET">


<input type=text name=search value=''>
<br> 
<input type=submit name=submit value='search'>

<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$search = $_GET['search'];


if($_GET['submit'] and $search != null)
{

echo '<br><br>You are searching for '; echo $search;

echo '<br><br><br>';

echo 'We are now searching for any records that match your search in the ACTOR database... ';

$query = "SELECT id,first,last,dob,dod FROM Actor";
$result = mysql_query($query, $db_connection)or die(mysql_error());

$query2 = "SELECT id,title,year FROM Movie";
$result2 = mysql_query($query2, $db_connection)or die(mysql_error());

$query1 = "SELECT id FROM MaxPersonID";
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);

 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result);

	//if(strnatcasecmp($row[1],$search) == 0|| strnatcasecmp($row[2],$search) == 0)
	if(stristr($row[1],$search) || stristr($row[2],$search))
	{
		echo '<br>'; 
		echo "Actor: <a href=showactor.php?actorid=$row[0]&submit=true target='start'>$row[1] $row[2] ($row[3])</a>";
				
	}
	else if($row[1] == null)
	{
		echo '<br>no more entries';
		break;
	}
    }

echo '<br><br>We are now searching for any records that match your search in the MOVIE database... ';


 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result2);

	//if(strnatcasecmp($row[1],$search) == 0)
	if(stristr($row[1],$search))
	{
		echo '<br>'; 
		echo "Movie: <a href=showmovie.php?movieid=$row[0]&submit=true target='start'>$row[1] ($row[2])</a>";
				
	}
	else if($row[1] == null)
	{
		echo '<br>no more entries';
		break;
	}
    }

}
else if($_GET['submit'])
{
	echo '<br><br>Please type in your search criteria';
}

?> 


</form>
</html>