<HTML>
<BODY BGCOLOR = 'black'>
<font color='gold'>
<?php 

echo '<HEADER><FONT SIZE=6> MOVIE DATABASE WEB INTERFACE';
echo '<br><br><br><br><br>';

echo '<b><font size = 5> Welcome, please choose what you would like to do from the menu on the left.'

?>

</HTML>
