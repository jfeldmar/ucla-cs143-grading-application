<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>What what would you like add?</b>

<form action="addactor.php" method="GET">
<input type='radio' name='type' value=0 checked=true>Actor
<input type='radio' name='type' value=1>Director
<br>

<hr><br><br>

<b>First Name</b>: <input type='text' name='fname' value=''><br>
<b>Last Name</b>: <input type='text' name='lname' value=''><br>
<b>Sex</b>: <input type='radio' name='sex' value='Male' checked=true>Male
	    <input type='radio' name='sex' value='Female'>Female<br>
<b>Date of Birth</b>: <input type='text' name='dob' value=''>
<font size=2>Format : yyyy-mm-dd<br></font>
<b>Date of Death</b>: <input type='text' name='dod' value=''>
<font size=2>(leave blank if alive now)<br></font>
<hr>
<input type='submit' name='submit' value='Submit'><br><br>

</form>

<?php

error_reporting(0);

$type = $_GET['type'];
$fname = $_GET['fname'];
$lname = $_GET['lname'];
$sex = $_GET['sex'];
$dob = $_GET['dob'];
$dod = $_GET['dod'];


$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);


if($_GET['submit'] && $type ==0 && $fname != null && $lname != null && $sex != null && $dob != null)
{

	$result1 = mysql_query('UPDATE MaxPersonID SET id = id + 1' , $db_connection) or die(mysql_error());
	$result1 = mysql_query('SELECT id FROM MaxPersonID', $db_connection);
	$row = mysql_fetch_row($result1);
	//echo $row[0];
	$query2 = "INSERT INTO Actor(id,last,first,sex,dob,dod) VALUES ('$row[0]','$lname','$fname','$sex','$dob','$dod')";
	$result2 = mysql_query($query2, $db_connection)or die(mysql_error());
	if($result2)
	{
		echo 'Success, the following person was added to the actor database';
	}
	else
		echo 'Sorry, the person could not be added';

}
else if($_GET['submit'] && $type==1 && $fname != null && $lname != null && $sex != null && $dob != null)
{

	$result1 = mysql_query('UPDATE MaxPersonID SET id = id + 1' , $db_connection) or die(mysql_error());
	$result1 = mysql_query('SELECT id FROM MaxPersonID', $db_connection);
	$row = mysql_fetch_row($result1);
	//echo $row[0];
	$query2 = "INSERT INTO Director(id,last,first,dob,dod) VALUES ('$row[0]','$lname','$fname','$dob','$dod')";
	$result2 = mysql_query($query2, $db_connection)or die(mysql_error());
	if($result2)
	{
		echo 'Success, the following person was added to the director database';
	}
	else
		echo 'Sorry, the person could not be added';

}
else if($_GET['submit'])
{
	echo 'Sorry, the person could not be added';
}

mysql_close($db_connection);
?>

</body>
</font>
</HTML>
