<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>

<B>Add A New Comment<br><br></B>


<hr>
<form action=addcomment.php>

Please select the movie you would like to add a comment to:<br><br>

<?php

$moviename = $_GET['moviename'];


$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);


$query = 'SELECT id,title FROM Movie';
$result = mysql_query($query, $db_connection);

$query1 = 'SELECT id FROM MaxMovieID';
$result1 = mysql_query($query1, $db_connection);
$row1 = mysql_fetch_row($result1);

?>

<Select name = 'moviename'>


<?php

 for ($i=0;$i<$row1;$i++)
    {
        $row = mysql_fetch_row($result);
        
        if($row[0]!=null)
	{
		if($moviename == $row[0])
			print("<option value=\"$row[0]\" selected='selected'>$row[1]</option>");
		else
			print("<option value=\"$row[0]\">$row[1]</option>");
	}
	else
		break;
    }
?>

</SELECT>
<br><br>
<b>Please Enter Your Name: 
<input type=text name='name' value='Enter name here...'onFocus=this.value=''> <br>
<b>Rate This Movie:
<select name ='rate'>
<option  value=5>5 - Excellent
<option value=4>4 - Good
<option value=3>3 - Its OK
<option value=2>2 - Not Worth
<option value=1>1 - I hate it
</select><br>

<b>Comments:<br>
<TEXTAREA name=comments cols=100 rows=8></TEXTAREA>
<br><br>
<input type=submit name=submit value='Submit'>

<hr>
<?php

$name = $_GET['name'];
$rate = $_GET['rate'];
$comments = $_GET['comments'];

if($_GET['submit'] && $moviename && ($name != 'Enter name here...' && $name != null) && $rate && $comments)
{

$query2 = "SELECT id,title FROM Movie WHERE id= '$moviename' ";
$result2 = mysql_query($query2, $db_connection)or die(mysql_error());
$row2 = mysql_fetch_row($result2);

$query3 = "SELECT NOW()";
$result3 = mysql_query($query3, $db_connection)or die(mysql_error());
$row3 = mysql_fetch_row($result3);

$query3 = "INSERT INTO Review(name,time,mid,rating,comment) VALUES ('$name', '$row3[0]', '$row2[0]','$rate', '$comments')";
$result3 = mysql_query($query3, $db_connection)or die(mysql_error());

if($result3)
{
	echo 'Thank you for your comment.<br>';
	echo 'A comment has been added to the movie: '; echo "<a href=showmovie.php?movieid=$row2[0]&submit=true > $row2[1]</a>";
}
else
	echo 'Sorry, Your comment could not be added, please make sure you completetly fill out the form.';
}
else if($_GET['submit'])
{
	echo 'Sorry, Your comment could not be added, please make sure you completetly fill out the form.';

}

?>
</BODY>
</HTML>