<HTML>

<frameset cols="300,*" border=0 >
<frame src="menu.php" name="menu" scrolling="no"/>
<frame src="start.php" name="start" scrolling="yes" noresize=true />
</frameset>

<HTML>