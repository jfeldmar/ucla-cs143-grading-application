<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>To find information about a movie, please fill out the following data and submit.</b>
<br><br>
<form action="showmovie.php" method="GET">

<b> Please select the actor you wish to find out more information about:<br>


<?php
$movieid = $_GET['movieid'];


$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$query1 = 'SELECT id FROM MaxMovieID';
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);

$query2 = 'SELECT id,title,year FROM Movie';
$result2 = mysql_query($query2, $db_connection);

?>

<Select name = 'movieid'>


<?php

 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result2);
        
        if($row[0]!=null)
	{
		if($movieid == $row[0])
			print("<option value=\"$row[0]\" selected='selected'>$row[1] ($row[2])</option>");
		else
			print("<option value=\"$row[0]\">$row[1] ($row[2])</option>");
	}
	else
		break;
    }
?>

</select>

<input type=submit name=submit value='Submit'>

<hr>


</FORM>

<?php


if($_GET['submit'])
{

if($movieid != null)
{
	$query5 = "SELECT title,year,rating,company FROM Movie WHERE id='$movieid'";
	$result5 = mysql_query($query5, $db_connection)or die(mysql_error());
	$row5 = mysql_fetch_row($result5);

	$query3 = "SELECT genre FROM MovieGenre WHERE mid = '$movieid'";
	$result3 = mysql_query($query3, $db_connection)or die(mysql_error());
	$row3 = mysql_fetch_row($result3);

	echo '<br><b>Here is the movie information you have requested: ';
	echo '<br>Title: '; echo $row5[0];
	echo '<br>Year of production: '; echo $row5[1];
	echo '<br>MPAA Rating: '; echo $row5[2];
	echo '<br>Production Company: '; echo $row5[3];
	echo '<br>Genre: '; echo $row3[0];
	
	$query6 = "SELECT aid,role FROM MovieActor WHERE mid = '$movieid'";
	$result6 = mysql_query($query6, $db_connection)or die(mysql_error());
	

	$query8 = 'SELECT id FROM MaxPersonID';
	$result8 = mysql_query($query8, $db_connection)or die(mysql_error());
	$row8 = mysql_fetch_row($result8);
	
	echo '<br><br> The following actors were in this movie: ';
	
	
	for($i = 0; $i < $row8[0]; $i++)
	{
		$row6 = mysql_fetch_row($result6);
		

		if($row6[0])
		{
		$actorid = $row6[0];

		$query7 = "SELECT id,first,last FROM Actor WHERE id='$actorid'";
		$result7 = mysql_query($query7, $db_connection)or die(mysql_error());
		$row7 = mysql_fetch_row($result7);

		echo "<br>Name: <a href=showactor.php?actorid=$row7[0]&submit=true> $row7[1] $row7[2] </a>";
		echo '<br>Role: '; echo $row6[1];

		}
		else
			break;
	}

	echo '<br><br><br>The following reviews were found:';
	echo '<br>';

	$query9 = "SELECT COUNT(*),avg(rating),name,time,comment,rating FROM Review WHERE mid='$movieid' GROUP BY mid";
	$result9 = mysql_query($query9, $db_connection)or die(mysql_error());
	$row9 = mysql_fetch_row($result9);

	echo $row9[0];


	if($row9[0])
	{
		echo 'Average Rating: '; echo $row9[1]; echo ' out of 5';
		echo "<br><a href=addcomment.php?moviename=$movieid>Add Review now</a>";
		for($i = 0; $i < $row9[0]; $i++)
		{

			echo '<br><br>At time '; echo $row9[3]; echo ', '; echo $row9[2]; echo ' rated the movie at '; echo $row9[5]; echo ' with the 			following comment: ';
			echo '<br>'; echo $row9[4];
		}
	}
	else
	{
		echo "<a href=addcomment.php?moviename=$movieid>Add Review now</a>";
		echo '<br>No ratings were found';
	}

}
}



?>

</BODY>
</HTML>