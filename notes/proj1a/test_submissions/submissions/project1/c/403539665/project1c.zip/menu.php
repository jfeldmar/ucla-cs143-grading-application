<HTML>
<BODY BGCOLOR = 'black'>
<font color='gold'>
<br><br><br><br><br><br>
<b><font size = 4> Input Pages: <b></font>
<br><br>
    <b><a href='addactor.php' target='start'> Add Actor/Director </a><br>
    <b><a href='addcomment.php' target='start'>Add Comments To Movie</a> <br>
    <b><a href='addmovie.php' target='start'>Add Movie Information <br></a>
    <b><a href='addmovierelation.php' target='start'>Add Movie / Actor Relation <br></a>
<br><br>
<b><font size = 4>Browse Content: <br></font></b>
<br>
    <b><a href='showactor.php' target='start'>Show Actor Information</a><br></b>
    <b><a href='showmovie.php' target='start'>Show Movie Information</a><br></b>
<br><br><br>
<b><font size=4>Search Interface:<br></b></font>
<br>
    <b><a href='search.php' target='start'>Search Actor/Movie</b><br>
<br><br>
</HTML>

