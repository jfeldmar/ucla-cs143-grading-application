<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>To add a Movie / Actor Relation, please fill out the following data and submit.</b>

<form action="addmovierelation.php" method="GET">

<b>Please select the movie:

<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$movieid = $_GET['movie'];
$actor = $_GET['actor'];
$role = $_GET['role'];
$submit = $_GET['submit'];


$query = 'SELECT id, title, year FROM Movie';
$result = mysql_query($query, $db_connection)or die(mysql_error());

$query1 = 'SELECT id FROM MaxMovieID';
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);

?>

<Select name = 'movie'>


<?php

 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result);
        
        if($row[0]!=null)
	{
		if($movieid = $row[0])
			print("<option value=\"$row[0]\" selected='selected'>$row[1] ($row[2])</option>");
		else
			print("<option value=\"$row[0]\">$row[1] ($row[2])</option>");
	}
	else
		break;
    }
?>

</select>


<br><b> Please select the actor: </b>
<?php

$query = 'SELECT id,first,last,dob FROM Actor';
$result = mysql_query($query, $db_connection)or die(mysql_error());
$row2 = mysql_fetch_row($result);

$query1 = 'SELECT id FROM MaxPersonID';
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);

$actorid = '$row2[0]';

?>

<Select name = 'actor'>


<?php

 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result);
        
        if($row[0]!=null)
		print("<option value=\"$row[0]\">$row[1] $row[2] ($row[3])</option>");
	else
		break;
    }
?>

</select>
<br><br>
<b> Role the actor played: </b>
<input type= text name='role'>

<br><br>
<input type=submit name='submit' value='Submit'> 

<hr>
</FORM>


<?php


if($submit && $role && $movieid && $actor)
{

$query = "INSERT INTO MovieActor(mid,aid,role) VALUES ('$movieid','$actor','$role')";
$result5 = mysql_query($query,$db_connection)or die(mysql_error());
echo '<br><br><br>Success. The Movie-Actor Relation Has Been Added.';

}
else if($submit)
{
	echo '<br><br><br>Sorry, the relation could not be added successfully';
}

?>


</HTML>
