<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>To add a movie, please fill out the following data and submit.</b>

<form action="addmovie.php" method="GET">

<hr><br><br>

<b>Title</b>: <input type='text' name='title' value=''><br>
<b>Year Produced</b>: <input type='text' name='year' value=''><br>
<b>MPAA Rating</b>: <select name=rating>
		<option value=G>G
		<option value=NC17>NC-17
		<option value=PG>PG
		<option value=PG13>PG-13
		<option value=R>R
		</select><br>
<b>Production Company</b>: <input type='text' name='company' value=''>
<br>

<b>Director</b>: <select name=director>

<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);


$query1 = 'SELECT id,first,last,dob FROM Director GROUP BY first';
$result1 = mysql_query($query1, $db_connection);

$query2 = 'SELECT count(*) FROM Director';
$result2 = mysql_query($query2, $db_connection);
$row2 = mysql_fetch_row($result2);

echo 'row2[0]';

for ($i=0;$i<=$row2[0];$i++)
    {
        $row = mysql_fetch_row($result1);
        
        if($row[0]!=null)
		print("<option value=\"$row[0]\">$row[1] $row[2] ($row[3])</option>");
	else
		break;
    }
?>

</select>

<br>
<b>Genre</b><Select name = genre>
<option value='Action'>Action
<option value="Adult">Adult
<option value="Adventure">Adventure
<option value="Animation">Animation
<option value="Comedy">Comedy
<option value="Crime">Crime
<option value="Documentary">Documentary
<option value="Drama">Drama
<option value="Family">Family
<option value="Fantasy">Fantasy
<option value="Horror">Horror
<option value="Musical">Musical
<option value="Mystery">Mystery
<option value="Romance">Romance
<option value="Sci-Fi">Sci-Fi
<option value="Short">Short
<option value="Thriller">Thriller
<option value="War">War
<option value="Western">Western
</select>


<br>
<br>
<input type='submit' name='submit' value='Submit'><br><br>

<hr>

</form>

<?php

error_reporting(0);

$title = $_GET['title'];
$year = $_GET['year'];
$rating = $_GET['rating'];
$company = $_GET['company'];
$director = $_GET['director'];
$genre = $_GET['genre'];


if($_GET['submit'] && $title != null && $year != null && $rating != null && $company != null && $director != null && $genre != null)
{

	$query3 = "UPDATE MaxMovieID SET id = id + 1";
	$result3 = mysql_query($query3, $db_connection)or die(mysql_error());
	
	$query4 = "SELECT id FROM MaxMovieID";
	$result4 = mysql_query($query4, $db_connection)or die(mysql_error());
	$row4 = mysql_fetch_row($result4);
	
	$query5 = "INSERT INTO Movie(id,title,year,rating,company) VALUES ('$row4[0]','$title','$year','rating','company')";
	$result5 = mysql_query($query5,  $db_connection) or die(mysql_error());

	$query6 = "INSERT INTO MovieDirector(mid,did) VALUES ('$row4[0]', '$director')";
	$result6  = mysql_query($query6, $db_connection)or die(mysql_error());

	$query7 = "INSERT INTO MovieGenre(mid,genre) VALUES ('$row4[0]', '$genre')";
	$result7 = mysql_query($query7, $db_connection)or die(mysql_error());

	$query8 = "SELECT id FROM Movie WHERE title='$title'";
	$result8 = mysql_query($query8, $db_connection);
	$row8 = mysql_fetch_row($result8);

	
	if($result3 && $row4[0] && result5 && result6 && result7)
	{
		echo 'Success, the movie has been added.';
		echo "<a href=addmovierelation.php?title='$title'&movie='$row8[0]' target='start'>Add Actor/Role Relation</a>";
	}
	else
		echo 'Sorry, the movie could not be added';

}
else if($_GET['submit'])
{
	echo 'Sorry, the movie could not be added';
}

mysql_close($db_connection);
?>

</body>
</font>
</HTML>
