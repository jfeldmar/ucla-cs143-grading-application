<HTML>
<body bgcolor = 'black'>
<font color='gold'>
<HEADER><font size= 6>MOVIE DATABASE WEB INTERFACE</HEADER></font>
<br><br><br><br><br>
<b>To show a specific actors details, please fill out the following data and submit.</b>
<br><br>
<form name ="mainform" action="showactor.php" method="GET">

<b> Please select the actor you wish to find out more information about:<br>
<?php

$actorid = $_GET['actorid'];

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$query = 'SELECT id,first,last,dob FROM Actor GROUP BY first';
$result = mysql_query($query, $db_connection)or die(mysql_error());
$row2 = mysql_fetch_row($result);

$query1 = 'SELECT id FROM MaxPersonID';
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);


?>

<Select name = 'actorid'>


<?php

 for ($i=0;$i<$row1[0];$i++)
    {
        $row = mysql_fetch_row($result);
        
        if($row[0]!=null)
	{
		if($actorid == $row[0])
			print("<option value=\"$row[0]\" selected='selected'>$row[1] $row[2] ($row[3])</option>");
		else
			print("<option value=\"$row[0]\">$row[1] $row[2] ($row[3])</option>");
	}
	else
		break;
    }
?>

</select>

<input type=submit name=submit value='Submit'>

<hr>


</FORM>

<?php

if($_GET['submit'] && $actorid != null)
{

$query = "SELECT first,last,sex,dob,dod FROM Actor WHERE id='$actorid'";
$result = mysql_query($query, $db_connection)or die(mysql_error());
$row = mysql_fetch_row($result);


$query1 = 'SELECT id FROM MaxMovieID';
$result1 = mysql_query($query1, $db_connection)or die(mysql_error());
$row1 = mysql_fetch_row($result1);

print('<br><br>Here is the information you requested: </b>');
echo '<br>Name: '; echo $row[0]; echo ' '; echo $row[1];
echo '<br>Sex: '; echo $row[2];
echo '<br>Date of Birth: '; echo $row[3];
echo '<br>Date of Death: '; if($row[4] != null){ echo $row[4]; } else { echo 'N/A'; } ;


$query = "SELECT mid,role FROM MovieActor WHERE aid = '$actorid'";
$result = mysql_query($query, $db_connection);


echo '<b><br><br>The actor you chose acted in the following movies: </b><br><br>';

for($i = 0; $i <= $row1[0]; $i++)
{

$row2 = mysql_fetch_row($result);

if($row2[0] != null)
{
	$query = "SELECT title FROM Movie WHERE id = '$row2[0]'";
	$result3 = mysql_query($query, $db_connection)or die(mysql_error());
	$row3 = mysql_fetch_row($result3);
	
	if($row3[0] != null)
	{
		echo "<br><b>Movie: <a href=showmovie.php?movieid=$row2[0]&submit=true> $row3[0]</a>";
		echo '<br><b>Role: '; echo $row2[1];
	}
	else
		break;

}
else {
		break;
	}

}


echo '<hr>';
}

?>


</HTML>