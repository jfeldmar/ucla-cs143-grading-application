<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<title>OMDB</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
      <h1>Welcome to OMDB.</h1>
      <p>OMDB is a creation of Stephen Oakley.  All materials are subject to copyright as permitted by the policies of CS 143.
      </div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>
