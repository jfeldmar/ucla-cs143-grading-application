<?php

function formatDate($date){
	$Months = array("January","Febuary",
					"March","April",
					"May","June",
					"July","August",
					"September","October",
					"November","December");
	$index = array(	"day" => 2,
					"month" => 1,
					"year" => 0);
	$parts = explode("-",$date);
	
	return $Months[(int)$parts[$index["month"]]]." "
			.$parts[$index["day"]].", "
			.$parts[$index["year"]];
}

?>