<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();

		
	$genre = array("Action",
					"Adult",
					"Adventure",
					"Animation",
					"Comedy",
					"Crime",
					"Documentary",
					"Drama",
					"Family",
					"Fantasy",
					"Horror",
					"Musical",
					"Mystery",
					"Romance",
					"Sci-Fi",
					"Short",
					"Thriller",
					"War",
					"Western");
	
	$title = NULL;
	$company = NULL;
	$year = NULL;
	$did = NULL;
	$mpaarating = NULL;
	$mid = NULL;
	$genre_string = "";
	
	if(isset($_GET['title']) && isset($_GET['company']) 
			&& isset($_GET['year']) && isset($_GET['did'])
			&& isset($_GET['mpaarating'])){
		$title = mysql_real_escape_string($_GET['title'],$con);
		$company = mysql_real_escape_string(trim($_GET['company']),$con);
		$year = mysql_real_escape_string($_GET['year'],$con);
		$did = mysql_real_escape_string(trim($_GET['did']),$con);
		$mpaarating = mysql_real_escape_string(trim($_GET['mpaarating']),$con);
		
		foreach($genre as $x){
			if(isset($_GET['genre_'.$x])){
				$genre_string .= "".($genre_string == "" ? "" : ",").$x;
			}
		}
		
		$sql = "SELECT id FROM MaxMovieID LIMIT 1;";
		$temp = mysql_fetch_array(query($con,$sql));
		$max = $temp['id'] + 1;
		$mid = $max;
		//echo $max."<br/>";
		
		$sql = "UPDATE MaxMovieID SET "
				."MaxMovieID.id = ".$max." "
				."WHERE MaxMovieID.id = ".($max -1).";";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO Movie VALUES "
				."(".$max.",'".$title."',".$year
				.",'".$mpaarating."','".$company."');";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO MovieGenre VALUES "
				."(".$max.",'".$genre_string."');";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO MovieDirector VALUES "
				."(".$max.",".$did.");";
		$result = query($con,$sql);
		// echo $sql."<br/>";
	}
?>

<head>
<title>OMDB: Add Movie</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
    <h3>Add new movie:</h3>

<form action="./add_movie.php" method="GET">			
Title : <input type="text" name="title" maxlength="20"><br/>
Compnay: <input type="text" name="company" maxlength="50"><br/>
Year : <input type="text" name="year" maxlength="4"><br/>	<!-- Todo: validation-->	
Director : <select name="did">
			<?
				$sql = "SELECT id,first,last FROM Director;";
				$directors = query($con,$sql);
				$options = "";
				while($row = mysql_fetch_array($directors)){
				$options .= "<option value=\"".$row['id']."\">"
							.$row['last'].", ".$row['first']
							."</option>";
				}
				echo $options;
			?>
			</select>

<br/>		
MPAA Rating : <select name="mpaarating">
				<option value="G">G</option>
				<option value="NC-17">NC-17</option>
				<option value="PG">PG</option>
				<option value="PG-13">PG-13</option>
				<option value="R">R</option>
				<option value="surrendere">surrendere</option>
			</select>

<br/>
Genre : 
<br/>
<?
	$count = 0;
	foreach($genre as $x){
		echo "<input type=\"checkbox\" name=\"genre_"
				.$x."\" value=\"".$x."\"> ".$x." ... </input>";
		$count++;
		if($count % 5 == 0)
			echo "<br/>";
	}
?>
					
<br/>
			
<input type="submit" value="Add it!!"/>
</form>
<hr/>

<?
	if($mid){
		echo "Add was successful!<br/>";
		echo "<a href = './movie.php?mid=".$mid
				."'>See Movie Info</a>";
		echo "<hr/>";
	}
?>
	</div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>
