<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();
	$clean_id = mysql_real_escape_string(trim($_GET['mid']),$con);
	
	$movie_info = NULL;
	if(isset($_GET['mid'])){
		$sql = "SELECT * FROM Movie WHERE id = '"
				   .$clean_id."';";
		$movie_info = mysql_fetch_array(query($con,$sql));
	}
?>
<head>
<title>OMDB: <? echo $movie_info['title']; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
<? if(isset($_GET['mid'])){ ?>
		<h1><? echo $movie_info['title']." (".$movie_info['year'].")"; ?></h1>

<h2>Overview</h2>
<!--User Rating: <br/> -->
MPAA: <? echo $movie_info['rating']; ?><br/>
Company: <? echo $movie_info['company']; ?><br/>

<h2>Cast</h2>
<?
	$sql = "SELECT aid,first,last,role FROM MovieActor "
		   ."INNER JOIN Actor "
		   ."ON MovieActor.aid = Actor.id "
		   ."WHERE mid='".$clean_id."';";
	$result = query($con,$sql);
	while($row = mysql_fetch_array($result)){
		echo "<a href=\"./actor.php?aid=".$row['aid']."\">"
			.$row['first']." ".$row['last']."</a>"
			." ... ".$row['role'];
		echo "<br/>";
	}
	//echo $sql;
?>
<h2>User Comments</h2>
<a href="./add_comment.php">(Comment on this title)</a>
<?
	$sql = "SELECT AVG(rating),COUNT(name) FROM Review "
			."WHERE mid = ".$clean_id.";";
	$temp = mysql_fetch_array(query($con,$sql));
	$avg = $temp['AVG(rating)'];
	$count = $temp['COUNT(name)'];
	
	echo "<br/>";
	echo "Average Rating: ".($avg?$avg."/5 (5.0 being best)":"unestablished")." by "
			.$count." reviews.";
	echo "<br/><br/>";
	
	$sql = "SELECT name,time,rating,comment FROM Review "
		   ."WHERE mid='".$clean_id."';";
	$result = query($con,$sql);
	while($row = mysql_fetch_array($result)){
		echo "By ".$row['name']." , "
				.formatDate($row['time']);
		echo "<br/>";		
		echo "Rating ".$row['rating']."/5";
		echo "<br/>";
		echo $row['comment'];
		echo "<br/>";
		echo "<br/>";
	}
	//echo $sql;
?>

<? 
	} 
	else {
?>

<form action="./movie.php" method="GET">	
Movie:	<select name="mid">
		<?
			$sql = "SELECT id,title FROM Movie;";
			$movies = query($con,$sql);
			$options = "";
			while($row = mysql_fetch_array($movies)){
			$options .= "<option value=\"".$row['id']."\">"
						.$row['title']
						."</option>";
			}
			echo $options;
		?>
		</select>
<br/>
<input type="submit" value="View Movie"/>
</form>
<? } ?>
	</div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>