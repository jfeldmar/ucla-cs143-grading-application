<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();

	$identity = NULL;
	$first = NULL;
	$last = NULL;
	$sex = NULL;
	$dob = NULL;
	$dod = NULL;
	$id = NULL;
	
	if(isset($_GET['identity']) && isset($_GET['first']) && isset($_GET['last'])
		&& isset($_GET['sex']) && isset($_GET['dob'])){
		$identity = mysql_real_escape_string(trim($_GET['identity']),$con);
		$first = mysql_real_escape_string(trim($_GET['first']),$con);
		$last = mysql_real_escape_string(trim($_GET['last']),$con);
		$sex = mysql_real_escape_string(trim($_GET['sex']),$con);
		$dob = mysql_real_escape_string(trim($_GET['dob']),$con);
		
		if(isset($_GET['dod']))
			$dod = mysql_real_escape_string(trim($_GET['dod']),$con);
		
		$sql = "SELECT id FROM MaxPersonID LIMIT 1;";
		$temp = mysql_fetch_array(query($con,$sql));
		$max = $temp['id'] + 1;
		$id = $max;
		//echo $max."<br/>";
		
		$sql = "UPDATE MaxPersonID SET "
				."MaxPersonID.id = ".$max." "
				."WHERE MaxPersonID.id = ".($max -1).";";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO ".$identity." VALUES "
				."(".$id.",'".$last."','".$first."',"
				.($identity == 'Actor'? "'".$sex."'," : "")
				."'".$dob."',".($dod != "" ? "'".$dod."'" : "NULL").");";
		//echo $sql."<br/>";
		$result = query($con,$sql);
	}
?>
<head>
<title>OMDB</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
    <h3>Add new actor/director:</h3>
<form action="./add_person.php" method="GET">
Identity:	<input type="radio" name="identity" value="Actor" checked="true">Actor
			<input type="radio" name="identity" value="Director">Director<br/>
<hr/>
First Name:	<input type="text" name="first" maxlength="20"><br/>
Last Name:	<input type="text" name="last" maxlength="20"><br/>
Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
			<input type="radio" name="sex" value="Female">Female<br/>
						
Date of Birth:	<input type="text" name="dob"> (yyyy-dd-mm)<br/>
Date of Death:	<input type="text" name="dod"> (leave blank if alive now)<br/>
<input type="submit" value="add it!!"/>
</form>
<hr/>
<?
	if($id){
		echo "Add was successful!<br/>";
		if($identity == 'Actor')
			echo "<a href = './actor.php?aid=".$id
					."'>See Actor Info</a>";
		echo "<hr/>";
	}
?>
	</div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>