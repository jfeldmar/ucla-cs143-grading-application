<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<?php
	require('./database.php');
	require('./utils.php');
?>
<title>OMDB: Search</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
      <form action="./search.php" method="GET">		
		Search: <input type="text" name="keyword"></input>
		<br/>
		<input type="submit" value="Search"/>
	</form>

<br/>
<?
	if(isset($_GET['keyword'])){
		echo "<h3>Search results for ".$_GET['keyword']."</h3>";
		
		$con = openConnection();
		$clean_keyword = mysql_real_escape_string(trim($_GET['keyword']),$con);
		
		$sql = "SELECT id,last,first,dob FROM Actor "
				."WHERE first LIKE '%".$clean_keyword."%' "
				."OR last LIKE '%".$clean_keyword."%';";
		//echo $sql;
		$results = query($con,$sql);
		
		echo "<h4>Results from Actors ...</h4><br/>";
		while($row = mysql_fetch_array($results)){
			echo "<a href=\"./actor.php?aid=".$row['id']."\">"
				.$row['first']." ".$row['last']."</a>"
				." ... (".formatDate($row['dob']).")";
			echo "<br/>";
		}
		
		$sql = "SELECT id,title,company,year FROM Movie "
				."WHERE title LIKE '%".$clean_keyword."%' "
				."OR company LIKE '%".$clean_keyword."%';";
		//echo $sql;
		$results = query($con,$sql);
		
		echo "<h4>Results from Movies ...</h4><br/>";
		while($row = mysql_fetch_array($results)){
			echo "<a href=\"./movie.php?mid=".$row['id']."\">"
				.$row['title']."</a>"
				." ... (".$row['year']." by ".$row['company'].")";
			echo "<br/>";
		}
	}		
?>
    </div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>