<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();
	
	$mid = NULL;
	$name = NULL;
	$rating = NULL;
	$comment = NULL;
	
	if(isset($_GET['mid']) && isset($_GET['name']) 
			&& isset($_GET['rating']) && isset($_GET['comment']) ){
		$mid = mysql_real_escape_string($_GET['mid'],$con);
		$name = mysql_real_escape_string(trim($_GET['name']),$con);
		$rating = mysql_real_escape_string($_GET['rating'],$con);
		$comment = mysql_real_escape_string(trim($_GET['comment']),$con);
		
		$sql = "INSERT INTO Review VALUES ('"
				.$name."',CURRENT_TIMESTAMP(),".$mid
				.",".$rating.",'".$comment."');";
		$result = query($con,$sql);	
		if(!result)
			echo "There has been an error with the database";
	}
?>
<head>
<title>OMDB: Comment</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="assets/css/common.css" />
</head>
<body>
<div id="wrapper">
  <div id="header"> <a href="index.htm"><img src="assets/images/logo.gif" alt="" width="203" height="102" class="logo" /></a> </div>
  <ul id="nav">
  </ul>
  <div id="content" class="clearfix">
    <div id="col_1">
      <h2>Add Content</h2>
      <ul id="subnav">
        <li><a href="./add_person.php" >Add Person</a></li>
        <li><a href="./add_comment.php" >Add Comment</a></li>
        <li><a href="./add_movie.php" >Add Movie</a></li>
		<li><a href="./add_movieactor.php" >Add Role</a></li>
      </ul>
	  <h2>Browse Content</h2>
      <ul id="subnav">
        <li><a href="./movie.php" >View Movie</a></li>
        <li><a href="./actor.php" >View Actor</a></li>
      </ul>
	  <h2>Search Content</h2>
      <ul id="subnav">
        <li><a href="./search.php" >Search Database</a></li>
      </ul>
    </div>
    <div id="col_2">
    <h3>Add new comment:</h3>

<form action="./add_comment.php" method="GET">			
Movie:	<select name="mid">
		<?
			$sql = "SELECT id,title FROM Movie;";
			$movies = query($con,$sql);
			$options = "";
			while($row = mysql_fetch_array($movies)){
			$options .= "<option value=\"".$row['id']."\">"
						.$row['title']
						."</option>";
			}
			echo $options;
		?>
		</select>

<br/>
Your Name:	<input type="text" name="name" value="Mr. Anonymous" maxlength="20"><br/>
Rating:	<select name="rating">
			<option value="5"> 5 - Excellent </option>
			<option value="4"> 4 - Good </option>
			<option value="3"> 3 - It's ok~ </option>
			<option value="2"> 2 - Not worth </option>
			<option value="1"> 1 - I hate it </option>
		</select>
<br/>
Comments: <br/>
<textarea name="comment" cols="80" rows="10"></textarea>
<br/>
<input type="submit" value="Rate it!!"/>
</form>
<hr/>

<?
	if($mid){
		echo "Thanks your comment!! We appreciate it!!<br/>";
		echo "<a href = './movie.php?mid=".$mid
				."'>See Movie Info (including others' reviews)</a>";
		echo "<hr/>";
	}
?>	
	</div>
  </div>
  <div id="footer"><small>All content copyright &copy; 2006 Your Site, all rights reserved.<br />
    Layout by <a href="http://cssweblayouts.com/" target="_blank">CSS Web Layouts</a></a></small></div>
</div>
</body>
</html>