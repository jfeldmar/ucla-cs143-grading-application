<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>add new ACTOR/DIRECTOR info<BR><BR>
<font size="3"></b>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
?>

<!----------------START FORM------------------------------------------------------------>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
Identity: 
<input type="radio" name="identity" value="Actor"/> Actor
<input type="radio" name="identity" value="Director"/> Director
<BR><BR>

First Name: 
<input type="text" name="first"/><BR><BR>

Last Name: 
<input type="text" name="last"/><BR><BR>

Sex: 
<input type="radio" name="sex" value="Male"/> Male
<input type="radio" name="sex" value="Female"/> Female
<BR><BR>

Date of Birth (YYYY-MM-DD): 
<input type="text" name="birth"/><BR><BR>

Date of Death (YYYY-MM-DD): 
<input type="text" name="death"/><BR><BR>

<input type="submit" value="Add to Database" name='sub'/>    
<BR><BR>
</form>


<!----------------END FORM--------------------------------------------------------------------->

<?php 
if(isset($_GET['sub']))
{
	$inputid = $_GET['identity'];
	$inputsex = $_GET['sex'];
	$inputfirst = $_GET['first'];
	$inputlast = $_GET['last'];
	$inputbirth = $_GET['birth'];
	$inputdeath = $_GET['death'];
	$idquery = mysql_query("select id from MaxPersonID");
	$idnumrow = mysql_fetch_row($idquery);
	$idnum = $idnumrow[0] + 1;
	
	// check first name
	$pattern2='/^[A-Za-z\.]*$/';
	(preg_match($pattern2, $inputfirst) == 1)
	or
    die('Error with name, failed to insert');
	
	//check last name
	(preg_match($pattern2, $inputlast) == 1)
	or
    die('Error with name, failed to insert');
	
	//check  birthday
	$pattern='/^[0-2][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]$/';
	(preg_match($pattern, $inputbirth) == 1)
	or
    die('Error with day of birth, failed to insert');
	
	//check death
	(preg_match($pattern, $inputdeath) == 1 or $inputdeath==NULL)
	or
    die('Error with day of death, failed to insert');
	
	if($inputdeath==NULL)
		{}
	else
		if($inputbirth > $inputdeath)
			die('Error, death earlier than birth');
	
	//check sex
	if($inputsex != 'Male' AND $inputsex != 'Female')
		die('Error with sex. Please specify male or female.');
		
	// check type of person
	if($inputid=='Actor')
		$query = "INSERT INTO " . $inputid . " VALUES ('$idnum','$inputlast','$inputfirst','$inputsex','$inputbirth','$inputdeath')";

	elseif($inputid=='Director')
		$query = "INSERT INTO " . $inputid . " VALUES ('$idnum','$inputlast','$inputfirst','$inputbirth','$inputdeath')";
	else
		die('Error with type of person. Please specify director or
			actor');
	
	
	mysql_query($query) or die('Error, insert query failed');
	mysql_query("update MaxPersonID set id=id+1") or die('update max id failed');
	
// ---------------note: when dod is left empty, inputs 0000-00-00---------------------------------//	
// ------------------------PRINT STATEMENT --------------------------------------------------------//

	if($inputdeath == NULL)
		$deathoutput = " still alive";
	else
		$deathoutput = " died on " . $inputdeath;

	echo "<HR WIDTH='100%' SIZE='3'>";		
	echo "Successful input into database!<br/>";
	echo $inputid . ", " . $inputfirst . " " . $inputlast . ", " . $inputsex . ", born on " . $inputbirth . ", " . $deathoutput;
}
?>

</body>
</html>