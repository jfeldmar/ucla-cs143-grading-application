<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>show MOVIE info<BR><BR>
<font size="3"></b>

<style type="text/css">
A:link {color: #990066; text-decoration: none}
A:visited {color: #990066; text-decoration: none}
A:active {color: #990066; text-decoration: none}
A:hover {color: #FF99CC; text-decoration: none}
</style>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
$query = 'select id,title,year from Movie order by title';
$rs = mysql_query($query, $conn) or die('Error finding movies');
?>

<!----------------BEGIN FORM--------------------------------------------------------------------->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">

Select Movie: 
<select name="movie">
<?php
while ($row = mysql_fetch_array($rs,MYSQL_NUM))
{
	if ($_GET['movie']==$row[0])
		echo "<option value='" . $row[0] . "' selected='selected'>" 
		. $row[1] . " (" . $row[2] . ")</option>";
	else
		echo "<option value='" . $row[0] . "'>" . $row[1] . " (" . 
		$row[2] . ")</option>";
}	
?>
</select>
&nbsp;

<input type="submit" value="Search Database" name='sub'/>    
<BR><BR>
</form>

<?php 
if(isset($_GET['sub']))
{
	$inmovie = $_GET['movie'];
	$query2 = "select * from Movie where id='" . $inmovie . "'";
	$rs2 = mysql_query($query2,$conn) 
	or die('Error finding Movie info');
	$row2 = mysql_fetch_array($rs2,MYSQL_NUM);
	
	$query3 = "select first,last from Director D, MovieDirector MD 
		where D.id=MD.did AND MD.mid='" . $inmovie . "'";
	$rs3 = mysql_query($query3,$conn) 
	or die('Problem finding Director');
	$row3 = mysql_fetch_array($rs3,MYSQL_NUM);

	$query4 = "select genre from MovieGenre where mid='" . $inmovie . 
		"'";
	$rs4 = mysql_query($query4,$conn) or die('Error finding genre');
	
	echo "<HR WIDTH='100%' SIZE='3'>";
	echo "<B>Search Results</b><BR><BR>";
	echo "Title: " . $row2[1] . "<BR>";
	echo "Producer: " . $row2[4] . "<BR>";
	echo "Year of Release: " . $row2[2] . "<BR>";
	echo "MPAA Rating: " . $row2[3] . "<BR>";
	
	if ($row3[0]==NULL AND $row3[1]==NULL)
		echo "Director: Not Listed<BR>";
	else
		echo "Director: " . $row3[0] . " " . $row3[1] . "<BR>";
	echo "Genre: ";
	while($row4 = mysql_fetch_array($rs4,MYSQL_NUM))
	{
		echo $row4[0] . " ";
	}
	echo "<BR><BR><BR>";
	
	//query5 gives the names of actors in this movie
	$query5 = "select first,last,id from Actor A, MovieActor MA where
		A.id=MA.aid AND MA.mid='" . $inmovie . "' order by first";
	$rs5 = mysql_query($query5,$conn)
	or die('Error finding actors in movie');
	
	$flag=false;
	echo "<B>Actors appearing in " . $row2[1] . "<BR><BR></b>";
	while($row5 = mysql_fetch_array($rs5,MYSQL_NUM))
	{
		$flag=true; 
		$query6 = "select role from MovieActor where
		mid='" . $inmovie . "' AND aid='" . $row5[2] . "'";
		$rs6 = mysql_query($query6,$conn)
		or die('Error finding role');
		
		while($row6 = mysql_fetch_array($rs6,MYSQL_NUM))
		{
			echo "<a href='showactor.php?actor=" . $row5[2] . 
			"&sub=Search+Database'>" . $row5[0] . " " . $row5[1] . 
			"</a> as '" . $row6[0] . "'<BR>";
		}
	}
	if($flag==false)
		echo "There are no actors listed for this movie<BR>";
	echo "<BR><BR><B>Reviews on " . $row2[1] . "<BR><BR></b>";
	
	$query7 = "select avg(rating) from Review where mid='" . $inmovie 
	. "' group by mid"
	or die('Error finding average score');
	
	$rs7 = mysql_query($query7,$conn);
	$row7 = mysql_fetch_array($rs7,MYSQL_NUM);
	
	if($row7[0] == NULL)
		echo "Sorry, no one has reviewed this movie yet";
	else
		echo "Average Rating: " . $row7[0] . " out of 5";

	echo "<BR><a href='addcomment.php?movie=" . $inmovie . "'>Click here to add your review!</a><BR><BR>";
	echo "<BR><B>Comments on " . $row2[1] . "<BR><BR></b>";
	
	if($row7[0] == NULL)
		echo "Sorry, there are no comments for this movie yet";
	else
	{
		$query8 = "select name,time,rating,comment from Review where
		mid='" . $inmovie . "'";
		$rs8 = mysql_query($query8,$conn);
	
		while($row8 = mysql_fetch_array($rs8,MYSQL_NUM))
		{
			echo "Name of Reviewer: " . $row8[0] . "<BR>";
			echo "Time of Review: " . $row8[1] . "<BR>";
			echo "Movie Rating: " . $row8[2] . "<BR>";
			echo "Comments: " . $row8[3] . "<BR><BR>";
		}
	}
	
}
?>


</body>
</html>