<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>add new MOVIE info<BR><BR>
<font size="3"></b>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
$query = 'select id,first,last from Director order by first';
$rs = mysql_query($query, $conn) or die('Error getting director');
?>

<!----------------BEGIN FORM--------------------------------------------------------------------->

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
Title: 
<input type="text" name="title"/>
<BR><BR>

Company: 
<input type="text" name="company"/>
<BR><BR>

Year: 
<input type="text" name="year"/>
<BR><BR>

Director: 
<select name="director">
<?php
while ($row = mysql_fetch_array($rs,MYSQL_NUM))
	echo "<option value='" . $row[0] . "'>" . $row[1] . " " . $row[2] ."</option>";
?>
</select>
<BR><BR>

MPAA Rating:
<select name="mpaa">
<option value="g">G</option>
<option value="pg">PG</option>
<option value="pg13">PG-13</option>
<option value="r">R</option>
<option value="nc17">NC-17</option>
</select>
<BR><BR>

Genre: <BR>
<input type="checkbox" name="genre[]" value="Action">Action<BR>
<input type="checkbox" name="genre[]" value="Adult">Adult<BR>
<input type="checkbox" name="genre[]" value="Adventure">Adventure<BR>
<input type="checkbox" name="genre[]" value="Animation">Animation<BR>
<input type="checkbox" name="genre[]" value="Comedy">Comedy<BR>
<input type="checkbox" name="genre[]" value="Crime">Crime<BR>
<input type="checkbox" name="genre[]" value="Documentary">Documentary<BR>
<input type="checkbox" name="genre[]" value="Drama">Drama<BR>
<input type="checkbox" name="genre[]" value="Family">Family<BR>
<input type="checkbox" name="genre[]" value="Fantasy">Fantasy<BR>
<input type="checkbox" name="genre[]" value="Horror">Horror<BR>
<input type="checkbox" name="genre[]" value="Musical">Musical<BR>
<input type="checkbox" name="genre[]" value="Mystery">Mystery<BR>
<input type="checkbox" name="genre[]" value="Romance">Romance<BR>
<input type="checkbox" name="genre[]" value="Sci-Fi">Sci-Fi<BR>
<input type="checkbox" name="genre[]" value="Short">Short<BR>
<input type="checkbox" name="genre[]" value="Thriller">Thriller<BR>
<input type="checkbox" name="genre[]" value="War">War<BR>
<input type="checkbox" name="genre[]" value="Western">Western<BR><BR>

<input type="submit" value="Add to Database" name='sub'/>    
<BR><BR>
</form>

<!----------------END FORM--------------------------------------------------------------------->

<?php 
if(isset($_GET['sub']))
{
	$intitle = $_GET['title'];
	$incompany = $_GET['company'];
	$inyear = $_GET['year'];
	$indirector = $_GET['director'];
	$inmpaa = $_GET['mpaa'];
	
	// check empty
	if($intitle=='')
		die('Error, must fill in completely');
	
	if($incompany=='')
		die('Error, must fill in completely');
	
	if($inyear=='')
		die('Error, must fill in completely');
		
	//check title
	$pattern2='/^[0-9A-Za-z\.!\?\s]*$/';
	(preg_match($pattern2, $intitle) == 1)
	or
    die('Error with title, failed to insert');
	
	//check company
	(preg_match($pattern2, $incompany) == 1)
	or
    die('Error with company, failed to insert');
	
	//check year
	$pattern3='/^[0-9]*$/';
	(preg_match($pattern3, $inyear) == 1)
	or
    die('Error with year, failed to insert');
	
	if($inyear < 0 OR $inyear > 2008)
		die('Error with year, failed to insert');
	
	$idquery = mysql_query("select id from MaxMovieID") 
		or die('Error getting max movie id');
	$idnumrow = mysql_fetch_row($idquery);
	$idnum = $idnumrow[0] + 1;
	
	$query2 = "insert into Movie values ('$idnum','$intitle',
		'$inyear','$inmpaa','$incompany')";
		
	mysql_query($query2,$conn) or die('Error, insert movie failed');
	mysql_query("update MaxMovieID set id=id+1")
		or die('Error updating max movie id');
	
	// check genre
	if(count($_GET['genre']) < 1)
		die('Error: no genre specified');
		
	for ($i=0; $i<count($_GET['genre']); $i++)
	{
		$onegenre = $_GET['genre'][$i];
		$gquery = "insert into MovieGenre values ('$idnum','$onegenre')";
			
		mysql_query($gquery,$conn) 
		or die('Error, insert into MovieGenre failed');
	}
	
	mysql_query("insert into MovieDirector values (" . $idnum . "," . 		$indirector . ")",$conn)
		or die('Error inserting into MovieDirector');
	
	echo "<HR WIDTH='100%' SIZE='3'>";
	echo "Successfully added movie to database! <br/><br/>";
	
}
?>

</body>
</html>