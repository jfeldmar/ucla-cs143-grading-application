<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>add new COMMENT to movie<BR><BR>
<font size="3"></b>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
$query = 'select id,title,year from Movie order by title';
$rs = mysql_query($query, $conn)
	or die('Error selecting info from Movie');
?>

<!----------------BEGIN FORM--------------------------------------------------------------------->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">

Movie: 
<select name="movie">
<?php
while ($row = mysql_fetch_array($rs,MYSQL_NUM))
{
	if ($_GET['movie']==$row[0])
		echo "<option value='" . $row[0] . "' selected='selected'>" 
		. $row[1] . " (" . $row[2] . ")</option>";
	else
		echo "<option value='" . $row[0] . "'>" . $row[1] . " (" . 
		$row[2] . ")</option>";
}	
?>
</select>
<BR><BR>

Your Name: 
<input type="text" name="name" value="Anonymous"/>
<BR><BR>

Rating: 
<select name="rating">
<option value="5">5: Excellent</option>
<option value="4">4: Good</option>
<option value="3">3: Average</option>
<option value="2">2: Bad</option>
<option value="1">1: Terrible</option>
</select>
<BR><BR>

Comments: <BR>
<textarea cols="60" rows="8" name="comments" wrap="HARD"/></textarea>
<BR><BR>

<input type="submit" value="Rate Movie" name='sub'/>    
<BR><BR>
</form>
<!----------------END FORM--------------------------------------------------------------------->


<?php 
if(isset($_GET['sub']))
{
	$rstime = mysql_query("select NOW()",$conn);
	$timerow = mysql_fetch_row($rstime);
	$intime = $timerow[0];

	$inname = $_GET['name'];
	$inmid = $_GET['movie'];
	$inrate = $_GET['rating'];
	$incom = $_GET['comments'];
	
	//check not empty
	if($inname == '')
		die('Error, must enter name');
	
	//check name
	$pattern2='/^[A-Za-z\.\s]*$/';
	(preg_match($pattern2, $inname) == 1)
	or
    die('Error with name, failed to insert');
	
	$query2 = "insert into Review values ('$inname','$intime',
		'$inmid','$inrate','$incom')";
		
	mysql_query($query2,$conn) or die('Error, insert comment failed');
	echo "<HR WIDTH='100%' SIZE='3'>";
	echo "Comment successfully submitted!";
}
?>

</body>
</html>