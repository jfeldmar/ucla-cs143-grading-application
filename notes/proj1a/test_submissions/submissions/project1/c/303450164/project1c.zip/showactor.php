<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>show ACTOR info<BR><BR>
<font size="3"></b>

<style type="text/css">
A:link {color: #990066; text-decoration: none}
A:visited {color: #990066; text-decoration: none}
A:active {color: #990066; text-decoration: none}
A:hover {color: #FF99CC; text-decoration: none}
</style>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
$query = 'select id,first,last from Actor order by first';
$rs = mysql_query($query, $conn) or die('Error getting Actors');
?>

<!----------------BEGIN FORM--------------------------------------------------------------------->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">

Search Actor: 
<select name="actor">
<?php
while ($row = mysql_fetch_array($rs,MYSQL_NUM))
{
	if ($_GET['actor']==$row[0])
		echo "<option value='" . $row[0] . "' selected='selected'>" . 
		$row[1] . " " . $row[2] . "</option>";
	else
		echo "<option value='" . $row[0] . "'>" . $row[1] . " " . 
		$row[2] . "</option>";
}
?>
</select>
&nbsp;

<input type="submit" value="Search Database" name='sub'/>    
<BR><BR>
</form>

<!----------------BEGIN FORM--------------------------------------------------------------------->

<?php 
if(isset($_GET['sub']))
{
	$inactor = $_GET['actor'];
	$query2 = "select * from Actor where id='" . $inactor . "'";
	$rs2 = mysql_query($query2,$conn) or 
	die('Error retrieving actor info');
	$row2 = mysql_fetch_array($rs2,MYSQL_NUM);
	
	echo "<HR WIDTH='100%' SIZE='3'>";
	
	echo "<B>Search Results</b><BR><BR>";
	echo "Actor Name: " . $row2[2] . " " . $row2[1] . "<br/>";
	echo "Sex: " . $row2[3] . "<br/>";
	echo "Date of Birth: " . $row2[4] . "<br/>";
	
	if($row2[5]=='0000-00-00' OR $row2[5]==NULL)
		echo "Date of Death: Still Alive <br/><BR><BR>";
	else
		echo "Date of Death: " . $row2[5] . "<br/><BR><BR>";
	
	$query3 = "select * from Movie M, MovieActor MA where M.id=MA.mid
		AND MA.aid='" . $inactor . "' order by M.year";
	$rs3 = mysql_query($query3,$conn) 
	or die('Error finding Movie/Actor results');
	
	echo "<B>" . $row2[2] . " " . $row2[1] . " has acted in...
	<br/><BR></b>";
	
	$flag=false;
	while ($row3 = mysql_fetch_array($rs3,MYSQL_NUM))
	{
		$flag=true;
		$query4 = "select role from MovieActor where aid='" . $inactor 			."' AND mid='" . $row3[0] . "'";
	
		$rs4 = mysql_query($query4,$conn)
		or die('Error getting role');
		$introle = mysql_fetch_array($rs4,MYSQL_NUM);
		$role = $introle[0];
		
		echo "<a href='showmovie.php?movie=" . $row3[0] . 
		"&sub=Search+Database'>" . $row3[1] . "</a>, " . $row3[2] .
		", " . $row3[4] . "<BR>";
		
		echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Role: " . $role . 		"<BR><BR>";
	}
	
	if($flag==false)
		echo "There are no movies listed for this actor";
	
	
}
?>

</body>
</html>