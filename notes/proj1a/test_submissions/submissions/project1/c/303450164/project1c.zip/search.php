<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>search ACTOR/MOVIE<BR><BR>
<font size="3"></b>

<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
?>

<style type="text/css">
A:link {color: #990066; text-decoration: none}
A:visited {color: #990066; text-decoration: none}
A:active {color: #990066; text-decoration: none}
A:hover {color: #FF99CC; text-decoration: none}
</style>

<!----------------BEGIN FORM--------------------------------------------------------------------->

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
Search for Actor/Movie: 
<input type="text" name="search"/>&nbsp;
<input type="submit" name="submit" value="Search Database"/>
</form>
<BR><BR>

<!----------------END FORM--------------------------------------------------------------------->

<?php
if(isset($_GET['submit']))
{
	$insearch = $_GET['search'];
	
	echo "<HR WIDTH='100%' SIZE='3'>";
	echo "<B>Search Results for [" . $insearch . "] in Actor database</b><BR><BR>";
	
	$query2="select * from Actor where first like '%" . $insearch . 
	"%' OR last like '%" . $insearch . "%' order by first";
	$rs2 = mysql_query($query2,$conn)
	or die('Error finding actor results');
	
	$flag=false;
	$flag2=false;
	while($row2 = mysql_fetch_array($rs2,MYSQL_NUM))
	{
		$flag2=true;
		echo "<a href='showactor.php?actor=" . $row2[0] . 
			"&sub=Search+Database'>" . $row2[2] . " " . $row2[1] . 
			"</a>, " . $row2[4] . "<BR>";
	}
	if($flag2 != true)
		echo "No results found<BR>";
	
	echo "<B><BR><BR>Search Results for [" . $insearch . "] in Movie database</b><BR><BR>";
	
	$query3 = "select * from Movie where title like '%" . 
	$insearch . "%' order by year";
	
	$rs3 = mysql_query($query3,$conn)
	or die('Error finding movie results');
	
		
	while($row3 = mysql_fetch_array($rs3,MYSQL_NUM))
	{
		$flag=true;
		echo "<a href='showmovie.php?movie=" . $row3[0] . 
		"&sub=Search+Database'>" . $row3[1] . "</a>, " . $row3[2] .
		"<BR>";
	}
	if($flag != true)
		echo "No results found<BR>";
		
	echo "<BR>";
}
?>

</body>
</html>