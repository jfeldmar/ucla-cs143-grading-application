<html>
<body>
<title>kIMDB</title>

<body bgcolor="#FF99CC">
<iframe src="main.php" width="80%" align="right" frameborder="1", height=100% name="main", scrolling="auto">
</iframe>

<style type="text/css">
A:link {color: #990066; text-decoration: none}
A:visited {color: #990066; text-decoration: none}
A:active {color: #990066; text-decoration: none}
A:hover {color: #ffccff; text-decoration: none}
</style>

<font size="5" face="tahoma">
<B>kIMDB MENU</font><BR><BR>

<font size="3" face="tahoma">
main<BR></b>
<a href="main.php" target="main">WELCOME PAGE</a><BR><BR>

<B>add new content</b><BR>
<a href="addperson.php" target="main">add ACTOR/DIRECTOR</a><BR>
<a href="addcomment.php" target="main">add COMMENT</a><BR>
<a href="addmovie.php" target="main">add MOVIE</a><BR>
<a href="addmovieactor.php" target="main">add MOVIE/ACTOR RELATION</a><BR><BR>

<B>browse content</b><BR>
<a href="showactor.php" target="main">show ACTOR info</a><BR>
<a href="showmovie.php" target="main">show MOVIE info</a><BR><BR>

<B>search content</b><BR>
<a href="search.php" target="main">search for ACTOR or MOVIE</a><BR><BR>




</body>
</html>