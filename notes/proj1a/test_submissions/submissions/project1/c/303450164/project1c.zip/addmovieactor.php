<html>
<body bgcolor="#FFCCFF">

<font size="5" face="tahoma">
<B>add new MOVIE/ACTOR RELATION info<BR><BR>
<font size="3"></b>
<!----------------START CONNECTION------------------------------------------------------------>

<?php 
$conn = mysql_connect(localhost,cs143,"");
if (!$conn)
    die('Could not connect: ' . mysql_error());

mysql_select_db("CS143", $conn);
$query = 'select id,title,year from Movie order by title';
$rs = mysql_query($query, $conn) or die('Error selecting from Movie');

$query2 = 'select id,first,last from Actor order by first';
$rs2 = mysql_query($query2, $conn) or die('Error selecting from Actor');
?>

<!----------------BEGIN FORM--------------------------------------------------------------------->

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
Movie: 
<select name="movie">
<?php
while ($row = mysql_fetch_array($rs,MYSQL_NUM))
	echo "<option value='" . $row[0] . "'>" . $row[1] . " (" . $row[2] . ")</option>";
?>
</select>
<BR><BR>

Actor: 
<select name="actor">
<?php
while ($row2 = mysql_fetch_array($rs2,MYSQL_NUM))
	echo "<option value='" . $row2[0] . "'>" . $row2[1] . " " . $row2[2] ."</option>";
?>
</select>
<BR><BR>

Role: 
<input type="text" name="role">
<BR><BR>

<input type="submit" value="Add to Database" name='sub'/>    
<BR><BR>
</form>

<!----------------END FORM--------------------------------------------------------------------->

<?php 
if(isset($_GET['sub']))
{
	$inmovie = $_GET['movie'];
	$inactor = $_GET['actor'];
	$inrole = $_GET['role'];

	//check empty
	if($inrole=='')
		die('Error, must input role');
	
	// check role
	$pattern2='/^[0-9A-Za-z\s]*$/';
	(preg_match($pattern2, $inrole) == 1)
	or
    die('Error with role, failed to insert');
	
	
	$query = "insert into MovieActor values ('$inmovie','$inactor',
		'$inrole')";
		
	mysql_query($query,$conn) or die('Error, insert movie/actor relation failed');
	echo "<HR WIDTH='100%' SIZE='3'>";
	echo "Successfully added movie/actor relation!";
}
?>

</body>
</html>