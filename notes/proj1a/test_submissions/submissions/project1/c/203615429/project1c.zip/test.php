<?php
$commentRating = array(
	                               "5 - Excellent",
			                       "4 - Good",
			                       "3 - It's ok~",
			                       "2 - Not worth",
			                       "1 - I hate it");
			                       print_r($commentRating);
?>