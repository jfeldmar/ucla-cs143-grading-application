<?php
function connectDB()
{
	// Connect to mysql server
	$connect = mysql_pconnect("localhost", "cs143") or die("Error - MySql server.");
	mysql_select_db("CS143", $connect) or die("Error - Database");
	return $connect;
}

function query( $q )
{
	return mysql_query($q) or die("Error - Query <br>".mysql_error());
}
?>