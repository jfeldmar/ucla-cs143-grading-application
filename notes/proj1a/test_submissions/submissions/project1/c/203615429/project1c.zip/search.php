<?php
include 'classes.php';
?>
<html>
<head>
<title>Search</title>
</head>

<body>
<form id="search" name="search" method="get" action="./search.php">
  <fieldset>
    <legend>Search
    </legend>
    <p>
      <label>
        <input type="text" name="text" id="text" />
      </label>
      <label>
        <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </p>
  </fieldset>
</form>
<?php
$text = $_REQUEST['text'];
if( $text )
{
	$mysql = new mysql();
	echo "<fieldset>";
    echo "<legend>Result</legend>";
    echo "You are searching [".$text."] results...<br>";
    echo "Searching match records in Actor database ... <br>";
	$query = "SELECT last, first, id, dob FROM Actor WHERE last LIKE '%".$text."%' OR first LIKE '%".$text."%' ";
	$mysql->query( $query );
	while( $row = $mysql->fetch_array() )
	{
		echo "Actor: <a href = \"./showActor.php?aid=".$row['id']."\">".$row['last']." ".$row['first']."(".$row['dob'].")</a><br/>";
	}
	echo "Searching match records in Movie database ...<br>";
	$query = "SELECT title, id, year FROM Movie WHERE title LIKE '%".$text."%'";
	$mysql->query( $query );
	while( $row = $mysql->fetch_array() )
	{
		echo "Movie: <a href = \"./showMovieInfo.php?mid=".$row['id']."\">".$row['title']."(".$row['year'].")</a><br/>";
	}
	echo "</fieldset>";
	$mysql->printAllQueryResult();
}
?>
</body>
</html>