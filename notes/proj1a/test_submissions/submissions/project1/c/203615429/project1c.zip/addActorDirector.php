<html>
	<head>
		<title>ADD PEOPLE</title>
	</head>
	<body>
		<font size="4">ADD PEOPLE</font><br>
		<form method="get" name="addActorDirector" action="mysql.php">
			<input type="hidden" name="me" value="<?=$_SERVER['PHP_SELF']?>">
			<input type="hidden" name="action" value="addPeople">
			<FIELDSET>
				<font size="4">Add what?</font><br>
				<input type="radio" name="addType" value="actor">Actor<br>
				<input type="radio" name="addType" value="director">Director<br>
				<input type="radio" name="addType" value="both">Both<br>
			</FIELDSET><br>
			<FIELDSET>
				<font size="4">Information</font><br>
				<table border="0" cellpadding="0" cellspacing="0">
					<tr>
						<td width="100">
							First Name:
						</td>
						<td>
							<input type="text" name="firstName">
						</td>
					</tr>
					<tr>
						<td width="100">
							Last Name:
						</td>
						<td>
							<input type="text" name="lastName">
						</td>
					</tr>
					<tr>
						<td width="100">
							Sex:
						</td>
						<td>
							<input type="radio" name="sex" value="Male">Male 
							<input type="radio" name="sex" value="Female">Female
						</td>
					</tr>
					<tr>
						<td width="100">
							Date of Birth:
						</td>
						<td>
							<input type="text" name="dob">
						</td>
					</tr>
					<tr>
						<td width="100">
							Date of Dead:
						</td>
						<td>
							<input type="text" name="dod">
						</td>
					</tr>
				</table>
			</FIELDSET>
			<input type="Submit" name="Submit" value="Submit">
		</form>
		<?php
		if( $_REQUEST["result"] == "good" )
			echo "<font color='Red'><b>Add Success!!</b></font>";
		elseif ( $_REQUEST["result"] == "bad" )
			echo "<font color='Red'><b>Add Fail!!</b></font>";
		?>
	</body>
</html>


<?php

?>