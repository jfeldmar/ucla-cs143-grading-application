<?php
class mysql
{
	const HOST     = 'localhost';
	const USERNAME = 'cs143';
	const PASSWORD = '';
	const DATABASE = 'CS143';
	
	private $connect;
	private $result;
	
	private $error = false;
	
	private $q_success;
	private $q_fail;
	private $q_fail_msg;
	
	private $fixed;
	
	
	
	public function __construct()
	{
		$this->q_success = array();
		$this->q_fail = array();
		$this->q_fail_msg = array();
		$this->fixed = array();
		
		$this->connectDB();
	}
	
	public function __destruct()
	{
		$this->disconnectDB();
	}
		
	
	public function connectDB()
	{
		// Connect to mysql server
		$this->connect = mysql_pconnect( self::HOST, self::USERNAME, self::PASSWORD) or die("Error - MySql server.");
		mysql_select_db( self::DATABASE, $this->connect ) or die("Error - Database");
	}
	
	public function disconnectDB()
	{
		mysql_close( $this->connect );
	}
	
	public function query( $query )
	{
		$this->result = mysql_query( $query );
		if( $this->result )
		{
			array_push( $this->q_success, $query );
		}
		else
		{
			$this->error = true;
			array_push( $this->q_fail, $query );
			array_push( $this->q_fail_msg, mysql_error() );
			
			//Fix
			//$this->fixDBError();
		}
	}
	
	public function fetch_row()
	{
		return mysql_fetch_row( $this->result );
	}
	
	public function fetch_array()
	{
		return mysql_fetch_array( $this->result );
	}
	
	public function num_rows()
	{
		return mysql_num_rows( $this->result );
	}
	
	public function isError()
	{
		return $this->error;
	}
	
	public function getResult()
	{
		return $this->result;
	}
	
	public function getQS()
	{
		return array_shift( $this->q_success );
	}
	
	public function getQF()
	{
		return array_shift( $this->q_fail );
	}
	
	public function getQFM()
	{
		return array_shift( $this->q_fail_msg );
	}
	
	public function isEmptyQS()
	{
		return empty( $this->q_success );
	}
	
	public function isEmptyQF()
	{
		return empty( $this->q_fail );
	}
	
	public function printQS()
	{
		while( !$this->isEmptyQS() )
		{
			echo $this->getQS();
			echo "<br>";
		}
	}
	
	public function printQF()
	{
		while( !$this->isEmptyQF() )
		{
			echo $this->getQF();
			echo "<br>";
			echo $this->getQFM();
			echo "<br>";
		}
	}
	
	public function printAllQueryResult()
	{
		echo "<html>";
		echo "<head>";
		echo "<title>Result</title>";
		echo "</head>";
		echo "<body>";
		echo "<font size=\"4\">SUCCESS</font><br>";
		echo "<FIELDSET>";
		$this->printQS();
		echo "</FIELDSET>";
		echo "<br>";
		echo "<font size=\"4\">FAIL</font><br>";
		echo "<FIELDSET>";
		$this->printQF();
		echo "</FIELDSET>";
		echo "<br>";
		echo "</body>";
		echo "</html>";
	}
	
	private function fixDBError()
	{
		//MaxPersonID Error
		$query = "SELECT * FROM Actor WHERE id IN (SELECT id FROM MaxPersonID)";
		$this->query( $query );
		
		if( $this->num_rows() > 0 )
		{
			array_push( $q_success, "Person ID Error" );
		}
		
		
		
	}
}

class select
{
	private $genre = array(0,
	                       "Action",
			               "Adult",
			               "Adventure",
			               "Animation",
			               "Comedy",
			               "Crime",
			               "Documentary",
			               "Drama",
			               "Family",
			               "Fantasy",
			               "Horror",
			               "Musical",
			               "Mystery",
			               "Romance",
			               "Sci-Fi",
			               "Short",
			               "Thriller",
			               "War",
			               "Western");
	               
	private $commentRating = array(1,
	                               "5 - Excellent",
			                       "4 - Good",
			                       "3 - It's ok~",
			                       "2 - Not worth",
			                       "1 - I hate it");
                     
	private $commentRatingValue = array(5,
	                                    4,
	                                    3,
	                                    2,
	                                    1);
	               
	private $mpaaRating = array(0,
	                            "G",
			                    "NC-17",
			                    "PG",
			                    "PG-13",
			                    "R",
			                    "surrendere");
	
	public function __construct()
	{
	}
			                    
	public function createSelect( $which, $name, $selected=0 )
	{
		echo "<select name=\"".$name."\">\n";
		for( $i=1; $i<count($this->{$which}); $i++ )
		{
			if( $this->{$which}[0] == 0 )
				if( $i == $selected )
					echo "<option value=\"".$i."\" selected=\"selected\">\n".$this->{$which}[$i]."</option>";
				else
					echo "<option value=\"".$i."\">".$this->{$which}[$i]."</option>\n";
			else
				if( $i == $selected )
					echo "<option value=\"".$this->{$which."Value"}[$i-1]."\" selected=\"selected\">".$this->{$which}[$i]."</option>\n";
				else
					echo "<option value=\"".$this->{$which."Value"}[$i-1]."\">".$this->{$which}[$i]."</option>\n";
		}
		echo "</select>\n";
	}
	
	public function createBox( $which, $selectedValue=1 )
	{
		for( $i=1; $i<count($this->{$which}); $i++ )
		{
			echo "<input type=\"checkbox\" name=\"".$this->{$which}[$i]."\" value=\"".$selectedValue."\">".$this->{$which}[$i]."</input>\n";
			if( $i%5 == 0 )
				echo "<br>";
		}
	}
	
	public function getValue( $name, $index )
	{
		return $this->{$name}[$index];
	}
	
	public function getCount( $name )
	{
		return count( $this->{$name} )-1;
	}
	
	public function mysqlSelect( $name, $table, $main, $id, $v1=0, $v2=0, $selected=0 )
	{
		echo "<select name=\"".$name."\" id=\"".$name."\">\n";
		$mysql = new mysql();
		if( $name == "director" || $name == "aid" || $name == "actor" )
			$query = "SELECT ".$main.", ".$id.", ".$v1.", ".$v2." FROM ".$table." ORDER BY ".$main;
		else
			$query = "SELECT ".$main.", ".$id.", ".$v1." FROM ".$table." ORDER BY ".$main;
		$mysql->query( $query );
		while( $row = $mysql->fetch_array() )
		{
			if( $name == "director" || $name == "aid" || $name == "actor" )
				if( $row[$id] == $selected )
					echo "<option value=\"".$row[$id]."\" selected>".$row[$main]." ".$row[$v1]."(Birth: ".$row[$v2].")</option>\n";
				else
					echo "<option value=\"".$row[$id]."\">".$row[$main]." ".$row[$v1]."(Birth: ".$row[$v2].")</option>\n";
			else
				if( $row[$id] == $selected )
					echo "<option value=\"".$row[$id]."\" selected>".$row[$main]."(".$row[$v1].")</option>\n";
				else
					echo "<option value=\"".$row[$id]."\">".$row[$main]."(".$row[$v1].")</option>\n";
		}
		echo "</select>\n";
	}
}
?>