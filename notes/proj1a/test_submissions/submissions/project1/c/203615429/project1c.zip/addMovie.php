<?php
include 'classes.php';
$select = new select();
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add New Movie</title>
</head>

<body>
<form id="addMovie" name="addMovie" method="get" action="mysql.php">
	<input type="hidden" name="me" value="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="action" value="addMovie">
  <fieldset>
    <legend>Add new Movie</legend>
    <table width="1079" height="187" border="0">
      <tr>
        <td width="168">Title:</td>
        <td width="895"><label>
          <input type="text" name="title" id="title" />
        </label></td>
      </tr>
      <tr>
        <td>Company:</td>
        <td><label>
          <input type="text" name="company" id="company" />
        </label></td>
      </tr>
      <tr>
        <td>Year:</td>
        <td><label>
          <input type="text" name="year" id="year" />
        </label></td>
      </tr>
      <tr>
        <td>Director:</td>
        <td><?=$select->mysqlSelect( "director", "Director", "last", "id", "first", "dob" )?></td>
      </tr>
      <tr>
        <td>MPAA Rating:</td>
        <td><?=$select->createSelect( "mpaaRating", "mpaa" )?></td>
      </tr>
      <tr>
        <td>Genre:</td>
        <td><?=$select->createBox("genre")?></td>
      </tr>
    </table>
    <p>
      <label>
        <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </p>
  </fieldset>
</form>
</body>
</html>
