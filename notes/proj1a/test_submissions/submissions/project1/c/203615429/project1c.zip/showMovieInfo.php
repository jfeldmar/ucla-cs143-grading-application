<?php
include 'classes.php';
$select = new select();
?>
<head>
<title>Show Movie Info</title>
</head>

<body>
<?php
$mid = $_REQUEST['mid'];
if( $mid )
{
	$mysql = new mysql();
	$query = "SELECT * FROM Movie WHERE id = '".$mid."'";
	$mysql->query( $query );
	$row = $mysql->fetch_array();
	echo "<fieldset>";
	echo "<legend>Show Movie Information</legend>";
	echo "Title: ".$row['title']." (".$row['year'].")<br>";
	echo "Producer: ".$row['company']."<br>";
	echo "MPAA Rating: ".$row['rating']."<br>";
	
	$query = "SELECT D.last, D.first, D.dob FROM Director D, MovieDirector MD WHERE D.id=MD.did AND MD.mid='".$mid."'";
	$mysql->query( $query );
	$row = $mysql->fetch_array();
	echo "Director: ";
	if( $row['last'] != NULL )
		echo "<font color='Green'>".$row['last']." ".$row['first']." (".$row['dob'].")</font>";
	echo "<br/>";
	$query = "SELECT genre FROM MovieGenre WHERE mid='".$mid."'";
	$mysql->query( $query );
	echo "Genre: <font color='Brown'>";
	while( $row = $mysql->fetch_array() )
	{
		echo $row['genre']." ";
	}
	echo "</font><br/>";
	echo "</fieldset>";
	echo "<br>";
	
	$query = "SELECT last, first, aid, role FROM Actor A, MovieActor MA WHERE A.id=MA.aid AND MA.mid='".$mid."'";
	$mysql->query( $query );
	echo "<fieldset>";
	echo "<legend>Actor in this movie</legend>";
	while( $row = $mysql->fetch_array() )
	{
		echo "<a href=\"./showActor.php?aid=".$row['aid']."\">".$row['last']." ".$row['first']."</a> act as \"".$row['role']."\"<br/>";
	}
	echo "</fieldset>";
	echo "<br>";
	
	//$query = "SELECT  FROM  WHERE mid='".$mid."'";
	$query = "SELECT AVG(rating) AS avg FROM Review WHERE mid='".$mid."'";
	$mysql->query( $query );
	$row = $mysql->fetch_array();
	$avg = $row['avg'];
	
	$query = "SELECT COUNT(*) AS count FROM Review WHERE mid='".$mid."'";
	$mysql->query( $query );
	$row = $mysql->fetch_array();
	$count = $row['count'];
	
	echo "<fieldset>";
	echo "<legend>User Review</legend>";
	if( $count == 0 )
		echo "No Comment  <a href='./addComment.php?mid=".$mid."'>  Add your review now!!</a>";
	else
	{
		echo "Average Score: ".$avg."/5 (5.0 is best) by ".$count." reviews(s).<a href='./addComment.php?mid=".$mid."'>  Add your review now!!</a><br>";
		echo "All Comments in Details:<br/>";
		$query = "SELECT name, time, rating, comment FROM Review WHERE mid='".$mid."'";
		$mysql->query( $query );
		while( $row = $mysql->fetch_array() )
		{
		echo "<font color='Blue'>In ".$row['time'].", <font color='Red'>".$row['name']."</font> said: I rate this movie score <font color='Red'>".$row['rating']."</font> point(s), here is my comment. </font><br/>".$row['comment']."<br/><br/>";
		}
	}
	echo "</fieldset>";
	echo "<br>";
}
?>
<form id="showMovieInfo" name="showMovieInfo" method="get" action="./showMovieInfo.php">
  <fieldset>
    <legend>Select Movie</legend>
    <?=$select->mysqlSelect( "mid", "Movie", "title", "id", "year", 0, $mid )?>
    <br>
    <p>
      <label>
        <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </p>
  </fieldset>
</form>
<?php
if( $mid )
{
	$mysql->printAllQueryResult();
}
?>
</body>
</html>
