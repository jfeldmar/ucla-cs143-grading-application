<?php
include 'classes.php';
$select = new select();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Comment</title>
</head>

<body>
<font size="4">Add new comment:</font>
<FIELDSET>
<form id="addcomment" name="addcomment" method="get" action="mysql.php">
	<input type="hidden" name="me" value="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="action" value="addComment">
  <table width="700" border="0">
    <tr>
      <td width="149">Movie:</td>
      <td width="381"><?=$select->mysqlSelect( "mid", "Movie", "title", "id", "year", 0, $_REQUEST['mid'] )?></td>
    </tr>
    <tr>
      <td>Your Name:</td>
      <td><input type="text" name="name" id="name" value="Mr. Anonymous" /></td>
    </tr>
    <tr>
      <td>Rating:</td>
      <td><select name="rating">
        <option value="5" selected="selected"> 5 - Excellent </option>
        <option value="4"> 4 - Good </option>
        <option value="3"> 3 - It's ok~ </option>
        <option value="2"> 2 - Not worth </option>
        <option value="1"> 1 - I hate it </option>
      </select></td>
    </tr>
  </table>
  Comments:
  <p>
    <textarea name="comment" id="comment" cols="45" rows="5"></textarea>
  </p>
  <p>
    <input type="submit" name="Submit" id="button" value="Submit" />
  </p>
</form>
</FIELDSET>

<?php
$id = $_REQUEST['id'];
if( !empty( $id ) )
{
?>
<br>
<FIELDSET>
<font color='Red'><b>Thanks your comment!! We appreciate it!!</b></font><br/><a href = './showMovieInfo.php?mid=<?=$id?>'>See Movie Info (including others' reviews)</a>
</FIELDSET>
<?php
}
?>
</body>
</html>
