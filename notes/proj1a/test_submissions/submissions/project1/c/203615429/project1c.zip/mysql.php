<?php
if( !$_REQUEST['action'] )
{
	exit("Error");
}

include 'classes.php';

$mysql = new mysql();

$action = $_REQUEST['action'];
$me = $_REQUEST['me'];
if( $action == "addPeople" )
{
	$addType = $_REQUEST['addType'];
	$firstName = $_REQUEST['firstName'];
	$lastName = $_REQUEST['lastName'];
	$sex = $_REQUEST['sex'];
	$dob = $_REQUEST['dob'];
	$dod = $_REQUEST['dod'];
	
	if( $addType == "actor" )
	{
		$query = "INSERT INTO Actor VALUES( (SELECT id+1 FROM MaxPersonID), '".$lastName."', '".$firstName."', '".$sex."', '".$dob."', '".$dod."' )";
		$mysql->query( $query );
		
		if( !$mysql->isError() )
		{
			$mysql->query( "UPDATE MaxPersonID SET id = id+1" );
		}
		if( !$mysql->isError() )
		{
			header ("Refresh: 5; url='".$me."'"); 
			$mysql->printAllQueryResult();
		}
		else
		{
			header ("Refresh: 10; url='".$me."'"); 
			$mysql->printAllQueryResult();
		}
	}
	elseif( $addType == "director" )
	{
		$query = "INSERT INTO Director VALUES( (SELECT id+1 FROM MaxPersonID), '".$lastName."', '".$firstName."', '".$dob."', '".$dod."' )";
		$mysql->query( $query );
		
		if( !$mysql->isError() )
		{
			$mysql->query( "UPDATE MaxPersonID SET id = id+1" );
		}
		if( !$mysql->isError() )
		{
			header ("Refresh: 5; url='".$me."'"); 
			$mysql->printAllQueryResult();
		}
		else
		{
			header ("Refresh: 10; url='".$me."'"); 
			$mysql->printAllQueryResult();
		}
	}
	elseif( $addType == "both" )
	{
		$query = "INSERT INTO Actor VALUES( (SELECT id+1 FROM MaxPersonID), '".$lastName."', '".$firstName."', '".$sex."', '".$dob."', '".$dod."' )";
		$mysql->query( $query );
		
		$query = "INSERT INTO Director VALUES( (SELECT id+1 FROM MaxPersonID), '".$lastName."', '".$firstName."', '".$dob."', '".$dod."' )";
		$mysql->query( $query );
		
		if( !$mysql->isError() )
		{
			$mysql->query( "UPDATE MaxPersonID SET id = id+1" );
		}
		if( !$mysql->isError() )
		{
			header ("Refresh: 5; url='".$me."?result=good'"); 
			$mysql->printAllQueryResult();
		}
		else
		{
			header ("Refresh: 10; url='".$me."?result=bad'"); 
			$mysql->printAllQueryResult();
		}
	}
	
}
elseif( $action == "addComment" )
{
	$movie = $_REQUEST['mid'];
	$name = $_REQUEST['name'];
	$rating = $_REQUEST['rating'];
	$comment = $_REQUEST['comment'];
	
	$query = "INSERT INTO Review VALUES( '".$name."', NOW(), ".$movie.", ".$rating.", '".$comment."' )";
	$mysql->query( $query );
	
	if( !$mysql->isError() )
	{
		header ("Refresh: 5; url='".$me."?id=".$movie."'"); 
		$mysql->printAllQueryResult();
	}
	else
	{
		header ("Refresh: 10; url='".$me."'"); 
		$mysql->printAllQueryResult();
	}
}
elseif( $action == "addMovie" )
{
	$title = $_REQUEST['title'];
	$company = $_REQUEST['company'];
	$year = $_REQUEST['year'];
	$director = $_REQUEST['director'];
	$select = new select();
	$mpaa = $select->getValue( "mpaaRating", $_REQUEST['mpaa'] );
	
	$query = "INSERT INTO Movie VALUES( (SELECT id+1 FROM MaxMovieID), '".$title."', '".$year."', '".$mpaa."', '".$company."' )";
	$mysql->query( $query );
	$query = "INSERT INTO MovieDirector VALUES( (SELECT id+1 FROM MaxMovieID), '".$director."' )";
	$mysql->query( $query );
	$select = new select();
	$total = $select->getCount( "genre" );
	for( $i=1; $i <= $total; $i++ )
	{
		$name = $select->getValue( "genre", $i );
		if( $_REQUEST[$name] == 1 )
		{
			$query = "INSERT INTO MovieGenre VALUES( (SELECT id+1 FROM MaxMovieID), '".$name."' )";
			$mysql->query( $query );
		}
	}
	$query = "UPDATE MaxMovieID SET id = id + 1";
	$mysql->query( $query );
	
	if( !$mysql->isError() )
	{
		header ("Refresh: 5; url='".$me."?id=1'"); 
		$mysql->printAllQueryResult();
	}
	else
	{
		header ("Refresh: 10; url='".$me."'"); 
		$mysql->printAllQueryResult();
	}
}
elseif( $action == "addRole" )
{
	$movie = $_REQUEST['movie'];
	$actor = $_REQUEST['actor'];
	$role = $_REQUEST['role'];
	
	$query = "INSERT INTO MovieActor VALUES( '".$movie."', '".$actor."', '".$role."' )";
	$mysql->query( $query );
	
	if( !$mysql->isError() )
	{
		header ("Refresh: 5; url='".$me."?result=good'"); 
		$mysql->printAllQueryResult();
	}
	else
	{
		header ("Refresh: 10; url='".$me."?result=bad'"); 
		$mysql->printAllQueryResult();
	}
}
else
{
	exit("Error");
}
exit();
?>