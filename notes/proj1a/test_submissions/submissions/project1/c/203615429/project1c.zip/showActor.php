<?php
include 'classes.php';
$select = new select();
?>
<html>
<head>
<title>Show Actor</title>
</head>

<body>
<?php
$aid = $_REQUEST['aid'];
if( $aid )
{
	$mysql = new mysql();
	$query = "SELECT * FROM Actor WHERE id = '".$aid."'";
	$mysql->query( $query );
	$row = $mysql->fetch_array();
	echo "<fieldset>";
	echo "<legend>Show Actor Information</legend>";
	echo "Name: ".$row['last']." ".$row['first']."<br>";
	echo "Sex: ".$row['sex']."<br>";
	echo "Date of birth: ".$row['dob']."<br>";
	echo "Date of death: ".(($row['dod'] == "0000-00-00" || $row['dod'] == NULL )?"--Still Alive--":$row['dod'])."<br>";
	echo "</fieldset>";
	echo "<br>";
	
	echo "<fieldset>";
	echo "<legend>Act in</legend>";
	$query = "SELECT (SELECT title FROM Movie WHERE id=mid) AS title, mid, role FROM MovieActor WHERE aid = '".$aid."'";
	$mysql->query( $query );
	while( $row = $mysql->fetch_array() )
	{
		echo "Act \"".$row['role']."\" in <a href = \"./showMovieInfo.php?mid=".$row['mid']."\">".$row['title']."</a><br/>";
	}
	echo "</fieldset>";
	echo "<br>";
}
?>
<form id="showActor" name="showActor" method="get" action="./showActor.php">
  <fieldset>
    <legend>Select Actor</legend>
    <p>
    	<?=$select->mysqlSelect( "aid", "Actor", "last", "id", "first", "dob", $aid )?>
    </p>
    <p>
      <label>
        <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </p>
  </fieldset>
</form>
<?php
if( $aid )
{
	$mysql->printAllQueryResult();
}
?>
</body>
</html>
