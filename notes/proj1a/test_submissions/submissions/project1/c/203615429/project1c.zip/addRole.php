<?php
include 'classes.php';
$select = new select();
?>
<html>
<head>
<title>Add Role</title>
</head>

<body>
<form id="addRole" name="addRole" method="get" action="mysql.php">
	<input type="hidden" name="me" value="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="action" value="addRole">
  <fieldset>
    <legend>Add new actor in a movie:</legend>
    <table width="692" border="0">
      <tr>
        <td width="103">Movie:</td>
        <td width="579"><?=$select->mysqlSelect( "movie", "Movie", "title", "id", "year" )?></td>
      </tr>
      <tr>
        <td>Actor:</td>
        <td><?=$select->mysqlSelect( "actor", "Actor", "last", "id", "first", "dob" )?></td>
      </tr>
      <tr>
        <td>Role:</td>
        <td><label>
          <input type="text" name="role" id="role" />
        </label></td>
      </tr>
    </table>
    <p>
      <label>
        <input type="submit" name="submit" id="submit" value="Submit" />
      </label>
    </p>
  </fieldset>
</form>
		<?php
		if( $_REQUEST["result"] == "good" )
			echo "<font color='Red'><b>Add Success!!</b></font>";
		elseif ( $_REQUEST["result"] == "bad" )
			echo "<font color='Red'><b>Add Fail!!</b></font>";
		?>
</body>
</html>
