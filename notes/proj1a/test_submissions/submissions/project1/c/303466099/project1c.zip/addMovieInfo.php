<html>

<head>

<title>Add Movie Information</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation" bordercolor="#FFE500">
<tr>
<td bgcolor="#FFE500">
<div id="tab"><a href="./addMovieInfo.php">[Add] Movie</a></div>
</td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>


<table id="main">
<tr><td id="content"><div id="tdscroll">

<p>
Add new movie:

<form action="./addMovieInfo.php" method="GET" name="addForm">
<p>
Title: 
<input type="text" name="title" maxlength="100"><br>

Company:
<input type="text" name="company" maxlength="50"><br>

Year:
<input type="text" name="year" maxlength="4"><br>

Director:
<select name="director">
<?php

$db_connection = mysql_connect("localhost", "cs143", "");
mysql_select_db("CS143", $db_connection);

$getDirectors = "SELECT id, last, first FROM Director ORDER BY last ASC";
$rs = mysql_query($getDirectors, $db_connection);

while($dir = mysql_fetch_row($rs))
	print "<option value=\"$dir[0]\">$dir[1], $dir[2]</option>";

?>
</select>

<br>

MPAA Rating:
<select name="rating">
<option value="G">G</option>
<option value="NC-17">NC-17</option>
<option value="PG">PG</option>
<option value="PG-13">PG-13</option>
<option value="R">R</option>
</select>

<br>

Genre:
<input type="text" name="genre" maxlength="20">
<!--
<input type="checkbox" name="genre[]" value="Action">Action<br>
<input type="checkbox" name="genre[]" value="Adult">Adult<br>
<input type="checkbox" name="genre[]" value="Adventure">Adventure<br>
<input type="checkbox" name="genre[]" value="Animation">Animation<br>
<input type="checkbox" name="genre[]" value="Comedy">Comedy<br>
<input type="checkbox" name="genre[]" value="Crime">Crime<br>
<input type="checkbox" name="genre[]" value="Documentary">Documentary<br>
<input type="checkbox" name="genre[]" value="Drama">Drama<br>
<input type="checkbox" name="genre[]" value="Family">Family<br>
<input type="checkbox" name="genre[]" value="Fantasy">Fantasy<br>
<input type="checkbox" name="genre[]" value="Horror">Horror<br>
<input type="checkbox" name="genre[]" value="Musical">Musical<br>
<input type="checkbox" name="genre[]" value="Mystery">Mystery<br>
<input type="checkbox" name="genre[]" value="Romance">Romance<br>
<input type="checkbox" name="genre[]" value="Sci-Fi">Sci-Fi<br>
<input type="checkbox" name="genre[]" value="Short">Short<br>
<input type="checkbox" name="genre[]" value="Thriller">Thriller<br>
<input type="checkbox" name="genre[]" value="War">War<br>
<input type="checkbox" name="genre[]" value="Western">Western<br>
-->

<input type="submit" value="Add"/>
</p>
</form>

</p>

<hr>

<?php

$query = "SELECT * FROM MaxMovieID";
$rs = mysql_query($query, $db_connection);
$maxID = mysql_fetch_row($rs);
$maxID = $maxID[0];

$title = $_GET["title"];
$title = mysql_real_escape_string($title);
$company = $_GET["company"];
$company = mysql_real_escape_string($company);
$year = $_GET["year"];
$year = mysql_real_escape_string($year);
$director = $_GET["director"];
$rating = $_GET["rating"];
$genre = $_GET["genre"];
$genre = mysql_real_escape_string($genre);

///////////////////////////////// Add Movie //////////////////////////////////

$regex_year = "/[^0-9]/";

if(preg_match($regex_year,$year))
	print "Invalid year";
else if($title != NULL && $company != NULL && $year != NULL)
{
	$update = "UPDATE MaxMovieID SET id = id +1";
	mysql_query($update, $db_connection);
	$maxID++;

	$query1 = "INSERT INTO Movie 
		VALUES($maxID, '$title', '$year', '$rating', '$company')";
	$query2 = "INSERT INTO MovieDirector
		VALUES($maxID, $director)";
	$query3 = "INSERT INTO MovieGenre
		VALUES($maxID, '$genre')";

	if(mysql_query($query1, $db_connection) &&
		mysql_query($query2, $db_connection) &&
		mysql_query($query3, $db_connection))
	{
		print "Add success!<br>";
		print "<a href=\"./addMovieActor.php?initMovie=$maxID\">
			Add actors to movie</a>";
	}
	else
		print "Add fail...";
}
/////////////////////////////////////////////////

mysql_close($db_connection);
?>

</div>
</td>
</tr>
</table>
</center>

</body>

</html>
