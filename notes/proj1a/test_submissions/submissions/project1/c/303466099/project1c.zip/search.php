<html>

<head>

<title>Search Actor/Movie</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$keyword = $_GET["keyword"];
$sanitized_keyword = mysql_real_escape_string($keyword, $db_connection);

//////////////////////////// SEARCH ACTORS ///////////////////////////////////

if($keyword != NULL)
{
	print "You are searching [$sanitized_keyword] results...<br><br>";

	$query = "
		(	
			SELECT *
			FROM Actor
			WHERE CONCAT_WS(' ', first, last) LIKE '%%%s%%'
		)
		UNION
		(
			SELECT *
			FROM Actor
			WHERE CONCAT_WS(' ', last, first) LIKE '%%%s%%'
		)
		";

	$query_to_issue = 
		sprintf($query, $sanitized_keyword, $sanitized_keyword);
	$rs = mysql_query($query_to_issue, $db_connection);

	print "Searching match records in Actor database...<br>";

	while($row = mysql_fetch_row($rs))
	{
		print "Actor: ";
		print "<a href=\"./showActorInfo.php?aid=$row[0]\">";
		print "$row[2]  $row[1]($row[4])";
		print "</a><br>";
	}
}

//////////////////////////////////////////////////////////////////////////////
///////////////////////////// SEARCH MOVIES //////////////////////////////////

if($keyword != NULL)
{
	$query = "SELECT * FROM Movie WHERE title LIKE '%%%s%%'";
	$query_to_issue = sprintf($query, $sanitized_keyword);
	$rs = mysql_query($query_to_issue, $db_connection);

	print "<br>Searching match records in Movie database...<br>";

	while($row = mysql_fetch_row($rs))
	{
		print "Movie: ";
		print "<a href=\"./showMovieInfo.php?mid=$row[0]\">";
		print "$row[1]($row[2])";
		print "</a><br>";
	}
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</div>
</td>
</tr>
</table>
</center>

</body>

</html>
