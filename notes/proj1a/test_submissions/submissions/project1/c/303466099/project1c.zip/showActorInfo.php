<html>

<head>

<title>Actor Information</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td bgcolor="#FFE500">
<div id="tab"><a href="./showActorInfo.php">[Browse] Actors/Directors</a></div>
</td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">



<form action="./showActorInfo.php" method="GET">
<p>Browse:&nbsp
<select name="aid">

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$query = "SELECT id, last, first, dob FROM Actor";
$getActors = mysql_query($query, $db_connection);

while($row = mysql_fetch_row($getActors))
	print "<option value=\"$row[0]\">$row[1], $row[2] ($row[3])</option>";

?>

</select>
<input type="submit" value="Browse">
</p>
</form>

<hr>

<?php

$aid = $_GET["aid"];

//////////////////////////// SHOW ACTOR INFO /////////////////////////////////

if($aid != NULL)
{
	$query = "SELECT * FROM Actor WHERE id = $aid";
	$rs = mysql_query($query, $db_connection);

	print "<p>";
	$actor = mysql_fetch_row($rs);
	print "-- Show Actor Info --<br>";
	print "Name: $actor[2] $actor[1]<br>";
	print "Sex: $actor[3]<br>";
	print "Date of Birth: $actor[4]<br>";
	print "Date of Death: ";
	if($actor[5] == "0000-00-00")
		print "-- Still Alive --<br><br>";
	else
		print "$actor[5]<br><br>";
	print "</p>";
}

//////////////////////////////////////////////////////////////////////////////
///////////////////////// SHOW MOVIE APPEARANCES /////////////////////////////

if($aid != NULL)
{
	$query = "
		SELECT mid, role, title 
		FROM MovieActor, Movie 
		WHERE mid = id AND aid = $aid
		";
	$rs = mysql_query($query, $db_connection);

	print "<p>";
	print "-- Act in --<br>";

	while($info = mysql_fetch_row($rs))
	{
		print "Act \"$info[1]\" in ";
		print "<a href=\"./showMovieInfo?mid=$info[0]\">";
		print "$info[2]</a><br>";
	}
	print "</p>";
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</td></div></tr>
</table>

</center>

</body>

</html>
