<html>

<head>

<title>Movie Information</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td bgcolor="#FFE500">
<div id="tab"><a href="./showMovieInfo.php">[Browse] Movies</a></div></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">

<form action="./showMovieInfo.php" method="GET">
<p>Browse:&nbsp
<select name="mid">

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$query = "SELECT id, title, year FROM Movie";
$getMovies = mysql_query($query, $db_connection);

while($row = mysql_fetch_row($getMovies))
	print "<option value=\"$row[0]\">$row[1] ($row[2])</option>";

?>

</select>

<input type="submit" value="Browse"/>
</p>
</form>

<hr>

<?php

$mid = $_GET["mid"];
$mv = $_GET["movie"];

/////////////////////////// SHOW MOVIE INFO //////////////////////////////////

if($mid != NULL)
{
	$query = "SELECT * FROM Movie WHERE id = $mid";
	$rs = mysql_query($query, $db_connection);

	$movie = mysql_fetch_row($rs);
	print "<p>-- Show Movie Info --<br>";
	print "Title: $movie[1] ($movie[2])<br>";
	print "Producer: $movie[4]<br>";
	print "MPAA Rating: $movie[3]<br>";

	$query = "
		SELECT first, last, genre
		FROM Director D, MovieDirector MD, MovieGenre MG
		WHERE MD.mid = $mid AND MD.did = D.id AND MG.mid = $mid
		";
	$rs = mysql_query($query, $db_connection);

	$movie = mysql_fetch_row($rs);
	print "Director: $movie[0] $movie[1]<br>";
	print "Genre: $movie[2]<br><br></p>";
}

//////////////////////////////////////////////////////////////////////////////
///////////////////////// SHOW MOVIE APPEARANCES /////////////////////////////

if($mid != NULL)
{
	$query = "
		SELECT aid, first, last, role
		FROM MovieActor, Actor
		WHERE mid = $mid AND aid = id
		";
	$rs = mysql_query($query, $db_connection);

	print "<p>-- Actor in this movie--<br>";

	while($info = mysql_fetch_row($rs))
	{
		print "<a href=\"./showActorInfo?aid=$info[0]\"> ";
		print "$info[1] $info[2]</a> act as \"$info[3]\"<br>";
	}
	
	print "<br></p>";

}

//////////////////////////////////////////////////////////////////////////////
////////////////////// SHOW USER REVIEW AND COMMENTS /////////////////////////

if($mid != NULL)
{
	print "<p>-- User Review --<br>";

	$query = "
		SELECT AVG(rating) 
		FROM Review
		WHERE mid = $mid
		";
	$rs = mysql_query($query, $db_connection);
	$avgScore = mysql_fetch_row($rs);
	$avgScore = $avgScore[0];

	$query = "
		SELECT COUNT(*)
		FROM Review
		WHERE mid = $mid
		";
	$rs = mysql_query($query, $db_connection);
	$numReviews = mysql_fetch_row($rs);
	$numReviews = $numReviews[0];

	if($avgScore == NULL)
		$avgScore = 0;
	print "Average Score: $avgScore/5 by $numReviews review(s). ";
	print "<a href=\"./addComment.php?init=$mid\">Add your review!</a><br>";
	print "All comments:<br>";

	$query = "
		SELECT time, name, rating, comment
		FROM Review
		WHERE mid = $mid
		";
	$rs = mysql_query($query, $db_connection);

	while($row = mysql_fetch_row($rs))
	{
		print "$row[1] said...<br>";
		print "$row[3]<br>";
		print "Rating: $row[2]/5\tWritten: $row[0]<br><br>";
	}

	print "</p>";
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</div>
</td>
</tr>
</table>
</center>

</body>

</html>
