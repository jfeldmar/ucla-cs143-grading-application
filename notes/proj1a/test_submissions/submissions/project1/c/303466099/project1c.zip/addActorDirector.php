<html>

<head>

<title>Add Actor/Director Information</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td bgcolor="#FFE500">
<div id="tab"><a href="./addActorDirector.php">[Add] Actor/Director</a></div>
</td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">

<p>Add Actor or Director:</p>

<form action="./addActorDirector.php" method="GET" name="addForm">
<p>
Identity: 
<input type="radio" name="identity" value="Actor" checked="true">Actor
<input type="radio" name="identity" value="Director">Director<br>
</p>
<hr>
<p>
First Name: <input type="text" name="first" maxlength="20"></input><br>
Last Name: <input type="text" name="last" maxlength="20"></input><br>

Sex:
<input type="radio" name="sex" value="Male" checked="true">Male
<input type="radio" name="sex" value="Female">Female<br>

Date of Birth: 
<select name="dobMonth">
<option value="01">January</option>
<option value="02">February</option>
<option value="03">March</option>
<option value="04">April</option>
<option value="05">May</option>
<option value="06">June</option>
<option value="07">July</option>
<option value="08">August</option>
<option value="09">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
<select name="dobDay">
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<input type="text" name="dobYear" maxlength="4"></input>

<br>

Date of Death: 
<select name="dodMonth">
<option value="">--</option>
<option value="01">January</option>
<option value="02">February</option>
<option value="03">March</option>
<option value="04">April</option>
<option value="05">May</option>
<option value="06">June</option>
<option value="07">July</option>
<option value="08">August</option>
<option value="09">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
<select name="dodDay">
<option value="">--</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
</select>
<input type="text" name="dodYear" maxlength="4"></input>

<input type="submit" value="Add"/>
</p>
</form>

<hr>

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$query = "SELECT * FROM MaxPersonID";
$rs = mysql_query($query, $db_connection);
$maxID = mysql_fetch_row($rs);
$maxID = $maxID[0];

$identity = $_GET["identity"];
$first = $_GET["first"];
$first = mysql_real_escape_string($first);
$last = $_GET["last"];
$last = mysql_real_escape_string($last);
$sex = $_GET["sex"];
$dobMonth = $_GET["dobMonth"];
$dobDay = $_GET["dobDay"];
$dobYear = $_GET["dobYear"];
$dobYear = mysql_real_escape_string($dobYear);
$dodMonth = $_GET["dodMonth"];
$dodDay = $_GET["dodDay"];
$dodYear = $_GET["dodYear"];
$dodYear = mysql_real_escape_string($dodYear);

$regex_year = "/[^0-9]/";

if(preg_match($regex_year, $dobYear) || preg_match($regex_year, $dodYear))
	print "Invalid year";

/////////////////////////// Add Actor/Director ///////////////////////////////

else if($first != NULL && $last != NULL && $dobYear != NULL)
{
	$update = "UPDATE MaxPersonID SET id = id +1";
	mysql_query($update, $db_connection);
	$maxID++;

	$dob = "$dobMonth/$dobDay/$dobYear";
	if($dodMonth != NULL && $dodDay != NULL && $dodYear != NULL)
		$dod = "$dodMonth/$dodDay/$dodYear";
	else
		$dod = NULL;

	if($identity == "Actor")
	{
		$query = "INSERT INTO Actor 
		VALUES($maxID, '$last', '$first', '$sex', 
			STR_TO_DATE('$dob','%m/%d/%Y'), 
			STR_TO_DATE('$dod','%m/%d/%Y'))";
	}
	else
	{
		$query = "INSERT INTO Director
		VALUES($maxID, '$last', '$first', 
			STR_TO_DATE('$dob','%m/%d/%Y'), 
			STR_TO_DATE('$dod','%m/%d/%Y'))";
	}
	if(mysql_query($query, $db_connection))
	{
		print "Add success!<br>";
		if($identity == "Actor")
		{
			print "<a href=\"./addMovieActor.php?initActor=$maxID\">
				Add Movie Appearances</a>";
		}
	}
	else
		print "Add fail...";
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</div>
</td>
</tr>
</center>

</body>

</html>
