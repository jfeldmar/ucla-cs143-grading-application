<html>

<head>

<title>Add Actor to Movie</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td><a href="./addComment.php">[Add] Comments</a></td>
<td bgcolor="#FFE500">
<div id="tab"><a href="./addMovieActor.php">[Add] Actor to Movie</a></div></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">

<p>Add new actor in a movie:</p>

<form action="./addMovieActor.php" method="GET" name="addForm">
<p>
Movie:&nbsp <select name="movie">

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$getMovies = "SELECT id, title, year FROM Movie ORDER BY title ASC";
$rs = mysql_query($getMovies, $db_connection);

$initMovie = $_GET["initMovie"];

while($row = mysql_fetch_row($rs))
{
	print "<option value=\"$row[0]\" ";
	if($initMovie == $row[0])
		print "selected=\"selected\"";
	print ">$row[1] ($row[2])</option>";
}

?>

</select>

<br>

Actor:&nbsp <select name="actor">

<?php

$getActors = "SELECT id, last, first FROM Actor ORDER BY last ASC";
$rs = mysql_query($getActors, $db_connection);

$initActor = $_GET["initActor"];

while($row = mysql_fetch_row($rs))
{
	print "<option value=\"$row[0]\" ";
	if($initActor == $row[0])
		print "selected=\"selected\"";
	print ">$row[1], $row[2]</option>";
}

?>

</select>

<br>

Role:&nbsp <input type="text" name="role" maxlength="50">

<input type="submit" value="Add"/>
</p>
</form>

<hr>

<?php

$movie = $_GET["movie"];
$actor = $_GET["actor"];
$role = $_GET["role"];

////////////////////// Add Movie/Actor Information ///////////////////////////

if($movie != NULL && $actor != NULL)
{
	$query = "INSERT INTO MovieActor VALUES($movie, $actor, '$role')";

	if(mysql_query($query, $db_connection))
		print "Add success!";
	else
		print "Add fail...";
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</div>
</td>
</tr>
</table>
</center>

</body>

</html>
