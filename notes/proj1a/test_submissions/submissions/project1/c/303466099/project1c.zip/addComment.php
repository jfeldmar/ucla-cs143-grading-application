<html>

<head>

<title>Add Comment to Movie</title>

<link rel="stylesheet" type="text/css" href="./mystyle.css">

</head>

<body>

<form action="./search.php" method="GET" id="search">
<input type="text" name="keyword"></input>
<input type="submit" value="Search"/>
</form>

<center>

<table id="navigation">
<tr>
<td><a href="./addMovieInfo.php">[Add] Movie</a></td>
<td><a href="./addActorDirector.php">[Add] Actor/Director</a></td>
<td bgcolor="#FFE500">
<div id="tab"><a href="./addComment.php">[Add] Comments</a></div>
</td>
<td><a href="./addMovieActor.php">[Add] Actor to Movie</a></td>
<td><a href="./showMovieInfo.php">[Browse] Movies</a></td>
<td><a href="./showActorInfo.php">[Browse] Actors/Directors</a></td>
</tr>
</table>

<table id="main">
<tr><td id="content"><div id="tdscroll">

<p>
Add new comment:
</p>

<form action="./addComment.php" method="GET" name="addForm">
<p>
Movie:
<select name="movie">

<?php

$db_connection = mysql_connect("localhost", "cs143", "");

mysql_select_db("CS143", $db_connection);

$getMovies = "SELECT id, title, year FROM Movie ORDER BY title ASC";
$rs = mysql_query($getMovies, $db_connection);

$init = $_GET["init"];

while($row = mysql_fetch_row($rs))
{
	print "<option value=\"$row[0]\"";
	if($init == $row[0])
		print "selected=\"selected\"";
	print ">$row[1] ($row[2])</option>";
}

?>

</select>

<br>

Your Name:
<input type="text" name="name" maxlength="20"></input>

<br>

Rating:
<select name="rating">
<option value="5">5 - Excellent</option>
<option value="4">4 - Good</option>
<option value="3">3 - Average</option>
<option value="2">2 - Fair</option>
<option value="1">1 - Poor</option>
</select>

<br>

Comment:
<textarea name="comment" cols="80" rows="10"></textarea>

<br>

<input type="submit" value="Rate"/>
</p>
</form>

<hr>

<?php

$movie = $_GET["movie"];
$name = $_GET["name"];
$name = mysql_real_escape_string($name);
$rating = $_GET["rating"];
$comment = $_GET["comment"];
$comment = mysql_real_escape_string($comment);

///////////////////////////// Add Comment ////////////////////////////////////

$query = "INSERT INTO Review 
		VALUES('$name', NOW(), $movie, '$rating', '$comment')";

if($name != NULL)
{
	if(mysql_query($query, $db_connection))
		print "Add success!";
	else
		print "Add fail...";
}

//////////////////////////////////////////////////////////////////////////////

mysql_close($db_connection);

?>

</div>
</td>
</tr>
</table>
</center>

</body>

</html>
