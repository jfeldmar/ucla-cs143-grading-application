<!--===============================================================================
CS143 PAGE B2
Show information about a movie.
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('selector.php');
require('wrapper.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function print_data(&$data)
{

	// Print the resulting data
	echo "<h1 id='title'>".$data['title']."</h1>".
		  "<h2>Main Information</h2>".
		  "<div class='display_style'>Year: ".$data['year']."</div>".
		  "<div class='display_style'>Rating: ".$data['rating']."</div>".
		  "<div class='display_style'>Producer: ".$data['company']."</div>";
	echo "<div class='display_style'>Genre".(count($data['genres']) <= 1 ? "" : "s").": ";
	foreach( $data['genres'] as $index => $genre )
		echo ($index == 0 ? "" : ", ").$genre;
	echo "</div>";

	echo "<div class='display_style'>Director".( count($data['directors']) <= 1 ? "" : "s").": ";
	foreach( $data['directors'] as $index => $director )
		echo ($index == 0 ? "" : ", ")."<a href='b1.php?id={$director['id']}'>".$director['name']."</a>";
	echo "</div>";

	echo "<h2>Cast members (alphabetical)</h2>";
	echo "<ul>";
	foreach ($data['actors'] as $actor)
		echo "<li><a href='b1.php?id={$actor['id']}'>".$actor['name']."</a> ... ".$actor['role']."</li>";
	echo "</ul>";

	echo "<h2>Reviews</h2>";
	if ($data['num_scores']) {
		echo "<div class='display_style'>Average score: ".$data['avg_score']." / 5 (".$data['num_scores']." votes)</div>";
		foreach ($data['reviews'] as $review) {
			echo '<h3>'.$review['name'].'  ('.$review['time'].')
			('.$review['score'].' / 5)</h3>';
			echo '<div class="display_style">'.$review['text'].'</div>';
			}
		}
	else
		echo "No reviews are available for this movie.";
	echo "<h3>Try writing a review <a href='i2.php?id={$data['id']}'>here</a>!</h3>";
}

function &build_data($id,&$data,&$dbh)
{
		$id = mysql_real_escape_string($id,$dbh); // Sanitize the id

		// Check to make sure the id is correct
		if (!is_numeric($id)) {
			echo "Error: Invalid actor/director id!";
			return NULL;
		}

		// Construct a query using our new sanitized id
		$query = 'SELECT * FROM Movie WHERE id='.$id;
		$rc = query_wrapper($query,__LINE__,$dbh);

		// Get basic informatino about the movie
		if ($row = mysql_fetch_row($rc)) {
			$data['title'] = htmlspecialchars($row[1]);
			$data['year'] = $row[2];
			$data['rating'] = $row[3];
			$data['company'] = htmlspecialchars($row[4]);
		}

		else {
			echo "Error: Invalid movie id!";
			$data = NULL;
			return NULL;
		}

		
		// Save the id
		$data['id'] = $id;

		// Perform another query to get the genres of the movie
		$query = 'SELECT genre FROM MovieGenre WHERE mid = '.$id;
		$rc = query_wrapper($query,__LINE__,$dbh);

		$data['genres'] = array(); // Declare genre to be an empty array

		// Iterate through the rows of our result and fetch each genre
		while($row = mysql_fetch_row($rc))
			$data['genres'][] = $row[0];

		// Perform another query to get the director of the movie
		$query = 'SELECT first,last,did FROM MovieDirector, Director 
					 WHERE mid = '.$id.' AND did = Director.id';
		$rc = query_wrapper($query,__LINE__,$dbh);

		$data['directors'] = array(); // Declare directors to be an empty array

		// Iterate through the rows of our result and fetch each director
		while($row = mysql_fetch_row($rc))
			$data['directors'][] = array( 'name' => "$row[0] $row[1]", 'id' =>
			$row[2]);

		// Perform another query to get the actors of the movie
		$query = 'SELECT first,last,role,aid FROM MovieActor, Actor
		 			 WHERE mid = '.$id.' AND aid = Actor.id ORDER BY last';
		$rc = query_wrapper($query,__LINE__,$dbh);

		$data['actors'] = array(); // Declare actors to be an empty array

		// Iterate through the rows of our result and fetch each actor
		while ($row = mysql_fetch_row($rc))
			$data['actors'][] = array( 'name' => "$row[0] $row[1]", 'role' => "$row[2]", 'id' => $row[3]);

		// Query for the average score
		$query = 'SELECT avg(rating), count(rating) FROM Review WHERE mid = '.$id;
		$rc = query_wrapper( $query, __LINE__, $dbh );
		$row = mysql_fetch_row($rc);
		$data['avg_score'] = $row[0];
		$data['num_scores'] = $row[1];

		// Finally, query for information on user reviews (if any exist)
		if ($data['num_scores']) {
			$query = 'SELECT * FROM Review WHERE mid = '.$id.' ORDER BY time';
			$rc = query_wrapper($query,__LINE__,$dbh);

			$data['reviews'] = array(); // Declare reviews

			// Iterate through the rows of our result and fetch each review
			while ($row = mysql_fetch_row($rc))
				$data['reviews'][] = array( 'time' => $row[1], 'name' => htmlspecialchars($row[0]), 'score' =>
				$row[3], 'text' => htmlspecialchars($row[4]));
		}
	
	return $data;
}

?>

<?php print_headers("View movie information") ?>

<?php
	$data = NULL;
	if ($id = $_GET['id']) // If we have an mid in our URL
		$data = build_data($id,$data,$dbh);
	if ($data) // If we found the data
		print_data($data); // Print it!
	else
		echo "<h1>Select a movie below!</h1>";
?>
<form method="get" action"./b2.php">
	<?php print_selector(0,'id','movies',$dbh) ?>
	<div class="form_style"><input type="submit" value="Submit" /></div>
</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
