<!--===============================================================================
CS143 PAGE I2
Add comments to movies.
================================================================================-->
<?php

require('selector.php');
require('wrapper.php');

$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function check_data(&$data,&$dbh)
{
	global $errors;
	// Check that required data is included
	
	if (!$data['name'])
		$errors['name'] = "You need to provide a username.";
	
	if (!$data['rating'])
		$errors['rating'] = "You need to provide a rating from 1 to 5.";

	if (!$data['comment'])
		$errors['comment'] = "You need to provide a comment.";
	
	if (!$data['mid'])
		$errors['mid'] = "You need to select a movie.";
	
	if (!$data['name'] || !$data['rating'] || !$data['comment'] || !$data['mid'])
		return false;

	// Now check that required data makes sense
	
	// Is the rating between 1 and 5?
	if ($data['rating'] < 1 || $data['rating'] > 5) {
		$errors['rating'] = "You need to provide a rating from 1 to 5.";
		return false;
		}
	
	// Does the mid exist?
	$query = "SELECT * FROM Movie WHERE id={$data['mid']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	if (!mysql_fetch_row($rc)) {
		$errors['mid'] = "Movie id doesn't exist, try a different movie.";
		return false;
		}

	return true;

}

function submit_data(&$data,&$dbh)
{
	// Sanitize all incoming data
	foreach ($data as $datum) {
		$datum = mysql_real_escape_string($datum,$dbh);
		$datum = htmlspecialchars($datum);
		}

	if(!check_data($data,$dbh))
		return false;

	// Construct an INSERT INTO statement to insert data into our review table
	$query = "INSERT INTO Review(name,time,mid,rating,comment)
					VALUES('{$data['name']}',
							 NOW(),
							 {$data['mid']},
							 '{$data['rating']}',
							 '{$data['comment']}')";
	query_wrapper($query,__LINE__,$dbh);

	return true;

}

?>

<?php print_headers("Write a review") ?>

<?php
	// Do we have a request for submission?
	if ($_POST['subreq']) {
		if (submit_data($_POST,$dbh))
			echo "Success! Check out your review <a
				href='b2.php?id={$_POST['mid']}'>here</a>.";
		else
			echo "<h1>Submission error, try again!</h1>";
	}
?>


<h1 class="form_style">Fill out the form below: </h1>

<form method="post" action="./i2.php">
Select movie title:
<?php print_selector(0,'mid','movies',$dbh); ?>
<?php error_check('mid') ?>

<div class="form_style">Your Name:	<input type="text" name="name"
	value='<?php if ($_POST['name']) echo $_POST['name']; else echo "Mr. Anonymous" ?>' maxlength="20" />
	<?php error_check('name') ?>
	</div>
<div class="form_style">Rating:	<select name="rating">
						<option value="5"> 5 - Excellent</option>
						<option value="4"> 4 - Good </option>
						<option value="3"> 3 - Okay</option>

						<option value="2"> 2 - Bad</option>
						<option value="1"> 1 - Ugly</option>
					</select>

			<?php error_check('rating') ?>
			</div>
<div class="form_style">Comments:<br />
	<textarea name="comment" id="comment" cols="80" rows="10"><?php if ($_POST['comment']) echo $_POST['comment'] ?></textarea>
	<?php error_check('comment') ?>
	<div class="form_style"><input type="submit" name="subreq" value="Submit" /></div>
</div>
</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
