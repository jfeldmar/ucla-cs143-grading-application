<!--===============================================================================
CS143 MAIN PAGE
Main page of our site.
================================================================================-->

<?php require('wrapper.php') ?>

<?php print_headers("CS143 Movie Database") ?>
<h1>
Welcome to the movie database! Choose any of the options on the sidebar to get
started.
</h1>
<?php print_footers() ?>
