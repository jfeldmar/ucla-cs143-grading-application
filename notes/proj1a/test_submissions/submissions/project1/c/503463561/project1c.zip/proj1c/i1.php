<!--===============================================================================
CS143 PAGE I1
Add information about an actor or director.
================================================================================-->
<?php

require('wrapper.php'); // Require nav.php for printing standard navbar

$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function check_data(&$data,&$dbh)
{
	global $errors;
	// Check that required data is included
	if ( (!$data['is_actor'] && !$data['is_director']) )
		$errors['identity'] = "You need to check either an actor or director
		box!";	

	if ( !$data['first'] )
		$errors['first'] = "You need to provide a first name.";
	
	if ( !$data['last'] )
		$errors['last'] = "You need to provide a last name.";

	if ( !$data['sex'] )
		$errors['sex'] = "You need to provide a gender.";
	
	if ( !$data['dob'] )
		$errors['dob'] = "You need to provide a date of birth.";
	
	if (  (!$data['is_actor'] && !$data['is_director']) ||
			!$data['first'] || !$data['last'] ||
			!$data['sex'] || !$data['dob'])
		return false;
	
	// Now check that required data makes sense

	// Is the sex valid?
	if ($data['sex'] != "Male" && $data['sex'] != "Female")
		return false;

	// Is the date of birth and date of death valid?
	$query = "SELECT YEAR(STR_TO_DATE('{$data['dob']}','%m/%d/%Y'))";
	$rc = query_wrapper($query,__LINE__,$dbh);
	$row = mysql_fetch_row($rc);
	if (!($dob = $row[0])) {
		$errors['dob'] = "Invalid format, try again.";
		return false;
		}

	$query = "SELECT YEAR(STR_TO_DATE('{$data['dod']}','%m/%d/%Y'))";
	$rc = query_wrapper($query,__LINE__,$dbh);
	$row = mysql_fetch_row($rc);
	if (!($dod = $row[0])) {
		$errors['dob'] = "Invalid date of birth!";
		return false;
		}
	
	// Is the person born after he died? Return false then
	if ($dob > $dod) {
		$errors['dod'] = "Date of birth is earlier than date of death!";
		return false;
		}


	return true;
}

function submit_data(&$data,&$dbh)
{
	// Sanitize all incoming data
	foreach ($data as $datum) {
		$datum = mysql_real_escape_string($datum,$dbh);
		$datum = htmlspecialchars($datum);
		}
	

	if(!check_data($data,$dbh))
		return false;
	
	// Get the current MaxPersonID then increment it
	$query = "SELECT * FROM MaxPersonID";
	$rc = query_wrapper($query,__LINE__,$dbh);
	$query = "UPDATE MaxPersonID SET id = id+1";
	query_wrapper($query,__LINE__,$dbh);
	
	if ($row = mysql_fetch_row($rc))
		$data['id'] = $row[0];
	else
		die("Fatal error, MaxPersonID not found!");
	
	// If this is an actor:
	// Construct an INSERT INTO statement to insert data into our actor table
	
	if ($data['is_actor']) {
		$query = "INSERT INTO Actor(id,first,last,sex,dob,dod) VALUES (
					{$data['id']},
					'{$data['first']}',
					'{$data['last']}',
					'{$data['sex']}',
					STR_TO_DATE('{$data['dob']}','%m/%d/%Y'),".
					($data['dod'] ? "STR_TO_DATE('{$data['dod']}','%m/%d/%Y')" : 'NULL').")";
		query_wrapper($query,__LINE__,$dbh);
	}
	if ($data['is_director']) {
		$query = "INSERT INTO Director(id,first,last,dob,dod) VALUES (
					{$data['id']},
					'{$data['first']}',
					'{$data['last']}',
					STR_TO_DATE('{$data['dob']}','%m/%d/%Y'),".
					($data['dod'] ? "STR_TO_DATE('{$data['dod']}','%m/%d/%Y')" : 'NULL').")";
		query_wrapper($query,__LINE__,$dbh);
	}

	return true;
}

?>

<?php print_headers("Insert new actor/director") ?>

<?php
	// Do we have a request for submission?
	if ($_POST['subreq']) {
		if (submit_data($_POST,$dbh))
			echo "Success! Check out your new actor/director <a
				href='b1.php?id={$_POST['id']}'>here</a>.";
		else
			echo "<h1>Submission error, try again!</h1>";
	}
?>
		<h1 class="form_style">Fill out the form below: </h1>

<form action="./i1.php" method="post">
			<div class="form_style">Identity (please check at least one):	
				<input type="checkbox" name="is_actor" value="Actor" <?php if ($_POST['is_actor']) echo 'checked="true"' ?>/> Actor
				<input type="checkbox" name="is_director" value="Director" <?php if ($_POST['is_director']) echo 'checked="true"' ?>/>Director
				 <?php error_check('identity') ?>
			</div>
			<hr/>
			<div class="form_style">First Name:	<input type="text" name="first" value="<?php echo $_POST['first']?>" maxlength="20" />
				 <?php error_check('first') ?>
			</div>
			<div class="form_style">Last Name:	<input type="text" name="last" value="<?php echo $_POST['last']?>" maxlength="20" />
				 <?php error_check('last') ?>
			</div>
			<div class="form_style">Sex:  
				 <input type="radio" name="sex" value="Male" <?php if ($_POST['sex'] == "Male") echo 'checked="true"' ?> />Male
				 <input type="radio" name="sex" value="Female" <?php if ($_POST['sex'] == "Female") echo 'checked="true"' ?>/>Female
				 <?php error_check('sex') ?>
			</div>

						
			<div class="form_style">Date of Birth:	<input type="text" value="<?php echo $_POST['dob']?>" name="dob" /> (MM/DD/YYYY) 
				 <?php error_check('dob') ?>
				</div>
			<div class="form_style">Date of Death:	<input type="text" value="<?php echo $_POST['dod']?>" name="dod" /> 
				(leave blank if alive now)
				 <?php error_check('dod') ?>
				 </div>
<input type="submit" name = "subreq" value="add it!!" />
		</form>
		<hr/>

<?php print_footers() ?>
<?php
mysql_close($dbh); // Close the database once we're finished
?>
