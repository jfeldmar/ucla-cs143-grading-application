<!--===============================================================================
CS143 PAGE S1
Add information about an actor or director.
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('wrapper.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function print_data(&$data)
{

	echo "<h1>Search results</h1>";
	echo "<h2>Movie matches</h2>";
	if ($data['movies'])
		foreach($data['movies'] as $movie)
			echo "<div class='display_style'><a href='b2.php?id={$movie['id']}'>\"{$movie['title']}\"</a>
			({$movie['year']})</div>";
	else
		echo "<div class='display_style'>None</div>";
	echo "<h2>Actor matches</h2>";
	if ($data['actors'])
		foreach($data['actors'] as $actor)
			echo "<div class='display_style'><a href='b1.php?id={$actor['id']}'>{$actor['last']},
			{$actor['first']}</a> ({$actor['dob']})</div>";
	else
		echo "<div class='display_style'>None</div>";
}

function &retrieve_data(&$params,&$dbh)
{
	// Sanitize all incoming data
	foreach ($params as $param)
		$param = mysql_real_escape_string($param,$dbh);
	
	// Check that required data is included
	if (!$params['keyword'])
		return NULL;
	
	// TODO: Check that required data makes sense
	
	$data = array();
	
	$query = "SELECT id,first,last,dob FROM Actor WHERE CONCAT(first,' ',last) REGEXP '". $params['keyword'] ."'";
	$rc = query_wrapper($query,__LINE__,$dbh);
	while ($row = mysql_fetch_row($rc)) {
		$data['actors'][] = array('id' => $row[0], 'first' => $row[1], 'last' =>
			$row[2], 'dob' => $row[3]);
	}
	
	
	$query = "SELECT id,title,year FROM Movie WHERE title REGEXP '". $params['keyword'] ."'";
	$rc = query_wrapper($query,__LINE__,$dbh);
	while ($row = mysql_fetch_row($rc)) {
		$data['movies'][] = array('id' => $row[0], 'title' => htmlspecialchars($row[1]), 'year' =>
			$row[2]);
	}

	return $data;
}

?>

<?php print_headers("Search") ?>

<?php
	// Do we have a request for submission?
	if ($_GET['subreq']) {
		if ($data = retrieve_data($_GET,$dbh))
			print_data($data);
		else
			echo "<h1>Submission error, try again!</h1>";
	}
	else
		echo "<h1>Type in a search keyword to get started!</h1>";
?>
		<form method="get" action="./s1.php">		
			<div class="form_style">Search: <input type="text" name="keyword" /></div>

			<div class="form_style"><input type="submit" name="subreq" value="Submit" /></div>
		</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
