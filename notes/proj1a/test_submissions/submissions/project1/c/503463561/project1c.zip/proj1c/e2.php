<!--===============================================================================
CS143 PAGE E2
Relationship between movie and director
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('wrapper.php');
require('selector.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function check_data(&$data,&$dbh)
{
	global $errors;
	if (!$data['mid'])
		$errors['mid'] = "You need to select a movie.";
	if (!$data['did'])
		$errors['did'] = "You need to select a director.";
	// Check that required data is included
	if (!$data['mid'] || !$data['did'])
		return false;

	// Now check that required data makes sense
	
	// Does the mid and did exist?
	$query = "SELECT * FROM Movie WHERE id={$data['mid']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	if (!mysql_fetch_row($rc))
		return false;
	$query = "SELECT * FROM Director WHERE id={$data['did']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	if (!mysql_fetch_row($rc))
		return false;

	return true;

}

function submit_data(&$data,&$dbh)
{
	// Sanitize all incoming data
	foreach ($data as $datum) {
		$datum = mysql_real_escape_string($datum,$dbh);
		$datum = htmlspecialchars($datum);
		}

	if(!check_data($data,$dbh))
		return false;

	// Construct an INSERT INTO statement to insert data into our review table
	$query = "INSERT INTO MovieDirector(mid,did)
					VALUES('{$data['mid']}',
							 {$data['did']})";
	query_wrapper($query,__LINE__,$dbh);

	return true;

}

?>

<?php print_headers("Add director/movie relation") ?>

<?php
	// Do we have a request for submission?
	if ($_POST['subreq']) {
		if (submit_data($_POST,$dbh))
			echo "Success! This has been added to the list of <a
			href='b1.php?id={$_POST['did']}'>directed movies</a>.";
		else
			echo "<h1>Submission error, try again!</h1>";
	}
?>
<h1>Choose an actor and movie in the form below...</h1>

<form method="post" action="./e2.php">
Movie:
<?php print_selector(0,'mid','movies',$dbh) ?>
<?php error_check('mid') ?>
Director:
<?php print_selector(1,'did','directors',$dbh) ?>
<?php error_check('did') ?>

<div class="form_style"><input type="submit" name="subreq" value="Submit" /></div>
</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
