<!--===============================================================================
CS143 WRAPPER.PHP
Functions to print out standard modules for our site.
================================================================================-->

<?php

// Declare a global array of user input errors
$errors = array();

function error_check($errtype)
{
	global $errors;
	if ($errors[$errtype])
		echo "<span class='error'>{$errors[$errtype]}</span><br/>";
}

function print_navbar() {

?>
<div id="navbar">
	<h2>Edit</h2>
	<ul class="menu">
	<li><a href="i1.php">Insert new actor / director</a></li>
	<li><a href="i2.php">Write a review</a></li>
	<li><a href="i3.php">Add movie information</a></li>
	<li><a href="e1.php">Add actor/movie relation</a></li>
	<li><a href="e2.php">Add director/movie relation</a></li>
	</ul>
	<h2>Browse</h2>
	<ul class="menu">
	<li><a href="b1.php">View actor/director info</a></li>
	<li><a href="b2.php">View movie information</a></li>
	</ul>
	<h2>Search</h2>
	<ul class="menu">
	<li><a href="s1.php">Search tool</a></li>
	</ul>
</div>
<?php

}

function print_scripts() {
?>
	<script type="text/javascript" src="mootools.js"></script>
	<script type="text/javascript">

	function GetXmlHttpObject()
		{
		var xmlHttp=null;
		try
		 {
		 // Firefox, Opera 8.0+, Safari
		 xmlHttp=new XMLHttpRequest();
		 }
		catch (e)
		 {
		 //Internet Explorer
		 try
		  {
		  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
		  }
		 catch (e)
		  {
		  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		 }
		return xmlHttp;
		}
	</script>
<?php
}

function print_headers($title) {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css" />
<?php print_scripts() ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $title ?></title>
</head>
<body>
<div id="main-outer">
<div id="sidebar">
<div id="main-title" onclick="location.href='index.php'"><h2>B&amp;BMdB</h2></div>
<?php print_navbar() ?>
<div id="sidebar-bottom"></div>
</div> <!-- sidebar -->
<div id="main-middle">
<div id="subpage-title"><?php echo $title ?></div>
<div id="main-inner">
<?php
}

function print_footers() {
?>
</div>
</div> <!-- main-middle -->
<div style="clear:both"></div>
<div id="footer">
(C) 2008 Brian Nguyen and Brian Jew<br/>
Uses the <a href="http://mootools.net/">Mootools Framework</a> (MIT License)
</div>
</div> <!-- main-outer -->
</body>
</html>
<?php
}

?>
