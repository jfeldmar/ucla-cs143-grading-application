<!--===============================================================================
SELECTOR.PHP
Construct a general AJAX selector.
================================================================================-->

<?php
// Print a browser for selecting something from the database
function print_selector($id,$name,$param,&$dbh)
{
?>
<script type="text/javascript">
	function getItem<?php echo $id?>Index(str)
	{
		xmlHttp = GetXmlHttpObject();
		if (xmlHttp == null) {
			alert("Browser does not support HTTP request");
			return;
		}
		var url="ajax.php";
		url += "?<?php echo $param?>="+str+"&name=<?php echo $name?>";
		xmlHttp.onreadystatechange = getItem<?php echo $id?>StateChanged;
		xmlHttp.open("GET",url,true);
		xmlHttp.send(null);
	}
	function getItem<?php echo $id?>StateChanged(letter)
	{
		if (xmlHttp.readyState == 4 || xmlHttp.readyState == 'complete')
			$('selecttarget<?php echo $id?>').innerHTML=xmlHttp.responseText;
	}
</script>

<?php
	echo "<div class='selector'>";
	foreach(range('a','z') as $letter)
		echo "<span onclick=\"getItem".$id."Index('$letter')\">".strtoupper($letter)."</span>"; 
	echo "<span onclick=\"getItem".$id."Index(-1)\">?</span>";
	echo "</div>";
	echo "<div id='selecttarget$id'></div>";
}

?>
