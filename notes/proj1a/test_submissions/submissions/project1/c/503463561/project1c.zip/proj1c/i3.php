<!--===============================================================================
CS143 PAGE I3
Add movie information.
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('wrapper.php');
require('selector.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function check_data(&$data,&$dbh)
{
	global $errors;

	if (!$data['title'])
		$errors['title'] = "You need to provide a title.";
	
	if (!$data['company'])
		$errors['company'] = "You need to provide a company name.";
	
	if (!$data['year'])
		$errors['year'] = "You need to provide the year the movie was released.";
	
	if (!$data['did'])
		$errors['did'] = "You need to choose a director.";
	
	if (!$data['rating'])
		$errors['rating'] = "You need to provide the MPAA rating of the film.";

	// Check that required data is included
	if (!$data['title'] || !$data['company'] || !$data['year'] ||
		 !$data['did'] || !$data['rating'])
		 return false;

	// Now check that required data makes sense
	
	// Is the year numeric?
	if (!is_numeric($data['year'])) {
		$errors['year'] = "Year should be numeric.";
		return false;
		}
	
	// Is the did in our database?
	$query = "SELECT * FROM Director WHERE id={$data['did']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	$row = mysql_fetch_row($rc);
	if (!$row[0]) {
		$errors['did'] = "Director not found in database.";
		return false;
	}

	return true;
}

function submit_data(&$data,&$dbh)
{
	// Sanitize all incoming data
	foreach ($data as $datum) {
		$datum = mysql_real_escape_string($datum,$dbh);
		$datum = htmlspecialchars($datum);
		}


	if (!check_data($data,$dbh))
		return false;

	// Get the current MaxMovieID then increment it
	$query = "SELECT * FROM MaxMovieID";
	$rc = query_wrapper($query,__LINE__,$dbh);
	$query = "UPDATE MaxMovieID SET id = id+1";
	query_wrapper($query,__LINE__,$dbh);

	if ($row = mysql_fetch_row($rc))
		$data['id'] = $row[0];
	else
		die("Fatal error, MaxMovieID not found!");

 	// Construct a INSERT INTO statement to insert data into our movie table
	$query = "INSERT INTO Movie(id,title,year,rating,company) 
						VALUES ({$data['id']},
						        '{$data['title']}',
								  {$data['year']},
								  '{$data['rating']}',
								  '{$data['company']}')";
	$rc = query_wrapper($query,__LINE__,$dbh);

	// Construct an INSERT INTO statemment to insert director into our movie
	// table
	$query = "INSERT INTO MovieDirector(did,mid)
						VALUES ({$data['did']},{$data['id']})";

	$rc = query_wrapper($query,__LINE__,$dbh);

	// For each genre listed, construct an INSERT INTO statement to insert the
	// genre into our movie table
	
	// First, find the array keys of interest (with prefix genre_)
	$genres = preg_grep("/genre_/",array_keys($data));

	// Then start our query to add genres
	$query = "INSERT INTO MovieGenre (genre,mid) VALUES ";

	// Now for each genre we find, add the tuple to our query
	if ($genres) {
		foreach ($genres as $genre)
			$query .= "('{$data[$genre]}',{$data['id']}),";

		// Trim off the last comma at the end
		$query = substr($query, 0, -1);

		// Finally, execute our query
		$rc = query_wrapper($query,__LINE__,$dbh);
	}

	return true;
}

?>

<?php print_headers("Add movie information") ?>

<?php
	// Do we have a request for submission?
	if ($_POST['subreq']) {
		if (submit_data($_POST,$dbh))
			echo "Success! Check out your new movie <a
			href='b2.php?id={$_POST['id']}'>here</a>.";
		else
			echo "<h1>Submission error, try again!</h1>";
	}
?>

<h1>Fill out the form below:</h1>

<form action="./i3.php" method="post">
<div class="form_style">Movie title: <input type="text" name="title"
value="<?php echo $_POST['title']?>" />
	<?php error_check('title')?></div>
<div class="form_style">Company: <input type="text" name="company" value="<?php
	echo $_POST['company'] ?>"/>
	<?php error_check('company')?></div>
<div class="form_style">Year: <input type="text" name="year" value="<?php echo
$_POST['year'] ?>"/><?php
error_check('year')?></div>

<div>Director: </div>
<?php print_selector(0,'did','directors',$dbh) ?>
<?php error_check('did')?>

<div class="form_style"> MPAA Rating:
	<select name="rating">
		<!-- We don't fetch options from the database since some might be
		invalid or not available; instead, we manually specify which options are
		available. -->
		<option value="G">G</option>
		<option value="PG">PG</option>
		<option value="PG-13">PG-13</option>
		<option value="R">R</option>
		<option value="NC-17">NC-17</option>
		<option value="X">X</option>
		<option value="GP">GP</option>
		<option value="NR">NR</option>
	</select> <?php error_check('rating') ?> </div>
<div class="form_style"> Genre:
	<!-- Here we do fetch genres from the database, since there may be potentially
	many genres to choose from, and the definition is much more open. -->
	<?php
	$query = 'SELECT DISTINCT genre FROM MovieGenre';
	$rc = query_wrapper($query,__LINE__,$dbh);
	while ($row = mysql_fetch_row($rc)) {
		$genre = $row[0];
		echo "<br/><input type='checkbox' value='$genre' name='genre_$genre' />$genre";
	}
	?>
</div>
<div class="form_style"><input type="submit" name="subreq" value="Submit" /></div>
</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
