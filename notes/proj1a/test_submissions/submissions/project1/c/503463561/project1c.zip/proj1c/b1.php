<!--===============================================================================
CS143 PAGE B1
Show information about an actor or director.
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('wrapper.php');
require('selector.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function print_data(&$data)
{
		// Print the resulting data
		echo "<h1 id='name'>".$data['first'].' '.$data['last']."</h1>";
		echo "<h2>Main Information</h2>".
				"<div class=\"display_style\">Sex: ".($data['sex'] ? $data['sex'] : " N/A ")."</div>".
				"<div class=\"display_style\">Date of birth: ".$data['dob']."</div>";
		echo  $data['dod'] ? "<div class=\"display_style\">Date of death: ".$data['dod']."</div>" : "";

		echo "<div class=\"display_style\">Occupation: ";
		if ($data['is_actor'] && !$data['is_director'])
			echo "Actor";
		else if (!$data['is_actor'] && $data['is_director'])
			echo "Director";
		else
			echo "Actor/Director";
		echo "</div>";

		// Print actor-specific stuff
		if (count($data['movies_acted'])) {
			echo "<h2>Acting roles</h2>";
			echo '<ul>';
			foreach ($data['movies_acted'] as $movie_acted)
				echo "<li><a href='b2.php?id={$movie_acted['id']}'>\"{$movie_acted['title']}</a>\"
						({$movie_acted['year']}) ... {$movie_acted['role']}</li>";
			echo '</ul>';
		}

		// Print director-specific stuff
		if (count($data['movies_directed'])) {
			echo "<h2>Directing roles</h2>";
			echo '<ul>';
			foreach ($data['movies_directed'] as $movie_directed)
				echo "<li><a href='b2.php?id={$movie_directed['id']}'>
					\"{$movie_directed['title']}\"</a> {$movie_directed['year']}";
			echo '</ul>';
		}
}

function &build_data($id,&$data,&$dbh)
{
		$id = mysql_real_escape_string($id,$dbh); // Sanitize the mid

		// Check to make sure the id is correct
		if (!is_numeric($id)) {
			echo "Error: Invalid actor/director id!";
			return NULL;
			}

		// Initialize the variables we'll be using for later
		$data = array();

		// Get basic information about the person's acting
		$query = 'SELECT * FROM Actor WHERE id = '.$id;
		$rc = query_wrapper($query,__LINE__,$dbh);
		if ($row = mysql_fetch_row($rc)) {
		   $data['last'] = $row[1];
		   $data['first'] = $row[2];
			$data['sex'] = $row[3];
			$data['dob'] = $row[4];
			$data['dod'] = $row[5];
			$data['is_actor'] = true;
		}

		// Get basic information about the person's directing
		$query = 'SELECT * FROM Director WHERE id = '.$id;
		$rc = query_wrapper($query,__LINE__,$dbh);
		if ($row = mysql_fetch_row($rc)) {
		  $data['last'] = $row[1];
		  $data['first'] = $row[2];
        $data['dob'] = $row[3];
		  $data['dod'] = $row[4];
		  $data['is_director'] = true;
		}

		// Return if the id is not found in database
		if (!$data['is_actor'] && !$data['is_director']) {
			echo "Error: Invalid actor/director id!";
			$data = NULL;
			return NULL;
			}

		// What movies has this person acted in?
		if ($data['is_actor']) {
			$data['movies_acted'] = array();
			$query = 'SELECT mid, title, role, year FROM MovieActor, Movie WHERE aid = '.$id.'
			AND MovieActor.mid = Movie.id ORDER BY year DESC';
			$rc = query_wrapper($query,__LINE__,$dbh);
			while ($row = mysql_fetch_row($rc)) {
				$data['movies_acted'][] = array( 'id' => $row[0], 'title' => htmlspecialchars($row[1]),
				'role' => $row[2], 'year' => $row[3] );
			}
		}

		// What movies has this person directed?
		if ($data['is_director']) {
			$data['movies_directed'] = array();
			$query = 'SELECT mid, title, year FROM MovieDirector, Movie WHERE did =
			'.$id.' AND MovieDirector.mid = Movie.id ORDER BY year DESC';
			$rc = query_wrapper($query,__LINE__,$dbh);
			while ($row = mysql_fetch_row($rc)) {
				$data['movies_directed'][] = array( 'id' => $row[0], 'title' => htmlspecialchars($row[1]),
				'year' => $row[2] );
			}
		}
	
		return $data;
}
?>



<?php print_headers("View actor/director info") ?>


<?php


	$data = NULL;
	
	// If we get an id, build data for the person
	if ($id = $_GET['id'])
		$data = build_data($id,$data,$dbh);

	// If we got data, print it!
	if ($data)
		print_data($data);
	else
		echo "<h1>Select an actor/director below!</h1>";


?>

<form method='get' action='./b1.php'>
<?php print_selector(0,'id','people',$dbh); ?>
<input type="submit" value="Submit" />
</form>



<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
