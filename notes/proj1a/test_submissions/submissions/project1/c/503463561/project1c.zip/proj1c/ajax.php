<!--===============================================================================
AJAX.PHP
Implement AJAX controls.
================================================================================-->
<?php
if (!count($_GET) || !$_GET['name'])
	die ('Error: attempt to directly access ajax.php!');
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

foreach( $_GET as $datum)
	$datum = mysql_real_escape_string($datum);

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

$name = $_GET['name'];

// Get a list of people starting with the letter passed to us.
if ($_GET['people']) {
	$letter = $_GET['people'];

	if ($letter == -1)
		$query = "SELECT DISTINCT * FROM (SELECT id,last,first,dob FROM Actor UNION
											 SELECT id,last,first,dob FROM Director)
											 ActorDirector WHERE NOT (LEFT(last,1)) REGEXP '[A-Za-z]' ORDER BY last";
	else
		$query = "SELECT DISTINCT * FROM (SELECT id,last,first,dob FROM Actor UNION
											 SELECT id,last,first,dob FROM Director)
											 ActorDirector WHERE LEFT(last,1) = '$letter' ORDER BY last"; 
	$rc = query_wrapper($query,__LINE__,$dbh);
	echo "<div class='form_style'><select name='$name'>";
	while ($row = mysql_fetch_row($rc)) {
		$id = $row[0];
		$last = $row[1];
		$first = $row[2];
		$dob = $row[3];
		echo "<option value='$id'>$last, $first ($dob)</option>\n";
	}
	echo '</select></div>';
}

if ($_GET['movies']) {
	$letter = $_GET['movies'];
	if ($letter == -1)
		$query = "SELECT id,title,year FROM Movie	WHERE NOT
		LEFT(title,1) REGEXP '[A-Za-z]'";
	else
		$query = "SELECT id,title,year FROM Movie WHERE LEFT(title,1) =
		'$letter' ORDER BY title";
	$rc = query_wrapper($query,__LINE__,$dbh);
	echo "<div class='form_style'><select name='$name'>";
	while ($row = mysql_fetch_row($rc)) {
		$id = $row[0];
		$title= $row[1];
		$year = $row[2];
		echo "<option value='$id'>$title ($year)</option>\n";
	}
	echo '</select></div>';
}

if ($_GET['actors']) {
	$letter = $_GET['actors'];
	if ($letter == -1)
		$query = 'SELECT id,first,last,dob FROM Actor WHERE NOT LEFT (last,1) REGEXP
	"[A-Za-z]" ORDER BY last';
	else
		$query =  "SELECT id,first,last,dob FROM Actor WHERE LEFT(last,1) =
		'$letter'";
	$rc = query_wrapper($query,__LINE__,$dbh);

	// Generate a drop-down menu using our actor list
	echo "<div class='form_style'><select name='$name'>";
	while ($row = mysql_fetch_row($rc)) {
		$mid = $row[0];
		$name = htmlspecialchars($row[2]) . ', ' . htmlspecialchars($row[1]);
		echo "<option value=\"$mid\">$name (".$row[3].")</option>";
	};
	echo '</select></div>';

}

if ($_GET['directors']) {
	$letter = $_GET['directors'];
	if ($letter == -1)
		$query = "SELECT id,last,first,dob FROM Director WHERE NOT
			LEFT(last,1) REGEXP '[A-Za-z]'";
	else
		$query = "SELECT id,last,first,dob FROM Director WHERE
			LEFT(last,1) = '$letter'";
	$rc = query_wrapper($query,__LINE__,$dbh);
	// Generate a drop down menu of directors in our database
	echo '<div class="form_style"><select name="did">';
		while ($row = mysql_fetch_row($rc)) {
			$did = $row[0];
			$last = $row[1];
			$first = $row[2];
			$dob = $row[3];
			if ($did == $did_match)
				echo "<option value=\"$did\" selected=\"selected\">$last, $first ($dob)</option>";
			else
				echo "<option value=\"$did\">$last, $first ($dob)</option>";
			}
	echo '</select></div>';
}

mysql_close($dbh);

?>

