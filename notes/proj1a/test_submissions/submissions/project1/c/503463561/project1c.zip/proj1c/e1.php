<!--===============================================================================
CS143 PAGE E1
Relationship between movie and actor
================================================================================-->
<?php
$dbh = mysql_connect ('localhost','cs143','') 
or die ('Error: Cannot connect to MySQL!<br/>'.mysql_error()); // Grab a database handler
mysql_select_db("CS143",$dbh)
or die ('Error: CS143 database does not exist!<br/>'.mysql_error()); // If successful, switch to the CS143 database

require('selector.php');
require('wrapper.php');

function &query_wrapper($query,$line,&$dbh)
{
	$rc = mysql_query($query,$dbh) or die("ERROR: Query failed at line $line!<br/>".mysql_error()); // Execute the query
	return $rc; // Return the resulting rc
}

function check_data(&$data,&$dbh)
{
	global $errors;
	if (!$data['mid'])
		$errors['mid'] = "You need to select a movie.";
	if (!$data['aid'])
		$errors['aid'] = "You need to select an actor.";
	if (!$data['role'])
		$errors['role'] = "You need to provide the role the actor played."; 

	// Check that required data is included
	if (!$data['mid'] || !$data['aid'] || !$data['role'])
		return false;

	// Now check that required data makes sense
	
	// Does the mid and aid exist?
	$query = "SELECT * FROM Movie WHERE id={$data['mid']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	if (!mysql_fetch_row($rc))
		return false;
	$query = "SELECT * FROM Actor WHERE id={$data['aid']}";
	$rc = query_wrapper($query,__LINE__,$dbh);
	if (!mysql_fetch_row($rc))
		return false;

	return true;

}

function submit_data(&$data,&$dbh)
{
	// Sanitize all incoming data
	foreach ($data as $datum) {
		$datum = mysql_real_escape_string($datum,$dbh);
		$datum = htmlspecialchars($datum);
		}

	if(!check_data($data,$dbh))
		return false;

	// Construct an INSERT INTO statement to insert data into our review table
	$query = "INSERT INTO MovieActor(mid,aid,role)
					VALUES('{$data['mid']}',
							 {$data['aid']},
							 '{$data['role']}')";
	query_wrapper($query,__LINE__,$dbh);

	return true;

}

?>

<?php print_headers("Add actor/movie relation") ?>

<?php
	// Do we have a request for submission?
	if ($_POST['subreq']) {
		if (submit_data($_POST,$dbh))
			echo "Success! This has been added to the list of <a
			href='b1.php?id={$_POST['aid']}'>roles</a>.";
		else
			echo "<h1>Submission error, try again!</h1>";
	}
?>
<h1>Choose an actor and movie in the form below...</h1>

<form method="post" action="./e1.php">
Movie:
<?php print_selector(0,'mid','movies',$dbh) ?>
<?php error_check('mid') ?>
Actor:
<?php print_selector(1,'aid','actors',$dbh) ?>
<?php error_check('aid') ?>

<div class="form_style">Role:	<input type="text" name="role" maxlength="50" value="<?php echo $_POST['role']?>"/>
<?php error_check('role')?></div>
<div class="form_style"><input type="submit" name="subreq" value="Submit" /></div>
</form>

<?php print_footers() ?>

<?php
mysql_close($dbh); // Close the database once we're finished
?>
