<html>
<head>
<title>MOVIETRON 5000 : ROLE EDITOR!</title>
</head>
<body>
<h1>MOVIETRON 5000: role editor</h1>

<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top'  width='150'>

<?php
include('MovieTron.php');

// if variables OK, then connect to server
$username = "cs143";
$password = "";
$hostname = "localhost";
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

include("sidebar.php");
echo "</td><td valign='top' >";

echo "<form action='editrole.php' method='get'>
	<h3>add actor to film</h3>
<table border='0' cellspacing='1' cellpadding='1'>
<tr><td> Movie: ";

echo "<select name='mid'>";
$stmt = "SELECT DISTINCT id, title, year from Movie ORDER BY title";
$result = mysql_query($stmt);
do {
	$mid = $row['id'];
	$title = $row['title'];
	$year = $row['year'];
	if ($mid and $title) {
	echo "<option value='$mid'>$title ($year)</option>";
	}
} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
echo "</select>"; 

echo "</td></tr><tr><td>Actor: ";
	
echo "<select name='aid'>";
$stmt = "SELECT DISTINCT id, last, first from Actor ORDER BY last";
$result = mysql_query($stmt);
do {
	$aid = $row['id'];
	$last = $row['last'];
	$first = $row['first'];
	if ($aid and $last) {
	echo "<option value='$aid'>$last, $first</option>";
	}
} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
echo "</select>";

echo "</td></tr>
<tr><td>
Role <input type='text' width='30' name='role'>
</td></tr>
</table>
<input type='submit' name='submit' value='Submit'>
</form>";

$debug = 1;

$mid = $_REQUEST['mid'];
$aid = $_REQUEST['aid'];
$role = $_REQUEST['role'];
if ($mid != '' and $aid != '' and $role != '') {
	if (!preg_match("/^[[:digit:]]+$/", $mid)) { // date fits form
		ErrorMsg("Movie id ($mid) not in numeric format.");
	} else if (!preg_match("/^[[:digit:]]+$/", $aid)) { // date fits form
		ErrorMsg("Actor id ($aid) not in numeric format.");
	}


	$role = mysql_real_escape_string($role, $dbh);

	// do insertions
	$stmt = "INSERT INTO MovieActor VALUES($mid, $aid, '$role')";
	if (!mysql_query($stmt)) {
		ErrorMsg("Failure inserting new tuple ($stmt)");
	} else {
		echo "<h3>New info updated.</h3>";
	}

	// close dbh
	mysql_close($dbh);
	FinishPage();

} else if ($mid || $aid || $role) { // we got some input but not all
	ErrorMsg("A required field was missing: (mid, aid, role)");
}

?>

