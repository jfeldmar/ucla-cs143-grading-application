<html>
<head>
<title>MOVIETRON 5000 : SEARCH</title>
</head>
<body>
<h1>MOVIETRON 5000: Search-o-matic!</h1>
<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top'  width='150'>
<?php
include("MovieTron.php"); // helper functions

include("sidebar.php");
echo "</td><td valign='top' >";

//include("searchbar.html");


$debug = 1;

$title = $_REQUEST['title'];
$first = $_REQUEST['first'];
$last = $_REQUEST['last'];
$sactor = $_REQUEST['sactor'];
$sactress = $_REQUEST['sactress'];
$sdirect = $_REQUEST['sdirect'];
$smovie = $_REQUEST['smovie'];
if ($first != ""| $sactor != "" | $sactress != "" | $title != ""
		| $last != "" | $sdirect != "" | $smovie != "" ) {

	echo "<h3>RESULTS</h3>";
	// typecheck variables here
	$splode = explode(" ", $string);
	
	// if variables OK, then connect to server
	$username = "cs143";
	$password = "";
	$hostname = "localhost";
	$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
	$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

	// run selected queries

	if (!($actor || $actress || $sdirect || $title)) {
		echo "<p>You did not select one of Actors, Actresses, Directors, or enter a movie title.</p>";

	}

	if ($sactor != "") {
			$stmt = "SELECT DISTINCT id, last, first, sex, dob, dod 
					 FROM Actor
					 WHERE first LIKE '%$first%' AND
						last LIKE '%$last%' AND
						sex = 'Male'"; 

			$result = mysql_query($stmt);
			TablePrint($result, "Actors", "actor");
	}
	
	if ($sactress != "") {
			$stmt = "SELECT DISTINCT id, last, first, sex, dob 
					 FROM Actor
					 WHERE first LIKE '%$first%' AND
						last LIKE '%$last%' AND
						sex = 'Female'"; 


			$result = mysql_query($stmt);
			TablePrint($result, "Actresses", "actor");
	}
	
	if ($sdirect != "") {
			$stmt = "SELECT DISTINCT id, last, first, dob 
					 FROM Director
					 WHERE first LIKE '%$first%' AND
						last LIKE '%$last%'"; 


			$result = mysql_query($stmt);
			TablePrint($result, "Directors", "director");
	}

	if ($title != "") {
			$stmt = "SELECT DISTINCT M.id, title, year, rating, company, genre
					 FROM Movie M, MovieGenre MG
					 WHERE title LIKE '%$title%'
					 AND M.id = MG.mid
					 ORDER BY year"; 


			$result = mysql_query($stmt);
			TablePrint($result, "Movies", "movie");

	}
	// close dbh
	mysql_close($dbh);
}

FinishPage("</tr></td></table>");

?>
