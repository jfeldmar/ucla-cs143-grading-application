<html>
<head>
<title>MOVIETRON 5000 : MOVIE!</title>
</head>
<body>
<h1>MOVIETRON 5000: movie profile</h1>
<table border='0' cellpadding='1' cellspacing='1' align='top'>
<tr><td width='150' valign='top'>
<?php
include('MovieTron.php');

include("sidebar.php");
echo "</td><td valign='top'>";


$debug = 1;

$id = $_REQUEST['id'];
if ($id != "" ) {

	// typecheck variables here
	$splode = explode(" ", $string);
	
	// if variables OK, then connect to server
	$username = "cs143";
	$password = "";
	$hostname = "localhost";
	$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
	$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

	
	$name = $_REQUEST['name'];
	$rating = $_REQUEST['rating'];
	$comment = $_REQUEST['comment'];

	if ($name and $rating and $comment ) {

		$name = mysql_real_escape_string($name);
		$rating = mysql_real_escape_string($rating);
		$comment = mysql_real_escape_string($comment);

		$stmt = "INSERT INTO Review VALUES('$name', NOW(), $id, $rating, '$comment')";
		if (!mysql_query($stmt)) {
			ErrorMsg("Problem inserting comment into database! ($stmt)");
		} else {
			echo "<h3>Comment added.</h3>";
		}

	} else if ($name or $rating or $comment ) {
		ErrorMsg("One or more missing required fields (name, rating, or comment)");
	} 

// run selected queries

	if ($id != "") {

		$stmt = "SELECT M.id, title, year, rating, company, genre FROM Movie M, MovieGenre MG 
			 WHERE M.id = $id AND MG.mid = $id";
			$result = mysql_query($stmt);
			TablePrint($result, "Title", "movie");

			$stmt = "SELECT AVG(rating)
				FROM Review
				WHERE mid=$id";
			$result = mysql_query($stmt);
			TablePrint($result, "Average Rating", NULL);
			
                        $stmt = "SELECT D.id, first, last, dob, dod
			FROM Movie M, MovieDirector MD, Director D
			WHERE M.id = MD.mid AND D.id = MD.did AND M.id = $id";
			$result = mysql_query($stmt);
			TablePrint($result, "Director", "director");


			$stmt = "SELECT DISTINCT id, first, last, role 
					 FROM MovieActor MA, Actor A
					 WHERE mid = $id AND MA.aid = A.id"; 

			$result = mysql_query($stmt);
			TablePrint($result, "Actors", "actor");
	}
$stmt = "SELECT name, time, rating, comment
	FROM Review
	WHERE mid=$id
	ORDER BY time DESC";
$result = mysql_query($stmt);

echo "
<form name='comments' method='get' action='movie.php'>
Rating: 
<input type='hidden' name='id' value='$id'>
<input type='radio' name='rating' value='1'> 1
<input type='radio' name='rating' value='2'> 2
<input type='radio' name='rating' value='3'> 3
<input type='radio' name='rating' value='4'> 4
<input type='radio' name='rating' value='5'> 5 <br />
Name: <input type='text' name='name' width='30'><br />
Comment: <br />
<textarea name='comment' cols='50' rows='10'>
</textarea><br />
<input type='submit' name='cbutton' value='Post Comment'>
</form>
<h3>Previous Comments</h3>
";

CommentPrint($result);
	
	// close dbh
	mysql_close($dbh);
	FinishPage("</td></tr></table>");
}

?>

