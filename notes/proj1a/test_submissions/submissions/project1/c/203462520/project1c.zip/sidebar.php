<?php

include('searchbar-vert.html');
echo "<h3>Edit Movietron</h3>";
echo "<ul>";
echo "<li><b><a href='editperson.php'>add a person</a></b><br />";
echo "<li><b><a href='editmovie.php'>add a movie</a></b><br />";
echo "<li><b><a href='editdirector.php'>add director to film</a></b><br />";
echo "<li><b><a href='editrole.php'>add actor to film</a></b><br />";
echo "</ul>";

?>
