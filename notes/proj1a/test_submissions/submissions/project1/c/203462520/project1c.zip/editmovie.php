<html>
<head>
<title>MOVIETRON 5000 : MOVIE EDITOR!</title>
</head>
<body>
<h1>MOVIETRON 5000: movie editor</h1>

<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top'  width='150'>


<?php
include('MovieTron.php');

include("sidebar.php");
echo "</td><td valign='top' >";

$username = "cs143";
$password = "";
$hostname = "localhost";
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

echo "
<h2>Add a movie:</h2>
<form action='editmovie.php' method='get'>
<table border='0' cellspacing='1' cellpadding='1'>
<tr><td>
Title <input type='text' width='30' name='title'> 
</td><td>
Company <input type='text' width='30' name='company'>
</td></tr>
<tr><td>
Rating <input type='text' width='30' name='rating'>
</td><td>
Year <input type='text' width='30' name='year'>
</td></tr>
<tr><td>Genre: ";

echo "<select name='genre'>";
$stmt = "SELECT DISTINCT genre from MovieGenre";
$result = mysql_query($stmt);
do {
	$gtype = $row['genre'];
	echo "<option value='$gtype'>$gtype</option>";
} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
echo "</select>";
echo "</td><td>

<input type='submit' name='submit' value='Submit'>
</td></tr>
</table>
</form>";

$debug = 1;

$title = $_REQUEST['title'];
$company = $_REQUEST['company'];
$rating = $_REQUEST['rating'];
$year = $_REQUEST['year'];
$genre = $_REQUEST['genre'];
if ($title != '' and $company != '' and $rating != '' 
	and $year != '' and $genre != '') {
	if (!preg_match("/^[[:digit:]]{4}$/", $year)) { // date fits form
		ErrorMsg("year ($year) not in yyyy format.");
	} else if (!preg_match("/^(G|PG|PG-13|R|NC-17|NR)$/", $rating)) { // date fits form
		ErrorMsg("Rating ($rating) must be one of: G, PG, PG-13, R, NC-17, or NR.");
	}


	// if variables OK, then connect to server
	$title = mysql_real_escape_string($title, $dbh);
	$company = mysql_real_escape_string($company, $dbh);
	$genre = mysql_real_escape_string($genre, $dbh);

	// get MaxPersonId
	$stmt = "SELECT id FROM MaxMovieID";
	$result = mysql_query($stmt);
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	foreach ($row as $mpi) {
			$mpi++;
	}

	// update mpi -- maybe should wait after insert, 
	// but that's a race condition (race to update mpi)
	$stmt = "UPDATE MaxMovieID SET id=$mpi";
	if (!mysql_query($stmt)) {
		ErrorMsg("Failure updating MaxMovieID (to $mpi)");
	}

	// do insertions
	$stmt = "INSERT INTO Movie VALUES($mpi, '$title', $year, '$rating', '$company')";
	if (!mysql_query($stmt)) {
		ErrorMsg("Failure inserting new tuple ($stmt)");
	}
	$stmt = "INSERT INTO MovieGenre VALUES($mpi, '$genre')";
	if (!mysql_query($stmt)) {
		ErrorMsg("Failure inserting new tuple ($stmt)");
	} else {
		echo "<h3>New info updated.</h3>";
	}


} else if ($title || $year || $rating || $company) { // we got some input but not all
	ErrorMsg("A required field was missing: (title, year, rating, company, genre)");
}

// close dbh
mysql_close($dbh);
FinishPage("</td></tr></table>");

?>

