<html>
<head>
<title>MOVIETRON 5000 : PEOPLE EDITOR!</title>
</head>
<body>
<h1>MOVIETRON 5000: person editor</h1>


<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top'  width='150'>


<?php
include('MovieTron.php');

include("sidebar.php");
echo "</td><td valign='top' >";

echo "<form action='editperson.php' method='get'>
	<h3>Add an actor or director:</h3>
<table border='0' cellspacing='1' cellpadding='1'>
<tr><td>
First <input type='text' width='30' name='first'> 
</td><td>
Last <input type='text' width='30' name='last'>
</td><td>
Actor's Sex<br />
<input type='radio' name='sex' value='Male'> Male
<input type='radio' name='sex' value='Female'> Female
</td></tr>
<tr><td>
DOB (yyyy-mm-dd)
</td><td>
DOD (yyyy-mm-dd)
</td><td>
<input type='radio' name='sex' value='Director'>Director (not actor)
</td></tr>
<tr><td>
<input type='text' width='10' name='dob'>
</td><td>
<input type='text' width='10' name='dod'>
</td><td>
<input type='submit' name='submit' value='Submit'>
</td></tr>
</table>
</form>";

$debug = 1;

$first = $_REQUEST['first'];
$last = $_REQUEST['last'];
$sex = $_REQUEST['sex'];
$dob = $_REQUEST['dob'];
$dod = $_REQUEST['dod'];
$barray = explode("-", $dob);
$darray = explode("-", $dod);
$cdob = preg_replace("/-/", "", $dob);
$cdod = preg_replace("/-/", "", $dod);

if ($first != '' and $last != '' and $dob != '' and $sex != '') {
	if (!preg_match("/^[ A-Za-z0-9' -]+$/", $first)) { // first is alnum
		ErrorMsg("Firstname ($first) must be made only of A-Z,a-z,0-9,-, and '.");
	} else if (!preg_match("/^[ A-Za-z0-9'-]+$/", $last)) { // last is alnum
		ErrorMsg("Lastname ($last) must be made only of A-Z,a-z,0-9,-, and '.");
	} else if (!preg_match("/^[[:digit:]]{4}-[[:digit:]]{2}-[[:digit:]]{2}$/", $dob)) { // date fits form
		ErrorMsg("dob ($dob) not in yyyy-mm-dd format.");
	} else if ((!preg_match("/^[[:digit:]]{4}-[[:digit:]]{2}-[[:digit:]]{2}$/", $dod)) and $dod != '') { // date fits form
		ErrorMsg("dod ($dod) not null or in yyyy-mm-dd format.");
	} else if (!($barray[0] > 1850) or !($barray[0] < 2009)) { // components fit form
		ErrorMsg("dob year ($barray[0]) out of range 1850-2008");
	} else if (!($barray[2] >= 1) or !($barray[2] <= 31)) {
		ErrorMsg("dob day ($barray[2]) out of range 1-31");
	} else if (!($barray[1] >= 1) or !($barray[1] <= 12)) {
		ErrorMsg("dob month ($barray[1]) out of range 1-12");
	} else if ($dod != '') {
		if (!($darray[1] >= 1) or !($darray[1] <= 12)) {
			ErrorMsg("dod month ($darray[1]) out of range 1-12");
		} else if (!($darray[0] > 1850) or !($darray[0] < 2009)) { // components fit form
			ErrorMsg("dod year ($darray[0]) out of range 1850-2008");
		} else if (!($darray[2] >= 1) or !($darray[2] <= 31)) {
			ErrorMsg("dod day ($darray[2]) out of range 1-31");
		} else if ($cdod < $cdob) {
			ErrorMsg("dod ($dod) is EARLIER than dob ($dob)!");
		}
	}

	// if variables OK, then connect to server
	$username = "cs143";
	$password = "";
	$hostname = "localhost";
	$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
	$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

	// get MaxPersonId
	$stmt = "SELECT id FROM MaxPersonID";
	$result = mysql_query($stmt);
	$row = mysql_fetch_array($result, MYSQL_ASSOC);
	$mpi = 0;
	foreach ($row as $mpi) {
			$mpi++;
	}

	// update mpi -- maybe should wait after insert, 
	// but that's a race condition (race to update mpi)
	$stmt = "UPDATE MaxPersonID SET id=$mpi";
	//echo "<p>$stmt</p>";
	if (!mysql_query($stmt)) {
		ErrorMsg("Failure updating MaxPersonId (to $mpi)");
	}

	// do insertions
	if ($sex == "Director") { // directors have no sex!
		$stmt = "INSERT INTO Director VALUES($mpi, '$last', '$first', '$dob', '$dod')";
	} else {
		$stmt = "INSERT INTO Actor VALUES($mpi, '$last', '$first', '$sex', '$dob', '$dod')";
	}

	if (!mysql_query($stmt)) {
		ErrorMsg("The insertion did not work for some reason: ($stmt)");
	} else {
		echo "<h3>Person added successfully.</h3>";
	}

	// close dbh
	mysql_close($dbh);
	FinishPage();	

} else if ($first || $last || $sex || $dob || $dod) { // we got some input but not all
	ErrorMsg("A required field was missing: (first, last, dob, and male/female or director)");
}

?>

