<html>
<head>
<title>MOVIETRON 5000 : DIRECTOR EDITOR!</title>
</head>
<body>
<h1>MOVIETRON 5000: director editor</h1>


<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top'  width='150'>


<?php
include('MovieTron.php');

include("sidebar.php");
echo "</td><td valign='top' >";

// if variables OK, then connect to server
$username = "cs143";
$password = "";
$hostname = "localhost";
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");


$debug = 1;

echo "<form action='editdirector.php' method='get'>
	<h3>add director to film</h3>
<table border='0' cellspacing='1' cellpadding='1'>
<tr><td>
Movie: ";

echo "<select name='mid'>";
$stmt = "SELECT DISTINCT id, title, year from Movie ORDER BY title";
$result = mysql_query($stmt);
do {
	$mid = $row['id'];
	$title = $row['title'];
	$year = $row['year'];
	if ($mid and $title) {
		echo "<option value='$mid'>$title ($year)</option>";
	}
} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
echo "</select>";

echo "</td></tr><tr><td>";

echo "Director: <select name='did'>";
$stmt = "SELECT DISTINCT id, last, first from Director ORDER BY last";
$result = mysql_query($stmt);
do {
	$did = $row['id'];
	$last = $row['last'];
	$first = $row['first'];
	if ($did and $last) {
		echo "<option value='$did'>$last, $first</option>";
	}
} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
echo "</select>";
	
echo "</td></tr>
</table>
<input type='submit' name='submit' value='Submit'>
</form>";

$mid = $_REQUEST['mid'];
$did = $_REQUEST['did'];
if ($mid and $did) {
	if (!preg_match("/^[[:digit:]]+$/", $mid)) { // date fits form
		ErrorMsg("Movie id ($mid) not in numeric format.");
	} else if (!preg_match("/^[[:digit:]]+$/", $did)) { // date fits form
		ErrorMsg("Actor id ($did) not in numeric format.");
	}


	// do insertions
	$stmt = "INSERT INTO MovieDirector VALUES($mid, $did)";
	if (!mysql_query($stmt)) { // try updating
		$stmt = "UPDATE MovieDirector SET did = $did WHERE mid = $mid";
		if (!mysql_query($stmt)) {
			ErrorMsg("Failure updating tuple ($stmt)");
		}
	}

	// close dbh
	mysql_close($dbh);
	FinishPage();

} else if ($mid || $mid) { // we got some input but not all
	ErrorMsg("A required field was missing: (mid, did)");
}

?>

