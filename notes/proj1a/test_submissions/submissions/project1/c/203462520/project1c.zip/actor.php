<html>
<head>
<title>MOVIETRON 5000 : ACTOR!</title>
</head>
<body>
<h1>MOVIETRON 5000: actor profile</h1>
<table border='0' cellpadding='1' cellspacing='1'>
<tr><td valign='top' width='150'>

<?php
include('MovieTron.php');

include("sidebar.php");
echo "</td><td valign='top'>";

$debug = 1;

$id = $_REQUEST['id'];
if ($id != "" ) {

	// typecheck variables here
	$splode = explode(" ", $string);
	
	// if variables OK, then connect to server
	$username = "cs143";
	$password = "";
	$hostname = "localhost";
	$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to database");
	$selected = mysql_select_db("CS143", $dbh) or die ("Couldn't connect to db CS143");

	// run selected queries

	if ($id != "") {

			$stmt = "SELECT id, first, last, sex, dob, dod FROM Actor WHERE id = $id";

			$result = mysql_query($stmt);
			TablePrint($result, "Actor/Actress", "actor");

			$stmt = "SELECT DISTINCT id, title, role 
					 FROM MovieActor MA, Movie A
					 WHERE aid = $id AND MA.mid = A.id"; 

			$result = mysql_query($stmt);
			TablePrint($result, "Appeared in:", "movie");
	}
	
	// close dbh
	mysql_close($dbh);
}



FinishPage("</td></tr></table>");

?>
