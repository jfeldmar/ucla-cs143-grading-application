<?php

function FinishPage($txt="</tr></td></table>")
{
	echo $txt;
	echo "</body>";
	echo "</html>";
}

function ErrorMsg($hint="No suggestion.", $txt=NULL)
{
   echo "<h2>Whoops:</h2>";
   echo "<p>The script encountered a slight problem:</p>";
   echo "<p>Suggestion: <i>$hint</i></p>";
   echo "<p>We sincerely apologize for the mistake; please check your input and try again.</p>";
   FinishPage($txt);
   exit(0);
}


function TablePrint($result, $heading, $detail)
{
	$row = mysql_fetch_array($result, MYSQL_ASSOC); # get first result and attr names

	echo "<h3>$heading</h3";

	if ($row) {
		echo "<p>";
		echo "<table border='0' cellspacing='1' cellpadding='2'>\n";
		echo "<tr>";
		$attrnames = array_keys($row);
		foreach ($attrnames AS $attrname) { # print out attr names in bold
			echo "<td align='center'><b>$attrname</b></td>";
		}
		echo "</tr>";

		do { # print first row, and get any remaining rows
			echo "<tr>";
			$attrcol = 0; // reset attr column count
			foreach ($row as $attr) {
				$attrcol++;
				echo "<td align='center'>";
				if ($attr != "") {
					if ($attrcol == 1 and $detail != '') { // id
							echo "<a href='$detail.php?id=$attr'>(detail)</a>";
					} else {
							echo "$attr";
					}
				} else {
					echo "N/A";
				}
				echo "</td>";
				
			}
			echo "</tr>\n";
		} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
		echo "</p>";
		echo "</table>";
	} else {
		echo "<p>No results.</p>";
	}
}

function CommentPrint($result)

{
	$row = mysql_fetch_array($result, MYSQL_ASSOC); # get first result and attr names

	if ($row) {
		echo "<p>";
		echo "<table border='1' cellspacing='1' cellpadding='2'>\n";

		do { # print first comment, and get any remaining rows
			echo "<tr><td><b>" . $row['name'] . "</b> -- <i>" .
				$row['time'] . "</i> <b>Rating:</b> " .
				$row['rating'] . "</td></tr>";
			echo "<tr><td><p><tt><i>" . $row['comment'] . "</i></tt></p></td></tr>";
		} while ($row = mysql_fetch_array($result, MYSQL_ASSOC));
		echo "</p>";
		echo "</table>";
	} else {
		echo "<p>No comments.</p>";
	}
}


?>	


