<!--  
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - addnewmovie.php
-->
<html>
	<head>
		<title>IMDB-0: R! Links</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
		<br><font color=cyan size=5>Adding a movie IMDB-0: R!</font><br><br><br>
		<?php
			//Build the form within PHP
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection) {
					$errmsg = mysql_error($db_connection);
					echo "Connection failed: $errmsg <br>";
					exit(1);
				}
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				if (!($directorlist = mysql_query("SELECT last, first, id FROM Director ORDER BY last", $db_connection))) {
						$errmsg = mysql_error();
						echo ("ERROR: $errmsg");
						mysql_close($db_connection);
						exit(1);
					}
				
			echo "<form method=\"GET\" action=\"./addnewmovie.php\">
					Title :
					<input type=\"text\" maxlength=\"20\" name=\"title\"/>
					<br/><br/>
					Company:
					<input type=\"text\" maxlength=\"50\" name=\"company\"/>
					<br/><br/>
					<font color=white>Year :</font>
					<input type=\"text\" maxlength=\"4\" name=\"year\"/>
					<br/><br/>
					<font color=white>Director :</font>
					<select name=\"did\">";
					$first=1;
					$last=0;
					$did=2;
					while (($directors = mysql_fetch_row($directorlist))) {
						echo "<option value=$directors[$did]";
						echo ">$directors[$last], $directors[$first]</option>";
					}					
					echo "</select>
					<br/><br/>
					<font color=white>MPAA Rating :</font>
						<select name=\"mpaarating\">
						<option value=\"G\">G</option>
						<option value=\"NC-17\">NC-17</option>
						<option value=\"PG\">PG</option>
						<option value=\"PG-13\">PG-13</option>
						<option value=\"R\">R</option>
					</select>
					<br/><br/>
					<font color=white>Genre :</font>
					<select name=\"genre\">
						<option value=\"Action\">Action</option>
						<option value=\"Adult\">Adult</option>
						<option value=\"Adventure\">Adventure</option>
						<option value=\"Animation\">Animation</option>
						<option value=\"Comedy\">Comedy</option>
						<option value=\"Crime\">Crime</option>
						<option value=\"Documentary\">Documentary</option>
						<option value=\"Drama\">Drama</option>
						<option value=\"Family\">Family</option>
						<option value=\"Fantasy\">Fantasy</option>
						<option value=\"Horror\">Horror</option>
						<option value=\"Musical\">Musical</option>
						<option value=\"Mystery\">Mystery</option>
						<option value=\"Romance\">Romance</option>
						<option value=\"Sci-Fi\">Sci-Fi</option>
						<option value=\"Short\">Short</option>
						<option value=\"Thriller\">Thriller</option>
						<option value=\"War\">War</option>
						<option value=\"Western\">Western</option>
					</select>
					<br/><br/>
					<input type=\"submit\" value=\"Add it!!\"/>
					</form>
					<hr/>";
			if ($_GET[title] AND $_GET[company] AND $_GET[year]){
				$title=$_GET[title];
				$company=$_GET[company];
				$director=$_GET[did];
				$mpaarating=$_GET[mpaarating];
				$genre=$_GET[genre];
				$year=$_GET[year];
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				//Get new id for new movie
				mysql_query("UPDATE MaxMovieID SET id = id + 1", $db_connection);
				$newID = mysql_fetch_row(mysql_query("SELECT * FROM MaxMovieID", $db_connection));
				$id = $newID[0];
				if(!mysql_query("INSERT INTO MovieDirector VALUES ('$id', '$director')", $db_connection)) echo "ERROR:".mysql_error();
				if(!mysql_query("INSERT INTO MovieGenre VALUES ('$id', '$genre')", $db_connection)) echo "ERROR:".mysql_error();
					
				if (!mysql_query("INSERT INTO Movie VALUES ('$id', '$title', '$year', '$mpaarating', '$company')", $db_connection)) {
					mysql_query("INSERT INTO MovieDirector VALUES ('$id', '$director')", $db_connection);
					mysql_query("UPDATE MaxMovieID SET id = id - 1", $db_connection);
					mysql_query("DELETE FROM MovieDirector WHERE mid=$id", $db_connection);
					mysql_query("DELETE FROM MovieGenre WHERE mid=$id", $db_connection);
					echo "<hr/><br><font color=red size=4>BAD INPUT!</font><br>";
					echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";
				}
				else {
					echo "<hr/><br><font color=cyan size=4>Thank you for your input!!!</font><br>";
					echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";					
				}
				mysql_free_result($directorlist);
				mysql_close($db_connection);
			}			
		?>
		
	</body>
</html>