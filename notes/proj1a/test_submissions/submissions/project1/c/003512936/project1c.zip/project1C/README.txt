-- Name: Angel Darquea
-- ID: 003512936
-- Date: 10/31/2008
-- Fall 2008
-- Project 1C - README
 Great poject! Most useful things I've learned so far!
