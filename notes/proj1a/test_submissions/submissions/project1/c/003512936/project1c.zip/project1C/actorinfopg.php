<!-- 
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - actorinfopg.php
-->
<html>
	<head>
		<title>Actor's Bio!</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
		<?php
			if ($_GET["aid"]){
				$actorID = $_GET["aid"];
				$notInMovies = 1;
				//Establish db connection , check it was established:
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection) {
					$errmsg = mysql_error($db_connection);
					echo "Connection failed: $errmsg <br />";
					exit(1);
				}
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				//Build queries to be sent to mySQL, get resources (relations actorrs, moviers):
				$actorQuery="SELECT first, last, dob, dod, sex FROM Actor WHERE id = '$actorID'";
				$actorrs = mysql_query($actorQuery, $db_connection);
				$moviesInQuery = "select title, year, rating, company, id, role from Movie M, MovieActor MA where M.id=MA.mid AND MA.aid = '$actorID'";
				$moviers = mysql_query($moviesInQuery, $db_connection);
				//Check if errors; return resulting relation to the actor resource 'actorrs', print results: 
				if (!$actorrs) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				 if (!$moviers) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				//Fields to print:
				$fname=0;
				$lname=1;
				$dob=2;
				$dod=3;
				$sex=4;
				$mtitle=0;
				$myear=1;
				$mrating=2;
				$mstudio=3;
				$mid=4;
				$mrole=5;
				
				//Print actor's info
				$actor = mysql_fetch_row($actorrs);
				$role = mysql_fetch_row($actorrs);
				echo "<br><font color=cyan size=5>$actor[$fname] $actor[$lname]</font><br><br><br>";
				echo "<font size=3><b><u>Actor's Bio</u></b><font><br><br>";
				echo "<b><font color=cyan>Name: </font></b>$actor[$fname] $actor[$lname] <br>
				<b><font color=cyan>Born on:</font></b> $actor[$dob] <br>";
				if ($actor[$dod]<>"")
					echo "<b><font color=cyan>Died on:</font></b> $actor[$dod] <br>";
				else
					echo "<b><font color=cyan>Died on:</font></b> Still acting! <br>";		
				//Print "movies in" info	
				echo "<hr/><font size=3><b><u>Movies:</u></b><font><br><br>";

				while (($movies = mysql_fetch_row($moviers))) {
					$notInMovies = 0;
					echo "In <a href=\"./movieinfopg.php?mid=$movies[$mid]\">$movies[$mtitle]</a>, as <font color=cyan>$movies[$mrole]</font>, $movies[$myear], $movies[$mrating], $movies[$mstudio]<br>";
				}
				if ($notInMovies) echo "No movies found for this actor!<br>";
				//We are done so we release aactorrs's, moviers's memory and close the connection:
				mysql_free_result($actorrs);
				mysql_free_result($moviers);
				mysql_close($db_connection);
			}
		?> 
		<br><hr	><a href=searchpg.php>Moovle something!</a><br><br>
	</body>
</html>