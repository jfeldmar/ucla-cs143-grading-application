<!-- 
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - movieinfopg.php
-->
<html>
	<head>
		<title>Movie's Info</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
		<?php
			if ($_GET["mid"]){
				$movieID = $_GET["mid"];
				//Establish db connection , check it was established:
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection) {
					$errmsg = mysql_error($db_connection);
					echo "Connection failed: $errmsg <br />";
					exit(1);
				}
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				//Build queries to be sent to mySQL, and get resources (Relations moviesrs, mgenresrs, mdirectorrs, mrolers):
				$movieQuery="SELECT title, company, rating, year FROM Movie WHERE id = '$movieID'";
				$moviesrs = mysql_query($movieQuery, $db_connection);
				$movieGenre="SELECT genre FROM MovieGenre WHERE mid = '$movieID'";
				$mgenrers = mysql_query($movieGenre, $db_connection);
				$movieDirector="SELECT first, last, dob FROM Director WHERE id in (SELECT did FROM MovieDirector WHERE mid = '$movieID')";
				$mdirectorrs = mysql_query($movieDirector, $db_connection);
				$mactorRole = "SELECT first, last, role, Actor.id from Actor, MovieActor where id=aid and mid = '$movieID'";
				$mrolers = mysql_query($mactorRole, $db_connection);
				$mreviews = "SELECT time, name, comment, rating, mid FROM Review where mid='$movieID'";
				$reviewsrs = mysql_query($mreviews, $db_connection);
				$mavgrating = "SELECT COUNT(rating), ROUND(SUM(rating)/COUNT(rating),1) FROM Review WHERE mid = '$movieID'";
				$avgratingrs = mysql_query($mavgrating, $db_connection);
				//Check if errors;
				if (!$moviesrs) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				if (!$mgenrers) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				if (!$mdirectorrs) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				if (!$mrolers) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				} 
				if (!$reviewsrs) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				if (!$avgratingrs) {
					$errmsg = mysql_error();
					echo ("$errmsg");
					mysql_close($db_connection);
					exit(1);
				}
				//Fields to print:
				$mtitle=0;
				$mcompany=1;
				$mrating=2;
				$myear=3;
				$mgenre=0;
				$mdirfirst=0;
				$mdirlast=1;
				$mdirdob=2;
				$mactorfst=0;
				$mactorlst=1;
				$mactorrl=2;
				$mactorid=3;
				$mrevtime=0;
				$mrevname=1;
				$mrevcomment=2;
				$mrevrating=3;
				$mrevmid=4;
				$mratingcount=0;
				$mavgerating=1;
				//Print movie's info
				$movie = mysql_fetch_row($moviesrs);
				echo "<br><font color=cyan size=5>$movie[$mtitle]</font><br><br><br>";
				echo "<font size=3><b><u>Movie's Info</u></b><font><br><br>";
				echo "<b><font color=cyan>Name: </font></b>$movie[$mtitle] <br>
				<b><font color=cyan>Year:</font></b> $movie[$myear] <br>
				<b><font color=cyan>Studio:</font></b> $movie[$mcompany] <br>
				<b><font color=cyan>Rating:</font></b> $movie[$mrating] <br>";
				echo "<b><font color=cyan>Directed by:</font></b><br>";
				while (($director = mysql_fetch_row($mdirectorrs))) {
					echo "&nbsp&nbsp -->$director[$mdirfirst] $director[$mdirlast] ($director[$mdirdob])<br>";	
				}
				echo "<b><font color=cyan>Genre: </font></b><br>";
				while (($genre = mysql_fetch_row($mgenrers))) {
					echo "&nbsp&nbsp -->$genre[$mgenre]<br>";
				}
				//Now print the actors and roles:
				echo "<font size=3><b><u><hr/>Some of the actors in this one:</u></b><font><br><br>";
				while (($actorrl = mysql_fetch_row($mrolers))) {
					echo "<a href=\"./actorinfopg.php?aid=$actorrl[$mactorid]\">$actorrl[$mactorfst] $actorrl[$mactorlst]</a>, as \"$actorrl[$mactorrl]\"<br>";
				}
				//Now print the users' reviews of this movie:
				$rate = mysql_fetch_row($avgratingrs);
				echo "<font size=3><b><u><hr/>And what people thought of the movie:</u></b><font><br>";
				echo "The average rating is <font color=cyan>$rate[$mavgerating] stars</font>, from <font color=cyan>$rate[$mratingcount]</font> comments left by users.<br><br>";
				while (($ureviews = mysql_fetch_row($reviewsrs))) {
					echo "On $ureviews[$mrevtime], <font color=cyan>$ureviews[$mrevname]</font> said: <br><font color=cyan>\"---->$ureviews[$mrevcomment]\"</font> and gave it <font color=cyan>$ureviews[$mrevrating]</font> star(s).<br><br>";
				}
				//We are done so we release aactorrs's, moviers's memory and close the connection:
				mysql_free_result($mgenrers);
				mysql_free_result($moviesrs);
				mysql_free_result($mdirectorrs);
				mysql_close($db_connection);
			}
			echo "<a href=\"./addmovcomment.php?mid=$movieID\"><hr/>Add your own review!</a><br><br>";
		?>
		<a href=searchpg.php>Moovle something!</a><br><br>
	</body>
</html>