<!-- 
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - addmovcomment.php
--> 
<html>
	<head><title>Add your movie reviews!</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>
	<body>
		<br><font color=cyan size=5>Leave a comment!</font><br><br><br>
		<!--PHP Script-->
		<?php
			//Build the form within PHP
			echo "<form method=\"GET\" action=\"./addmovcomment.php\">
					<b>Movie: </b>
					<select name=\"movies\">";
					$db_connection = mysql_connect("localhost", "cs143", "");
					if (!$db_connection) {
						$errmsg = mysql_error($db_connection);
						echo "Connection failed: $errmsg <br />";
						exit(1);
					}
					// Tell mySQL server which database to use; check if error:
					$connected2db = mysql_select_db("CS143", $db_connection);
					if (!$connected2db) {
						echo "Data base not found!<br />";
						mysql_close($db_connection);
						exit(1);
					}
					if (!($movieslist = mysql_query("SELECT id, title, year FROM Movie", $db_connection))) {
						$errmsg = mysql_error();
						echo ("$errmsg");
						mysql_close($db_connection);
						exit(1);
					}
					$m_id=0;
					$m_title=1;
					$m_year=2;	
					while (($movies = mysql_fetch_row($movieslist))) {
						echo "<option value=$movies[$m_id] ";
						if ($movies[$m_id] == $_GET[mid]) echo "selected=\"selected\"";
						echo ">$movies[$m_title] ($movies[$m_year]) </option>";
					}	
				echo "</select><br><br>
					<b>Who are you?:</b><input type=\"text\" maxlenght=\"20\" value=\"Frodo\" name=\"username\"><br><br>
					<b>How was it?: &nbsp&nbsp</b>
					<select name=\"rating\">
						<option value=\"5\"> 5 - AWESOME! </option>
						<option value=\"4\"> 4 - Not bad at all! </option>
						<option value=\"3\"> 3 - Watchable! </option>
						<option value=\"2\"> 2 - I threw up a little bit!</option>
						<option value=\"1\"> 1 - McCain 08! </option>
					</select><br><br>
					<font color=white><b>Explain!:</b></font><br>
					<textarea rows=\"5\" cols=\"50\" name=\"comment\"></textarea><br><br>
					<input type=\"submit\" value=\"Rate it!\">
				</form>";	
			if ($_GET[username] AND $_GET[comment]){
				$username=$_GET[username];
				$comment=$_GET[comment];
				$mid=$_GET[movies];
				$rating=$_GET[rating];
				
				mysql_query("INSERT INTO Review VALUES ('$username', NOW(), '$mid', '$rating', '$comment')", $db_connection);
				echo "<hr/><br><font color=cyan size=4>Thank you for your review!!!</font><br>";
				echo "<font color=cyan size=3>Click <a href=\"./movieinfopg.php?mid=$mid\">here</a> to go back to the movie info page.<br></font>";
				mysql_free_result($movieslist);
				mysql_close($db_connection);
			}
		?>
	</body>
</html>
