<!--  
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - addactortomovie.php
-->
<html>
	<head>
		<title>IMDB-0: R! Links</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
		<br><font color=cyan size=5>Adding an actor to a movie in IMDB-0: R!</font><br><br><br>
		<?php
			//Build the form within PHP
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection) {
					$errmsg = mysql_error($db_connection);
					echo "Connection failed: $errmsg <br>";
					exit(1);
				}
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				if (!($actorlist = mysql_query("SELECT id, last, first FROM Actor ORDER BY last", $db_connection))) {
						$errmsg = mysql_error();
						echo ("ERROR: $errmsg");
						mysql_close($db_connection);
						exit(1);
					}
				if (!($movielist = mysql_query("SELECT id, title FROM Movie ORDER BY title", $db_connection))) {
						$errmsg = mysql_error();
						echo ("ERROR: $errmsg");
						mysql_close($db_connection);
						exit(1);
					}
				
			echo "<form method=\"GET\" action=\"./addactortomovie.php\">
					Role :
					<input type=\"text\" maxlength=\"20\" name=\"role\"/>
					<br/><br/>
					<font color=white>Played by :</font>
					<select name=\"actor\">";
					$aid=0;
					$last=1;
					$first=2;
					while (($actors = mysql_fetch_row($actorlist))) {
						echo "<option value=$actors[$aid]";
						echo ">$actors[$last], $actors[$first]</option>";
					}					
					echo "</select>
					<br/><br/>
					<font color=white>In the movie :</font>
					<select name=\"movie\">";
					$mid=0;
					$title=1;
					while (($movies = mysql_fetch_row($movielist))) {
						echo "<option value=$movies[$mid]";
						echo ">$movies[$title]</option>";
					}					
					echo "</select><br><br>
					<input type=\"submit\" value=\"Add actor!!\"/>
					</form>
					<hr/>";
			if ($_GET[role]){
				$mid=$_GET[movie];
				$aid=$_GET[actor];
				$role=$_GET[role];
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				if(!mysql_query("INSERT INTO MovieActor VALUES ('$mid', '$aid', '$role')", $db_connection)) {
					echo mysql_error();
					echo "<hr/><br><font color=red size=4>BAD INPUT!</font><br>";
					echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";
				}
				else {
					echo "<hr/><br><font color=cyan size=4>Thank you for your input!!!</font><br>";
					echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";					
				}
				mysql_free_result($movielist);
				mysql_free_result($actorlist);
				mysql_close($db_connection);
			}			
		?>
		
	</body>
</html>