<!--
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - seacrhpg.php
-->
<html>
	<html>
	<head>
		<title>Who was that? What movie?</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
	<br>
		<form action="./searchpg.php" method="GET">
			<p style="text-align: center;">
			<font size="4" color="white"><b>Looking for an actor, actress or movie?</b></font>
			<input type="text" name="keyword">
			<input type="submit" value="Moovle it!">
			</p>
		</form>
		<!--PHP Script-->
		<?php
			if ($_GET["keyword"]){
					$myKeyword = $_GET["keyword"];
					//Variable print outputs:
					$noresults = 1;
					//Establish db connection , check it was established:
					$db_connection = mysql_connect("localhost", "cs143", "");
					if (!$db_connection) {
						$errmsg = mysql_error($db_connection);
						echo "Connection failed: $errmsg <br />";
						exit(1);
					}
					// Tell mySQL server which database to use; check if error:
					$connected2db = mysql_select_db("CS143", $db_connection);
					if (!$connected2db) {
						echo "Data base not found!<br />";
						mysql_close($db_connection);
						exit(1);
					}				
					//Build queries to be sent to mySQL, get resource (relations, ars and mrs)
					$myActorQuery="SELECT first, last, dob, id FROM Actor WHERE first LIKE '%$myKeyword%' OR last LIKE '%$myKeyword%' OR CONCAT_WS(' ', first,last) LIKE '%$myKeyword%' OR CONCAT_WS(' ',last,first) LIKE '%$myKeyword%' OR CONCAT_WS(', ', first,last) LIKE '%$myKeyword%' OR CONCAT_WS(', ',last,first) LIKE '%$myKeyword%'";
					$ars = mysql_query($myActorQuery, $db_connection);
					$myMovieQuery="SELECT title, id, year FROM Movie WHERE title LIKE '%$myKeyword%'";
					$mrs = mysql_query($myMovieQuery, $db_connection);
					//Check if errors; return resulting relation to the actor resource 'ars', print results:
					echo ("<br><br><br><font size=5>Results for '$myKeyword':</font><br><br>");
					if (!$ars) {
						$errmsg = mysql_error();
						echo ("$errmsg");
						mysql_close($db_connection);
						exit(1);
					}
					if (!$mrs) {
						$errmsg = mysql_error();
						echo ("$errmsg");
						mysql_close($db_connection);
						exit(1);
					}
					//Display results in HTML
					//Names of fields to print
					$fname=0;
					$lname=1;
					$dob=2;
					$aid=3;
					$mtitle=0;
					$mid=1;
					$myear=2;
					echo "<font size=4><u>Actors found:</u></font><br>";
					while (($row = mysql_fetch_row($ars))) {
						$noresults = 0;
						echo "<b><font color=cyan>Name: </font></b><a href=\"./actorinfopg.php?aid=$row[$aid]\">$row[$fname] $row[$lname]</a> <b><font color=cyan>Born on:</font></b> $row[$dob]";
						echo "<br>";
					}
					if ($noresults) echo "No actors found for $myKeyword!<br>";
					echo "<br>";
					echo "<font size=4><u>Movies found:</u></font><br>";
					while (($mrow = mysql_fetch_row($mrs))) {
						$noresults = 0;
						echo "<b><font color=cyan>Movie: </font></b><a href=\"./movieinfopg.php?mid=$mrow[$mid]\">$mrow[$mtitle]</a> <b><font color=cyan>Year:</font></b> $mrow[$myear]";
						echo "<br>";
					}
					if ($noresults) echo "No movies found for $myKeyword!<br>";
					//We are done so we release ars's, mrs's memory and close the connection:
					mysql_free_result($ars);
					mysql_free_result($mrs);
					mysql_close($db_connection);
			}	
		?>		
	</body>
</html>