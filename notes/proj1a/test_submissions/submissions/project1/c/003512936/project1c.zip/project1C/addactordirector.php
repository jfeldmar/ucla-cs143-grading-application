<!--  
Name: Angel Darquea
ID: 003512936
Date: 10/31/2008
Fall 2008
Project 1C - addactordirector.php
-->
<html>
	<head>
		<title>IMDB-0: R! Links</title>
		<style type="text/css">
		@import url(reckon.css);
		</style>
	</head>	
	<body>
		<br><font color=cyan size=5>Adding an actor or director to IMDB-0: R!</font><br><br><br>
		<?php
			//Build the form within PHP
			echo "<form method=\"get\" action=\"./addactordirector.php\">
			&nbsp Identity:
			<input type=\"radio\" value=\"Actor\" name=\"identity\"/>
			&nbsp Actor
			<input type=\"radio\" value=\"Director\" name=\"identity\"/>
			&nbsp Director
			<br/>
			<hr/>
			&nbsp First Name:
			<input type=\"text\" maxlength=\"20\" name=\"first\"/><br>
			<br/>
			&nbsp Last Name:
			<input type=\"text\" maxlength=\"20\" name=\"last\"/><br>
			<br/>
			&nbsp <font color=white>Sex:</font><br>
			&nbsp <input type=\"radio\" value=\"Male\" name=\"sex\"/>
			&nbsp <font color=white>Male</font>
			&nbsp <input type=\"radio\" value=\"Female\" name=\"sex\"/>
			<font color=white>Female</font>
			<br/><br>
			<font color=white>&nbsp Date of Birth:</font>
			<input type=\"text\" name=\"dob\"/><br>
			<br/>
			<font color=white>&nbsp Date of Death:</font>
			<input type=\"text\" name=\"dod\"/> <font color=white>(leave blank if alive now)</font><br>
			<br/>
			&nbsp <input type=\"submit\" value=\"add it!!\"/>
			</form>";
			if ($_GET[identity] AND $_GET[first] AND $_GET[sex] AND $_GET[dob]){
				$identity=$_GET[identity];
				$fname=$_GET[first];
				$lname=$_GET[last];
				$sex=$_GET[sex];
				$dob=$_GET[dob];
				$dod=$_GET[dod];
				
				$db_connection = mysql_connect("localhost", "cs143", "");
				if (!$db_connection) {
					$errmsg = mysql_error($db_connection);
					echo "Connection failed: $errmsg <br />";
					exit(1);
				}
				// Tell mySQL server which database to use; check if error:
				$connected2db = mysql_select_db("CS143", $db_connection);
				if (!$connected2db) {
					echo "Data base not found!<br />";
					mysql_close($db_connection);
					exit(1);
				}
				//Get new id for new actor
				mysql_query("UPDATE MaxPersonID SET id = id + 1", $db_connection);
				$newID = mysql_fetch_row(mysql_query("SELECT * FROM MaxPersonID", $db_connection));
				$id = $newID[0];

				if ($identity == "Actor")
					if (!mysql_query("INSERT INTO Actor VALUES ('$id', '$lname', '$fname', '$sex', '$dob', '$dod')", $db_connection)) {
						mysql_query("UPDATE MaxPersonID SET id = id - 1", $db_connection);
						echo "<hr/><br><font color=red size=4>BAD INPUT!</font><br>";
						echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";
					}
					else {
						echo "<hr/><br><font color=cyan size=4>Thank you for your input!!!</font><br>";
						echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";					
					}
					
				if ($identity == "Director")
					if (!mysql_query("INSERT INTO Director VALUES ('$id', '$lname', '$fname', '$dob', '$dod')", $db_connection)) {
						mysql_query("UPDATE MaxPersonID SET id = id - 1", $db_connection);
						echo "<hr/><br><font color=red size=4>BAD INPUT!</font><br>";
						echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";
					}
					else {
						echo "<hr/><br><font color=cyan size=4>Thank you for your input!!!</font><br>";
						echo "<font color=cyan size=3>Click <a href=\"./searchpg.php\">here</a> to go back to the search page.<br><font color=cyan size=3>";					
					}
				mysql_close($db_connection);
			}			
		?>
		
	</body>
</html>