<html>
<head><title>CS143 Project 1C</title></head>
<body>
<?php
$actor = $_GET["sel_actor"];
$db_connection = mysql_connect("localhost", "cs143", "");
if(!$db_connection) {
	$errmsg = mysql_error($db_connection);
	print "Connection failed: $errmsg <br />";
	exit(1);
}

mysql_select_db("CS143", $db_connection);

if($actor <> "") {
	$query = sprintf("SELECT * FROM Actor WHERE id = %d ORDER BY last, first", $actor);
	$query_to_issue = sprintf($query, $sanitized_name);
	//print "<h3>Input query: </h3>".$query."<br />";
	$rs = mysql_query($query_to_issue, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		$row = mysql_fetch_row($rs);

		print "<br />";
		print "-- Show Actor Info --<br />";
		print "Name: ".$row[2]." ".$row[1]."<br />";
		print "Sex: ".$row[3]."<br />";
		print "Date of Birth: ".$row[4]."<br />";
		
		if( $row[5] == NULL)
			print "Date of Death: Still Alive<br />";
		else	
			print "Date of Death : ".$row[5]."<br />";
		print "<br />";
				
			
		$query = sprintf("SELECT * FROM MovieActor WHERE aid = %d", $actor);
		$query_to_issue = sprintf($query, $sanitized_name);
		//print "<h3>Input query: </h3>".$query."<br />";
		$rs = mysql_query($query_to_issue, $db_connection);

		print "<br />";

		print "-- Filmography --<br />";
		while($row = mysql_fetch_row($rs)) {
			$movie_query = sprintf("SELECT * FROM Movie WHERE id = %d", $row[0]);
			$query_to_issue = sprintf($movie_query, $sanitized_name);
			//print "<h3>Input query: </h3>".$movie_query."<br />";
			$movie_rs = mysql_query($query_to_issue, $db_connection);

			while($movie_row = mysql_fetch_row($movie_rs)) {
				print "Act \"".$row[2]."\" in <a href=\"./browsingMovie.php?sel_movie=".$row[0]."\">".$movie_row[1]."</a><br>";
			}
		}
	}
}
?>
<p>
<form action="./browsingActor.php" method="GET">
<table border = "1">
	<tr>
		<td>Actor</td>
		<td><select name="sel_actor">
<?php
	$query = sprintf("SELECT * FROM Actor ORDER by last, first");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			if($actor == NULL || $actor <> $row[0])
				print "<option value=\"".$row[0]."\">".$row[2]." ".$row[1]." ".$row[4]."</option>\n";
			else
				print "<option value=\"".$row[0]."\" selected=\"selected\">".$row[2]." ".$row[1]." ".$row[4]."</option>\n";
		}
	}
?>
		</select></td>
	</tr>						
</td>
</table>
<input type="submit" value="Submit" />
</form>
</p>
</body>
</html>
