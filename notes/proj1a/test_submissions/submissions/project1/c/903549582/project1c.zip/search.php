<html>
<head><title>CS143 Project 1C</title></head>
<body>
<form action='./search.php' method='GET'>
<table border = '1'>
	<tr>
		<td>Search</td>
		<td><select name='kind'>
			<option value='1'>All</option>
			<option value='2'>Actor/Actress</option>
			<option value='3'>Movie</option>
		</select></td>
		<td><input type='text' name='keyword'></td>
		<td><input type='submit' value='Submit' /></td>
	</tr>
</table>
</form>
</p>

<?php
$kind = $_GET["kind"];
$keyword = $_GET["keyword"];

if($kind == "" && $keyword == "")
	exit(1);

$db_connection = mysql_connect("localhost", "cs143", "");
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed: $errmsg <br />";
    exit(1);
}
mysql_select_db("CS143", $db_connection);

if($kind == 2 || $kind == 1) {
	$query = sprintf("SELECT * FROM Actor WHERE last like '%%%s%%' OR first like '%%%s%%' ORDER BY last, first", mysql_real_escape_string($keyword), mysql_real_escape_string($keyword));
	print "<h3>Actor/Actress</h3>";

	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		//$errmsg = mysql_error($db_connection);
		//print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs))
			print "Actor: <a href = ./browsingActor.php?sel_actor=".$row[0].">".$row[2]." ".$row[1]." (".$row[4].")</a><br>";
	}
}

if($kind == 3 || $kind == 1) {
	$query = sprintf("SELECT * FROM Movie WHERE title like '%%%s%%' ORDER BY title", mysql_real_escape_string($keyword));
	print "<h3>Movie</h3>";

	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		//$errmsg = mysql_error($db_connection);
		//print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs))
			print "Movie: <a href = ./browsingMovie.php?sel_movie=".$row[0].">".$row[1]." (".$row[2].")</a><br>";
	}
}

?>
</body>
</html>
