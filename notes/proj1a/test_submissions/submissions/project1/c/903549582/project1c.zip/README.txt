CS143 Project1C
 
Alfred Heu, 903549582, elf777@cs.ucla.edu
SeungHoon Lee, 403450559, shlee@cs.ucla.edu
As a team, we did pair programming and tested/verified the logics together.

Functionalities
1)default page: movie.html
The page has links to other php pages to add/show movie related database information.

2)Add Actor/Director menu: user can add an actor or director with his/her name, DoB and DoD.
The Id of actor/director will be automatically assigned from MaxPersonID table and the value in the table is increased after the insertion.
User has to input value on a blank with star sign. Otherwise we print error message.

3)Add Comment: user can add comments to a movie. User can select a movie from the php page and put comments in a text box 

4)Add Movie: user can add a movie with movie title, production company, director and genere.
The Id of movie will be automatically assigned from MaxMovieID table and the value in the table is increased after the insertion. 
User has to input value on a blank with star sign. Otherwise we print error message.

5)Add Movie/Actor Relation: user can add a role of actor in a movie

6)Show Actor: user can select an actor to see his information. the page will show the actor's information and movies that he acts
The movie presented has a link so that the user also can see the detail information of the movie.

7)Show Movie: user can select a movie to see information. the page will show the movie information and actors who are in the movie.
The actors presented have a link so that the user also can see the detail information of the actors.

8)Search Actor/Movie: user can search actor or movie by keyword. The search results also have links to detail information.

-- We modified and resubmitted our codes (11/01/2008 about 22:00).