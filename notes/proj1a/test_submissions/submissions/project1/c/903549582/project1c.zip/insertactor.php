<html>
<head><title>CS143 Project 1C</title></head>
<body>
<p>
<form action="./insertactor.php" method="GET">
<table border = "1">
	<tr>
		<td>Identity *</td>
		<td><input type="radio" name="identity" value="Actor" checked="true"> Actor
			<input type="radio" name="identity" value="Director"> Director
		</td>
	</tr>
	<tr>
		<td>First *</td>
		<td><input type="text" name="first"><br></td>
	</tr>
	<tr>
		<td>Last *</td>
		<td><input type="text" name="last"><br></td>
	</tr>
	<tr>
		<td>Gender *</td>
		<td><input type="radio" name="gender" value="Male" checked="true"> Male
			<input type="radio" name="gender" value="Female"> Female
		</td>
	</tr>
	<tr>
		<td>Date of birth *</td>
		<td><input type="text" name="dob"><br></td>
	</tr>
	<tr>
		<td>Date of death</td>
		<td><input type="text" name="dod">(leave blank if he/she is still alive)<br></td>
	</tr>
	<tr>
		<td></td>
</table>
<input type="submit" value="Submit" />
</form>
</p>

<?php
$identity = $_GET["identity"];
$first = $_GET["first"];
$last = $_GET["last"];
$gender = $_GET["gender"];
$dob = $_GET["dob"];
$dod = $_GET["dod"];



if($identity == "" && $first == "" && $last == "" && $gender == "" && $dob == "" && $dod == "")
	exit(1);

if($identity == "" || $first == "" || $last == "" || $gender == "" || $dob == "") {
	print "Please input information!<br />";
	exit(1);
}

$db_connection = mysql_connect("localhost", "cs143", "");
if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed: $errmsg <br />";
    exit(1);
}

mysql_select_db("CS143", $db_connection);
$query = sprintf("SELECT id FROM MaxPersonID");
$rs = mysql_query($query, $db_connection);

if(!$rs) {
	$errmsg = mysql_error($db_connection);
	print "$errmsg <br />";
    exit(1);
}


$row = mysql_fetch_row($rs);
$max_person_id = $row[0];


if($identity == "Actor"){
	if($dod == "")
		$query = sprintf("INSERT INTO Actor VALUES (%d, '%s', '%s', '%s', '%s', NULL)", $max_person_id, mysql_real_escape_string($last, $db_connection), mysql_real_escape_string($first, $db_connection), mysql_real_escape_string($gender, $db_connection), mysql_real_escape_string($dob, $db_connection));
	else
		$query = sprintf("INSERT INTO Actor VALUES (%d, '%s', '%s', '%s', '%s', '%s')", $max_person_id, mysql_real_escape_string($last, $db_connection), mysql_real_escape_string($first, $db_connection), mysql_real_escape_string($gender, $db_connection), mysql_real_escape_string($dob, $db_connection), mysql_real_escape_string($dod, $db_connection));
}
else if($identity == "Director"){
	if($dod == "")
		$query = sprintf("INSERT INTO Director VALUES (%d, '%s', '%s', '%s', NULL)", $max_person_id, mysql_real_escape_string($last, $db_connection), mysql_real_escape_string($first, $db_connection), mysql_real_escape_string($dob, $db_connection));
	else
		$query = sprintf("INSERT INTO Director VALUES (%d, '%s', '%s', '%s', '%s')", $max_person_id, mysql_real_escape_string($last, $db_connection), mysql_real_escape_string($first, $db_connection), mysql_real_escape_string($dob, $db_connection), mysql_real_escape_string($dod, $db_connection));
}
else{
	print "not identified.... <br />";
  exit(1);
}
mysql_select_db("CS143", $db_connection);

$rs = mysql_query($query, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
    exit(1);
}
else 
	print "Success! on $identity ".$first." ".$last." added into our Database<br />";
	$max_personID_query = sprintf("UPDATE MaxPersonID SET id = id + 1");
	$query_to_issue = sprintf($max_personID_query, $sanitized_name);
	//print "<h3>Input query: </h3>".$max_personID_query."<br />";
	$rs = mysql_query($query_to_issue, $db_connection);
	
	if($rs){
		//print "Success on <br />";
	}
	else{
		//print "$errmsg <br />";
		exit(1);	
	}
		
?>
</body>
</html>
