<html>
<head><title>CS143 Project 1C</title></head>
<body>
<?php
$in_id=$_GET["id"];
?>
<p>
<form action='./insertcomment.php' method="GET">
<table border = "1">
	<tr>
		<td>Movie</td>
		<td><select name="sel_movie">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	mysql_select_db("CS143", $db_connection);

	$query = sprintf("SELECT * FROM Movie ORDER BY title");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			if($in_id == NULL || $in_id <> $row[0])
				print "<option value=\"".$row[0]."\">".$row[1]."(".$row[2].")</option>\n";
			else
				print "<option value=\"".$row[0]."\" selected=\"selected\">".$row[1]."(".$row[2].")</option>\n";
		}
	}
?>
		</select></td>
	</tr>
	<tr>
		<td>Reviewer name</td>
		<td><input type="text" name="name" value="Anonymous"><br></td>
	</tr>
	<tr>
		<td>Review rating</td>
		<td><select name="rating">
			<option value="5">5(Excellent)</option>
			<option value="4">4(Good)</option>
			<option value="3">3(So so)</option>
			<option value="2">2(Not good)</option>
			<option value="1">1(Bad)</option>
		</select></td>
		<?php
			print "<td><input type=hidden name=id value=".$in_id."></td>";
		?>
	</tr>
	<tr>
		<td>Reviewer Comment</td>
		<td><textarea name="comment" cols="60" rows="8"></textarea><br></td>
	</tr>
</table>
<input type="submit" value="Submit" />
</form>
</p>

<?php
$name = $_GET["name"];
$rating = $_GET["rating"];
$comment = $_GET["comment"];
$movie = $_GET["sel_movie"];

if($name == "" && $rating == "" && $comment == "")
	exit(1);

$query = sprintf("INSERT INTO Review VALUES ('%s', NOW(), %d, %d, '%s')", mysql_real_escape_string($name, $db_connection), $movie, $rating, mysql_real_escape_string($comment, $db_connection));

$rs = mysql_query($query, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
    exit(1);
}
else {
	print "Thanks your comment!! We appreciate it!!<br />";
	print "<a href = ./browsingMovie.php?sel_movie=".$movie.">See Movie Info (including others' reviews)</a></br>";
}
?>
</body>
</html>
