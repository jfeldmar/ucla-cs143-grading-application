<html>
<head><title>CS143 Project 1C</title></head>
<body>
<?php
$movie = $_GET["sel_movie"];
?>
<p>
<form action="./browsingMovie.php" method="GET">
<table border = "1">
	<tr>
		<td>Movie</td>
		<td><select name="sel_movie">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	mysql_select_db("CS143", $db_connection);

	$query = sprintf("SELECT * FROM Movie ORDER BY title");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			if($movie == NULL || $movie <> $row[0])
				print "<option value=\"".$row[0]."\">".$row[1]." (".$row[2].")</option>";
			else
				print "<option value=\"".$row[0]."\" selected=\"selected\">".$row[1]." (".$row[2].")</option>";
		}
	}
?>
		</select></td>
	</tr>

</td>
</table>
<input type="submit" value="Submit" />
</form>
</p>

<?php
if($movie == "")
	exit(1);

$query = sprintf("SELECT * FROM Movie WHERE id = %d", $movie);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
	//exit(1);
}
else {
	$row = mysql_fetch_row($rs);

	print "-- Show Movie Info --<br />";
	print "Title: ".$row[2]." (".$row[1].")<br />";
	print "Producer: ".$row[4]."<br />";
	print "MPAA Rating: ".$row[3]."<br />";
}

$query = sprintf("SELECT * FROM Director D, MovieDirector MD WHERE MD.did = D.id AND MD.mid = %d", $movie);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
	//exit(1);
}
else {
	$row = mysql_fetch_row($rs);
	if($row[2] == '' && $row[3] == '')
		print "Director:<br />";
	else
		print "Director: " .$row[2]." ".$row[1]."(".$row[3].")<br />";
}

$query = sprintf("SELECT genre FROM MovieGenre WHERE mid = %d", $movie);
$query_to_issue = sprintf($query, $sanitized_name);
$rs = mysql_query($query_to_issue, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
	//exit(1);
}
else {
	$row = mysql_fetch_row($rs);

	print "Genre: ".$row[0];
	while($row = mysql_fetch_row($rs)){
		print ", ".$row[0];	
	}
	print "<br />";
}


$query = sprintf("SELECT DISTINCT Actor.id, Actor.last, Actor.first, role FROM Actor, MovieActor WHERE MovieActor.mid = %d and MovieActor.aid = Actor.id", $movie );
$query_to_issue = sprintf($query, $sanitized_name);
//print "<h3>Input query: </h3>".$query."<br />";
$rs = mysql_query($query_to_issue, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
    //exit(1);
}
else {
	print "<br/>-- Actors in the movie --<br/>";
	while($row = mysql_fetch_row($rs)) {
		print "<a href=\"./browsingActor.php?sel_actor=".$row[0]."\">".$row[2]." ".$row[1]."</a> act as \"".$row[3]."\"<br />";
	}
}
	
print "<br/>-- User Review --<br/>";
$query = sprintf("SELECT AVG(rating), COUNT(*) FROM Review WHERE Review.mid = %d", $movie );
$query_to_issue = sprintf($query, $sanitized_name);
//print "<h3>Input query: </h3>".$query."<br />";
$rs = mysql_query($query_to_issue, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
    //exit(1);
}
else {
	$row = mysql_fetch_row($rs);
	if($row[1] <> 0) {
		print "Average Rating : ".$row[0]."/5 ".$row[1]." votes";
		print "<br/>User Comments<br/>";
		$query = sprintf("SELECT * FROM Review WHERE Review.mid = %d", $movie );
		$query_to_issue = sprintf($query, $sanitized_name);
		//print "<h3>Input query: </h3>".$query."<br />";
		$rs = mysql_query($query_to_issue, $db_connection);
		if(!$rs) {
			//$errmsg = mysql_error($db_connection);
			//print "$errmsg <br />";
			//exit(1);
		}
		else {
			while($row = mysql_fetch_row($rs)) {
				print "In ".$row[1].", ".$row[0]." rates ".$row[3]." point(s) for this movie.<br/>";
				print "comment : ".$row[4]."<br/>";
			}
			print "<a href=\"./insertcomment.php?id=".$movie."\">Add another comment</a><br />";
		}
	}
	else {
		print "Average Rating : This movie is not rated. <br/>";
		print "<a href=\"./insertcomment.php?id=".$movie."\">Add new comment</a><br />";
	}
}

?>
</body>
</html>
