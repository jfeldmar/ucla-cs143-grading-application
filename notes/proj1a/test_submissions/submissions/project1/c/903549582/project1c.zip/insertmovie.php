<html>
<head><title>CS143 Project 1C</title></head>
<body>
<p>
<form action="./insertmovie.php" method="GET">
<table border = "1">
	<tr>
		<td>Movie title *</td>
		<td><input type="text" name="title"><br></td>
	</tr>
	<tr>
		<td>Release year *</td>
		<td><input type="text" name="year"><br></td>
	</tr>
	<tr>
		<td>Production company *</td>
		<td><input type="text" name="company"><br></td>
	</tr>
	<tr>
		<td></td>
	<tr>
		<td>Director</td>
		<td><select name="sel_director">
<?php
	$db_connection = mysql_connect("localhost", "cs143", "");
	if(!$db_connection) {
	    $errmsg = mysql_error($db_connection);
	    print "Connection failed: $errmsg <br />";
	    exit(1);
	}
	
	mysql_select_db("CS143", $db_connection);

	$query = sprintf("SELECT * FROM Director ORDER BY last, first");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			print "<option value=\"".$row[0]."\">".$row[2]." ".$row[1]."(".$row[3].")</option>";
		}
	}
?>
		</select></td>
	</tr>
	<tr>
		<td>MPAA rating</td>
		<td><select name="sel_rating">
<?php

	$query = sprintf("SELECT DISTINCT rating FROM Movie");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			print "<option value=\"".$row[0]."\">".$row[0]."</option>";
		}
	}
?>
		</select></td>
	</tr>
	<tr>
		<td>Genre</td>
<td>
<?php
	$query = sprintf("SELECT DISTINCT genre FROM MovieGenre");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			print "<input type=\"checkbox\" name=\"sel_genre[]\" value=\"".$row[0]."\">".$row[0]."<br>";
		}
	}
?>
						
</td>
</table>
<input type="submit" value="Submit" />
</form>
</p>

<?php
$title = $_GET["title"];
$year = $_GET["year"];
$company = $_GET["company"];
$director = $_GET["sel_director"];
$rating = $_GET["sel_rating"];
$genre = $_GET["sel_genre"];

if($title == "" && $year == "" && $rating == "" && $company == "")
	exit(1);
	
if($title == "" || $year == "" || $company == "") {
	print "Please input information!<br />";
	exit(1);
}


$query = sprintf("SELECT id FROM MaxMovieID");
$rs = mysql_query($query, $db_connection);

$row = mysql_fetch_row($rs);
$max_movie_id = $row[0];

$cnt = count($genre);

$movie_query = sprintf("INSERT INTO Movie VALUES (%d, '%s', %d, '%s', '%s')", $max_movie_id, mysql_real_escape_string($title, $db_connection), $year, mysql_real_escape_string($rating, $db_connection), mysql_real_escape_string($company, $db_connection));

$rs = mysql_query($movie_query, $db_connection);

if(!$rs) {
	//$errmsg = mysql_error($db_connection);
	//print "$errmsg <br />";
    exit(1);
}
else {
	print "Success on Movie $title added!<br />";

	$max_movieID_query = sprintf("UPDATE MaxMovieID SET id = id + 1");
	$query_to_issue = sprintf($max_movieID_query, $sanitized_name);
	//print "<h3>Input query: </h3>".$max_movieID_query."<br />";
	$rs = mysql_query($query_to_issue, $db_connection);
	
	if($rs){
		//print "Success on MaxMovieID<br />";
	}

	for($i = 0; $i < $cnt; $i++){
		$genre_query = sprintf("INSERT INTO MovieGenre VALUES (%d, '%s')", $max_movie_id, mysql_real_escape_string($genre[$i], $db_connection));
		$query_to_issue = sprintf($genre_query, $sanitized_name);

		//print "<h3>Input query: </h3>".$genre_query."<br />";
		$rs = mysql_query($query_to_issue, $db_connection);
	
		if(!$rs) {
			//$errmsg = mysql_error($db_connection);
			//print "$errmsg <br />";
			//exit(1);
		}
		else{
			//print "Success on MovieGenre $i<br />";
		}
	}

	$director_query = sprintf("INSERT INTO MovieDirector VALUES (%d, %d)", $max_movie_id, $director);
	$rs = mysql_query($director_query, $db_connection);
}
?>
</body>
</html>
