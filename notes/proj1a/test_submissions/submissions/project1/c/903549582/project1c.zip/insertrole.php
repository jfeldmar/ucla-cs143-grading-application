<html>
<head><title>CS143 Project 1C</title></head>
<body>
<?php
$db_connection = mysql_connect("localhost", "cs143", "");
if(!$db_connection) {
	$errmsg = mysql_error($db_connection);
	print "Connection failed: $errmsg <br />";
	exit(1);
}

mysql_select_db("CS143", $db_connection);
?>
<p>
Add new actor in a movie: 
<form action="./insertrole.php" method="GET">
<br/>Movie: <select name="sel_movie">
<?php
	$query = sprintf("SELECT * FROM Movie ORDER BY title");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			if($movie == NULL || $movie <> $row[0])
				print "<option value=\"".$row[0]."\">".$row[1]." (".$row[2].")</option>";
			else
				print "<option value=\"".$row[0]."\" selected=\"selected\">".$row[1]." (".$row[2].")</option>";
		}
	}
?>
</select>
<br />Actor: <select name="sel_actor">
<?php
	$query = sprintf("SELECT * FROM Actor ORDER BY last, first");
	$rs = mysql_query($query, $db_connection);

	if(!$rs) {
		$errmsg = mysql_error($db_connection);
		print "$errmsg <br />";
		exit(1);
	}
	else {
		while($row = mysql_fetch_row($rs)) {
			if($actor == NULL || $actor <> $row[0])
				print "<option value=\"".$row[0]."\">".$row[2]." ".$row[1]." ".$row[4]."</option>";
			else
				print "<option value=\"".$row[0]."\" selected=\"selected\">".$row[2]." ".$row[1]." ".$row[4]."</option>";
		}
	}
?>
</select>
<br />Role :
<input type="text" name="role">
<input type="submit" value="Submit" />
</form>
</p>
<?php
$actor = $_GET["sel_actor"];
$movie = $_GET["sel_movie"];
$role = $_GET["role"];

if($actor == '' && $movie == '')
	exit(1);
else {
	$query = sprintf("INSERT INTO MovieActor VALUES (%d, %d, '%s')", $movie, $actor, mysql_real_escape_string($role, $db_connection));
}

$rs = mysql_query($query, $db_connection);
if(!$rs) {
	$errmsg = mysql_error($db_connection);
	print "$errmsg <br />";
    exit(1);
}
else {
	print "Add Success!!<br />";
}
?>
</body>
</html>
