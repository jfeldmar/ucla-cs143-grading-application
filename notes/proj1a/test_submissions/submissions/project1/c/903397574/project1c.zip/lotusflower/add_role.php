<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();

	$mid = NULL;
	$aid = NULL;
	$role = NULL;
	
	if(isset($_GET['mid']) && isset($_GET['aid']) && isset($_GET['role'])){
		$mid = mysql_real_escape_string(trim($_GET['mid']),$con);
		$aid = mysql_real_escape_string(trim($_GET['aid']),$con);
		$role = mysql_real_escape_string(trim($_GET['role']),$con);
		
		$sql = "INSERT INTO MovieActor VALUES "
				."(".$mid.",".$aid.",'".$role."');";
		$result = query($con,$sql);
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>IMDB by Sona Chaudhuri</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h3>Add new actor in a movie:</h3>
<form action="./add_role.php" method="GET">	
Movie:	<select name="mid">
		<?
			$sql = "SELECT id,title FROM Movie ORDER BY title ASC;";
			$movies = query($con,$sql);
			$options = "";
			while($row = mysql_fetch_array($movies)){
			$options .= "<option value=\"".$row['id']."\">"
						.$row['title']
						."</option>";
			}
			echo $options;
		?>
		</select>
<br/>
Actor : <select name="aid">
			<?
				$sql = "SELECT id,first,last FROM Actor;";
				$actors = query($con,$sql);
				$options = "";
				while($row = mysql_fetch_array($actors)){
				$options .= "<option value=\"".$row['id']."\">"
							.$row['last'].", ".$row['first']
							."</option>";
				}
				echo $options;
			?>
			</select>
<br/>
Role: <input type="text" name="role" maxlength="50">
<br/>
<input type="submit" value="Add it!!"/>
</form>
<hr/>

<?
	if($mid){
		echo "Add was successful!<br/>";
		echo "<a href = './movie.php?mid=".$mid
				."'>See Movie Info</a>";
		echo "<hr/>";
	}
?>
	</div>
  </div>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
