<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();
	
	$mid = NULL;
	$name = NULL;
	$rating = NULL;
	$comment = NULL;
	
	if(isset($_GET['mid']) && isset($_GET['name']) 
			&& isset($_GET['rating']) && isset($_GET['comment']) ){
		$mid = mysql_real_escape_string($_GET['mid'],$con);
		$name = mysql_real_escape_string(trim($_GET['name']),$con);
		$rating = mysql_real_escape_string($_GET['rating'],$con);
		$comment = mysql_real_escape_string(trim($_GET['comment']),$con);
		
		$sql = "INSERT INTO Review VALUES ('"
				.$name."',CURRENT_TIMESTAMP(),".$mid
				.",".$rating.",'".$comment."');";
		$result = query($con,$sql);	
		if(!result)
			echo "There has been an error with the database";
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>IMDB by Sona Chaudhuri</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h3>Add new comment:</h3>

<form action="./add_comment.php" method="GET">			
Movie:	<select name="mid">
		<?
			$sql = "SELECT id,title FROM Movie ORDER BY title ASC;";
			$movies = query($con,$sql);
			$options = "";
			while($row = mysql_fetch_array($movies)){
			$options .= "<option value=\"".$row['id']."\">"
						.$row['title']
						."</option>";
			}
			echo $options;
		?>
		</select>

<br/>
Your Name:	<input type="text" name="name" value="Mr. Anonymous" maxlength="20"><br/>
Rating:	<select name="rating">
			<option value="5"> 5 - Excellent </option>
			<option value="4"> 4 - Good </option>
			<option value="3"> 3 - It's ok~ </option>
			<option value="2"> 2 - Not worth </option>
			<option value="1"> 1 - I hate it </option>
		</select>
<br/>
Comments: <br/>
<textarea name="comment" cols="80" rows="10"></textarea>
<br/>
<input type="submit" value="Rate it!!"/>
</form>
<hr/>

<?
	if($mid){
		echo "Thanks for your comment! It helps to accurately determine the reviews for our movies.<br/>";
		echo "<a href = './movie.php?mid=".$mid
				."'>See Movie Info (including others' reviews)</a>";
		echo "<hr/>";
	}
?>	
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
