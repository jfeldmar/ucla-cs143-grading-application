<html>
<?php
	require('./database.php');
	require('./utils.php');
?>
<head>
<title>IMDB by Sona Chaudhuri</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title">Search for your favorite Movie or Actor: </h1>
			<div class="entry">
				<form action="./search.php" method="GET">		
		Search: <input type="text" name="keyword"></input>
		<br/>
		<input type="submit" value="Search"/>
	</form>
				<?
	if(isset($_GET['keyword'])){
		echo "<h3>Search results for ".$_GET['keyword']."</h3>";
		
		$con = openConnection();
		$clean_keyword = mysql_real_escape_string(trim($_GET['keyword']),$con);
		
		$sql = "SELECT id,last,first,dob FROM Actor "
				."WHERE first LIKE '%".$clean_keyword."%' "
				."OR last LIKE '%".$clean_keyword."%';";
		//echo $sql;
		$results = query($con,$sql);
		
		echo "<h4>Results from Actors ...</h4><br/>";
		while($row = mysql_fetch_array($results)){
			echo "<a href=\"./actor.php?aid=".$row['id']."\">"
				.$row['first']." ".$row['last']."</a>"
				." ... (".formatDate($row['dob']).")";
			echo "<br/>";
		}
		
		$sql = "SELECT id,title,company,year FROM Movie "
				."WHERE title LIKE '%".$clean_keyword."%' "
				."OR company LIKE '%".$clean_keyword."%';";
		//echo $sql;
		$results = query($con,$sql);
		
		echo "<h4>Results from Movies ...</h4><br/>";
		while($row = mysql_fetch_array($results)){
			echo "<a href=\"./movie.php?mid=".$row['id']."\">"
				.$row['title']."</a>"
				." ... (".$row['year']." by ".$row['company'].")";
			echo "<br/>";
		}
	}		
?>
			</div>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
