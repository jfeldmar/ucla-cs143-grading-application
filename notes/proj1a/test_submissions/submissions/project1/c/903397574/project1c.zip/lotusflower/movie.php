<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();
	$clean_id = mysql_real_escape_string(trim($_GET['mid']),$con);
	
	$movie_info = NULL;
	if(isset($_GET['mid'])){
		$sql = "SELECT * FROM Movie WHERE id = '"
				   .$clean_id."';";
		$movie_info = mysql_fetch_array(query($con,$sql));
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Movie Lookup</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title">Movie Information</h1>
			<div class="entry">
			<? if(isset($_GET['mid'])){ ?>
				<h1><? echo $movie_info['title']." (".$movie_info['year'].")"; ?></h1>
				<h2>Overview</h2>
					<!--User Rating: <br/> -->
					MPAA: <? echo $movie_info['rating']; ?><br/>
					Company: <? echo $movie_info['company']; ?><br/>
				<h2>Cast</h2>
				<?
					$sql = "SELECT aid,first,last,role FROM MovieActor "
						   ."INNER JOIN Actor "
						   ."ON MovieActor.aid = Actor.id "
						   ."WHERE mid='".$clean_id."';";
					$result = query($con,$sql);
					while($row = mysql_fetch_array($result)){
						echo "<a href=\"./actor.php?aid=".$row['aid']."\">"
							.$row['first']." ".$row['last']."</a>"
							." ... ".$row['role'];
						echo "<br/>";
					}
					//echo $sql;
				?>
				<h2>User Comments</h2>
				<a href="./add_comment.php">(Comment on this title)</a>
				<?
					$sql = "SELECT AVG(rating),COUNT(name) FROM Review "
							."WHERE mid = ".$clean_id.";";
					$temp = mysql_fetch_array(query($con,$sql));
					$avg = $temp['AVG(rating)'];
					$count = $temp['COUNT(name)'];
					
					echo "<br/>";
					echo "Average Rating: ".($avg?$avg."/5 (5.0 being best)":"unestablished")." by "
							.$count." reviews.";
					echo "<br/><br/>";
					
					$sql = "SELECT name,time,rating,comment FROM Review "
						   ."WHERE mid='".$clean_id."';";
					$result = query($con,$sql);
					while($row = mysql_fetch_array($result)){
						echo "By ".$row['name']." , "
								.formatDate($row['time']);
						echo "<br/>";		
						echo "Rating ".$row['rating']."/5";
						echo "<br/>";
						echo $row['comment'];
						echo "<br/>";
						echo "<br/>";
					}
					//echo $sql;
					} 
					else {
				?>

				<form action="./movie.php" method="GET">	
				Movie:	<select name="mid">
					<?
						$sql = "SELECT id,title FROM Movie ORDER BY title ASC;";
						$movies = query($con,$sql);
						$options = "";
						while($row = mysql_fetch_array($movies)){
						$options .= "<option value=\"".$row['id']."\">"
									.$row['title']
									."</option>";
						}
						echo $options;
					?>	
						</select>
				<br/>
				<input type="submit" value="View Movie"/>
				</form>
			<? } ?>
			</div>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
