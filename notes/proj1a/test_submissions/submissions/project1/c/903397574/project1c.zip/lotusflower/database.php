<?php

function openConnection(){
	$con = mysql_connect("localhost","cs143","");
	if(!$con){
		die('Could not connect: ' .mysql_error());
	}
	return $con;
}

function query($con,$sql){
	mysql_select_db("CS143",$con);
	$result = mysql_query($sql); 
	if(!$result){
		echo mysql_error();
	}
	
	return $result;
}
	
?>