<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();

		
	$genre = array("Action",
					"Adult",
					"Adventure",
					"Animation",
					"Comedy",
					"Crime",
					"Documentary",
					"Drama",
					"Family",
					"Fantasy",
					"Horror",
					"Musical",
					"Mystery",
					"Romance",
					"Sci-Fi",
					"Short",
					"Thriller",
					"War",
					"Western");
	
	$title = NULL;
	$company = NULL;
	$year = NULL;
	$did = NULL;
	$mpaarating = NULL;
	$mid = NULL;
	$genre_string = "";
	
	if(isset($_GET['title']) && isset($_GET['company']) 
			&& isset($_GET['year']) && isset($_GET['did'])
			&& isset($_GET['mpaarating'])){
		$title = mysql_real_escape_string($_GET['title'],$con);
		$company = mysql_real_escape_string(trim($_GET['company']),$con);
		$year = mysql_real_escape_string($_GET['year'],$con);
		$did = mysql_real_escape_string(trim($_GET['did']),$con);
		$mpaarating = mysql_real_escape_string(trim($_GET['mpaarating']),$con);
		
		foreach($genre as $x){
			if(isset($_GET['genre_'.$x])){
				$genre_string .= "".($genre_string == "" ? "" : ",").$x;
			}
		}
		
		$sql = "SELECT id FROM MaxMovieID LIMIT 1;";
		$temp = mysql_fetch_array(query($con,$sql));
		$max = $temp['id'] + 1;
		$mid = $max;
		//echo $max."<br/>";
		
		$sql = "UPDATE MaxMovieID SET "
				."MaxMovieID.id = ".$max." "
				."WHERE MaxMovieID.id = ".($max -1).";";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO Movie VALUES "
				."(".$max.",'".$title."',".$year
				.",'".$mpaarating."','".$company."');";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO MovieGenre VALUES "
				."(".$max.",'".$genre_string."');";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO MovieDirector VALUES "
				."(".$max.",".$did.");";
		$result = query($con,$sql);
		// echo $sql."<br/>";
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>IMDB by Sona Chaudhuri</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h3>Add new movie:</h3>

<form action="./add_movie.php" method="GET">			
Title : <input type="text" name="title" maxlength="20"><br/>
Company: <input type="text" name="company" maxlength="50"><br/>
Year : <input type="text" name="year" maxlength="4"><br/>	<!-- Todo: validation-->	
Director : <select name="did">
			<?
				$sql = "SELECT id,first,last FROM Director ORDER BY last ASC;";
				$directors = query($con,$sql);
				$options = "";
				while($row = mysql_fetch_array($directors)){
				$options .= "<option value=\"".$row['id']."\">"
							.$row['last'].", ".$row['first']
							."</option>";
				}
				echo $options;
			?>
			</select>

<br/>		
MPAA Rating : <select name="mpaarating">
				<option value="G">G</option>
				<option value="NC-17">NC-17</option>
				<option value="PG">PG</option>
				<option value="PG-13">PG-13</option>
				<option value="R">R</option>
			</select>

<br/>
Genre : 
<br/>
<?
	$count = 0;
	foreach($genre as $x){
		echo "<input type=\"checkbox\" name=\"genre_"
				.$x."\" value=\"".$x."\"> ".$x." ... </input>";
		$count++;
		if($count % 5 == 0)
			echo "<br/>";
	}
?>
					
<br/>
			
<input type="submit" value="Add it!!"/>
</form>
<hr/>

<?
	if($mid){
		echo "Add was successful!<br/>";
		echo "<a href = './movie.php?mid=".$mid
				."'>See Movie Info</a>";
		echo "<hr/>";
	}
?>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
