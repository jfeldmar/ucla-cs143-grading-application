<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();
	$clean_id = mysql_real_escape_string(trim($_GET['aid']),$con);
	
	
	$actor_info = NULL;
	if(isset($_GET['aid'])){
		$sql = "SELECT * FROM Actor WHERE id = '"
				   .$clean_id."';";
		$actor_info = mysql_fetch_array(query($con,$sql));
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Movie Lookup</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h1 class="title">Actor Information </h1>
			<div class="entry">
			<? if(isset($_GET['aid'])){ ?>
    <h1><? echo $actor_info['first']." ".$actor_info['last']; ?></h1>

<h2>Overview</h2>
Date of Birth: <? echo formatDate($actor_info['dob']); ?><br/>
<? 
if($actor_info['dod']){
	echo "Date of Death: ".formatDate($actor_info['dod'])."<br/>";
}
?>

Sex: <? echo $actor_info['sex']; ?><br/>

<h2>Filmography</h2>
<?
	$sql = "SELECT mid,title,year,role FROM MovieActor "
		   ."INNER JOIN Movie "
		   ."ON MovieActor.mid = Movie.id "
		   ."WHERE aid='".$clean_id."';";
	$result = query($con,$sql);
	while($row = mysql_fetch_array($result)){
		echo "<a href=\"./movie.php?mid=".$row['mid']."\">"
			.$row['title']."</a>"
			." (".$row['year'].")"
			." ... ".$row['role'];
		echo "<br/>";
	}
	//echo $sql;
?>  

<? 
	} 
	else {
?>

<form action="./actor.php" method="GET">	
Actor : <select name="aid">
			<?
				$sql = "SELECT id,first,last FROM Actor ORDER BY last ASC;";
				$actors = query($con,$sql);
				$options = "";
				while($row = mysql_fetch_array($actors)){
				$options .= "<option value=\"".$row['id']."\">"
							.$row['last'].", ".$row['first']
							."</option>";
				}
				echo $options;
			?>
			</select>
<br/>
<input type="submit" value="View Actor"/>
</form>
<? } ?>
	</div>
	</div>
	</div>
	
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
