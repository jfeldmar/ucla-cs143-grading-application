<html>
<?php
	require('./database.php');
	require('./utils.php');
	
	$con = openConnection();

	$identity = NULL;
	$first = NULL;
	$last = NULL;
	$sex = NULL;
	$dob = NULL;
	$dod = NULL;
	$id = NULL;
	
	if(isset($_GET['identity']) && isset($_GET['first']) && isset($_GET['last'])
		&& isset($_GET['sex']) && isset($_GET['dob'])){
		$identity = mysql_real_escape_string(trim($_GET['identity']),$con);
		$first = mysql_real_escape_string(trim($_GET['first']),$con);
		$last = mysql_real_escape_string(trim($_GET['last']),$con);
		$sex = mysql_real_escape_string(trim($_GET['sex']),$con);
		$dob = mysql_real_escape_string(trim($_GET['dob']),$con);
		
		if(isset($_GET['dod']))
			$dod = mysql_real_escape_string(trim($_GET['dod']),$con);
		
		$sql = "SELECT id FROM MaxPersonID LIMIT 1;";
		$temp = mysql_fetch_array(query($con,$sql));
		$max = $temp['id'] + 1;
		$id = $max;
		//echo $max."<br/>";
		
		$sql = "UPDATE MaxPersonID SET "
				."MaxPersonID.id = ".$max." "
				."WHERE MaxPersonID.id = ".($max -1).";";
		$result = query($con,$sql);
		// echo $sql."<br/>";
		
		$sql = "INSERT INTO ".$identity." VALUES "
				."(".$id.",'".$last."','".$first."',"
				.($identity == 'Actor'? "'".$sex."'," : "")
				."'".$dob."',".($dod != "" ? "'".$dod."'" : "NULL").");";
		//echo $sql."<br/>";
		$result = query($con,$sql);
	}
?>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>IMDB by Sona Chaudhuri</title>
<link href="default.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="logo-wrap">
<div id="logo">
	<h1><a href="#">Internet Movie DataBase </a></h1>
	<!---<h2> Design by Sona</h2>--->
</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<h3>Add new actor/director:</h3>
<form action="./add_acdir.php" method="GET">
Identity:	<input type="radio" name="identity" value="Actor" checked="true">Actor
			<input type="radio" name="identity" value="Director">Director<br/>
<hr/>
First Name:	<input type="text" name="first" maxlength="20"><br/>
Last Name:	<input type="text" name="last" maxlength="20"><br/>
Sex:		<input type="radio" name="sex" value="Male" checked="true">Male
			<input type="radio" name="sex" value="Female">Female<br/>
						
Date of Birth:	<input type="text" name="dob"> (yyyy-dd-mm)<br/>
Date of Death:	<input type="text" name="dod"> (leave blank if alive now)<br/>
<input type="submit" value="add it!!"/>
</form>
<hr/>
<?
	if($id){
		echo "Add was successful!<br/>";
		if($identity == 'Actor')
			echo "<a href = './actor.php?aid=".$id
					."'>See Actor Info</a>";
		echo "<hr/>";
	}
?>
		</div>
	</div>
	<!-- end content -->
	<!-- start sidebar -->
	<div id="sidebar">
		<ul>
			<li id="search">
				<h2>Search</h2>
				<ul>
				<li><a href="./search.php">Search</a></li>
				</ul>
			</li>
			<li>
				<h2>Browse Content</h2>
				<ul>
					<li><a href="./movie.php">View Movie</a></li>
					<li><a href="./actor.php">View Actors</a></li>
				</ul>
			</li>
			<li>
				<h2>Add Content</h2>
				<ul>
					<li><a href="./add_acdir.php">Add an Actor or Director</a></li>
					<li><a href="./add_comment.php">Add a Comment</a></li>
					<li><a href="./add_movie.php">Add a Movie</a></li>
					<li><a href="./add_role.php">Add Roles to a Movie</a></li>
				</ul>
			</li>
		</ul>
	</div>
	<!-- end sidebar -->
	<div style="clear: both;">&nbsp;</div>
</div>
<!-- end page -->
<!-- start footer -->
<div id="footer">
	<div id="footer-wrap">
	<p id="legal">(c) 2008 Sona Chaudhuri</p>
	</div>
</div>
<!-- end footer -->
</body>
</html>
